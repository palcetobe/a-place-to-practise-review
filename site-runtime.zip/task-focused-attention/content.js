window.TaskFocusedAttentionContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/attention-training",
  "resourceId": "tool/task-focused-attention",
  "routeProposal": "/task-focused-attention/",
  "title": "Task-Focused Attention Training",
  "version": "2026-11-05-public-review-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. No recordings are provided for this practice; scripts are prepared and listening approval is not asserted.",
  "scope": "Therapist-introduced CBT practice for socially anxious self-monitoring or threat scanning: learn flexible attention in an ordinary task, then use it to follow and contribute to a suitable interaction, reviewing actual attention and participation without suppression, reassurance seeking or performance scoring.",
  "groupedSetStatus": "One existing canonical entry, classic/attention-training. Complete bounded ordinary-task training and social-application cycle, not complete social-anxiety CBT, formal auditory ATT, ACT/DBT mindfulness, pre/post-event processing or appearance/mirror/checking procedures. Existing attention resources retain their own identities. No new canonical count.",
  "implementedSubset": "ordinary-task-training-and-social-application",
  "relatedComponentsComplete": false,
  "clinicalContract": {
    "learningObjective": "Distinguish useful task attention from monitoring how one appears, scanning others for judgment, suppressing anxiety or escaping an interaction into an unrelated sensory focus. Transfer a noticing-and-return skill from a safe ordinary activity to relevant conversational content and one’s own message.",
    "practiceObjective": "Review the self-focused/threat-focused pattern with the therapist, choose and actually practise an accessible ordinary task, review learning, agree a suitable interaction, identify task-relevant information, notice and flexibly return while engaging, then review actual content, participation, anxiety and fit over further agreed opportunities.",
    "sourcePopulationContext": "CCI Stepping Out of Social Anxiety Module6 (2020) is the directly read procedural source. This is a therapist-introduced bounded CBT adaptation, not diagnosis or a full treatment. No age floor or all-age efficacy claim; developmental, communication, cultural, safeguarding, access and individual clinical fit require review. NICE is a catalogue reference; current recommendations were not retrieved because the exact URL returned403.",
    "exclusions": [
      "No universal treatment for attention difficulties, diagnosis, demand for normal-looking behavior, eye contact or masking disability",
      "No formal metacognitive auditory Attention Training Technique, invented sound sequence or claim of equivalence to ACT/DBT mindfulness",
      "No exposure ladder, dropping clinician-agreed supports, deliberately increasing distress, video/audio recording or social contact initiated by the tool",
      "No pre/post-event processing protocol, replaying conversations, mirror/appearance checking or medical/interoceptive exercise",
      "No attention diversion away from genuine danger, access needs, urgent symptoms, driving or other safety-critical tasks",
      "No requirement to suppress thoughts/anxiety, collect reassurance, prove social approval or count perfect concentration"
    ],
    "adaptations": [
      "Original explanation, optional record and fictional example; not copied source worksheet or script",
      "Accessible safe ordinary-task training keeps the source notice-and-return function; breath, body attention, eating and safety-critical examples are not required",
      "Social application uses the actual communication task, including accessible speech/signing/AAC where clinically appropriate; no required gaze or sense",
      "Source regular practice is individualized with the therapist; no automatic daily schedule, required duration, 0–10 concentration score or performance rating",
      "Review uses a brief relevant-content observation, actual participation and anxiety/fit without detailed recall tests, reassurance or repeated replay",
      "The native Return Your Attention body and its classic/present counterpart preserve the same tool/return-your-attention identity; this candidate adds the specific CBT social-attention formulation and transfer without replacing it"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of bounded CBT formulation, ordinary-task/social transfer, source adaptations and release rights",
      "Individual consent, prior teaching, developmental/communication/cultural/safeguarding/access and clinical fit; identify genuine safety needs and useful supports",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration production and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose planning or review",
      "options": [
        {
          "value": "prepare",
          "label": "Plan a practice",
          "startSectionId": "task-focused-attention.practice.situation"
        },
        {
          "value": "review",
          "label": "Review what happened",
          "startSectionId": "task-focused-attention.practice.result"
        }
      ]
    },
    "entryGate": "Purpose, fit, safety and non-suppression boundaries visible before entry. No default mode, clinical indication or completed training inferred.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing, sequence, attempt or result.",
    "reviewAccess": "Direct blank review identifies the ordinary-task or social practice actually being reviewed. No saved plan, training, interaction, attention change or benefit inferred.",
    "writing": "Optional and hidden initially; hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help for preparation or review only, never private notes or a competing track during the real interaction. No audio, TTS, recording or autoplay.",
    "timer": "None. No fixed duration, concentration score, frequency quota, streak or performance target.",
    "completion": "No inferred training, social interaction, successful attention return, improved performance/anxiety or completion of related methods."
  },
  "intro": {
    "id": "task-focused-attention.intro",
    "title": "Put attention on what you are taking part in",
    "paragraphs": [
      "In a social moment, attention can get caught in checking how you look or sound, planning every word, or watching for signs of judgment. That can leave less room to follow what is actually being said or done.",
      "This practice helps you notice that pull and return to the task you chose. First you practise with an ordinary activity. Then, with your therapist, you use the skill in a suitable interaction. The aim is taking part, not making anxiety vanish.",
      "Use this after your therapist has explained why it may fit your situation. You can prepare, use the made-up example, review an earlier practice or finish. It is not a test of whether you can concentrate perfectly."
    ]
  },
  "fit": {
    "id": "task-focused-attention.fit",
    "title": "Keep the task, choice and safety in view",
    "paragraphs": [
      "This is for a pattern you and your therapist have discussed, not every attention difficulty. Check health, communication, learning and access needs, including which senses work for you. Not every distraction is due to anxiety.",
      "Choose a safe ordinary activity and, later, an interaction you freely agree is suitable. Do not practise while driving, using dangerous equipment or doing work where your attention is needed to keep people safe. This is not a way to ignore real threats, mistreatment, urgent symptoms or a need for help.",
      "Keep communication aids, helpful notes and agreed supports. You do not have to make eye contact, act in a way others call normal, hide discomfort or use a particular sense. A therapist can help adapt the task for your age, understanding, culture and access. You can think, speak, sign, use an aid or explore the example without writing.",
      "Anxiety or a thought can remain while you take part. Do not use the task as a trick to force them away or make yourself safe by checking perfectly. If the practice becomes pressure, checking or avoidance, pause and discuss the fit. You can stop; this is not an instruction to push through distress."
    ]
  },
  "privacy": {
    "id": "task-focused-attention.privacy",
    "title": "Notes are optional and stay in this page",
    "paragraphs": [
      "Use a few words if helpful, without names or private details about another person. This tool does not contact anyone, watch an interaction, record voice or send your therapist a report.",
      "Writing stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.",
      "Hiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox."
    ]
  },
  "close": {
    "id": "task-focused-attention.close",
    "title": "Finish without a perfect-focus result",
    "paragraphs": [
      "You can finish after reading, planning, trying or reviewing. Noticing one return may be useful, but you do not need a return, a finished conversation or lower anxiety to leave.",
      "Take one observation or question to your therapist if helpful. No reminder or new task is created. Leaving clears notes from this tool, not outside copies."
    ]
  },
  "example": {
    "id": "task-focused-attention.example",
    "title": "A made-up practice: following a shared project",
    "paragraphs": [
      "Dev notices that during craft-group conversations, attention often goes to “Did I sound strange?” Dev misses parts of the plan while rehearsing a reply. A therapist helps Dev separate that pattern from genuine needs, including having written instructions available.",
      "For ordinary-task practice, Dev sorts a few safe paper pieces. Attention rests on their shapes and where each piece belongs. A worry appears. Dev notices getting caught in it and returns to sorting, without trying to erase the worry. The review finds that returning was possible, though attention still wandered.",
      "Later, Dev chooses a suitable short discussion about a shared collage. The useful task is to understand which colors the group plans to use and share one idea if Dev wants. Dev keeps the written plan and does not set an eye-contact goal.",
      "During the real discussion, Dev starts monitoring how their voice sounds. Dev notices this and returns to the color choice being discussed, then to the meaning of their own suggestion while speaking. Dev asks for one detail to be repeated because it was missed, not to ask again whether Dev seemed strange.",
      "Afterward, Dev recalls that the group chose blue for one part and that the suggestion was shared. Anxiety stayed much the same. That gives some information about participation, not proof of approval or perfect attention. Dev plans to review the fit with the therapist rather than replay the whole conversation."
    ]
  },
  "learn": {
    "id": "task-focused-attention.learn",
    "title": "Task focus is not just looking outside yourself",
    "paragraphs": [
      "Self-focused attention can mean monitoring signs of anxiety, imagining how you appear or checking each word. Looking outward can also keep the same loop going if you search faces or the room for proof that people judge you.",
      "Task-focused attention follows what you are actually doing together. In conversation, that means taking in the other person’s meaning, then attending to the message you want to share when it is your turn. It can include a useful question, a pause or a request for accessible information.",
      "The ordinary-task stage practises noticing where attention goes and choosing a return. In a conversation, return to the conversation itself, not to an unrelated sound, object or body sensation to escape the moment. Thoughts and feelings do not have to disappear first.",
      "The familiar notice-and-return skill also appears in mindfulness. This CBT practice has a specific purpose: working with the socially anxious checking pattern and transferring attention to participation. A different method called Attention Training Technique uses set sound exercises. This page does not teach that method, provide a full treatment or prove that others approve of you.",
      "Useful attention is flexible. A real problem, a changed task or a need for support may deserve attention. No one keeps a perfect focus all the time, and not every unclear social cue needs an answer."
    ]
  },
  "practice": [
    {
      "id": "task-focused-attention.practice.situation",
      "title": "Choose the practice that fits now",
      "paragraphs": [
        "With your therapist, name the social situation and attention pattern this skill is meant to help. What would you like to take part in more fully? Choose your own aim, not a demand to seem calm or normal.",
        "Begin with ordinary-task training if this is new. If you have already practised it and agreed the next step with your therapist, you can move to the social-use prompts. You can also go straight to review or use Dev’s example."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The situation and what I want to take part in",
          "optional": true
        },
        {
          "key": "stage-choice",
          "label": "A task, an agreed conversation, review or example",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am unsure why I am using this",
        "text": "Ask your therapist about the pattern and fit. General concentration problems may need a different kind of help."
      }
    },
    {
      "id": "task-focused-attention.practice.notice",
      "title": "Notice where attention gets pulled",
      "paragraphs": [
        "Think of one manageable social moment, without replaying it in detail. Did attention go to checking yourself, rehearsing words, looking for judgment, the shared task, or somewhere else? You can be unsure.",
        "Did any part become harder to follow? It is okay if not, or if you are unsure. Briefly name the pattern. Do not scan your body now, search your memory for mistakes or decide that another person’s expression proves what they thought."
      ],
      "fields": [
        {
          "key": "attention-pattern",
          "label": "Where attention seemed to go, if known",
          "optional": true
        },
        {
          "key": "task-cost",
          "label": "Anything harder to follow or do, or no change",
          "optional": true
        }
      ],
      "help": {
        "title": "If there was a real threat",
        "text": "Safety and support come first. This practice is not meant to dismiss danger, discrimination or mistreatment."
      }
    },
    {
      "id": "task-focused-attention.practice.task",
      "title": "Choose a safe ordinary activity",
      "paragraphs": [
        "Choose a simple activity you can do comfortably, such as arranging a few safe objects. Pick something that gives you real details to attend to while doing it, rather than a test of concentration.",
        "Which details help you carry out that task? Use an available sense or accessible information. You do not need every sense, breath focus or body attention. Agree a small opportunity that fits; the page sets no timer."
      ],
      "fields": [
        {
          "key": "ordinary-task",
          "label": "The safe activity I can actually practise",
          "optional": true
        },
        {
          "key": "task-details",
          "label": "Accessible details that help me do this task",
          "optional": true
        }
      ],
      "help": {
        "title": "If the activity does not fit my access needs",
        "text": "Change the activity or ask for an adaptation. Missing sensory information or needed support is not failed attention."
      }
    },
    {
      "id": "task-focused-attention.practice.train",
      "title": "Do the activity and practise returning",
      "paragraphs": [
        "When it fits, actually do the activity. Attend to the details that help you do it. If you notice getting caught in a worry, self-check or something unrelated, briefly recognize that and return to the task.",
        "You can let a thought or feeling stay without solving it. Return again if useful; do not count every wander, demand perfect focus or create distractions on purpose. Stop or change the task if it no longer fits."
      ],
      "fields": [
        {
          "key": "ordinary-attempt",
          "label": "What I actually tried, stopped or did not try",
          "optional": true
        },
        {
          "key": "ordinary-return",
          "label": "Any task detail or return I noticed",
          "optional": true
        }
      ],
      "help": {
        "title": "If attention did not wander",
        "text": "Continue the activity or finish. There is no need to make a thought appear to complete a step."
      }
    },
    {
      "id": "task-focused-attention.practice.warmreview",
      "title": "Review the ordinary-task practice",
      "paragraphs": [
        "Was the task accessible? What happened when attention moved, and how was returning? It may have been easy, hard, mixed or unclear. Reading the prompts alone is not the same as trying the activity.",
        "Discuss whether more ordinary practice, a different task or social use fits next. Regular practice is part of learning this skill. Agree with your therapist how to fit it into your life. This page does not create a daily requirement."
      ],
      "fields": [
        {
          "key": "training-learning",
          "label": "What the real task practice showed",
          "optional": true
        },
        {
          "key": "training-next",
          "label": "More practice, an adaptation, social use or a pause",
          "optional": true
        }
      ],
      "help": {
        "title": "If I used the activity to block feelings",
        "text": "That is useful to notice. Discuss how to return while allowing thoughts and feelings, rather than trying harder to remove them."
      }
    },
    {
      "id": "task-focused-attention.practice.social",
      "title": "Choose an agreed social opportunity",
      "paragraphs": [
        "After ordinary-task practice and therapist discussion, choose a safe, manageable interaction that fits your goal. It need not be difficult, long or with someone new. This page does not ask you to face a fear as a test or contact anyone for you.",
        "What is the shared task? It could be understanding an idea, making a simple plan or sharing something relevant. In your form of communication, what information helps you follow and take part?"
      ],
      "fields": [
        {
          "key": "social-opportunity",
          "label": "The suitable interaction I have agreed to try",
          "optional": true
        },
        {
          "key": "social-task",
          "label": "The shared task and relevant information",
          "optional": true
        }
      ],
      "help": {
        "title": "If no suitable interaction is available",
        "text": "Stay with ordinary practice, use the example or finish. You do not need to arrange extra social contact for the page."
      }
    },
    {
      "id": "task-focused-attention.practice.prepare",
      "title": "Make a simple attention plan",
      "paragraphs": [
        "Choose one useful cue, such as the topic or the meaning of the next message. When the other person communicates, attend to what they mean. When you communicate, attend to what you want to say, not a running judgment of how you seem.",
        "Keep needed aids and agreed supports. Do not plan to stare, scan faces for approval or focus on an unrelated object to escape anxiety. Decide what would mean pause or ask for help, and when you may review."
      ],
      "fields": [
        {
          "key": "social-cue",
          "label": "A relevant topic or meaning to return to",
          "optional": true
        },
        {
          "key": "social-support",
          "label": "Aids or support I need, and reasons to pause",
          "optional": true
        },
        {
          "key": "plan-review",
          "label": "A suitable point to review with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am trying to prevent all anxiety",
        "text": "The aim is engagement, not a guarantee of calm or safety. Check the plan with your therapist before using it as another rule to get right."
      }
    },
    {
      "id": "task-focused-attention.practice.apply",
      "title": "Use the skill in the real interaction",
      "paragraphs": [
        "Prepare with this step before the interaction. Put the page aside while you take part. At the agreed opportunity, when you notice self-checking or scanning for judgment, gently return to the topic, the other person’s meaning or the message you are sharing.",
        "A thought, feeling or stumble can remain. If you missed information, you may ask for it again in a way that fits. You do not need to monitor every moment, record the interaction, seek approval or replay it while it is still happening."
      ],
      "fields": [
        {
          "key": "actual-try",
          "label": "What I actually tried, stopped or did not try",
          "optional": true
        },
        {
          "key": "try-context",
          "label": "Any support, interruption or change that mattered",
          "optional": true
        }
      ],
      "help": {
        "title": "If I get caught in checking again",
        "text": "Notice it when you can and choose a useful return. You can pause or leave; this is not an endurance or performance test."
      }
    },
    {
      "id": "task-focused-attention.practice.result",
      "title": "Review what actually happened",
      "paragraphs": [
        "Are you reviewing an ordinary activity or a social interaction? Briefly name what you actually tried, including a partial attempt or no attempt. You can start here without a saved plan.",
        "What relevant detail, meaning or action do you remember? Was there a moment of noticing and returning? Leave unknown parts unknown. One brief observation is enough; do not replay the event to get a perfect account or prove you seemed acceptable."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "The practice and what actually happened",
          "optional": true
        },
        {
          "key": "observations",
          "label": "A relevant detail, action or attention return",
          "optional": true
        },
        {
          "key": "experience",
          "label": "What was difficult, helpful or unclear",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot recall a detail",
        "text": "That alone does not prove the practice failed. Memory, access and circumstances vary. Keep uncertainty rather than turn review into another test."
      }
    },
    {
      "id": "task-focused-attention.practice.compare",
      "title": "Look at participation and the pattern over time",
      "paragraphs": [
        "Did attention to the task help you follow or contribute, stay about the same, get harder or remain unclear? What happened with anxiety, if you noticed? Anxiety can rise, fall or stay; lower anxiety is not the only useful result.",
        "Across further agreed opportunities, what do you notice about self-checking, returning and taking part? Compare only real experiences and allow for different people, tasks, access and support. Do not use approval, a score or constant self-monitoring as proof.",
        "Check whether you used task focus to avoid taking part, push feelings away, ask again and again if things were okay, or follow a new strict rule. A brief review with your therapist can help. This page does not prove a cause or judge your social performance."
      ],
      "fields": [
        {
          "key": "participation",
          "label": "What I could follow or contribute, and any anxiety change",
          "optional": true
        },
        {
          "key": "later-pattern",
          "label": "What I notice across real practices, or not yet known",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "A question about fit, checking or uncertainty",
          "optional": true
        }
      ],
      "help": {
        "title": "If I have only tried once",
        "text": "Keep the result small. You can discuss another suitable opportunity, but there is no need to invent a trend or make a harder plan."
      }
    },
    {
      "id": "task-focused-attention.practice.next",
      "title": "Choose what to keep, change or leave",
      "paragraphs": [
        "With your therapist, you might keep the same practice, return to an ordinary task, change the cue or support, or pause. Do not automatically make the interaction harder or remove useful aids.",
        "Take one observation forward if helpful. You can finish with no new plan. This visit does not complete a full course of treatment. Other work, such as repeated worries before or after an event or checks of how you look, needs a separate plan."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What I want to keep, change, pause or leave here",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Support or a question for the next session",
          "optional": true
        }
      ],
      "help": {
        "title": "If practice feels like another way to judge myself",
        "text": "Pause and bring that pattern to your therapist. You do not have to earn support by using this skill well."
      }
    }
  ],
  "sources": [
    {
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Consumer-Modules/Stepping-out-of-Social-Anxiety/Stepping-out-of-Social-Anxiety---Module-6---The-Role-of-Attention.pdf",
      "supports": "Printed pp.2–7: self-focused and threat-scanning attention, relevant task focus, ordinary training, actual social transfer and review.",
      "limits": "Original bounded digital adaptation, not a copied worksheet, full treatment, fixed-dose programme or validated all-age intervention. Source regular practice is individualized; numerical ratings are optional and not implemented.",
      "label": "CCI: Stepping Out of Social Anxiety, Module6 (2020)"
    },
    {
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Meaningful participation, choice, refusal and access to communication and support.",
      "limits": "Rights guidance, not evidence of CBT efficacy or equivalence across communication adaptations.",
      "label": "ASHA/NJC: Communication Bill of Rights"
    },
    {
      "url": "https://www.cci.health.wa.gov.au/Home/Utilities/Copyright-and-Disclaimer",
      "supports": "Source materials are general information, with copyright and professional-care boundaries.",
      "limits": "Public availability does not grant general reproduction rights. Original expression and source links do not establish release clearance; no source worksheets or diagrams are copied.",
      "label": "CCI: Copyright and Disclaimer"
    },
    {
      "url": "https://www.nice.org.uk/Guidance/CG159/chapter/recommendations",
      "supports": "Existing catalogue cites this guideline as broader clinical context.",
      "limits": "Broader catalogue context only; detailed current recommendations were not verified for this adaptation. No age-specific equivalence or complete NICE protocol implementation is claimed.",
      "label": "NICE CG159: catalogue context only"
    }
  ],
  "narrationSegments": [
    {
      "id": "task-focused-attention.intro",
      "title": "Put attention on what you are taking part in",
      "text": "In a social moment, attention can get caught in checking how you look or sound, planning every word, or watching for signs of judgment. That can leave less room to follow what is actually being said or done.\n\nThis practice helps you notice that pull and return to the task you chose. First you practise with an ordinary activity. Then, with your therapist, you use the skill in a suitable interaction. The aim is taking part, not making anxiety vanish.\n\nUse this after your therapist has explained why it may fit your situation. You can prepare, use the made-up example, review an earlier practice or finish. It is not a test of whether you can concentrate perfectly.",
      "sha256": "06252020671447a32eba25a34acd5bab1c5fae2847db0e06ac487e3c2e03b90b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.fit",
      "title": "Keep the task, choice and safety in view",
      "text": "This is for a pattern you and your therapist have discussed, not every attention difficulty. Check health, communication, learning and access needs, including which senses work for you. Not every distraction is due to anxiety.\n\nChoose a safe ordinary activity and, later, an interaction you freely agree is suitable. Do not practise while driving, using dangerous equipment or doing work where your attention is needed to keep people safe. This is not a way to ignore real threats, mistreatment, urgent symptoms or a need for help.\n\nKeep communication aids, helpful notes and agreed supports. You do not have to make eye contact, act in a way others call normal, hide discomfort or use a particular sense. A therapist can help adapt the task for your age, understanding, culture and access. You can think, speak, sign, use an aid or explore the example without writing.\n\nAnxiety or a thought can remain while you take part. Do not use the task as a trick to force them away or make yourself safe by checking perfectly. If the practice becomes pressure, checking or avoidance, pause and discuss the fit. You can stop; this is not an instruction to push through distress.",
      "sha256": "5d6baf903b14de5ea0e9d843dd6beb43875c76d1bb67aad3bf760e377be75fdc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.privacy",
      "title": "Notes are optional and stay in this page",
      "text": "Use a few words if helpful, without names or private details about another person. This tool does not contact anyone, watch an interaction, record voice or send your therapist a report.\n\nWriting stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.\n\nHiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox.",
      "sha256": "8940fd2576a588f9f9e71001177324ce745dcd56973aaa654a78e8358a8a5e93",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.close",
      "title": "Finish without a perfect-focus result",
      "text": "You can finish after reading, planning, trying or reviewing. Noticing one return may be useful, but you do not need a return, a finished conversation or lower anxiety to leave.\n\nTake one observation or question to your therapist if helpful. No reminder or new task is created. Leaving clears notes from this tool, not outside copies.",
      "sha256": "969301e3b886c2f43aaec3d81ae5c89a6426d635fd4f4e21d2d2393a5bab9247",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.example",
      "title": "A made-up practice: following a shared project",
      "text": "Dev notices that during craft-group conversations, attention often goes to “Did I sound strange?” Dev misses parts of the plan while rehearsing a reply. A therapist helps Dev separate that pattern from genuine needs, including having written instructions available.\n\nFor ordinary-task practice, Dev sorts a few safe paper pieces. Attention rests on their shapes and where each piece belongs. A worry appears. Dev notices getting caught in it and returns to sorting, without trying to erase the worry. The review finds that returning was possible, though attention still wandered.\n\nLater, Dev chooses a suitable short discussion about a shared collage. The useful task is to understand which colors the group plans to use and share one idea if Dev wants. Dev keeps the written plan and does not set an eye-contact goal.\n\nDuring the real discussion, Dev starts monitoring how their voice sounds. Dev notices this and returns to the color choice being discussed, then to the meaning of their own suggestion while speaking. Dev asks for one detail to be repeated because it was missed, not to ask again whether Dev seemed strange.\n\nAfterward, Dev recalls that the group chose blue for one part and that the suggestion was shared. Anxiety stayed much the same. That gives some information about participation, not proof of approval or perfect attention. Dev plans to review the fit with the therapist rather than replay the whole conversation.",
      "sha256": "9d60f38d888d02d7f62c97079f3a9f4bcbaf6c6bedd9a5cd8d48d60d55d56932",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.learn",
      "title": "Task focus is not just looking outside yourself",
      "text": "Self-focused attention can mean monitoring signs of anxiety, imagining how you appear or checking each word. Looking outward can also keep the same loop going if you search faces or the room for proof that people judge you.\n\nTask-focused attention follows what you are actually doing together. In conversation, that means taking in the other person’s meaning, then attending to the message you want to share when it is your turn. It can include a useful question, a pause or a request for accessible information.\n\nThe ordinary-task stage practises noticing where attention goes and choosing a return. In a conversation, return to the conversation itself, not to an unrelated sound, object or body sensation to escape the moment. Thoughts and feelings do not have to disappear first.\n\nThe familiar notice-and-return skill also appears in mindfulness. This CBT practice has a specific purpose: working with the socially anxious checking pattern and transferring attention to participation. A different method called Attention Training Technique uses set sound exercises. This page does not teach that method, provide a full treatment or prove that others approve of you.\n\nUseful attention is flexible. A real problem, a changed task or a need for support may deserve attention. No one keeps a perfect focus all the time, and not every unclear social cue needs an answer.",
      "sha256": "4d2dd65e5d73c83d9bdca14f558fac7b3c143727ab3f571baaa85d8695999cf3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.situation",
      "title": "Choose the practice that fits now",
      "text": "With your therapist, name the social situation and attention pattern this skill is meant to help. What would you like to take part in more fully? Choose your own aim, not a demand to seem calm or normal.\n\nBegin with ordinary-task training if this is new. If you have already practised it and agreed the next step with your therapist, you can move to the social-use prompts. You can also go straight to review or use Dev’s example.",
      "sha256": "03b2e6a0eecd1271035a618b65ffb388d8ddf0911fd60fd158d93129dc505088",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.situation.help",
      "title": "If I am unsure why I am using this",
      "text": "Ask your therapist about the pattern and fit. General concentration problems may need a different kind of help.",
      "sha256": "bb56b7b01b46fadb0f09c15669ee29df516ab2abcaa14c82808e6f0f02b8f2aa",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.notice",
      "title": "Notice where attention gets pulled",
      "text": "Think of one manageable social moment, without replaying it in detail. Did attention go to checking yourself, rehearsing words, looking for judgment, the shared task, or somewhere else? You can be unsure.\n\nDid any part become harder to follow? It is okay if not, or if you are unsure. Briefly name the pattern. Do not scan your body now, search your memory for mistakes or decide that another person’s expression proves what they thought.",
      "sha256": "9cff525ae4ed5913b5563a5275c599f575014cc9d737bddba9f7e1cca4ebf4c2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.notice.help",
      "title": "If there was a real threat",
      "text": "Safety and support come first. This practice is not meant to dismiss danger, discrimination or mistreatment.",
      "sha256": "b78baf4e0e2c0a439710e97df3ec1c2e68de291021fef29c8ce7ce8f15029089",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.task",
      "title": "Choose a safe ordinary activity",
      "text": "Choose a simple activity you can do comfortably, such as arranging a few safe objects. Pick something that gives you real details to attend to while doing it, rather than a test of concentration.\n\nWhich details help you carry out that task? Use an available sense or accessible information. You do not need every sense, breath focus or body attention. Agree a small opportunity that fits; the page sets no timer.",
      "sha256": "2befebc08938a7a62b562d4cdd91ee945e69b7674043630a6738612c45130d53",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.task.help",
      "title": "If the activity does not fit my access needs",
      "text": "Change the activity or ask for an adaptation. Missing sensory information or needed support is not failed attention.",
      "sha256": "09a6023a4fcc912a0830ad8a628bd9cdacaa9321c7d766b7ef8d5c16293355b1",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.train",
      "title": "Do the activity and practise returning",
      "text": "When it fits, actually do the activity. Attend to the details that help you do it. If you notice getting caught in a worry, self-check or something unrelated, briefly recognize that and return to the task.\n\nYou can let a thought or feeling stay without solving it. Return again if useful; do not count every wander, demand perfect focus or create distractions on purpose. Stop or change the task if it no longer fits.",
      "sha256": "dc266642ec0d03538605e7bd87df8b01cd2927923dd6a06d08e0f38604c31cb1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.train.help",
      "title": "If attention did not wander",
      "text": "Continue the activity or finish. There is no need to make a thought appear to complete a step.",
      "sha256": "f286e39ea00ae0e9d1e332bf6c06f17a3375d8ebf7dcc28d9a2ec5cc0063e28f",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.warmreview",
      "title": "Review the ordinary-task practice",
      "text": "Was the task accessible? What happened when attention moved, and how was returning? It may have been easy, hard, mixed or unclear. Reading the prompts alone is not the same as trying the activity.\n\nDiscuss whether more ordinary practice, a different task or social use fits next. Regular practice is part of learning this skill. Agree with your therapist how to fit it into your life. This page does not create a daily requirement.",
      "sha256": "ce678c55eb2a455cd8ae1be60c2273fb16c1a7b18a95be8d7cc402878a9801ca",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.warmreview.help",
      "title": "If I used the activity to block feelings",
      "text": "That is useful to notice. Discuss how to return while allowing thoughts and feelings, rather than trying harder to remove them.",
      "sha256": "e965c023a09be0c4b6487b3298fef04d0e85ceff18a1197f1e456d51e518b37a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.social",
      "title": "Choose an agreed social opportunity",
      "text": "After ordinary-task practice and therapist discussion, choose a safe, manageable interaction that fits your goal. It need not be difficult, long or with someone new. This page does not ask you to face a fear as a test or contact anyone for you.\n\nWhat is the shared task? It could be understanding an idea, making a simple plan or sharing something relevant. In your form of communication, what information helps you follow and take part?",
      "sha256": "9d7802aef14398c12aaece39ac92647d2363a2c49902630dcabda282c0a43f1f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.social.help",
      "title": "If no suitable interaction is available",
      "text": "Stay with ordinary practice, use the example or finish. You do not need to arrange extra social contact for the page.",
      "sha256": "bdf167a7c9b7779160cec74b7aa24f0ce3221fb6a32195942ada3eefd0fbcd6e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.prepare",
      "title": "Make a simple attention plan",
      "text": "Choose one useful cue, such as the topic or the meaning of the next message. When the other person communicates, attend to what they mean. When you communicate, attend to what you want to say, not a running judgment of how you seem.\n\nKeep needed aids and agreed supports. Do not plan to stare, scan faces for approval or focus on an unrelated object to escape anxiety. Decide what would mean pause or ask for help, and when you may review.",
      "sha256": "a2d9f21c7807381859b1b517935332e5b201aab335af805d1f7b92152119a5e6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.prepare.help",
      "title": "If I am trying to prevent all anxiety",
      "text": "The aim is engagement, not a guarantee of calm or safety. Check the plan with your therapist before using it as another rule to get right.",
      "sha256": "46b04ebceac13e67dd093283c438837818c78830ada3e3b8284523827967f4ef",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.apply",
      "title": "Use the skill in the real interaction",
      "text": "Prepare with this step before the interaction. Put the page aside while you take part. At the agreed opportunity, when you notice self-checking or scanning for judgment, gently return to the topic, the other person’s meaning or the message you are sharing.\n\nA thought, feeling or stumble can remain. If you missed information, you may ask for it again in a way that fits. You do not need to monitor every moment, record the interaction, seek approval or replay it while it is still happening.",
      "sha256": "295d2faeeee873c60543b3bfd8d9a0cf2f1e6e368099affa0b956c4151e2e672",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.apply.help",
      "title": "If I get caught in checking again",
      "text": "Notice it when you can and choose a useful return. You can pause or leave; this is not an endurance or performance test.",
      "sha256": "3aa4ca4e723335d3b04c97f3560a1e8600ce894c10f5b072caf5cb30c0579b91",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.result",
      "title": "Review what actually happened",
      "text": "Are you reviewing an ordinary activity or a social interaction? Briefly name what you actually tried, including a partial attempt or no attempt. You can start here without a saved plan.\n\nWhat relevant detail, meaning or action do you remember? Was there a moment of noticing and returning? Leave unknown parts unknown. One brief observation is enough; do not replay the event to get a perfect account or prove you seemed acceptable.",
      "sha256": "d19b01624d18e7ee312d84356ca6c25f3d1b3bf15ec85ffda85e6a0984a50abe",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.result.help",
      "title": "If I cannot recall a detail",
      "text": "That alone does not prove the practice failed. Memory, access and circumstances vary. Keep uncertainty rather than turn review into another test.",
      "sha256": "ea98a43dbe658cd0ec922b14c545e5b74351137e3d8f7ea4966c00404aaf2049",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.compare",
      "title": "Look at participation and the pattern over time",
      "text": "Did attention to the task help you follow or contribute, stay about the same, get harder or remain unclear? What happened with anxiety, if you noticed? Anxiety can rise, fall or stay; lower anxiety is not the only useful result.\n\nAcross further agreed opportunities, what do you notice about self-checking, returning and taking part? Compare only real experiences and allow for different people, tasks, access and support. Do not use approval, a score or constant self-monitoring as proof.\n\nCheck whether you used task focus to avoid taking part, push feelings away, ask again and again if things were okay, or follow a new strict rule. A brief review with your therapist can help. This page does not prove a cause or judge your social performance.",
      "sha256": "bca08d7c910f3a92249b443150d91f6c48df4ff1b4edd684f3ae849e7a72c237",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.compare.help",
      "title": "If I have only tried once",
      "text": "Keep the result small. You can discuss another suitable opportunity, but there is no need to invent a trend or make a harder plan.",
      "sha256": "7aa35a15ed6253afa6c1f8bc202624537e1cef62d37d046e37f38adfae0e122a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "task-focused-attention.practice.next",
      "title": "Choose what to keep, change or leave",
      "text": "With your therapist, you might keep the same practice, return to an ordinary task, change the cue or support, or pause. Do not automatically make the interaction harder or remove useful aids.\n\nTake one observation forward if helpful. You can finish with no new plan. This visit does not complete a full course of treatment. Other work, such as repeated worries before or after an event or checks of how you look, needs a separate plan.",
      "sha256": "691932bab721f420ff6a41dd63bd27e42df8419937eaaedd636b19e55f42b1f0",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "task-focused-attention.practice.next.help",
      "title": "If practice feels like another way to judge myself",
      "text": "Pause and bring that pattern to your therapist. You do not have to earn support by using this skill well.",
      "sha256": "c1278d9bcc44a8673768e0d35ac023c655d893fce347cdb2a851e7379ddfa239",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
