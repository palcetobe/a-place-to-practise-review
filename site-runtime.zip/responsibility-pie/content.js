window.PerspectiveSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "responsibility-pie.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "contextReview": {
      "fields": [
        "event",
        "factors",
        "comparison"
      ],
      "placement": "review and adjacent comparison prompts",
      "behavior": "Literal entered context only when writing shown. Never infer a percentage, worth, blame, diagnosis or completion; hide/clear every echo with notes."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/responsibility-pie",
  "title": "Responsibility Pie / Reattribution",
  "subtitle": "Consider contributors without turning them into a blame verdict",
  "scope": "A bounded therapist-chosen, ordinary low-stakes attribution exercise. Not a factual cause calculator, moral or legal verdict, trauma-guilt intervention or assessment of victim responsibility.",
  "version": "2026-11-02-cbt-perspective-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish possible contributing circumstances, personal control and blame, and recognise that a chart cannot establish causal percentages.",
    "practiceObjective": "Describe one agreed ordinary event, identify supported and uncertain contributors, compare their possible roles using a tentative map or optional pie, and reconsider a proportionate account of one’s own role without forced allocation or repair.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.canadiancbt.com/_files/ugd/ece701_bf138d7aea8a4814b4b7b1d6e4330efc.pdf",
      "reviewed": "2026-11-02",
      "supports": "Author-created Responsibility Pie: event, multiple contributors, tentative slices and reconsideration of own role versus outside control.",
      "limits": "Clinical worksheet, not a treatment trial or causal allocation instrument. Original wording/example; narrower ordinary-event scope and optional nonpercentage comparison are explicit adaptations."
    }
  ],
  "resourceId": "tool/responsibility-pie",
  "routeProposal": "tool/responsibility-pie",
  "intro": {
    "id": "responsibility-pie.intro",
    "title": "Broaden the account before assigning a share",
    "paragraphs": [
      "An ordinary outcome may have several contributing circumstances. This practice looks beyond “It was all my fault” without automatically replacing it with “None of it was my responsibility.”",
      "Use an ordinary low-stakes event chosen with your therapist. You can compare contributors in words, or try a rough pie as a thinking aid. Neither method decides the facts or tells you who deserves blame."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "responsibility-pie.fit",
    "title": "Use only the agreed ordinary event",
    "paragraphs": [
      "A therapist should help choose a suitable event and explain the difference between contribution, control and blame.",
      "Do not use this exercise for abuse, assault, coercion, trauma-related guilt, victim responsibility, accidents involving serious injury, or disputed legal or medical responsibility. Do not assign a share of blame to someone for being harmed. Those situations need appropriate professional support.",
      "If the facts are disputed, key information is missing, or you feel driven to get an exact percentage, keep the uncertainty and stop the allocation. You can read the fictional example or take the question back to your therapist instead."
    ]
  },
  "learn": {
    "id": "responsibility-pie.learn",
    "title": "Why look at several contributors?",
    "paragraphs": [
      "A narrow account can leave out timing, information, systems and other circumstances. Considering them can help you describe your own role more proportionately, while keeping specific responsibilities where the evidence supports them.",
      "A contribution is not automatically blame, and influence is not complete control. Several factors can overlap; adding slices does not discover objective causal shares. An unknown factor should not be silently assigned to you.",
      "The source pie technique allocates tentative slices and reviews one’s role. If you prefer no numbers, compare factors in words as an adapted reattribution practice. That is not a completed percentage pie, and neither version establishes a verdict."
    ]
  },
  "example": {
    "id": "responsibility-pie.example",
    "title": "Example — a late start to a hobby meeting",
    "paragraphs": [
      "With a therapist, Casey chooses a low-stakes event: a hobby meeting began late. Casey initially thinks it was entirely their fault because they sent a reminder late. The room was also unexpectedly locked, and the group had no agreed key-holder.",
      "Casey considers the late reminder, room access and the missing key-holder arrangement, and starts sketching tentative slices. Casey then notices that access and planning overlap and there is not enough information to separate their shares. Casey drops the numerical allocation and compares the contributors in words instead; this is not a completed pie.",
      "Casey revises the account: “My reminder may have contributed, but it does not explain the whole delay. The access and planning issues also matter.” Casey can acknowledge the late reminder without taking over all future organising. Embarrassment remains; a specific repair is an option, not a condition of finishing."
    ]
  },
  "practiceScenario": {
    "id": "responsibility-pie.scenario",
    "title": "Optional fictional practice — Casey",
    "paragraphs": [
      "Use Casey’s late hobby meeting: late reminder, unexpectedly locked room and no agreed key-holder. The story does not tell you exactly how much each contributed.",
      "Compare possible roles and what remains unknown. Your estimates need not match Casey’s, and you do not have to allocate numbers or propose a repair."
    ]
  },
  "practice": [
    {
      "id": "responsibility-pie.practice.event",
      "title": "Describe the agreed event",
      "paragraphs": [
        "What ordinary outcome are you examining, and what responsibility are you currently taking for it? Stick to the event chosen with your therapist or Casey’s example.",
        "Separate what is known from what is assumed. If the event does not fit the boundaries above, stop this personal exercise."
      ],
      "fields": [
        {
          "key": "event",
          "label": "Agreed ordinary event and current account",
          "optional": true
        }
      ],
      "help": {
        "title": "If the situation is not agreed",
        "text": "Use Casey’s fictional example, read, or finish. This page cannot assess whether a different situation is suitable."
      }
    },
    {
      "id": "responsibility-pie.practice.factors",
      "title": "Consider multiple contributors",
      "paragraphs": [
        "What people, circumstances, information or arrangements may have contributed? Include evidence and uncertainty, not just a list of people to blame.",
        "Consider external circumstances as well as your own actions. Do not force every possibility into the map; some may be unknown, overlapping or irrelevant."
      ],
      "fields": [
        {
          "key": "factors",
          "label": "Contributors, evidence and uncertainties",
          "optional": true
        }
      ],
      "help": {
        "title": "If you only see your own role",
        "text": "Look at what information and control were actually available at the time. Do not invent another person’s fault to reduce your share."
      }
    },
    {
      "id": "responsibility-pie.practice.compare",
      "title": "Compare roles tentatively",
      "paragraphs": [
        "How do the possible contributors relate? Which seem important, limited or uncertain based on the information available? Use words or the optional pie; exact shares are not knowable from this page.",
        "Only include your own role where supported. You may leave the map incomplete. A remaining blank is not automatically your responsibility."
      ],
      "fields": [
        {
          "key": "comparison",
          "label": "Relative roles and what cannot be allocated",
          "optional": true
        }
      ],
      "help": {
        "title": "If numbers feel compulsory",
        "text": "Use a nonnumerical account or stop. The pie is one possible aid, not a demand to total up blame. Overlapping causes cannot be made independent simply by drawing slices."
      }
    },
    {
      "id": "responsibility-pie.practice.review",
      "title": "Review your own role fairly",
      "paragraphs": [
        "What account now describes your contribution and limits of control? It may change, stay similar or remain uncertain. Do not use the chart as proof against yourself or anyone else.",
        "If useful, consider a proportionate acknowledgment or practical repair for a supported part of your role. No apology, contact, acceptance of blame or new responsibility is required."
      ],
      "fields": [
        {
          "key": "review",
          "label": "A proportionate account or open question",
          "optional": true
        }
      ],
      "help": {
        "title": "If a repair is considered",
        "text": "A specific response need not mean accepting all responsibility. Discuss any uncertainty or interpersonal consequences with your therapist before acting."
      }
    }
  ],
  "close": {
    "id": "responsibility-pie.close",
    "title": "Leave the allocation provisional",
    "paragraphs": [
      "You can finish without a percentage or a resolved answer. The map is a reflection aid, not a verdict. No one acquires responsibility because this page has an empty slice."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "Original Casey case; no trauma, abuse, assault, victim responsibility, serious injury, medical/legal allocation or exact causal inference.",
    "Optional nonnumerical comparison is reattribution rehearsal, not a completed pie; no required 100 percent or automatic remaining share assigned to self."
  ],
  "visualAid": {
    "id": "responsibility.visual",
    "kind": "optional-tentative-pie",
    "default": "Off; empty user chart, no initial categories or equal slices. Fictional example chart may be viewed separately with clear Example label.",
    "placement": "factors/compare/review",
    "purpose": "Tentative comparison of possible contributors, never factual causation or blame.",
    "inputs": {
      "rows": "Start with blank optional label/share rows; add/remove a row by keyboard button; no required category count.",
      "share": "Optional rough user-entered number 0–100, labeled tentative comparison share, not responsibility verdict",
      "unknown": "Explicit optional unallocated/uncertain remainder; never assigned to the person, another category or equal slices.",
      "textEquivalent": "The ordinary-language areas/factors and comparison fields are complete alternatives. Label them adapted nonnumerical practice, not a completed percentage pie."
    },
    "behavior": [
      "Render only user-entered finite nonnegative values; never normalize, average, recommend shares or force a total of 100.",
      "If sum is below 100, mark remainder Unallocated/uncertain—not a personal share. If sum exceeds 100, show a gentle total notice and no misleading full pie; keep labels/text and allow revision or leaving it incomplete.",
      "For a labeled row with a blank share, show the literal label with “share not entered” in the text table. Do not infer its size from the unallocated remainder; the remainder is not evidence about any factor.",
      "Blank is not zero. With all entries blank, show an empty-chart placeholder, not a full uncertain slice. Zero entered explicitly may be listed in the textual legend without a visible wedge.",
      "A row missing its label or with invalid/nonfinite/out-of-range share is shown as incomplete with a nearby notice; do not silently discard it or invent a label. Keep text review available without rendering a misleading completed pie.",
      "No equal-slice goal, red/green score or change-success animation. Display total and all labels/shares in a keyboard-readable text table; chart never color-only.",
      "No dragging required; direct labeled inputs and Add/remove buttons suffice. User controls chart visibility independently, but hiding writing hides all private chart data/labels/echoes too.",
      "Clear labels/shares/visibility on exit/reload/clear/restart; internal Back/Learn/Example retains them. No private entries in narration or backend storage."
    ],
    "visibleNote": "These are tentative comparisons, not measured causes or blame. Unallocated does not mean yours."
  },
  "narrationSegments": [
    {
      "id": "responsibility-pie.intro",
      "title": "Broaden the account before assigning a share",
      "text": "An ordinary outcome may have several contributing circumstances. This practice looks beyond “It was all my fault” without automatically replacing it with “None of it was my responsibility.”\n\nUse an ordinary low-stakes event chosen with your therapist. You can compare contributors in words, or try a rough pie as a thinking aid. Neither method decides the facts or tells you who deserves blame.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.fit",
      "title": "Use only the agreed ordinary event",
      "text": "A therapist should help choose a suitable event and explain the difference between contribution, control and blame.\n\nDo not use this exercise for abuse, assault, coercion, trauma-related guilt, victim responsibility, accidents involving serious injury, or disputed legal or medical responsibility. Do not assign a share of blame to someone for being harmed. Those situations need appropriate professional support.\n\nIf the facts are disputed, key information is missing, or you feel driven to get an exact percentage, keep the uncertainty and stop the allocation. You can read the fictional example or take the question back to your therapist instead.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.learn",
      "title": "Why look at several contributors?",
      "text": "A narrow account can leave out timing, information, systems and other circumstances. Considering them can help you describe your own role more proportionately, while keeping specific responsibilities where the evidence supports them.\n\nA contribution is not automatically blame, and influence is not complete control. Several factors can overlap; adding slices does not discover objective causal shares. An unknown factor should not be silently assigned to you.\n\nThe source pie technique allocates tentative slices and reviews one’s role. If you prefer no numbers, compare factors in words as an adapted reattribution practice. That is not a completed percentage pie, and neither version establishes a verdict.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.example",
      "title": "Example — a late start to a hobby meeting",
      "text": "With a therapist, Casey chooses a low-stakes event: a hobby meeting began late. Casey initially thinks it was entirely their fault because they sent a reminder late. The room was also unexpectedly locked, and the group had no agreed key-holder.\n\nCasey considers the late reminder, room access and the missing key-holder arrangement, and starts sketching tentative slices. Casey then notices that access and planning overlap and there is not enough information to separate their shares. Casey drops the numerical allocation and compares the contributors in words instead; this is not a completed pie.\n\nCasey revises the account: “My reminder may have contributed, but it does not explain the whole delay. The access and planning issues also matter.” Casey can acknowledge the late reminder without taking over all future organising. Embarrassment remains; a specific repair is an option, not a condition of finishing.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.scenario",
      "title": "Optional fictional practice — Casey",
      "text": "Use Casey’s late hobby meeting: late reminder, unexpectedly locked room and no agreed key-holder. The story does not tell you exactly how much each contributed.\n\nCompare possible roles and what remains unknown. Your estimates need not match Casey’s, and you do not have to allocate numbers or propose a repair.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.event",
      "title": "Describe the agreed event",
      "text": "What ordinary outcome are you examining, and what responsibility are you currently taking for it? Stick to the event chosen with your therapist or Casey’s example.\n\nSeparate what is known from what is assumed. If the event does not fit the boundaries above, stop this personal exercise.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.event.help",
      "title": "If the situation is not agreed",
      "text": "Use Casey’s fictional example, read, or finish. This page cannot assess whether a different situation is suitable.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.factors",
      "title": "Consider multiple contributors",
      "text": "What people, circumstances, information or arrangements may have contributed? Include evidence and uncertainty, not just a list of people to blame.\n\nConsider external circumstances as well as your own actions. Do not force every possibility into the map; some may be unknown, overlapping or irrelevant.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.factors.help",
      "title": "If you only see your own role",
      "text": "Look at what information and control were actually available at the time. Do not invent another person’s fault to reduce your share.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.compare",
      "title": "Compare roles tentatively",
      "text": "How do the possible contributors relate? Which seem important, limited or uncertain based on the information available? Use words or the optional pie; exact shares are not knowable from this page.\n\nOnly include your own role where supported. You may leave the map incomplete. A remaining blank is not automatically your responsibility.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.compare.help",
      "title": "If numbers feel compulsory",
      "text": "Use a nonnumerical account or stop. The pie is one possible aid, not a demand to total up blame. Overlapping causes cannot be made independent simply by drawing slices.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.review",
      "title": "Review your own role fairly",
      "text": "What account now describes your contribution and limits of control? It may change, stay similar or remain uncertain. Do not use the chart as proof against yourself or anyone else.\n\nIf useful, consider a proportionate acknowledgment or practical repair for a supported part of your role. No apology, contact, acceptance of blame or new responsibility is required.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.practice.review.help",
      "title": "If a repair is considered",
      "text": "A specific response need not mean accepting all responsibility. Discuss any uncertainty or interpersonal consequences with your therapist before acting.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.close",
      "title": "Leave the allocation provisional",
      "text": "You can finish without a percentage or a resolved answer. The map is a reflection aid, not a verdict. No one acquires responsibility because this page has an empty slice.",
      "status": "Script only"
    },
    {
      "id": "responsibility-pie.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    },
    {
      "id": "responsibility.visual.note",
      "title": "About the optional visual",
      "text": "These are tentative comparisons, not measured causes or blame. Unallocated does not mean yours.",
      "status": "Static script only; never user labels or values"
    }
  ]
}
;
