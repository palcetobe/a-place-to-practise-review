window.RulesAssumptionsContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/rules",
  "resourceId": "tool/rules-and-assumptions",
  "routeProposal": "/rules-and-assumptions/",
  "title": "Adjusting Rules and Assumptions",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Explore one personal rule with your therapist, then review a small test you have agreed.",
  "groupedSetStatus": "One existing canonical entry, classic/rules. Rule revision is distinct from a Thought Record, a situation map, core-belief work or a complete self-esteem/perfectionism programme. No new catalogue count or validation claim.",
  "clinicalContract": {
    "learningObjective": "Recognize a personal demand or conditional assumption; examine its real effects and context; develop and test a credible, flexible alternative without requiring change.",
    "practiceObjective": "Work on one therapist-selected ordinary rule, preserve useful values and safeguards, formulate a bounded agreed test, and review actual observations or non-use before deciding what to retain or revise.",
    "sourcePopulationContext": "CCI self-esteem and perfectionism materials are adult-framed treatment resources, not validation of this isolated adaptation. No blanket adult-only or 16+ restriction and no universal age-suitability claim. Therapist review must address development, safeguarding, dependency/power, health, communication, culture and access.",
    "exclusions": [
      "No challenge to real law, ethics, consent, safety or health requirements",
      "No automatic pathologizing of cultural identity, oppression, trauma or protective learning",
      "No independent exposure/ERP, trauma recall, downward-arrow interrogation or proof of personal worth",
      "No tests involving food/weight, medication, health care, sleep deprivation, substances, harm, dangerous tasks, legal/financial commitments or unsafe relationships",
      "No dropping needed protection, disability aids, accommodations or support"
    ],
    "adaptations": [
      "Original wording and fictional example; no worksheet reproduced",
      "Context and history optional; no assumed origin or function",
      "Keep the rule, leave it open, or seek environmental/support changes are valid options",
      "Optional word/number ratings; no required change or score",
      "Actual non-use, changed plans, mixed, adverse and unclear results supported",
      "Session-only optional notes; exact selected-note export; no public guidance reads private notes"
    ],
    "reviewGates": [
      "Owner/clinician review of full method, wording, low-risk example and bounded test",
      "Individual clinical, developmental and safeguarding fit",
      "Novice comprehension and accessibility review; grade-five readability is a target not a validated result",
      "Real integrated browser/mobile/keyboard/screen-reader and navigation acceptance",
      "Authorized narration generation, exact-script listening, binding and controls review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use a rule you are working on with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Explore my agreed rule",
          "startSectionId": "rules-and-assumptions.practice.rule"
        },
        {
          "value": "review",
          "label": "Review my agreed test",
          "startSectionId": "rules-and-assumptions.practice.review"
        }
      ]
    },
    "entryGate": "Visible therapist-introduced scope before an explicit entry choice. The choice certifies neither individual fit nor test safety. Example, Learn, Finish and support remain available without it.",
    "focus": "One meaningful prompt group with free jump, Show all, Previous and Finish. No required writing or completion locks.",
    "reviewAccess": "Direct review without a prior plan, attempt or stored answers; never infer practice from clicking Next.",
    "writing": "Optional and hidden initially; fiction never fills notes. Hiding private writing removes visible private displays and invalidates export selection.",
    "persistence": "In-memory open-page notes only. Internal readings/navigation retain them; clear, restart, leaving/reloading, history navigation and BFCache return clear them. Offscreen visibility alone retains them.",
    "export": "No default note selection. Explicit selection produces exact preview; copy/download only that text. Editing, hiding or mode changes invalidate selection.",
    "narration": "Hashed fixed public paragraphs/help only, never notes. No media files, TTS, autoplay or activation.",
    "timer": "None. A real-world trial follows its therapist-agreed plan, not an app countdown.",
    "completion": "No completion, attempted, success, score, streak, mood or belief-change verdict."
  },
  "intro": {
    "id": "rules-and-assumptions.intro",
    "title": "Make room for a more flexible rule",
    "paragraphs": [
      "A personal rule is an idea about how you must act. It may sound like \"I must always get it right.\" An assumption is a guess about what will happen if you do not follow the rule.",
      "Some rules help. Some make life harder when there is no room for change. With your therapist, you can look at one rule and decide whether to keep it, loosen it or leave it open. You do not have to change a rule today."
    ]
  },
  "fit": {
    "id": "rules-and-assumptions.fit",
    "title": "Before using your own rule",
    "paragraphs": [
      "Choose one ordinary rule you and your therapist are already working on. This page cannot decide whether the rule or a test fits you. You can read the example or Learn more without doing a test.",
      "A word like \"must\" does not make a rule wrong. Keep real duties, people's right to say no, health advice and safety steps. Your culture, values and need for support matter. Do not change a rule just to please someone else.",
      "Do not use this page to test danger, abuse, harm, money or legal duties, or changes to food, medicine, sleep or substance use. Do not use this page to go over a traumatic event or start an exposure exercise (facing a fear as treatment).",
      "Before trying a new action, agree the exact small test, limits and review with your therapist. Keep needed aids, care and steps that keep you safe. No agreed test yet? Keep your ideas as questions for your session, not instructions to act."
    ]
  },
  "privacy": {
    "id": "rules-and-assumptions.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes to your therapist. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "rules-and-assumptions.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can stop after reading, thinking, making a plan or reviewing. Keeping a rule or leaving a question open can be a fair choice. A planned test is not a test you have done.",
      "You can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere."
    ]
  },
  "example": {
    "id": "rules-and-assumptions.example",
    "title": "Sam tries a new drawing hobby",
    "paragraphs": [
      "This is made up. It is not a rule or a test you need to copy. Sam and their therapist choose one rule about a new drawing hobby: \"I must be good at it from the start, or there is no point trying.\" For Sam, \"no point\" means learning nothing from trying. Sam feels very sure.",
      "Context: Sam has often been praised for getting things right. That may be part of the story, but Sam does not need to prove where the rule came from. Sam still values care and learning.",
      "Effects: The rule can push Sam to prepare. It also means Sam quits new hobbies before there is time to learn. Sam remembers learning a card game through practice. That does not fit the idea that everything must come easily at first.",
      "Flexible rule: \"I like doing things well. I can be new at a hobby and learn one part at a time.\" It feels possible, though Sam is not sure it will help.",
      "Agreed test: Sam and the therapist choose five minutes of drawing with materials Sam already uses. Sam can stop sooner. Prediction: \"If my first sketch is rough, I will learn nothing from trying.\" Sam will notice whether trying one change teaches them anything. They will keep the usual aids and review it in the next session.",
      "Actual result: Sam draws a cup. It looks uneven. Sam tries a wider handle and can see how that changes the shape. Sam is still unhappy with the picture, but can name one thing learned.",
      "Review: This one attempt does not fit \"I will learn nothing.\" It does not prove Sam must like drawing or keep doing it. Sam decides to keep exploring the flexible rule with the therapist.",
      "If Sam had not tried it, there would be no test result yet. If nothing useful had emerged, Sam could say so and review the plan. Neither result would say what Sam is worth as a person."
    ]
  },
  "learn": {
    "id": "rules-and-assumptions.learn",
    "title": "What makes this a rule?",
    "paragraphs": [
      "A thought can be about one moment: \"This sketch looks rough.\" A rule is a wider demand: \"I must be good at a hobby straight away.\" An assumption adds a feared meaning: \"If I am not, there is no point trying.\"",
      "Rules may come from many places, including learning, family, culture or real demands. You do not need to find one cause. A rule may have helped before and still help now. Check its fit with your therapist.",
      "Look at what the rule asks, what it helps with and what it costs. Ask whether it fits all the facts. A flexible rule keeps what matters while leaving room for the situation, your needs and your limits.",
      "This is more than changing one thought to sound kind. You explore a wider pattern, then use a small agreed test to learn about it. A test gives information, not proof that every future result will be the same.",
      "You may keep the rule, change it, or not know yet. Some problems call for real help or a change in the situation. You do not have to change a belief to make unfair treatment seem okay.",
      "Use actual events when you review. A result can fit the old guess, fit part of it, point another way or leave things unclear. Discuss this with your therapist before any new test. Feeling better or believing the new rule is not a pass mark."
    ]
  },
  "practice": [
    {
      "id": "rules-and-assumptions.practice.rule",
      "title": "Name the rule and its meaning",
      "paragraphs": [
        "Use the ordinary rule you chose with your therapist. What does it say you must, should or must never do? Try one clear sentence. You do not need to find a rule on your own.",
        "What do you expect if you do not follow it? Try \"If I do not do this, then...\" Keep the rule apart from the result you fear. If useful, note how sure you feel in words or from 0 to 100. Zero means not at all sure; 100 means fully sure. You can skip the rating."
      ],
      "fields": [
        {
          "key": "old-rule",
          "label": "The personal rule",
          "optional": true
        },
        {
          "key": "feared-meaning",
          "label": "What I expect if I do not follow it",
          "optional": true
        },
        {
          "key": "belief-before",
          "label": "How sure I feel about that expectation",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot find a rule",
        "text": "Bring one recent, manageable moment to your therapist. You do not have to search for hidden beliefs, recall painful events or work out what the rule says about your worth. You can leave this open."
      }
    },
    {
      "id": "rules-and-assumptions.practice.context",
      "title": "Look at the setting and what matters",
      "paragraphs": [
        "Where does this rule show up now? What matters in that setting? Think about real duties, power, culture, health, support and safety, not just your thoughts.",
        "If it helps, notice where you may have learned the rule or what it has helped you protect. You can skip its history. Do not force a reason. Is there a need or value you want to keep?"
      ],
      "fields": [
        {
          "key": "context",
          "label": "Where the rule shows up and what matters there",
          "optional": true
        },
        {
          "key": "helpful-purpose",
          "label": "What it may help me protect or keep",
          "optional": true
        }
      ],
      "help": {
        "title": "If the situation is unfair or unsafe",
        "text": "The answer may be more support or a change in the situation, not a different thought. Do not test a rule by accepting harm or losing needed protection. Pause and talk with your therapist or seek help."
      }
    },
    {
      "id": "rules-and-assumptions.practice.effects",
      "title": "Weigh what it helps and what it costs",
      "paragraphs": [
        "Think of times you followed this rule. What did it help with? What was hard about it? Notice effects on what you do, how you feel, your time, your needs and your relationships.",
        "Keep useful parts in view. You do not need to list equal good and bad points. If the rule fits your needs, keeping it can make sense. You can stop here and discuss what you found."
      ],
      "fields": [
        {
          "key": "benefits",
          "label": "Ways the rule helps",
          "optional": true
        },
        {
          "key": "costs",
          "label": "Ways the rule makes things harder",
          "optional": true
        }
      ],
      "help": {
        "title": "If changing feels like giving up",
        "text": "A flexible rule does not have to mean giving up care, effort or a value. It may mean more than one way to meet a need. You do not have to replace a useful rule just because you opened this page."
      }
    },
    {
      "id": "rules-and-assumptions.practice.check",
      "title": "Check how well the rule fits",
      "paragraphs": [
        "What real events support the rule or the result you fear? What events do not fit, or fit only part? Notice when, where and for whom it applies. \"Always\" and \"never\" may leave out important details.",
        "Do not dismiss real risks or unfair treatment. You can notice exceptions without claiming there is no risk. If there is not enough information, leave the question open."
      ],
      "fields": [
        {
          "key": "evidence",
          "label": "Events that fit the rule or feared result",
          "optional": true
        },
        {
          "key": "exceptions",
          "label": "Exceptions, limits or things I do not know",
          "optional": true
        }
      ],
      "help": {
        "title": "If the rule feels true everywhere",
        "text": "You do not need to argue yourself out of it. Tell your therapist what makes it feel true and where you need help. An example on this page is not evidence about your life."
      }
    },
    {
      "id": "rules-and-assumptions.practice.flexible",
      "title": "Try a fairer, more flexible rule",
      "paragraphs": [
        "If you want to explore a change, keep the value or need that matters. Make room for the setting, your limits and more than one way to act. Try words like \"I prefer\", \"sometimes\" or \"I can choose\", only if they fit.",
        "Does the new rule feel fair and possible, even if you do not fully believe it? It need not promise a good result. You can keep the old rule, try a smaller change or ask your therapist for help."
      ],
      "fields": [
        {
          "key": "flexible-rule",
          "label": "A flexible rule I want to explore",
          "optional": true
        },
        {
          "key": "what-keep",
          "label": "The value, need or useful part I want to keep",
          "optional": true
        }
      ],
      "help": {
        "title": "If the new rule sounds too positive",
        "text": "Use words you could mean. \"No one will ever judge me\" promises too much. A fair rule can allow mistakes and real risks without making either one a judgment of your whole worth."
      }
    },
    {
      "id": "rules-and-assumptions.practice.test",
      "title": "Set out the small test you agreed",
      "paragraphs": [
        "Before acting, agree the exact test with your therapist. What small action would try the flexible rule? If you want, note what, where, when and how much you agreed. This page does not choose or approve a test.",
        "What does the old rule predict? What other result is possible? Name something you can see, hear or clearly describe that would help you learn. Do not try to guess what is in another person's mind.",
        "Keep needed care, aids and safety steps. Include what might get in the way, when to stop, how to get support and when to review. If you have no agreed test, leave the action open and take the ideas to your therapist."
      ],
      "fields": [
        {
          "key": "prediction",
          "label": "The old prediction and another possible result",
          "optional": true
        },
        {
          "key": "agreed-test",
          "label": "The exact small action, setting and limits we agreed",
          "optional": true
        },
        {
          "key": "evidence-plan",
          "label": "What I could notice that would give information",
          "optional": true
        },
        {
          "key": "safeguards",
          "label": "Supports, possible problems and when to stop",
          "optional": true
        },
        {
          "key": "review-plan",
          "label": "How I will get help and review with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If you are unsure whether a test fits",
        "text": "Do not make it harder or guess what to drop. Pause for your therapist's advice. Keep health and safety steps. This page is not for dangerous actions, health changes, exposure exercises or testing an unsafe relationship."
      }
    },
    {
      "id": "rules-and-assumptions.practice.try",
      "title": "Use the plan only when it fits",
      "paragraphs": [
        "A real test happens in your life, not by pressing Next. Use only the plan you agreed. If your needs, the setting or the risks have changed, pause and check before going ahead.",
        "You can stop, try only part, or decide not to try. Do not repeat the test to force a result or make a rating go down. Review any change to the plan with your therapist.",
        "You can leave and come back to Review my agreed test. Notes in this page are not saved when you leave or reload. Choose notes to keep first if you want a copy."
      ],
      "help": {
        "title": "If you did not try it",
        "text": "You can still review what got in the way or why you stopped. Not trying is not evidence that the feared result happened. You do not need to invent an outcome or catch up on practice."
      }
    },
    {
      "id": "rules-and-assumptions.practice.review",
      "title": "Look at what actually happened",
      "paragraphs": [
        "Use this after the planned time, whether you tried all, part or none of the test. What did you actually do? Did the plan change? If there was no attempt, say that or leave the result open.",
        "What did you notice? Keep observations apart from guesses. Feelings are real parts of your experience, but they do not show what someone else thought. What is still unknown?",
        "Recall or check your original prediction and the information you planned to notice. If you cannot remember them, leave the comparison open. Do not make up what you expected. Compare the result with the prediction you actually made. Did the facts fit it, partly fit it, point another way or leave it unclear? Do not force a good result."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "What I tried, changed or did not try",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What I actually noticed and what is unknown",
          "optional": true
        },
        {
          "key": "comparison",
          "label": "How this compares with the prediction",
          "optional": true
        }
      ],
      "help": {
        "title": "If something hurtful or unsafe happened",
        "text": "Take it seriously. Stop and seek the support you need. You do not have to find a positive meaning or blame yourself. Review with your therapist before another test. Use Support and urgent help to find help options."
      }
    },
    {
      "id": "rules-and-assumptions.practice.learning",
      "title": "Decide what to keep or review",
      "paragraphs": [
        "What does this one result suggest about the old rule and the flexible rule? What does it not tell you? It may support a change, a smaller change, keeping the rule or no answer yet.",
        "If useful, return to the same expectation you rated at the start. Note how sure you feel about it now, using the same words or scale. If you do not remember it, you can skip this. It does not need to be lower. There is no right score.",
        "Bring your learning, what got in the way and your questions to your therapist. Agree whether to keep, revise or stop this plan. This page does not set a new test for you. You can finish without deciding yet."
      ],
      "fields": [
        {
          "key": "learning",
          "label": "What I might keep, change or leave open",
          "optional": true
        },
        {
          "key": "belief-after",
          "label": "How sure I feel about the first expectation now",
          "optional": true
        },
        {
          "key": "therapy-review",
          "label": "What I want to review with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want notes for your session",
        "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy."
      }
    }
  ],
  "sources": [
    {
      "id": "CCI: Adjusting Rules and Assumptions",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Improving-Self-Esteem/Improving-Self-Esteem---07---Adjusting-Rules-and-Assumptions.pdf",
      "supports": "Personal rule, learning/context, benefits and costs, flexible alternative and new action; keeping a useful rule remains an option.",
      "limits": "Adult-framed self-esteem treatment module, not validation of this isolated tool or its use across ages. Original wording and example here; no worksheet reproduced."
    },
    {
      "id": "CCI: Behavioural Experiments, Negative Predictions",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Mental-Health-Professionals/Anxiety/Anxiety---Information-Sheets/Anxiety-Information-Sheet---05---Behavioural-Experiments-Negative-Predictions.pdf",
      "supports": "Specific prediction and alternative, bounded plan, observed outcome and learning.",
      "limits": "Procedure source only. This tool requires therapist agreement, makes ratings optional and keeps real protections. It is not an exposure or response-prevention treatment."
    },
    {
      "id": "CCI: Reducing Perfectionist Behaviour",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Consumer-Modules/Perfectionism-in-Perspective/Perfectionism-in-Perspective--05--Reducing-my-Perfectionist-Behaviour.pdf",
      "supports": "Distinguish planning from actual trial and review, including results that partly support a belief.",
      "limits": "Used for review structure only. Food, weight and checking examples are not imported. The source is not evidence of generic digital efficacy."
    },
    {
      "id": "APA: Culturally Responsive CBT in Practice",
      "url": "https://www.apa.org/pubs/videos/4310900",
      "supports": "Attend to cultural identity, preferences and context; validate oppression and consider environmental change.",
      "limits": "Public clinical-training description read, not the paid video. This contextual safeguard is not a validated app screening instrument."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Rule and conditional meaning",
      "sections": [
        "practice.rule"
      ],
      "source": "CCI self-esteem module 7; catalogue core procedure"
    },
    {
      "operation": "Context and useful function without forced origins",
      "sections": [
        "practice.context"
      ],
      "source": "CCI module 7; APA public description; conservative optional-history adaptation"
    },
    {
      "operation": "Effects and possibility of retaining the rule",
      "sections": [
        "practice.effects"
      ],
      "source": "CCI module 7"
    },
    {
      "operation": "Reality, exceptions and limitations",
      "sections": [
        "practice.check"
      ],
      "source": "CCI module 7; original book thought-appraisal overlap"
    },
    {
      "operation": "Credible flexible alternative retaining values",
      "sections": [
        "practice.flexible"
      ],
      "source": "CCI module 7; original book p176 values/rules distinction"
    },
    {
      "operation": "Agreed behavioural test and real use",
      "sections": [
        "practice.test",
        "practice.try"
      ],
      "source": "CCI experiments; explicit therapist/safety adaptation"
    },
    {
      "operation": "Actual result, comparison and revisable learning",
      "sections": [
        "practice.review",
        "practice.learning"
      ],
      "source": "CCI experiments and perfectionism module 5; conservative adverse/no-use safeguards"
    }
  ],
  "narrationSegments": [
    {
      "id": "rules-and-assumptions.intro",
      "title": "Make room for a more flexible rule",
      "text": "A personal rule is an idea about how you must act. It may sound like \"I must always get it right.\" An assumption is a guess about what will happen if you do not follow the rule.\n\nSome rules help. Some make life harder when there is no room for change. With your therapist, you can look at one rule and decide whether to keep it, loosen it or leave it open. You do not have to change a rule today.",
      "sha256": "ca4c0311f7931e2422786fc42b5fd7ea1dd01a2efaa971188ef392ed3b3e9836",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.fit",
      "title": "Before using your own rule",
      "text": "Choose one ordinary rule you and your therapist are already working on. This page cannot decide whether the rule or a test fits you. You can read the example or Learn more without doing a test.\n\nA word like \"must\" does not make a rule wrong. Keep real duties, people's right to say no, health advice and safety steps. Your culture, values and need for support matter. Do not change a rule just to please someone else.\n\nDo not use this page to test danger, abuse, harm, money or legal duties, or changes to food, medicine, sleep or substance use. Do not use this page to go over a traumatic event or start an exposure exercise (facing a fear as treatment).\n\nBefore trying a new action, agree the exact small test, limits and review with your therapist. Keep needed aids, care and steps that keep you safe. No agreed test yet? Keep your ideas as questions for your session, not instructions to act.",
      "sha256": "b0804f4cc6788d20340ffbcc7ee78ff3e37190edd7d664d9f51fb21d1fd72c3d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes to your therapist. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "07d2c4ba17eda8f147248a607190bd4efeca29909a9e9eebe4354280ef30d4ab",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.close",
      "title": "Leave the practice here",
      "text": "You can stop after reading, thinking, making a plan or reviewing. Keeping a rule or leaving a question open can be a fair choice. A planned test is not a test you have done.\n\nYou can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere.",
      "sha256": "6726187cd00a842ecfdaa4b42d4a31608f203648e4c7fd02dbf5e2adbbebf8d8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.example",
      "title": "Sam tries a new drawing hobby",
      "text": "This is made up. It is not a rule or a test you need to copy. Sam and their therapist choose one rule about a new drawing hobby: \"I must be good at it from the start, or there is no point trying.\" For Sam, \"no point\" means learning nothing from trying. Sam feels very sure.\n\nContext: Sam has often been praised for getting things right. That may be part of the story, but Sam does not need to prove where the rule came from. Sam still values care and learning.\n\nEffects: The rule can push Sam to prepare. It also means Sam quits new hobbies before there is time to learn. Sam remembers learning a card game through practice. That does not fit the idea that everything must come easily at first.\n\nFlexible rule: \"I like doing things well. I can be new at a hobby and learn one part at a time.\" It feels possible, though Sam is not sure it will help.\n\nAgreed test: Sam and the therapist choose five minutes of drawing with materials Sam already uses. Sam can stop sooner. Prediction: \"If my first sketch is rough, I will learn nothing from trying.\" Sam will notice whether trying one change teaches them anything. They will keep the usual aids and review it in the next session.\n\nActual result: Sam draws a cup. It looks uneven. Sam tries a wider handle and can see how that changes the shape. Sam is still unhappy with the picture, but can name one thing learned.\n\nReview: This one attempt does not fit \"I will learn nothing.\" It does not prove Sam must like drawing or keep doing it. Sam decides to keep exploring the flexible rule with the therapist.\n\nIf Sam had not tried it, there would be no test result yet. If nothing useful had emerged, Sam could say so and review the plan. Neither result would say what Sam is worth as a person.",
      "sha256": "2cfc6893d2c4a96f90491412c4b9105bb24cadb0a2235622bc99d9b0a9ad945d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.learn",
      "title": "What makes this a rule?",
      "text": "A thought can be about one moment: \"This sketch looks rough.\" A rule is a wider demand: \"I must be good at a hobby straight away.\" An assumption adds a feared meaning: \"If I am not, there is no point trying.\"\n\nRules may come from many places, including learning, family, culture or real demands. You do not need to find one cause. A rule may have helped before and still help now. Check its fit with your therapist.\n\nLook at what the rule asks, what it helps with and what it costs. Ask whether it fits all the facts. A flexible rule keeps what matters while leaving room for the situation, your needs and your limits.\n\nThis is more than changing one thought to sound kind. You explore a wider pattern, then use a small agreed test to learn about it. A test gives information, not proof that every future result will be the same.\n\nYou may keep the rule, change it, or not know yet. Some problems call for real help or a change in the situation. You do not have to change a belief to make unfair treatment seem okay.\n\nUse actual events when you review. A result can fit the old guess, fit part of it, point another way or leave things unclear. Discuss this with your therapist before any new test. Feeling better or believing the new rule is not a pass mark.",
      "sha256": "a7c5612913852f3a7828e7bb272db3687b8dc852d9e02d18a7870e4af2ca755c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.rule",
      "title": "Name the rule and its meaning",
      "text": "Use the ordinary rule you chose with your therapist. What does it say you must, should or must never do? Try one clear sentence. You do not need to find a rule on your own.\n\nWhat do you expect if you do not follow it? Try \"If I do not do this, then...\" Keep the rule apart from the result you fear. If useful, note how sure you feel in words or from 0 to 100. Zero means not at all sure; 100 means fully sure. You can skip the rating.",
      "sha256": "24df6872f6be22492f6f9a44e448b60ac46d1d32f78f54ada434630be1a61f54",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.rule.help",
      "title": "If you cannot find a rule",
      "text": "Bring one recent, manageable moment to your therapist. You do not have to search for hidden beliefs, recall painful events or work out what the rule says about your worth. You can leave this open.",
      "sha256": "420fe397205abd4d37e7eab5591603e3b6ac5437d534e2dbf59399db0b9b9619",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.context",
      "title": "Look at the setting and what matters",
      "text": "Where does this rule show up now? What matters in that setting? Think about real duties, power, culture, health, support and safety, not just your thoughts.\n\nIf it helps, notice where you may have learned the rule or what it has helped you protect. You can skip its history. Do not force a reason. Is there a need or value you want to keep?",
      "sha256": "bdb25e85ecc59a7eedfd02080b989ea0cea739f5f9799406e3e189a9bb55a21a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.context.help",
      "title": "If the situation is unfair or unsafe",
      "text": "The answer may be more support or a change in the situation, not a different thought. Do not test a rule by accepting harm or losing needed protection. Pause and talk with your therapist or seek help.",
      "sha256": "aa7061110b799291726b5007757b7248c6107ec2bef8b1529746de003196728b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.effects",
      "title": "Weigh what it helps and what it costs",
      "text": "Think of times you followed this rule. What did it help with? What was hard about it? Notice effects on what you do, how you feel, your time, your needs and your relationships.\n\nKeep useful parts in view. You do not need to list equal good and bad points. If the rule fits your needs, keeping it can make sense. You can stop here and discuss what you found.",
      "sha256": "499cfd86aef4cf881fee67d24d30d4013cb3a63fbb9f86f61f29aa19f39e27b6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.effects.help",
      "title": "If changing feels like giving up",
      "text": "A flexible rule does not have to mean giving up care, effort or a value. It may mean more than one way to meet a need. You do not have to replace a useful rule just because you opened this page.",
      "sha256": "97494f54eeb690841c44aac02ed0eb26d13fe51eb06ad30babb026156d2b6c79",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.check",
      "title": "Check how well the rule fits",
      "text": "What real events support the rule or the result you fear? What events do not fit, or fit only part? Notice when, where and for whom it applies. \"Always\" and \"never\" may leave out important details.\n\nDo not dismiss real risks or unfair treatment. You can notice exceptions without claiming there is no risk. If there is not enough information, leave the question open.",
      "sha256": "2e2e5b11a7c7b858a5201363138e7834412ef95bfbced01b08a8cf8560762c21",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.check.help",
      "title": "If the rule feels true everywhere",
      "text": "You do not need to argue yourself out of it. Tell your therapist what makes it feel true and where you need help. An example on this page is not evidence about your life.",
      "sha256": "33af0760d2e0effeccce164155644de1636d57492550fe64551f1e3204e03df0",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.flexible",
      "title": "Try a fairer, more flexible rule",
      "text": "If you want to explore a change, keep the value or need that matters. Make room for the setting, your limits and more than one way to act. Try words like \"I prefer\", \"sometimes\" or \"I can choose\", only if they fit.\n\nDoes the new rule feel fair and possible, even if you do not fully believe it? It need not promise a good result. You can keep the old rule, try a smaller change or ask your therapist for help.",
      "sha256": "5ef1c56b97b96b2de8f149b10e0a66f42afd3c1a32216105f40fb80793fe420b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.flexible.help",
      "title": "If the new rule sounds too positive",
      "text": "Use words you could mean. \"No one will ever judge me\" promises too much. A fair rule can allow mistakes and real risks without making either one a judgment of your whole worth.",
      "sha256": "08783129f6b049b4fcfc24d48dd1401aed661fc6036d0583947ae32d13eb93a7",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.test",
      "title": "Set out the small test you agreed",
      "text": "Before acting, agree the exact test with your therapist. What small action would try the flexible rule? If you want, note what, where, when and how much you agreed. This page does not choose or approve a test.\n\nWhat does the old rule predict? What other result is possible? Name something you can see, hear or clearly describe that would help you learn. Do not try to guess what is in another person's mind.\n\nKeep needed care, aids and safety steps. Include what might get in the way, when to stop, how to get support and when to review. If you have no agreed test, leave the action open and take the ideas to your therapist.",
      "sha256": "275ce7ba8b965e4b83bb6c789fcf3076e8669667e836a429aaaea04efc024577",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.test.help",
      "title": "If you are unsure whether a test fits",
      "text": "Do not make it harder or guess what to drop. Pause for your therapist's advice. Keep health and safety steps. This page is not for dangerous actions, health changes, exposure exercises or testing an unsafe relationship.",
      "sha256": "d1da4ca4719950f44b7183acf851ad57104500c2512dabbd685072e9dda6906f",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.try",
      "title": "Use the plan only when it fits",
      "text": "A real test happens in your life, not by pressing Next. Use only the plan you agreed. If your needs, the setting or the risks have changed, pause and check before going ahead.\n\nYou can stop, try only part, or decide not to try. Do not repeat the test to force a result or make a rating go down. Review any change to the plan with your therapist.\n\nYou can leave and come back to Review my agreed test. Notes in this page are not saved when you leave or reload. Choose notes to keep first if you want a copy.",
      "sha256": "19d45dbd5c330fa625ffc62ee19d257f2f2c11937cdd587ab99170e49e354df8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.try.help",
      "title": "If you did not try it",
      "text": "You can still review what got in the way or why you stopped. Not trying is not evidence that the feared result happened. You do not need to invent an outcome or catch up on practice.",
      "sha256": "be657554d89a7a671e98910d078561fe5bbf2fa704ee550c9cc7c437a4e94557",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.review",
      "title": "Look at what actually happened",
      "text": "Use this after the planned time, whether you tried all, part or none of the test. What did you actually do? Did the plan change? If there was no attempt, say that or leave the result open.\n\nWhat did you notice? Keep observations apart from guesses. Feelings are real parts of your experience, but they do not show what someone else thought. What is still unknown?\n\nRecall or check your original prediction and the information you planned to notice. If you cannot remember them, leave the comparison open. Do not make up what you expected. Compare the result with the prediction you actually made. Did the facts fit it, partly fit it, point another way or leave it unclear? Do not force a good result.",
      "sha256": "9cf6f0f167b28250fcb9b185b78f952c72c63a1784fb2a33043ee523f392554e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.review.help",
      "title": "If something hurtful or unsafe happened",
      "text": "Take it seriously. Stop and seek the support you need. You do not have to find a positive meaning or blame yourself. Review with your therapist before another test. Use Support and urgent help to find help options.",
      "sha256": "52bc1bc8e31d9564a6998fea899e342ec55488d01f2386a6f49161ebf839a169",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "rules-and-assumptions.practice.learning",
      "title": "Decide what to keep or review",
      "text": "What does this one result suggest about the old rule and the flexible rule? What does it not tell you? It may support a change, a smaller change, keeping the rule or no answer yet.\n\nIf useful, return to the same expectation you rated at the start. Note how sure you feel about it now, using the same words or scale. If you do not remember it, you can skip this. It does not need to be lower. There is no right score.\n\nBring your learning, what got in the way and your questions to your therapist. Agree whether to keep, revise or stop this plan. This page does not set a new test for you. You can finish without deciding yet.",
      "sha256": "622066199db565815fce363ae83f7164bfb4f069451cf0de0f0d4c99a7d3fb7b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "rules-and-assumptions.practice.learning.help",
      "title": "If you want notes for your session",
      "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy.",
      "sha256": "ea01bb4fefac7239db070e2c8026831daf9ba58aa644678f1587ebe73d1080b5",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
