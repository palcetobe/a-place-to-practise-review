
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.BehaviouralActivationModel=api;})(typeof window!=='undefined'?window:globalThis,()=>{
 'use strict';
 function create(content){
  const fieldKeys=new Set([...content.plan,...content.review,content.close].flatMap(x=>(x.fields||[]).map(f=>f.key)));
  let stage='intro',mode='plan',writing=false,notes=Object.create(null),positions={plan:0,review:0},showAll={plan:false,review:false};
  function reset(){stage='intro';mode='plan';writing=false;notes=Object.create(null);positions={plan:0,review:0};showAll={plan:false,review:false};}
  return Object.freeze({
   snapshot:()=>({stage,mode,writing,notes:{...notes},positions:{...positions},showAll:{...showAll}}),
   note:(key,value)=>{if(!fieldKeys.has(key))throw new Error('Unknown field');notes[key]=String(value);},
   mode:next=>{if(!['plan','review'].includes(next))throw new Error('Unknown mode');mode=next;stage='practice';},
   intro:()=>{stage='intro';},close:()=>{stage='close';},resume:()=>{stage='practice';},
   writing:value=>{writing=Boolean(value);},
   position:(index,all=false)=>{positions[mode]=Math.max(0,Math.min(content[mode].length-1,Number(index)||0));showAll[mode]=Boolean(all);},
   personal:()=>Object.values(notes).some(v=>v.trim().length>0),
   reset
  });
 }
 return Object.freeze({create});
});
