
window.BehaviouralActivationContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/ba",
  "routeProposal": "tool/behavioural-activation",
  "version": "2026-11-02-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "title": "Behavioural Activation",
  "subtitle": "Plan one activity and learn from trying it",
  "scope": "Activity monitoring, planning and review component; not a complete course of Behavioural Activation treatment.",
  "clinicalContract": {
    "learningObjective": "Recognise how an activity pattern can affect opportunities for meaning, connection or accomplishment, without treating all rest as avoidance.",
    "practiceObjective": "Notice one recent pattern; choose a meaningful feasible activity and opportunity; try it when appropriate; review the attempt and one possible adjustment.",
    "observedPractice": "A privately considered or optionally written pattern, specific activity, opportunity and later review. Planning is not counted as performing the activity. Symptom reduction is not a completion criterion.",
    "boundaries": [
      "Do not prescribe exercise, sleep change or activity beyond agreed health or access limits.",
      "Do not label low mood, rest, disability, fatigue or material constraints as laziness.",
      "When severe deterioration, markedly increased activity/reduced sleep, medical limits or urgent risk need assessment, direct to appropriate support rather than increasing tasks.",
      "Not a Graded Task Assignment replacement, mood diagnostic or stand-alone treatment.",
      "A session-only tool cannot provide a longitudinal treatment diary. A therapist may agree a separate accessible record."
    ],
    "sourcePopulationContext": "ABCT describes Behavioural Activation across age groups; NICE NG222 assessment guidance covers adults aged 18 and over. Neither source validates this digital adaptation or establishes its suitability for every age. Therapist selection and adaptation should account for development, communication, consent, privacy, safeguarding, health and circumstances."
  },
  "intro": {
    "id": "ba.intro",
    "title": "A place to begin",
    "paragraphs": [
      "When life feels hard, some activities can fall away. That may leave fewer chances for connection, care, enjoyment or a sense of doing something that matters.",
      "This practice helps you notice one pattern, plan one activity that fits your life, and learn from trying it. You do not have to feel motivated first, or feel better afterwards.",
      "Rest can be useful too. Choose an activity that fits your health, energy, safety and what is possible today. You can pause, stop or ask for support."
    ],
    "scopeNote": "This is one practice within Behavioural Activation, not a full treatment programme.",
    "actions": [
      {
        "id": "plan",
        "label": "Plan an activity",
        "description": "Notice a pattern and choose one realistic activity."
      },
      {
        "id": "review",
        "label": "Review an activity I tried or planned",
        "description": "Look at what happened, including if it did not happen."
      }
    ]
  },
  "learn": {
    "id": "ba.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "What we do and how we feel can affect each other. Pulling back may bring short-term relief, but sometimes it also takes us further from things that matter.",
      "Behavioural Activation uses planned activities and review to learn what helps. An activity may offer care, enjoyment, connection, meaning or accomplishment. It is not a test of how busy or productive you can be.",
      "A small, realistic attempt can give you something to learn from. Mood may change slowly, stay the same or vary for other reasons. Look at what happened, not just whether you felt better.",
      "This page works with one activity at a time. You and your therapist can decide whether a longer activity record would be useful."
    ]
  },
  "example": {
    "id": "ba.example",
    "title": "Example — making room for connection",
    "paragraphs": [
      "Alex has stopped contacting a friend. Scrolling each evening puts off the effort of a message, but Alex notices feeling more cut off afterwards.",
      "Connection matters to Alex. A long visit feels too much, so Alex chooses one friendly text after lunch tomorrow. A short draft is ready if finding words is hard.",
      "Alex sends the text. Mood stays low and the reply is delayed. That does not make the attempt pointless.",
      "In review, Alex notices that the lunchtime cue helped and the valued contact happened. Alex can keep this plan, change it, choose another activity or leave the next decision open. There is no need to make another plan now."
    ],
    "note": "Your activity may be different. Use something that matters to you and fits your circumstances."
  },
  "plan": [
    {
      "id": "ba.plan.notice",
      "title": "Notice one recent pattern",
      "paragraphs": [
        "Think of a recent part of your day. What did you do, or put off? What did you notice afterwards?",
        "For example, did the pattern make room for care or connection, help you rest, or leave something important harder to reach? You do not have to judge it as good or bad."
      ],
      "fields": [
        {
          "key": "pattern",
          "label": "What I did or put off and what I noticed",
          "optional": true
        }
      ],
      "help": {
        "title": "If a pattern is hard to see",
        "text": "Use one recent moment rather than your whole week. You can also leave this open and choose one activity you would like to try."
      }
    },
    {
      "id": "ba.plan.choose",
      "title": "Choose one activity that matters",
      "paragraphs": [
        "What would you like a little more room for? It could be care, connection, enjoyment, a useful task or something else that matters to you.",
        "Choose one activity you can picture doing. “Spend time with music” could become “listen to one song.” Choose your own example; it does not have to be a task or involve another person."
      ],
      "fields": [
        {
          "key": "activity",
          "label": "An activity I want to try",
          "optional": true
        },
        {
          "key": "reason",
          "label": "Why it matters to me",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing sounds enjoyable",
        "text": "You do not need to feel excited. Consider something that used to matter, a small act of care, or a neutral activity you are willing to try. Rest may fit your needs. You can also stop and discuss options with your therapist."
      }
    },
    {
      "id": "ba.plan.opportunity",
      "title": "Make room for the activity",
      "paragraphs": [
        "When or after what usual event could you try it? Where would it fit?",
        "Choose a size that fits your energy, time, access and health needs. If it is too much, shorten it, change it or choose something else."
      ],
      "fields": [
        {
          "key": "opportunity",
          "label": "When or after what event I could try it",
          "optional": true
        },
        {
          "key": "place",
          "label": "Where or what I need",
          "optional": true
        }
      ],
      "help": {
        "title": "If the activity feels too big",
        "text": "Choose a smaller version or a different activity. You do not need to push past pain, exhaustion, health advice or safety limits. A separate task-breaking skill can help later if that is what you need."
      }
    },
    {
      "id": "ba.plan.barrier",
      "title": "Allow for a difficulty",
      "paragraphs": [
        "What might get in the way? Consider one change or kind of support that could make the activity more workable.",
        "If you cannot see a useful change, you can leave this open. The plan is something to try, not a promise you must keep."
      ],
      "fields": [
        {
          "key": "barrier",
          "label": "One possible difficulty",
          "optional": true
        },
        {
          "key": "adjustment",
          "label": "A change or support that might help",
          "optional": true
        }
      ],
      "help": {
        "title": "If the barrier is outside your control",
        "text": "Cost, access, caring demands, health and other people can affect what is possible. This is information about the plan, not a personal failure. Choose what is workable or bring the problem to your therapist."
      }
    },
    {
      "id": "ba.plan.try",
      "title": "Try it when it fits",
      "paragraphs": [
        "Bring your activity and chosen opportunity to mind. You can try a small part now if it is safe and practical, or leave the page and try it at the time you chose.",
        "Afterwards, return to “Review an activity I tried or planned.” You can review an attempt even if you did not finish or could not begin.",
        "A click here does not record the activity as done. This page does not send reminders or share a plan with your therapist."
      ],
      "fields": [],
      "help": {
        "title": "Keeping your plan",
        "text": "You can remember it privately or note it somewhere you choose off this page. Optional writing here is cleared when you leave this tool or reload; it is not a saved diary."
      }
    }
  ],
  "review": [
    {
      "id": "ba.review.happened",
      "title": "Look at what happened",
      "paragraphs": [
        "Bring the activity you planned to mind. Did you try it, try part of it, or not get to it?",
        "Notice what actually happened without marking yourself as a success or failure. If you did not make a plan first, you can review an activity you chose during the day."
      ],
      "fields": [
        {
          "key": "reviewActivity",
          "label": "The activity I am reviewing",
          "optional": true
        },
        {
          "key": "happened",
          "label": "What happened",
          "optional": true
        }
      ],
      "help": {
        "title": "If it did not happen",
        "text": "You can still use this review. Notice what got in the way. The aim is to understand the plan and your circumstances, not to blame yourself."
      }
    },
    {
      "id": "ba.review.notice",
      "title": "Notice what you learned",
      "paragraphs": [
        "What did you notice about the activity, your energy, your mood or what mattered to you? It is okay if the answer is unclear.",
        "An activity can matter even when your mood does not improve. It can also turn out not to fit. Notice what the experience tells you."
      ],
      "fields": [
        {
          "key": "learning",
          "label": "What I noticed or learned",
          "optional": true
        }
      ],
      "help": {
        "title": "If your mood stayed the same",
        "text": "That is a possible result, not a failed exercise. Consider whether the activity was workable or meaningful, and discuss repeated difficulties or worsening symptoms with your therapist."
      }
    },
    {
      "id": "ba.review.adjust",
      "title": "Keep what fits or adjust",
      "paragraphs": [
        "Would you keep the activity as it is, change the timing or size, try something else, or leave the next step open?",
        "You can finish without deciding. If useful, bring one observation to your next session. Nothing is sent to your therapist from this page."
      ],
      "fields": [
        {
          "key": "next",
          "label": "Something to keep, change or discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If choosing another step feels like more pressure",
        "text": "Leave it here. Reviewing what happened is enough for this visit. A new activity is not required to finish."
      }
    }
  ],
  "close": {
    "id": "ba.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "You can finish here. A plan, an attempt and a review are different parts of the practice. You do not need to have completed all three today.",
      "If useful, notice one thing you want to remember. You can keep it private or skip reflecting."
    ],
    "fields": [
      {
        "key": "reflection",
        "label": "Something I want to remember",
        "optional": true
      }
    ],
    "actions": [
      "Return to my practice",
      "Finish and clear"
    ]
  },
  "privacy": {
    "id": "ba.privacy",
    "paragraphs": [
      "Writing is optional. You can think privately, say a few words off-device or use your own paper.",
      "Notes stay only in this open practice. Back and the example or learning view keep them. Leaving the tool, reloading, clearing or starting again removes them.",
      "No notes are sent for narration or shared with your therapist. This page is not monitored. It does not save a diary, schedule reminders or keep a plan across devices."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "destination": "Reuse the existing verified project support route; do not invent a new contact destination.",
    "placement": "Always available outside focus folds and before mode selection.",
    "noAutomaticAdvice": "Do not assess risk from text, mood or completion; do not prescribe activity."
  },
  "interactionContract": {
    "modes": [
      "plan",
      "review"
    ],
    "modeChange": "Offer both from intro. Changing mode retains existing session-only notes unless explicit clear; never implies the activity occurred.",
    "focus": "Shared GuidedFocusComponents; one prompt group, free jump, Show all, contextual example and Finish always usable.",
    "writing": "Hidden by default; showing optional writing never gates prompt navigation. Hide all user-authored displays including summary.",
    "summary": "Optional plan summary may echo only typed fields while writing is shown. Label it as a plan, not a completed activity. Do not reconstruct untyped private thought.",
    "timer": "No timer required or proposed.",
    "persistence": "Session-only; no localstorage, backend, personal export or reminders in this build.",
    "narration": "Exact visible content only; established voice; generated scripts below. No liveaudio claim until matching assets, listening QA and integration succeed. Use honest disabled controls if not ready.",
    "visual": "Optional static Plan → Try → Notice → Adjust orientation, text-equivalent; no progress score or completion animation.",
    "icon": "Neutral entry; no new per-skill icon or inferred goal branding."
  },
  "sources": [
    {
      "id": "abct-ba",
      "url": "https://www.abct.org/fact-sheets/behavioral-activation/",
      "reviewed": "2026-11-02",
      "supports": "Activity monitoring, meaningful/rewarding activity scheduling, barriers and repeated review; supports broad approach not exactdigitalprocedure."
    },
    {
      "id": "cci-ba",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Consumer-Modules/Back-from-The-Bluez/Back-from-the-Bluez---02---Behavioural-Strategies.pdf",
      "reviewed": "2026-11-02",
      "supports": "Feasible activity selection, smallrealisticsteps, scheduling and review; sources adultoriented selfhelp, not validation for16–17 app."
    },
    {
      "id": "nice-fit",
      "url": "https://www.nice.org.uk/guidance/ng222/chapter/Recommendations",
      "reviewed": "2026-11-02",
      "supports": "Adult assessment considers mood elevation, functional impairment, physical health and context. Supports professional fit review, not digital assessment or diagnosis."
    }
  ],
  "productAdaptations": [
    "One recent pattern and one planned activity rather than full treatment diary.",
    "Plan and return-review modes inside one canonical component.",
    "Optional typing, no rating requirement, no mandatory new plan at close.",
    "Original Alex example with unchanged mood and actual review.",
    "Clinical-fit caution and session-only privacy semantics; not a validated protocol."
  ],
  "fit": {
    "id": "ba.fit",
    "title": "Is this a useful fit right now?",
    "paragraphs": [
      "This practice is designed for use with your therapist between sessions.",
      "If daily life is getting much harder, or your health or energy has changed a lot, speak with your therapist or a healthcare professional. If you feel unusually full of energy or driven to do much more while needing much less sleep, get professional advice promptly. A bigger activity plan may not be what you need.",
      "Keep activities within your health and safety needs. This tool does not assess those needs. Use support or urgent help when needed; you do not have to finish the practice first."
    ],
    "placement": "Visible short scope line on intro; full fit panel accessible from intro and Learn more. Support remains separate and always visible."
  },
  "narrationSegments": [
    {
      "id": "ba.intro",
      "title": "A place to begin",
      "text": "When life feels hard, some activities can fall away. That may leave fewer chances for connection, care, enjoyment or a sense of doing something that matters.\n\nThis practice helps you notice one pattern, plan one activity that fits your life, and learn from trying it. You do not have to feel motivated first, or feel better afterwards.\n\nRest can be useful too. Choose an activity that fits your health, energy, safety and what is possible today. You can pause, stop or ask for support.",
      "status": "Script only; no generated or listening-approved audio asserted"
    },
    {
      "id": "ba.fit",
      "title": "Is this a useful fit right now?",
      "text": "This practice is designed for use with your therapist between sessions.\n\nIf daily life is getting much harder, or your health or energy has changed a lot, speak with your therapist or a healthcare professional. If you feel unusually full of energy or driven to do much more while needing much less sleep, get professional advice promptly. A bigger activity plan may not be what you need.\n\nKeep activities within your health and safety needs. This tool does not assess those needs. Use support or urgent help when needed; you do not have to finish the practice first.",
      "status": "Script only; no generated or listening-approved audio asserted"
    },
    {
      "id": "ba.learn",
      "title": "Why this skill may help",
      "text": "What we do and how we feel can affect each other. Pulling back may bring short-term relief, but sometimes it also takes us further from things that matter.\n\nBehavioural Activation uses planned activities and review to learn what helps. An activity may offer care, enjoyment, connection, meaning or accomplishment. It is not a test of how busy or productive you can be.\n\nA small, realistic attempt can give you something to learn from. Mood may change slowly, stay the same or vary for other reasons. Look at what happened, not just whether you felt better.\n\nThis page works with one activity at a time. You and your therapist can decide whether a longer activity record would be useful.",
      "status": "Script only; no generated or listening-approved audio asserted"
    },
    {
      "id": "ba.example",
      "title": "Example — making room for connection",
      "text": "Alex has stopped contacting a friend. Scrolling each evening puts off the effort of a message, but Alex notices feeling more cut off afterwards.\n\nConnection matters to Alex. A long visit feels too much, so Alex chooses one friendly text after lunch tomorrow. A short draft is ready if finding words is hard.\n\nAlex sends the text. Mood stays low and the reply is delayed. That does not make the attempt pointless.\n\nIn review, Alex notices that the lunchtime cue helped and the valued contact happened. Alex can keep this plan, change it, choose another activity or leave the next decision open. There is no need to make another plan now.",
      "status": "Script only; no generated or listening-approved audio asserted"
    },
    {
      "id": "ba.close",
      "title": "Leave it here for now",
      "text": "You can finish here. A plan, an attempt and a review are different parts of the practice. You do not need to have completed all three today.\n\nIf useful, notice one thing you want to remember. You can keep it private or skip reflecting.",
      "status": "Script only; no generated or listening-approved audio asserted"
    },
    {
      "id": "ba.privacy",
      "title": "privacy",
      "text": "Writing is optional. You can think privately, say a few words off-device or use your own paper.\n\nNotes stay only in this open practice. Back and the example or learning view keep them. Leaving the tool, reloading, clearing or starting again removes them.\n\nNo notes are sent for narration or shared with your therapist. This page is not monitored. It does not save a diary, schedule reminders or keep a plan across devices.",
      "status": "Script only; no generated or listening-approved audio asserted"
    },
    {
      "id": "ba.plan.notice",
      "title": "Notice one recent pattern",
      "text": "Think of a recent part of your day. What did you do, or put off? What did you notice afterwards?\n\nFor example, did the pattern make room for care or connection, help you rest, or leave something important harder to reach? You do not have to judge it as good or bad.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.notice.help",
      "title": "If a pattern is hard to see",
      "text": "Use one recent moment rather than your whole week. You can also leave this open and choose one activity you would like to try.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.choose",
      "title": "Choose one activity that matters",
      "text": "What would you like a little more room for? It could be care, connection, enjoyment, a useful task or something else that matters to you.\n\nChoose one activity you can picture doing. “Spend time with music” could become “listen to one song.” Choose your own example; it does not have to be a task or involve another person.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.choose.help",
      "title": "If nothing sounds enjoyable",
      "text": "You do not need to feel excited. Consider something that used to matter, a small act of care, or a neutral activity you are willing to try. Rest may fit your needs. You can also stop and discuss options with your therapist.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.opportunity",
      "title": "Make room for the activity",
      "text": "When or after what usual event could you try it? Where would it fit?\n\nChoose a size that fits your energy, time, access and health needs. If it is too much, shorten it, change it or choose something else.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.opportunity.help",
      "title": "If the activity feels too big",
      "text": "Choose a smaller version or a different activity. You do not need to push past pain, exhaustion, health advice or safety limits. A separate task-breaking skill can help later if that is what you need.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.barrier",
      "title": "Allow for a difficulty",
      "text": "What might get in the way? Consider one change or kind of support that could make the activity more workable.\n\nIf you cannot see a useful change, you can leave this open. The plan is something to try, not a promise you must keep.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.barrier.help",
      "title": "If the barrier is outside your control",
      "text": "Cost, access, caring demands, health and other people can affect what is possible. This is information about the plan, not a personal failure. Choose what is workable or bring the problem to your therapist.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.try",
      "title": "Try it when it fits",
      "text": "Bring your activity and chosen opportunity to mind. You can try a small part now if it is safe and practical, or leave the page and try it at the time you chose.\n\nAfterwards, return to “Review an activity I tried or planned.” You can review an attempt even if you did not finish or could not begin.\n\nA click here does not record the activity as done. This page does not send reminders or share a plan with your therapist.",
      "status": "Script only"
    },
    {
      "id": "ba.plan.try.help",
      "title": "Keeping your plan",
      "text": "You can remember it privately or note it somewhere you choose off this page. Optional writing here is cleared when you leave this tool or reload; it is not a saved diary.",
      "status": "Script only"
    },
    {
      "id": "ba.review.happened",
      "title": "Look at what happened",
      "text": "Bring the activity you planned to mind. Did you try it, try part of it, or not get to it?\n\nNotice what actually happened without marking yourself as a success or failure. If you did not make a plan first, you can review an activity you chose during the day.",
      "status": "Script only"
    },
    {
      "id": "ba.review.happened.help",
      "title": "If it did not happen",
      "text": "You can still use this review. Notice what got in the way. The aim is to understand the plan and your circumstances, not to blame yourself.",
      "status": "Script only"
    },
    {
      "id": "ba.review.notice",
      "title": "Notice what you learned",
      "text": "What did you notice about the activity, your energy, your mood or what mattered to you? It is okay if the answer is unclear.\n\nAn activity can matter even when your mood does not improve. It can also turn out not to fit. Notice what the experience tells you.",
      "status": "Script only"
    },
    {
      "id": "ba.review.notice.help",
      "title": "If your mood stayed the same",
      "text": "That is a possible result, not a failed exercise. Consider whether the activity was workable or meaningful, and discuss repeated difficulties or worsening symptoms with your therapist.",
      "status": "Script only"
    },
    {
      "id": "ba.review.adjust",
      "title": "Keep what fits or adjust",
      "text": "Would you keep the activity as it is, change the timing or size, try something else, or leave the next step open?\n\nYou can finish without deciding. If useful, bring one observation to your next session. Nothing is sent to your therapist from this page.",
      "status": "Script only"
    },
    {
      "id": "ba.review.adjust.help",
      "title": "If choosing another step feels like more pressure",
      "text": "Leave it here. Reviewing what happened is enough for this visit. A new activity is not required to finish.",
      "status": "Script only"
    }
  ]
}
;
