window.EmotionRegulationTroubleshootingContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/emotion-awareness",
  "componentId": "component/emotion-awareness/troubleshooting-emotion-regulation",
  "resourceId": "tool/emotion-regulation-troubleshooting",
  "routeProposal": "/emotion-regulation-troubleshooting/",
  "title": "Troubleshooting Emotion Regulation",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Therapist-guided review of an emotion-regulation skill already learned: examine six possible obstacles, select a specifically matched previously taught or individually agreed response, distinguish actual use from plans, and review before another check or clinical support.",
  "groupedSetStatus": "Existing uncounted component under classic/emotion-awareness. Complete bounded troubleshooting companion, not standalone treatment, instruction in every response skill, full emotion-regulation curriculum or proof of clinical readiness. No new canonical count.",
  "clinicalContract": {
    "learningObjective": "Distinguish an obstacle hypothesis from a fact or blame; connect each relevant check to its own response family and actual result rather than treating six categories as interchangeable reflection.",
    "practiceObjective": "Describe the attempted skill and concern, consider ordered checks with an early overload/safety boundary, agree a matched response, actually try it when appropriate, and record helped/not helped/unclear/not tried before stopping, moving to another check or seeking coaching.",
    "sourcePopulationContext": "2015 author/publisher DBT Handout24, Worksheet16 and ManualXXIII inform this original review companion. Prior instruction and individualized response planning are required. No age floor or all-age efficacy claim; clinical, developmental, cultural, communication, safeguarding and access fit remain necessary.",
    "exclusions": [
      "No new medical advice, medication changes, food/sleep/exercise targets, substance withdrawal or PLEASE prescription",
      "No new TIP, deliberate arousal, body exposure, trauma recall or crisis-management instructions",
      "No punishment, manipulation, control of another person, withholding essential care or attribution of deliberate emotionality",
      "No automatic obstacle diagnosis, routing, symptom score, success inference or claim that distress proves insufficient effort",
      "No demand to remove justified emotions, accept abuse, repeat until calm or finish every check",
      "No full DBT programme, reproduction of source forms or validation claim for this app"
    ],
    "adaptations": [
      "Original plain-language questions and case; optional notes, no compulsory ratings or source checkbox form",
      "Six source checks retained in order with matched response families and result/next-check logic; free navigation never counts as completing checks",
      "Current safety/overload reviewed before entry as well as within check5; no automated clinical triage",
      "Use only previously taught or individually agreed responses; unavailable or unsuitable response leads to clinician review rather than substitute or completed-method claim",
      "Time/effort check includes capacity, support, access and consent without erasing the role of practice; reinforcement remains a hypothesis, not presumed intent"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of bounded companion scope, named dependencies, source adaptations and release rights",
      "Individual prior teaching, agreed responses, clinical/developmental/communication/cultural fit, consent and safeguarding",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script audio production and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose troubleshooting or later review",
      "options": [
        {
          "value": "prepare",
          "label": "Work through a skill difficulty",
          "startSectionId": "emotion-regulation-troubleshooting.practice.situation"
        },
        {
          "value": "review",
          "label": "Review an agreed response or no attempt",
          "startSectionId": "emotion-regulation-troubleshooting.practice.review"
        }
      ]
    },
    "entryGate": "Scope and current safety/overload boundaries visible before entry. No default mode or fit inferred.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence, writing, emotion label or completed check.",
    "reviewAccess": "Direct blank review identifies the check, matched response and actual outcome without stored plans or an inferred attempt; all six checks remain available for a next cycle.",
    "writing": "Optional and hidden initially; hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording or autoplay.",
    "timer": "None. No dose, practice quota, intensity rating or mandatory repetition.",
    "completion": "No inferred obstacle, motive, attempt, improvement, full procedure, clinical suitability or learning."
  },
  "intro": {
    "id": "emotion-regulation-troubleshooting.intro",
    "title": "Look at why a learned skill did not seem to help",
    "paragraphs": [
      "A skill can be hard to use for many reasons. This review helps you and your therapist look at one attempt without deciding that you or the skill failed. It is for skills you have already learned, not a lesson in every skill named here.",
      "After checking that review fits now, start with the first of six checks. If a check seems relevant, agree a matching response: a next step that fits what got in the way. Use the planning and trying sections when needed, then return to record what actually happened. If it did not help or remains unclear, consider the next check or ask for support. You can stop without checking everything.",
      "If you are returning after an agreed response, choose review. You can also use the made-up example or finish. Reading, planning, trying and getting help are different actions; this page never assumes one happened."
    ]
  },
  "fit": {
    "id": "emotion-regulation-troubleshooting.fit",
    "title": "Check whether a review fits right now",
    "paragraphs": [
      "Use an ordinary, manageable skill difficulty after your therapist has introduced this review. Agree which responses you know, what support you can use and when to stop. You do not need a perfect emotion word, a score or private details.",
      "If you are too upset to follow these questions, feel cut off from your surroundings or have urgent safety or care needs, pause the review. Use your existing support plan or seek real-world help. Do not push through the six checks. This page does not assess risk, monitor you or provide urgent care.",
      "Respond to danger, abuse, discrimination, pain and practical problems. A feeling can point to something that needs protection or change. This is not a task to make yourself accept harmful treatment or hide a justified feeling.",
      "If health or care concerns may be involved, ask a suitable professional. Keep your agreed care plan. This page does not advise changes to medication, food, sleep, movement or substance use, or teach physical techniques. Use speech, signing, communication aids, private thought or the example; writing and body attention are not required."
    ]
  },
  "privacy": {
    "id": "emotion-regulation-troubleshooting.privacy",
    "title": "Keep only the notes you choose",
    "paragraphs": [
      "Notes are optional. Use a few words or the made-up example. No voice is recorded and no message is sent to a therapist or anyone else.",
      "Writing stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.",
      "Hiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox."
    ]
  },
  "close": {
    "id": "emotion-regulation-troubleshooting.close",
    "title": "Finish with a result, a question or a pause",
    "paragraphs": [
      "You can finish after reading, planning, trying, reviewing, stopping or deciding not to use this practice. A question for your therapist can be enough. You do not need to feel calmer or prove that a response worked.",
      "No report, reminder or follow-up is created. Leaving clears notes from this tool, not copies elsewhere."
    ]
  },
  "example": {
    "id": "emotion-regulation-troubleshooting.example",
    "title": "A made-up review: a missing page",
    "paragraphs": [
      "Alex is frustrated because a page is missing from a hobby booklet. Alex tried a familiar calming skill, hoping that feeling calmer would help Alex get back to the hobby. The missing page was still a practical block. With a therapist, Alex chooses this small event rather than a more upsetting problem.",
      "At the care check, Alex knows of no relevant change in health or care, but leaves room for uncertainty. No treatment change is proposed. At the skill check, Alex sees a mismatch: the calming skill did not replace a step for getting the missing page. That does not mean Alex used it badly.",
      "The therapist helps Alex review the practical problem-solving skill already taught. They agree to check whether a spare copy of the page is available. Alex tries this and finds one. Alex is still a little frustrated, but can continue the hobby. The practical result helped; a different feeling was not promised.",
      "Alex records the matched response and the actual result, then stops this review. Alex does not need to invent answers to the remaining checks. If no copy had been available, that would be a different result to discuss, not proof of laziness or hidden motives. A future attempt would need its own plan."
    ]
  },
  "learn": {
    "id": "emotion-regulation-troubleshooting.learn",
    "title": "Keep the obstacle and the response connected",
    "paragraphs": [
      "Emotion regulation means working with emotions and related actions. It does not always mean making a feeling smaller. A useful goal may be to act safely, solve a practical problem or understand what support is missing.",
      "The six checks cover care and health factors; skill fit and use; what may keep a pattern going; practice and access; overload; and rules about emotions. More than one may matter. A guess is not a diagnosis or proof of why you felt something.",
      "Each check points to different support or learned skills. Do not swap in any activity just because it sounds helpful. If you do not know the matched response, ask for teaching or coaching. This page does not teach all those methods.",
      "The source uses an ordered worksheet with ratings and response checks. This companion keeps the check, matching response and result loop, but makes writing and ratings unnecessary. It adds an early safety pause and leaves clinical decisions to your therapist.",
      "The aim is a clear next step, including no further practice when it does not fit. Repeated checking for certainty, forcing an emotion away or blaming yourself are reasons to pause and review the approach."
    ]
  },
  "practice": [
    {
      "id": "emotion-regulation-troubleshooting.practice.situation",
      "title": "Describe the skill difficulty",
      "paragraphs": [
        "Which learned skill did you try, in what ordinary situation, and what did you hope it would help with? Describe what you actually did. If you only planned or read about it, keep that clear.",
        "What happened afterward? You can describe a feeling, action, practical result or uncertainty. There is no required score. Ask whether changing the emotion is the goal, or whether safety, a real problem or another need comes first."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The situation and skill already learned",
          "optional": true
        },
        {
          "key": "goal",
          "label": "What I hoped the skill would help with",
          "optional": true
        },
        {
          "key": "original-result",
          "label": "What I actually did and what happened",
          "optional": true
        }
      ],
      "help": {
        "title": "If there was no attempt",
        "text": "You can prepare with the example or ask for help learning a skill. Do not invent an unsuccessful attempt so the questions fit."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.care",
      "title": "Check 1: health and care factors",
      "paragraphs": [
        "Could illness, pain, disrupted sleep, food access, substance effects or another care issue have made this attempt harder? Notice only what you already know; do not search for symptoms or diagnose yourself.",
        "If relevant or unclear, discuss the care issue with the right professional and use your existing agreed plan. Your therapist may review PLEASE skills with you. This page gives no treatment, medication or lifestyle changes. If no issue is known, move to the next check. After an agreed response, record what happened; no help or uncertainty can lead to another check or support."
      ],
      "fields": [
        {
          "key": "care-evidence",
          "label": "What is known, unclear or not relevant about care",
          "optional": true
        },
        {
          "key": "care-response",
          "label": "The agreed care response or person to ask",
          "optional": true
        },
        {
          "key": "care-result",
          "label": "Actual result, not tried or waiting for support",
          "optional": true
        }
      ],
      "help": {
        "title": "If I wonder about medication",
        "text": "Ask your prescriber or pharmacist. Do not start, stop, skip, replace or change a medicine because of this review."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.skill",
      "title": "Check 2: skill choice and use",
      "paragraphs": [
        "Was this skill a good match for the situation and goal? Compare what you actually did with the instructions your therapist taught. Do not treat an unchanged feeling as proof that you used it wrongly.",
        "If a step or the choice is unclear, reread your agreed guide or get coaching. The response may be learning a missing step or selecting a better-matched skill with your therapist. Try only when the plan fits, then review the result. If the skill was suitable and used as agreed but did not help, consider the next check."
      ],
      "fields": [
        {
          "key": "skill-evidence",
          "label": "What matched the taught skill, or remains unclear",
          "optional": true
        },
        {
          "key": "skill-response",
          "label": "The specific instruction, coaching or skill change agreed",
          "optional": true
        },
        {
          "key": "skill-result",
          "label": "What I tried and whether it helped, or not tried",
          "optional": true
        }
      ],
      "help": {
        "title": "If an instruction does not fit my access needs",
        "text": "Ask for an agreed adaptation. Needing a cue, aid, more time or another way to communicate is not a lack of effort. Do not force a step that is unsafe or inaccessible."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.functions",
      "title": "Check 3: what may keep the pattern going",
      "paragraphs": [
        "Could what happens after an emotional response make that pattern more likely again? For example, it might bring needed support, help you act, confirm a belief or feel rewarding. These are possibilities to explore, not proof that you chose distress or tried to control someone.",
        "If unsure, review the emotion’s function with your therapist. A matched response might be a learned way to ask directly for support, another source of encouragement, self-validation, or pros and cons of changing the pattern. Keep the real need in view. Do not withhold care or punish anyone. After an agreed response, record its result; if this check does not fit or does not help, move on or seek coaching."
      ],
      "fields": [
        {
          "key": "functions-evidence",
          "label": "A possible pattern, evidence or uncertainty",
          "optional": true
        },
        {
          "key": "functions-response",
          "label": "The matched learned response or question for coaching",
          "optional": true
        },
        {
          "key": "functions-result",
          "label": "Actual result or response not tried",
          "optional": true
        }
      ],
      "help": {
        "title": "If this sounds like blaming me",
        "text": "You do not need to agree that a pattern exists. Needing support is real. Continued distress alone does not show a hidden benefit, choice or motive."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.effort",
      "title": "Check 4: practice, time and access",
      "paragraphs": [
        "Did you have the time, energy, access and support needed to use the skill as agreed? What practice actually happened? Keep lack of opportunity, a hard step, uncertainty about the goal and choosing not to practise separate.",
        "If this check fits, discuss which learned response matches. Options include problem solving for access or time, pros and cons of practice, radical acceptance of what is true, willingness to try, or mindful participation and effectiveness: joining in and doing what works. Agree a realistic step with your therapist, not a quota or demand to try harder. If practice was possible and used as agreed, review its result and consider another check when needed."
      ],
      "fields": [
        {
          "key": "effort-evidence",
          "label": "Actual practice, opportunity, barriers or choice",
          "optional": true
        },
        {
          "key": "effort-response",
          "label": "The specific access, planning or learned-skill response agreed",
          "optional": true
        },
        {
          "key": "effort-result",
          "label": "Actual result, no opportunity or not tried",
          "optional": true
        }
      ],
      "help": {
        "title": "If I do not want to practise",
        "text": "You can say that and explore the reasons without a penalty. Consent, disability, fatigue and unmet support needs are not problems to punish."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.overload",
      "title": "Check 5: was the task too complex at that moment?",
      "paragraphs": [
        "Were you able to take in the steps, or were emotions so strong that a complex skill was not usable? If that is happening now, pause this review and use agreed support. You do not have to prove a level of distress.",
        "With enough capacity and support, a problem that can be solved now may call for your learned problem-solving skill. If it cannot be solved now, your therapist may select mindfulness of current emotions if suitable and already taught. If thinking through skills is not possible, use your existing crisis-support plan or seek help instead. TIP and other crisis skills need their own teaching and fit checks; this page does not instruct them.",
        "Record only what you actually used and what followed. Return to review when it fits, not when a timer ends or a feeling reaches a target. If this check does not explain the difficulty, another check may be useful."
      ],
      "fields": [
        {
          "key": "overload-evidence",
          "label": "What I could or could not manage at the time",
          "optional": true
        },
        {
          "key": "overload-response",
          "label": "The matched response and support already agreed",
          "optional": true
        },
        {
          "key": "overload-result",
          "label": "What actually happened, paused or not tried",
          "optional": true
        }
      ],
      "help": {
        "title": "If body-focused mindfulness is not suitable",
        "text": "If focusing on your body is not suitable, pause. Ask your therapist which plan to use instead. This page does not teach that plan."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.myths",
      "title": "Check 6: rules about emotions",
      "paragraphs": [
        "Did a rule about feelings get in the way, such as believing that a strong feeling must decide your next action? You can name a belief you already noticed without searching for harsher thoughts.",
        "If relevant, use checking facts and nonjudgmental thinking already taught by your therapist to examine the belief. A feeling is real, but it need not settle every fact, identity or action. Do not debate away danger, injustice or your need for support. Try the agreed response if suitable, then record whether it helped. If no check fits or helps, ask for review rather than starting the loop over and over."
      ],
      "fields": [
        {
          "key": "myths-evidence",
          "label": "A belief that may have got in the way, or none known",
          "optional": true
        },
        {
          "key": "myths-response",
          "label": "The matched fact-checking or nonjudgmental response agreed",
          "optional": true
        },
        {
          "key": "myths-result",
          "label": "Actual result, unclear or not tried",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am unsure whether it is a myth",
        "text": "Leave it as a question. The page does not decide which beliefs are false or tell you how you should feel."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.plan",
      "title": "Plan one matched response",
      "paragraphs": [
        "Name the check you are working on and the specific response that follows from it. Use a skill already taught or a step individually agreed with the right professional. If you need teaching, care advice or a safety plan, seeking that support is the next step.",
        "Decide what you will actually do, what support or cue you need, when the situation is suitable and what would mean pause. Choose a useful way to review the outcome, such as whether a practical step became possible. A different feeling is not required."
      ],
      "fields": [
        {
          "key": "plan-check",
          "label": "The check and why this response matches",
          "optional": true
        },
        {
          "key": "plan-response",
          "label": "The agreed response, setting, support and limits",
          "optional": true
        },
        {
          "key": "plan-review",
          "label": "What result or question I will review",
          "optional": true
        }
      ],
      "help": {
        "title": "If I have several possible responses",
        "text": "Choose with your therapist rather than trying them all. Keep the reason for the choice clear, including what is still unknown."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.try",
      "title": "Try the agreed response when it fits",
      "paragraphs": [
        "If the plan is suitable and already agreed, carry out the actual response with the support you need. Reading this step or writing a plan is preparation, not proof that you used the response.",
        "You can pause, stop, seek support or decide not to try. Do not repeat until calm or force a result. Later, return to the relevant check or review section and describe what really happened."
      ],
      "fields": [
        {
          "key": "actual-try",
          "label": "What I actually tried, stopped or did not try",
          "optional": true
        },
        {
          "key": "try-context",
          "label": "Relevant circumstances or support used",
          "optional": true
        }
      ],
      "help": {
        "title": "If no suitable chance comes up",
        "text": "Keep that separate from a response that was tried and did not help. No missed-practice debt or automatic next attempt is created."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.review",
      "title": "Review the response and choose the next check",
      "paragraphs": [
        "Which check and matched response are you reviewing? What did you actually try, if anything? You can start here with no notes, no earlier plan and no attempt. Do not fill in a past step that did not happen.",
        "Did the response help with the goal, not help, make things harder, remain unclear or go untried? Describe any practical result and relevant feeling without forcing a score or improvement. Planning alone cannot show whether the response worked.",
        "If it helped enough, you can stop. If it did not help or remains unclear, go to the next relevant check in the six-check order or ask your therapist. If it made things worse, pause and review fit. If no check fits or no suitable response is available, ask your therapist. You do not need blame or endless repetition."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "The check, matched response and what actually happened",
          "optional": true
        },
        {
          "key": "observations",
          "label": "Result: helped, not helped, harder, unclear or not tried",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "Stop, next check or question for professional review",
          "optional": true
        }
      ],
      "help": {
        "title": "If the emotion stayed the same",
        "text": "That is useful information, not an automatic failure. Review the agreed goal and practical outcome with your therapist; do not invent improvement."
      }
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.next",
      "title": "Choose what to do next",
      "paragraphs": [
        "Choose whether to keep the plan, discuss another check, change the approach with your therapist, pause or stop. If a matched response has not been learned or does not fit, do not count it as completed.",
        "You can bring one clear question to your next session. There is no requirement to work through all checks, track every feeling or repeat this review each day. Support needs can be acted on without finishing the page."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, discuss, pause or leave",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Who or what may help with the next step",
          "optional": true
        }
      ],
      "help": {
        "title": "If troubleshooting becomes another worry loop",
        "text": "Pause the review and discuss that pattern with your therapist. More checking is not automatically more useful."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 Emotion Regulation Handout 24",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed pp.266–267: six checks and obstacle-specific response families.",
      "limits": "Original bounded companion, not copied handout or full instruction in each response. Medical, physical and crisis techniques require separate individual teaching and review."
    },
    {
      "id": "Linehan/Guilford: 2015 Emotion Regulation Worksheet 16",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed p.312: attempted skill, ordered checks, uncertainty, actual response/outcome and next-check loop.",
      "limits": "No copied checklist, compulsory score or completion inference. Early safety pause and optional notes are disclosed adaptations."
    },
    {
      "id": "Linehan/Guilford: 2015 teaching manual section XXIII",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-3teaching.pdf?t=1",
      "supports": "Printed pp.409–410: coaching, skill selection, possible reinforcing consequences and responses matched to overload/capacity.",
      "limits": "Historical Second Edition, not verified revised-2025 equivalence. Reinforcement is a hypothesis, not assumed motive. This digital companion has no separate efficacy validation."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal and access to communication and support.",
      "limits": "Rights guidance, not proof of clinical equivalence across adaptations."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-3teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from purchaser duplication permission.",
      "limits": "Source access does not grant public app rights. Release-rights and clinical decisions remain open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Attempted skill, goal and current fit",
      "sections": [
        "practice.situation"
      ],
      "source": "Worksheet16 context; original early safety/overload adaptation"
    },
    {
      "operation": "Six ordered checks and matched response/result",
      "sections": [
        "practice.care",
        "practice.skill",
        "practice.functions",
        "practice.effort",
        "practice.overload",
        "practice.myths"
      ],
      "source": "Handout24, Worksheet16 and ManualXXIII; each dependency retained without teaching unreviewed techniques"
    },
    {
      "operation": "Specific agreed response and actual use",
      "sections": [
        "practice.plan",
        "practice.try"
      ],
      "source": "Worksheet16 response/result loop; original explicit planning-versus-use distinction"
    },
    {
      "operation": "Result, next-check decision and clinical review",
      "sections": [
        "practice.review",
        "practice.next"
      ],
      "source": "Worksheet16 iterative outcomes; original no automatic completion, no endless checking and permission to stop"
    }
  ],
  "narrationSegments": [
    {
      "id": "emotion-regulation-troubleshooting.intro",
      "title": "Look at why a learned skill did not seem to help",
      "text": "A skill can be hard to use for many reasons. This review helps you and your therapist look at one attempt without deciding that you or the skill failed. It is for skills you have already learned, not a lesson in every skill named here.\n\nAfter checking that review fits now, start with the first of six checks. If a check seems relevant, agree a matching response: a next step that fits what got in the way. Use the planning and trying sections when needed, then return to record what actually happened. If it did not help or remains unclear, consider the next check or ask for support. You can stop without checking everything.\n\nIf you are returning after an agreed response, choose review. You can also use the made-up example or finish. Reading, planning, trying and getting help are different actions; this page never assumes one happened.",
      "sha256": "edb13aadc5ac9c15457cff1f572922c708ef1d9924ecbed5d9b3941199e6b0f0",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.fit",
      "title": "Check whether a review fits right now",
      "text": "Use an ordinary, manageable skill difficulty after your therapist has introduced this review. Agree which responses you know, what support you can use and when to stop. You do not need a perfect emotion word, a score or private details.\n\nIf you are too upset to follow these questions, feel cut off from your surroundings or have urgent safety or care needs, pause the review. Use your existing support plan or seek real-world help. Do not push through the six checks. This page does not assess risk, monitor you or provide urgent care.\n\nRespond to danger, abuse, discrimination, pain and practical problems. A feeling can point to something that needs protection or change. This is not a task to make yourself accept harmful treatment or hide a justified feeling.\n\nIf health or care concerns may be involved, ask a suitable professional. Keep your agreed care plan. This page does not advise changes to medication, food, sleep, movement or substance use, or teach physical techniques. Use speech, signing, communication aids, private thought or the example; writing and body attention are not required.",
      "sha256": "5532289a1839ec171866655f07ab0842d5312b7496825604cf46a0c981ef9a74",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.privacy",
      "title": "Keep only the notes you choose",
      "text": "Notes are optional. Use a few words or the made-up example. No voice is recorded and no message is sent to a therapist or anyone else.\n\nWriting stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.\n\nHiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox.",
      "sha256": "5057377fb7cdbf7f4f2e465d2ec865e3f7c132c22c5badf9bb632f6152af1106",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.close",
      "title": "Finish with a result, a question or a pause",
      "text": "You can finish after reading, planning, trying, reviewing, stopping or deciding not to use this practice. A question for your therapist can be enough. You do not need to feel calmer or prove that a response worked.\n\nNo report, reminder or follow-up is created. Leaving clears notes from this tool, not copies elsewhere.",
      "sha256": "327be44457076bfb5bd35ff5edc4bc1a5121c70e2d8a9795747716c96f9ab923",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.example",
      "title": "A made-up review: a missing page",
      "text": "Alex is frustrated because a page is missing from a hobby booklet. Alex tried a familiar calming skill, hoping that feeling calmer would help Alex get back to the hobby. The missing page was still a practical block. With a therapist, Alex chooses this small event rather than a more upsetting problem.\n\nAt the care check, Alex knows of no relevant change in health or care, but leaves room for uncertainty. No treatment change is proposed. At the skill check, Alex sees a mismatch: the calming skill did not replace a step for getting the missing page. That does not mean Alex used it badly.\n\nThe therapist helps Alex review the practical problem-solving skill already taught. They agree to check whether a spare copy of the page is available. Alex tries this and finds one. Alex is still a little frustrated, but can continue the hobby. The practical result helped; a different feeling was not promised.\n\nAlex records the matched response and the actual result, then stops this review. Alex does not need to invent answers to the remaining checks. If no copy had been available, that would be a different result to discuss, not proof of laziness or hidden motives. A future attempt would need its own plan.",
      "sha256": "32b2b47167e62b43f7a66ff7f76b95b1380d12e977d9c9f5e3cdf35511ef8344",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.learn",
      "title": "Keep the obstacle and the response connected",
      "text": "Emotion regulation means working with emotions and related actions. It does not always mean making a feeling smaller. A useful goal may be to act safely, solve a practical problem or understand what support is missing.\n\nThe six checks cover care and health factors; skill fit and use; what may keep a pattern going; practice and access; overload; and rules about emotions. More than one may matter. A guess is not a diagnosis or proof of why you felt something.\n\nEach check points to different support or learned skills. Do not swap in any activity just because it sounds helpful. If you do not know the matched response, ask for teaching or coaching. This page does not teach all those methods.\n\nThe source uses an ordered worksheet with ratings and response checks. This companion keeps the check, matching response and result loop, but makes writing and ratings unnecessary. It adds an early safety pause and leaves clinical decisions to your therapist.\n\nThe aim is a clear next step, including no further practice when it does not fit. Repeated checking for certainty, forcing an emotion away or blaming yourself are reasons to pause and review the approach.",
      "sha256": "7ab6f0f11da2a95530119370c18aeefb2cec18a64ed2eb159ced01c33b046606",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.situation",
      "title": "Describe the skill difficulty",
      "text": "Which learned skill did you try, in what ordinary situation, and what did you hope it would help with? Describe what you actually did. If you only planned or read about it, keep that clear.\n\nWhat happened afterward? You can describe a feeling, action, practical result or uncertainty. There is no required score. Ask whether changing the emotion is the goal, or whether safety, a real problem or another need comes first.",
      "sha256": "ebefaf5b422937763641dc7e0b8a580a848caf978e5b38a3917cd5113c0db4e9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.situation.help",
      "title": "If there was no attempt",
      "text": "You can prepare with the example or ask for help learning a skill. Do not invent an unsuccessful attempt so the questions fit.",
      "sha256": "d06329cbc003edf9ac7ffbb1747f929f569855446bc5096f4468b1d792e6421a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.care",
      "title": "Check 1: health and care factors",
      "text": "Could illness, pain, disrupted sleep, food access, substance effects or another care issue have made this attempt harder? Notice only what you already know; do not search for symptoms or diagnose yourself.\n\nIf relevant or unclear, discuss the care issue with the right professional and use your existing agreed plan. Your therapist may review PLEASE skills with you. This page gives no treatment, medication or lifestyle changes. If no issue is known, move to the next check. After an agreed response, record what happened; no help or uncertainty can lead to another check or support.",
      "sha256": "928d4ad754f87925d133058dfca848ff7a018d19357ffbcfac4ff95a48c57ed1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.care.help",
      "title": "If I wonder about medication",
      "text": "Ask your prescriber or pharmacist. Do not start, stop, skip, replace or change a medicine because of this review.",
      "sha256": "2f231a53e17437b79dbdfdc8e02f87dece684f082acfe08a8319d2c86bbb1545",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.skill",
      "title": "Check 2: skill choice and use",
      "text": "Was this skill a good match for the situation and goal? Compare what you actually did with the instructions your therapist taught. Do not treat an unchanged feeling as proof that you used it wrongly.\n\nIf a step or the choice is unclear, reread your agreed guide or get coaching. The response may be learning a missing step or selecting a better-matched skill with your therapist. Try only when the plan fits, then review the result. If the skill was suitable and used as agreed but did not help, consider the next check.",
      "sha256": "9194b3a93e76a90d7cac8052608113a53dcc85436ba654f9e8dfd2b053c37aad",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.skill.help",
      "title": "If an instruction does not fit my access needs",
      "text": "Ask for an agreed adaptation. Needing a cue, aid, more time or another way to communicate is not a lack of effort. Do not force a step that is unsafe or inaccessible.",
      "sha256": "730c543bdee35b37c46729ab18e3be6adbb05606c9e550c0a8e9765d3686f2cc",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.functions",
      "title": "Check 3: what may keep the pattern going",
      "text": "Could what happens after an emotional response make that pattern more likely again? For example, it might bring needed support, help you act, confirm a belief or feel rewarding. These are possibilities to explore, not proof that you chose distress or tried to control someone.\n\nIf unsure, review the emotion’s function with your therapist. A matched response might be a learned way to ask directly for support, another source of encouragement, self-validation, or pros and cons of changing the pattern. Keep the real need in view. Do not withhold care or punish anyone. After an agreed response, record its result; if this check does not fit or does not help, move on or seek coaching.",
      "sha256": "8e6e28c14fdcd3f7dde094ef705c3fc97f2617a33a45e0c08e704dda5591fabf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.functions.help",
      "title": "If this sounds like blaming me",
      "text": "You do not need to agree that a pattern exists. Needing support is real. Continued distress alone does not show a hidden benefit, choice or motive.",
      "sha256": "8c64f54c8ec1a9d21ae601516c94d1cc631f5247f2fad98c4666654d7611dbe2",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.effort",
      "title": "Check 4: practice, time and access",
      "text": "Did you have the time, energy, access and support needed to use the skill as agreed? What practice actually happened? Keep lack of opportunity, a hard step, uncertainty about the goal and choosing not to practise separate.\n\nIf this check fits, discuss which learned response matches. Options include problem solving for access or time, pros and cons of practice, radical acceptance of what is true, willingness to try, or mindful participation and effectiveness: joining in and doing what works. Agree a realistic step with your therapist, not a quota or demand to try harder. If practice was possible and used as agreed, review its result and consider another check when needed.",
      "sha256": "159c6b9e21bd3e9df654d7e44e6d8c487d6f390448c3d3ed8f8f05944ece3138",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.effort.help",
      "title": "If I do not want to practise",
      "text": "You can say that and explore the reasons without a penalty. Consent, disability, fatigue and unmet support needs are not problems to punish.",
      "sha256": "aa027b198ab1fad3b0f1460d9d899809a286c71c7ce6f97cdb7034737eca8e3b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.overload",
      "title": "Check 5: was the task too complex at that moment?",
      "text": "Were you able to take in the steps, or were emotions so strong that a complex skill was not usable? If that is happening now, pause this review and use agreed support. You do not have to prove a level of distress.\n\nWith enough capacity and support, a problem that can be solved now may call for your learned problem-solving skill. If it cannot be solved now, your therapist may select mindfulness of current emotions if suitable and already taught. If thinking through skills is not possible, use your existing crisis-support plan or seek help instead. TIP and other crisis skills need their own teaching and fit checks; this page does not instruct them.\n\nRecord only what you actually used and what followed. Return to review when it fits, not when a timer ends or a feeling reaches a target. If this check does not explain the difficulty, another check may be useful.",
      "sha256": "c9b9c025a54c54587b5548e44e662afddfed6ebe319d998599a615d69e13112d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.overload.help",
      "title": "If body-focused mindfulness is not suitable",
      "text": "If focusing on your body is not suitable, pause. Ask your therapist which plan to use instead. This page does not teach that plan.",
      "sha256": "38864d73b7c77cd0d49672c9919a67dc0ab0345d7d60a1694b14388be7f69972",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.myths",
      "title": "Check 6: rules about emotions",
      "text": "Did a rule about feelings get in the way, such as believing that a strong feeling must decide your next action? You can name a belief you already noticed without searching for harsher thoughts.\n\nIf relevant, use checking facts and nonjudgmental thinking already taught by your therapist to examine the belief. A feeling is real, but it need not settle every fact, identity or action. Do not debate away danger, injustice or your need for support. Try the agreed response if suitable, then record whether it helped. If no check fits or helps, ask for review rather than starting the loop over and over.",
      "sha256": "1316109f51ff7208a53c7f22befc60e2e53a24c487dde1c957d97e6a36956485",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.myths.help",
      "title": "If I am unsure whether it is a myth",
      "text": "Leave it as a question. The page does not decide which beliefs are false or tell you how you should feel.",
      "sha256": "cd48683151de69826f377c450efcedc12c374adb78ad30fc80ae208effd99490",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.plan",
      "title": "Plan one matched response",
      "text": "Name the check you are working on and the specific response that follows from it. Use a skill already taught or a step individually agreed with the right professional. If you need teaching, care advice or a safety plan, seeking that support is the next step.\n\nDecide what you will actually do, what support or cue you need, when the situation is suitable and what would mean pause. Choose a useful way to review the outcome, such as whether a practical step became possible. A different feeling is not required.",
      "sha256": "2003bded2ad15c8e1d6092647aa599e318f12dad568f52e468a15f4e36b71617",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.plan.help",
      "title": "If I have several possible responses",
      "text": "Choose with your therapist rather than trying them all. Keep the reason for the choice clear, including what is still unknown.",
      "sha256": "01ed8e7edbd03827cdfca4849d13abc52bc34eb19022ba11f8d16c17cb7dd939",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.try",
      "title": "Try the agreed response when it fits",
      "text": "If the plan is suitable and already agreed, carry out the actual response with the support you need. Reading this step or writing a plan is preparation, not proof that you used the response.\n\nYou can pause, stop, seek support or decide not to try. Do not repeat until calm or force a result. Later, return to the relevant check or review section and describe what really happened.",
      "sha256": "826f5315140cd173822c5fcfc089b22aa31659346d592a8988e767573ef86f1d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.try.help",
      "title": "If no suitable chance comes up",
      "text": "Keep that separate from a response that was tried and did not help. No missed-practice debt or automatic next attempt is created.",
      "sha256": "cf233a02fcbc2b2d2944d8340f26c0288816c35cc268d42d201166834ff97d50",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.review",
      "title": "Review the response and choose the next check",
      "text": "Which check and matched response are you reviewing? What did you actually try, if anything? You can start here with no notes, no earlier plan and no attempt. Do not fill in a past step that did not happen.\n\nDid the response help with the goal, not help, make things harder, remain unclear or go untried? Describe any practical result and relevant feeling without forcing a score or improvement. Planning alone cannot show whether the response worked.\n\nIf it helped enough, you can stop. If it did not help or remains unclear, go to the next relevant check in the six-check order or ask your therapist. If it made things worse, pause and review fit. If no check fits or no suitable response is available, ask your therapist. You do not need blame or endless repetition.",
      "sha256": "821aff968c576af120aea5ec234267e30d9a81b586e885972366ff909d5b4bc9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.review.help",
      "title": "If the emotion stayed the same",
      "text": "That is useful information, not an automatic failure. Review the agreed goal and practical outcome with your therapist; do not invent improvement.",
      "sha256": "77a0b05dac6b3f8cbc3d9daa527494459ebd57d0676fb6cab116230a6fb20024",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.next",
      "title": "Choose what to do next",
      "text": "Choose whether to keep the plan, discuss another check, change the approach with your therapist, pause or stop. If a matched response has not been learned or does not fit, do not count it as completed.\n\nYou can bring one clear question to your next session. There is no requirement to work through all checks, track every feeling or repeat this review each day. Support needs can be acted on without finishing the page.",
      "sha256": "bedf956958c7405a88cac69cbb33722833fb5291adf240d7817f7decb6b9745f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "emotion-regulation-troubleshooting.practice.next.help",
      "title": "If troubleshooting becomes another worry loop",
      "text": "Pause the review and discuss that pattern with your therapist. More checking is not automatically more useful.",
      "sha256": "9f8d0998a53798ee824cb789ea3299a1fd7e7444134094624c49bdc7185513d8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
