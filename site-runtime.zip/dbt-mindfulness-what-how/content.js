window.MindfulnessWhatHowContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/mindful",
  "componentIds": [
    "component/mindful/what-skills",
    "component/mindful/how-skills"
  ],
  "resourceId": "tool/dbt-mindfulness-what-how",
  "routeProposal": "/dbt-mindfulness-what-how/",
  "title": "DBT Mindfulness: What and How Skills",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Learn the three What and three How skills, choose one What for an agreed ordinary practice, then review actual use without a required result.",
  "groupedSetStatus": "The What Skills and How Skills components of existing classic/mindful only. One What at a time; How qualities apply alongside each. Wise Mind and other named mindfulness components remain distinct. No new canonical count or full-group clinical acceptance.",
  "clinicalContract": {
    "learningObjective": "Distinguish observing experience, describing it in words and participating in an activity; apply a nonjudgmental, one-mindful and effective approach without equating mindfulness with calm, obedience or ignoring risk.",
    "practiceObjective": "Choose an agreed accessible ordinary focus/activity, choose one What skill and appropriate How qualities, actually practise without constant written self-monitoring, then review actual use/non-use and adapt with the therapist.",
    "sourcePopulationContext": "Source skill teaching and worksheets establish the named procedures, not efficacy or suitability of this isolated digital adaptation. No blanket age floor or universal suitability. Individual developmental, clinical, safeguarding, cultural, sensory, communication and access fit needs review.",
    "exclusions": [
      "No crisis, trauma recall/processing, exposure, forced inward attention, eyes-closed practice, breath change or physical protocol",
      "No empty-mind, calm, thought-removal, concentration score or improvement requirement",
      "No participation that ignores danger, pain, consent, boundaries or necessary awareness",
      "No judgment that all judgments are wrong; nonjudgment does not remove discrimination, ethics or protection",
      "No efficiency, compliance or getting another person to agree as the definition of effectiveness",
      "No claim of the complete DBT mindfulness curriculum or replacement for Wise Mind/ACT Present-Moment Awareness"
    ],
    "adaptations": [
      "Original bounded activity instructions and example, not source worksheets or teaching scripts",
      "One What chosen at a time; no compulsory Observe-Describe-Participate sequence",
      "All three How skills taught alongside any What without a score or perfection test",
      "Accessible external focus and previously agreed alternatives; no default internal/body exercise",
      "User-paced actual practice with notes afterwards; no timer, notifications, automatic action or inferred completion",
      "Optional in-memory notes and exact selected export only"
    ],
    "reviewGates": [
      "Owner/clinician and rights review of full bounded What/How teaching and practice",
      "Individual developmental, clinical, safeguarding, sensory and access fit",
      "Human comprehension review; grade-five wording is a target, not a validated reading level",
      "Real integrated desktop/mobile/keyboard/screen-reader and lifecycle/navigation acceptance",
      "Authorized narration generation, exact-script listening, binding and controls review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "practice",
      "review"
    ],
    "modeChoice": {
      "title": "Use the practice you have agreed with your therapist",
      "options": [
        {
          "value": "practice",
          "label": "Choose and practise a skill",
          "startSectionId": "dbt-mindfulness-what-how.practice.choose"
        },
        {
          "value": "review",
          "label": "Review a practice I tried or planned",
          "startSectionId": "dbt-mindfulness-what-how.practice.review"
        }
      ]
    },
    "entryGate": "Visible therapist-introduced scope before explicit mode choice; not screening or approval. Readings, Finish and support remain available.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing, sequence or completion lock.",
    "reviewAccess": "Direct blank review without stored plan or an assumed attempt. Both modes expose all groups.",
    "writing": "Optional and initially hidden; fiction never fills notes. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only. Internal reading/navigation retains notes; clear, restart, leaving/reloading, history and BFCache return clear them. Offscreen visibility alone retains them.",
    "export": "No default selection. Exact selected preview/copy/download; editing, hiding, mode/stage changes and new selection invalidate it.",
    "narration": "Hashed fixed public paragraphs/help only; never notes. No audio assets, TTS, autoplay or activation.",
    "timer": "None. No required duration, completion cue, streak or schedule.",
    "completion": "No inferred practice, use of any skill, attention quality, success, calm, effect or completion."
  },
  "intro": {
    "id": "dbt-mindfulness-what-how.intro",
    "title": "Choose what you do with attention, and how",
    "paragraphs": [
      "DBT mindfulness has three What skills: Observe, Describe and Participate. They mean notice an experience, put it into words, or join in an activity. Use one at a time. You do not have to do all three in a set order.",
      "The three How skills are Nonjudgmentally, One-Mindfully and Effectively. They guide the way you use any What skill. This page teaches each one, then helps you choose a brief practice and look at what actually happened."
    ]
  },
  "fit": {
    "id": "dbt-mindfulness-what-how.fit",
    "title": "Start with a suitable ordinary practice",
    "paragraphs": [
      "Use this after your therapist has taught the skills and helped you choose a suitable focus or activity. Until then, read or bring questions to your session. This page does not decide what is safe for you.",
      "Choose an ordinary setting where a brief practice fits. Keep needed aids, support and awareness of your surroundings. Do not practise while driving, using dangerous equipment or doing something that needs urgent attention.",
      "You do not need to close your eyes, change breathing, focus inside your body or bring up a painful memory. Use an accessible focus you have agreed, or skip the practice. It is not trauma treatment, exposure or a test of how long you can bear distress.",
      "Pause or stop if you feel more threatened, overwhelmed, numb or far away, or if the task no longer fits. Turn to suitable support rather than pushing on. You do not need to become calm, clear your mind or feel better."
    ]
  },
  "privacy": {
    "id": "dbt-mindfulness-what-how.privacy",
    "title": "Notes are optional and stay only in this open tool",
    "paragraphs": [
      "You can practise without typing, speak privately or use your own paper. If you write here, avoid names and private history you do not need. Internal examples and help keep your notes in this open page.",
      "Leaving, reloading, clearing or starting again removes these notes. Choose notes to keep lets you select, preview, copy or download only what you want. A copy you keep stays outside the tool until you remove it.",
      "Nothing is sent to your therapist. This tool does not monitor practice, send messages, set reminders or alert anyone if you need help. The optional skill narration never reads notes; a screen reader or other device tool may read what you enter. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "dbt-mindfulness-what-how.close",
    "title": "You can finish without a score",
    "paragraphs": [
      "Reading about a skill is not the same as trying it. You can finish after reading, choosing, practising or reviewing. No completed exercise or better feeling is required.",
      "Return to a prompt or choose notes to keep for your session if useful. Finish and clear removes notes here, but not copies you kept elsewhere."
    ]
  },
  "example": {
    "id": "dbt-mindfulness-what-how.example",
    "title": "Ari tries three different ways with one cloth",
    "paragraphs": [
      "This made-up example shows separate tries, not three steps you must do. Ari and their therapist have chosen a familiar cloth-folding task that is comfortable for Ari. The aim is to make room on a shelf, not to become calm or make a perfect fold.",
      "First, Ari tries Observe. Ari looks at the cloth and lets a stripe and a bent corner come into view, without trying to name each detail. A thought about the shelf appears. Ari notices attention has moved and returns to looking.",
      "In a separate try, Ari uses Describe: \"There is a grey stripe. One corner is bent. I am having the thought that this will look messy.\" The words separate a seen detail from a thought. They do not prove the shelf is a mess or that Ari is bad at folding.",
      "Then Ari chooses Participate. Ari folds the cloth, joining in the action rather than reporting each movement or checking each second for the right feeling. When the fold will not fit, Ari pauses and looks at the available space. Ari changes to a simple roll, then joins in that action.",
      "The How skills support these tries. Ari notices the label \"messy\" without scolding themself for judging. Ari returns to the chosen task when attention moves. Ari changes the fold because the goal is to fit the cloth on the shelf.",
      "Afterwards, Ari reports the three short tries and the change to rolling. Impatience is still present. Ari found describing useful for separating a fact from a label, and found constant checking got in the way of participating. At the next session, Ari may choose just one skill to practise. No further practice has happened yet."
    ]
  },
  "learn": {
    "id": "dbt-mindfulness-what-how.learn",
    "title": "Different skills, not levels to pass",
    "paragraphs": [
      "Observe means contact with what is happening, without having to label it. Describe adds words to what you notice. Participate means entering an activity, rather than standing back and commenting on yourself. You can change What skills when the situation calls for it; use one at a time.",
      "The How skills can go with all three. Nonjudgmentally means separating facts and effects from labels of good or bad. One-Mindfully means giving this moment or task your attention and returning when it moves. Effectively means doing what fits your aim and the real situation.",
      "Nonjudgmental does not mean unsafe behavior is acceptable or that all claims are equally true. Effective does not mean obeying someone or abandoning your values. One-mindful does not mean missing a hazard or refusing an interruption that matters.",
      "A wandering mind, a judgment or a difficult feeling can be noticed. You do not need to defeat it or judge yourself for having it. A support, a shorter practice or a different way of taking part may fit better than trying harder.",
      "These two named skill groups are part of DBT Mindfulness. Wise Mind, other mindfulness practices and ACT Present-Moment Awareness have related but distinct teaching. One page or one try is not mastery of mindfulness or the full DBT programme."
    ]
  },
  "practice": [
    {
      "id": "dbt-mindfulness-what-how.practice.choose",
      "title": "Choose an accessible focus or activity",
      "paragraphs": [
        "Use the ordinary focus or activity you agreed with your therapist. What can you notice or take part in with the senses, movement, communication and support available to you? You do not have to use the cloth example.",
        "For example, a familiar object, a brief piece of sound or an ordinary small task may fit. No one sense or physical action is required. Keep needed care and safety checks; leave the practice open if you do not yet have a suitable option."
      ],
      "fields": [
        {
          "key": "focus",
          "label": "My agreed ordinary focus or activity",
          "optional": true
        },
        {
          "key": "access",
          "label": "Support, access needs and limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If inward attention does not fit",
        "text": "You may use an external focus agreed with your therapist. This is an option, not a promise that it will feel safe or helpful. Stop and seek support if it does not fit."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.observe",
      "title": "Observe: notice without having to name",
      "paragraphs": [
        "Let yourself notice what is present through a way that is accessible to you. You might notice a visible feature, a sound, or another agreed experience. You do not need to hunt for details or force a sensation.",
        "For an Observe try, leave naming and explaining for later. If a thought or feeling appears, you can notice that it is present without following it or pushing it away. When attention moves, gently come back to your chosen focus if it still fits."
      ],
      "fields": [
        {
          "key": "observe-focus",
          "label": "What I could observe without explaining it",
          "optional": true
        }
      ],
      "help": {
        "title": "If words keep appearing",
        "text": "That can happen. You do not have to make the mind silent. Notice the words as something that showed up, then return if you choose. Describe is a different skill you can choose at another moment."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.describe",
      "title": "Describe: put what you notice into words",
      "paragraphs": [
        "Choose Describe when you want to name what you have observed. Use plain words for the event or experience. A thought can be named as a thought and a feeling as a feeling, rather than treated as proof about the world.",
        "Separate what you notice from a guess about why it happened or what someone else thinks. For example, \"The reply has not arrived\" describes a fact; \"They do not care\" is an interpretation. You can name uncertainty instead of filling the gap."
      ],
      "fields": [
        {
          "key": "description",
          "label": "Words for what I actually noticed",
          "optional": true
        },
        {
          "key": "interpretation",
          "label": "Any guess, label or unknown to keep separate",
          "optional": true
        }
      ],
      "help": {
        "title": "If a word is hard to find",
        "text": "A short phrase, sign, symbol or private spoken description may be enough. You can leave it unclear. The page does not classify feelings, correct your words or decide that a thought is true."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.participate",
      "title": "Participate: join in the activity",
      "paragraphs": [
        "Choose Participate when it fits to enter the activity itself. Let yourself do the familiar action, rather than watch yourself from the outside, describe each move or keep checking how well you are doing.",
        "Stay responsive to what is happening. You can step back to observe, ask a question, change the action or stop when needed. Joining in does not mean losing awareness, ignoring a limit or doing what someone demands."
      ],
      "fields": [
        {
          "key": "participation",
          "label": "An agreed activity I can join in",
          "optional": true
        }
      ],
      "help": {
        "title": "If self-monitoring keeps pulling you away",
        "text": "Notice that briefly and return to the activity if it fits. Do not make perfect absorption the goal. Keep any checks the activity needs for safety or access, and change the practice with your therapist if needed."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.nonjudgmental",
      "title": "Nonjudgmentally: separate labels from facts",
      "paragraphs": [
        "Notice labels such as \"good,\" \"bad,\" \"useless\" or \"perfect.\" What are the facts, effects or preferences beneath the label? You may prefer one result or recognize harm without turning the whole person or moment into a verdict.",
        "If you catch yourself judging, notice that too. Adding \"I am bad at this\" is another judgment, not a reason to punish yourself. Return to the experience or useful description without demanding a judgment-free mind."
      ],
      "fields": [
        {
          "key": "judgment",
          "label": "A label I noticed, if any",
          "optional": true
        },
        {
          "key": "facts-effects",
          "label": "Facts, effects or preferences beneath it",
          "optional": true
        }
      ],
      "help": {
        "title": "If something is harmful or unfair",
        "text": "You can name harm, set limits and act to protect yourself. Nonjudgmental practice is not approval, false balance or an instruction to accept abuse. You do not have to remove emotion from your account."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.onemindful",
      "title": "One-Mindfully: return to what you are doing",
      "paragraphs": [
        "Choose one focus or activity for this moment. When attention moves elsewhere, notice and return if the task still fits. Returning is part of practice, not evidence that you failed.",
        "You may reduce an optional distraction or use a needed aid. Do not remove important alerts, support or safety checks. If something else needs your attention, deliberately switch to it rather than forcing the old plan."
      ],
      "fields": [
        {
          "key": "one-focus",
          "label": "The focus or task for this moment",
          "optional": true
        },
        {
          "key": "attention-support",
          "label": "What may help me return or switch when needed",
          "optional": true
        }
      ],
      "help": {
        "title": "If attention is difficult to hold",
        "text": "No fixed span of attention is required. Shorter practice, movement, another sense or an access aid may fit. Attention differences, fatigue and interruptions are not proof of poor effort."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.effective",
      "title": "Effectively: respond to the real situation",
      "paragraphs": [
        "What are you trying to do in this moment? What does the situation actually allow or need? Choose a response that serves the aim while respecting safety, values and everyone's limits.",
        "You can change a method that is not working instead of insisting that reality should be different. This does not mean giving in to harm, hiding unfairness or getting the result at any cost. A boundary, help or a pause may be the fitting response."
      ],
      "fields": [
        {
          "key": "aim",
          "label": "The practical aim for this moment",
          "optional": true
        },
        {
          "key": "workable-response",
          "label": "What fits the actual situation and limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want to prove you are right",
        "text": "Being right and choosing a useful response are different questions. You may keep your view and still change how you respond. The aim is not to win approval, silence an objection or give up a needed boundary."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.plan",
      "title": "Choose one What, with the How skills",
      "paragraphs": [
        "For this try, choose Observe, Describe or Participate. You do not need to work through all three. The earlier sections are options to learn and return to, not a required ladder.",
        "Consider how to approach it without a verdict, with attention to one thing, and in a way that fits the aim. You do not need to monitor or score all three How skills while practising. Choose the part you want to pay attention to with your therapist.",
        "Set a small amount or stopping point that fits you. Check any support and what would be a reason to pause or stop. This page has no required timer and does not approve a practice."
      ],
      "fields": [
        {
          "key": "chosen-what",
          "label": "The one What skill I choose",
          "optional": true
        },
        {
          "key": "chosen-how",
          "label": "How I want to approach this try",
          "optional": true
        },
        {
          "key": "practice-plan",
          "label": "My agreed amount, support and stopping choice",
          "optional": true
        }
      ],
      "help": {
        "title": "If you are not ready to choose",
        "text": "Read the example, discuss the choice in your session or finish. You do not have to use a personal situation or write a plan to continue using the page."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.try",
      "title": "Try the chosen skill, if it still fits",
      "paragraphs": [
        "Read the guidance you need, then give the chosen practice a little space. Observe, Describe or Participate as you agreed, using the How skills to guide your approach. You can keep this page open without writing while you practise.",
        "You may stop, change to another suitable skill or not begin. If you change What skills, do one at a time. Keep needed awareness and support. Nothing here marks an attempt or measures your attention.",
        "When you are ready, return to review. Pressing Next or reading an example is not the practice itself. If you leave or reload, notes here will clear; keep selected notes first if you want them."
      ],
      "fields": [
        {
          "key": "changed-fit",
          "label": "Anything that changes the fit before I try",
          "optional": true
        }
      ],
      "help": {
        "title": "If the practice increases distress",
        "text": "Stop or change focus with support. You do not need to keep watching a thought, feeling or sensation to make it go away. Contact your therapist or appropriate support if you need help; this page is not monitored."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.review",
      "title": "Review the try you actually made",
      "paragraphs": [
        "What did you actually try, change, stop or not begin? Which What skill were you using, and when did you switch if you did? If you did not practise, there is no result to invent; you can still discuss fit or barriers.",
        "What did you notice about the experience and the How skills? Perhaps you shifted from noticing to describing, constant checking interrupted participation, or a useful change helped the task fit. Describe your own result, including uncertainty or no clear change.",
        "Was the practice workable with your needs and limits? Any calm or discomfort is information, not a pass or fail. Do not treat noticing a judgment or wandering attention as a defect to erase."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "What I actually tried, changed or did not begin",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What I noticed, including what remains unclear",
          "optional": true
        },
        {
          "key": "fit-review",
          "label": "How the practice fitted my needs and limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If the result was mixed or unhelpful",
        "text": "Keep that information. You do not owe the exercise a positive review. Discuss a shorter try, another skill, better support or no further practice before repeating something that did not fit."
      }
    },
    {
      "id": "dbt-mindfulness-what-how.practice.next",
      "title": "Choose what to bring to your therapist",
      "paragraphs": [
        "What would you keep, adapt or ask about? A next practice may use the same What skill or another one, with the How qualities. You do not need to finish a set or build a streak.",
        "Agree any next step with your therapist. The choice may be to pause this practice while you find a better fit. You can bring only the notes you choose, or describe the experience in your own way."
      ],
      "fields": [
        {
          "key": "therapy-review",
          "label": "What I want to discuss or ask about",
          "optional": true
        },
        {
          "key": "next-choice",
          "label": "An agreed next choice, or leave it open",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want to keep a note",
        "text": "Choose notes to keep shows only what you select for preview, copy or download. Nothing is sent to your therapist and no practice history is stored after you leave."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan: DBT Skills Training Manual, 2015 teaching notes",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Primary teaching: What/How relationship (pp154–155); Observe (176–187), Describe (187–192), Participate (192–199), Nonjudgmentally (199–208), One-Mindfully (208–210), Effectively (210–213).",
      "limits": "Legacy second-edition teaching reviewed, not the full revised 2025 text. Original bounded instructions/example, not copied source scripts. Broader and power/compliance examples are not imported. Full DBT and isolated-app efficacy are not established."
    },
    {
      "id": "Linehan: official What/How handouts and source-use notice",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Named What/How distinctions and recognition that harm, safety, values and emotions are not erased by nonjudgmental practice; limited reproduction terms at PDF page2.",
      "limits": "Public access and the individual-purchaser licence do not authorize redistribution or electronic display of source materials. No worksheet, activity list, source diagram or teaching script is reproduced. Rights review remains open."
    },
    {
      "id": "Bradley Hospital: Pause and Practice, Andrea Gold (2025)",
      "url": "https://www.bradleyhospital.org/podcast/pause-and-practice",
      "supports": "Original clinician teaching of DBT/DBT-A What and How, How qualities alongside a chosen What, everyday practice and flexible response.",
      "limits": "Clinical explanation, not validation of this adaptation or universal fit across ages. No interview transcript, source exercise or audio is reproduced; driving examples are not used."
    },
    {
      "id": "VHA: Precautions with Using Mindful Awareness Practices",
      "url": "https://www.va.gov/WHOLEHEALTH/Veteran-Handouts/docs/PrecautionsMindfulAware-508Final-9-5-2018.pdf",
      "supports": "Choice, possible unwanted experiences and need for professional guidance with mindful-awareness practice.",
      "limits": "General guidance, not a DBT protocol or a validated app screening rule. Exact stop cues, access choices and no-crisis scope are conservative product safeguards. No efficacy or risk-rate claim."
    },
    {
      "id": "Guilford: current DBT Skills Training Manual, revised edition",
      "url": "https://www.guilford.com/books/DBT-Skills-Training-Manual/Marsha-Linehan/9781462556359/contents",
      "supports": "Publisher verification of the revised 2025 edition and Mindfulness Skills chapter.",
      "limits": "Scope and edition check only; the revised chapter text was not inspected. Listing and attribution do not grant publication permission."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Teach relationship: one What at a time, How alongside each",
      "sections": [
        "intro",
        "learn",
        "practice.plan"
      ],
      "source": "Linehan 2015 pp154–155; Bradley clinician transcript; no required sequence or score"
    },
    {
      "operation": "Observe without deliberate labels, without fighting spontaneous words",
      "sections": [
        "practice.observe"
      ],
      "source": "Linehan pp176–187; accessible focus and no forced body/breath exercise are bounded adaptations"
    },
    {
      "operation": "Describe direct observations; distinguish interpretation and other minds",
      "sections": [
        "practice.describe"
      ],
      "source": "Linehan pp187–192; plain-language uncertainty and access alternatives"
    },
    {
      "operation": "Participate in actual activity without constant self-monitoring; step back when useful",
      "sections": [
        "practice.participate",
        "practice.try"
      ],
      "source": "Linehan pp192–199, especially194; no perfect absorption or loss-of-awareness goal"
    },
    {
      "operation": "Nonjudgmental awareness retains facts/effects/values and does not judge judging",
      "sections": [
        "practice.nonjudgmental"
      ],
      "source": "Linehan pp199–208 and official Handout5; safety/boundary examples are original"
    },
    {
      "operation": "One-mindful attention includes returning and deliberate switching",
      "sections": [
        "practice.onemindful"
      ],
      "source": "Linehan pp208–210; disability/access support and no removal of needed alerts are safeguards"
    },
    {
      "operation": "Effectiveness relates goals, actual context and workable action",
      "sections": [
        "practice.effective"
      ],
      "source": "Linehan pp210–213; conservative safety/consent boundaries replace source compliance/power examples"
    },
    {
      "operation": "Actual brief chosen practice, truthful non-use and neutral review",
      "sections": [
        "practice.plan",
        "practice.try",
        "practice.review",
        "practice.next"
      ],
      "source": "Linehan core practice structure and Bradley everyday practice; explicit memory/privacy/non-inference and agreed follow-up are product adaptations"
    },
    {
      "operation": "Voluntary suitable practice with stopping/support",
      "sections": [
        "fit",
        "practice.choose",
        "practice.try"
      ],
      "source": "VHA precautions general guidance; exact cues and ordinary-context limits are not validated screening"
    }
  ],
  "narrationSegments": [
    {
      "id": "dbt-mindfulness-what-how.intro",
      "title": "Choose what you do with attention, and how",
      "text": "DBT mindfulness has three What skills: Observe, Describe and Participate. They mean notice an experience, put it into words, or join in an activity. Use one at a time. You do not have to do all three in a set order.\n\nThe three How skills are Nonjudgmentally, One-Mindfully and Effectively. They guide the way you use any What skill. This page teaches each one, then helps you choose a brief practice and look at what actually happened.",
      "sha256": "c4ce813faf1f2c3a30dd45d0e383011db1fb11034e165ae2cd123721390bd7a6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.fit",
      "title": "Start with a suitable ordinary practice",
      "text": "Use this after your therapist has taught the skills and helped you choose a suitable focus or activity. Until then, read or bring questions to your session. This page does not decide what is safe for you.\n\nChoose an ordinary setting where a brief practice fits. Keep needed aids, support and awareness of your surroundings. Do not practise while driving, using dangerous equipment or doing something that needs urgent attention.\n\nYou do not need to close your eyes, change breathing, focus inside your body or bring up a painful memory. Use an accessible focus you have agreed, or skip the practice. It is not trauma treatment, exposure or a test of how long you can bear distress.\n\nPause or stop if you feel more threatened, overwhelmed, numb or far away, or if the task no longer fits. Turn to suitable support rather than pushing on. You do not need to become calm, clear your mind or feel better.",
      "sha256": "0e1f7be970e79e3942aafbc6c0e0bd2ed4b9239774924315298bf6f17a5af1f9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.privacy",
      "title": "Notes are optional and stay only in this open tool",
      "text": "You can practise without typing, speak privately or use your own paper. If you write here, avoid names and private history you do not need. Internal examples and help keep your notes in this open page.\n\nLeaving, reloading, clearing or starting again removes these notes. Choose notes to keep lets you select, preview, copy or download only what you want. A copy you keep stays outside the tool until you remove it.\n\nNothing is sent to your therapist. This tool does not monitor practice, send messages, set reminders or alert anyone if you need help. The optional skill narration never reads notes; a screen reader or other device tool may read what you enter. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "3174f02a5ca2a289a23cd63aa0906db5bdc28826edafef9de00701625931b1a8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.close",
      "title": "You can finish without a score",
      "text": "Reading about a skill is not the same as trying it. You can finish after reading, choosing, practising or reviewing. No completed exercise or better feeling is required.\n\nReturn to a prompt or choose notes to keep for your session if useful. Finish and clear removes notes here, but not copies you kept elsewhere.",
      "sha256": "1e4a5ea170765d5c2cc682e7c61fa87802e2b3d4035127182b469b2917393307",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.example",
      "title": "Ari tries three different ways with one cloth",
      "text": "This made-up example shows separate tries, not three steps you must do. Ari and their therapist have chosen a familiar cloth-folding task that is comfortable for Ari. The aim is to make room on a shelf, not to become calm or make a perfect fold.\n\nFirst, Ari tries Observe. Ari looks at the cloth and lets a stripe and a bent corner come into view, without trying to name each detail. A thought about the shelf appears. Ari notices attention has moved and returns to looking.\n\nIn a separate try, Ari uses Describe: \"There is a grey stripe. One corner is bent. I am having the thought that this will look messy.\" The words separate a seen detail from a thought. They do not prove the shelf is a mess or that Ari is bad at folding.\n\nThen Ari chooses Participate. Ari folds the cloth, joining in the action rather than reporting each movement or checking each second for the right feeling. When the fold will not fit, Ari pauses and looks at the available space. Ari changes to a simple roll, then joins in that action.\n\nThe How skills support these tries. Ari notices the label \"messy\" without scolding themself for judging. Ari returns to the chosen task when attention moves. Ari changes the fold because the goal is to fit the cloth on the shelf.\n\nAfterwards, Ari reports the three short tries and the change to rolling. Impatience is still present. Ari found describing useful for separating a fact from a label, and found constant checking got in the way of participating. At the next session, Ari may choose just one skill to practise. No further practice has happened yet.",
      "sha256": "af1e1c3e88c6ee1a0629b087693af086371ee1f42902d721318793faf69933d4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.learn",
      "title": "Different skills, not levels to pass",
      "text": "Observe means contact with what is happening, without having to label it. Describe adds words to what you notice. Participate means entering an activity, rather than standing back and commenting on yourself. You can change What skills when the situation calls for it; use one at a time.\n\nThe How skills can go with all three. Nonjudgmentally means separating facts and effects from labels of good or bad. One-Mindfully means giving this moment or task your attention and returning when it moves. Effectively means doing what fits your aim and the real situation.\n\nNonjudgmental does not mean unsafe behavior is acceptable or that all claims are equally true. Effective does not mean obeying someone or abandoning your values. One-mindful does not mean missing a hazard or refusing an interruption that matters.\n\nA wandering mind, a judgment or a difficult feeling can be noticed. You do not need to defeat it or judge yourself for having it. A support, a shorter practice or a different way of taking part may fit better than trying harder.\n\nThese two named skill groups are part of DBT Mindfulness. Wise Mind, other mindfulness practices and ACT Present-Moment Awareness have related but distinct teaching. One page or one try is not mastery of mindfulness or the full DBT programme.",
      "sha256": "acf3dfcd3c1a75dc02b54774c5a9d79c85c30ca5211908047baba19a1619c303",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.choose",
      "title": "Choose an accessible focus or activity",
      "text": "Use the ordinary focus or activity you agreed with your therapist. What can you notice or take part in with the senses, movement, communication and support available to you? You do not have to use the cloth example.\n\nFor example, a familiar object, a brief piece of sound or an ordinary small task may fit. No one sense or physical action is required. Keep needed care and safety checks; leave the practice open if you do not yet have a suitable option.",
      "sha256": "69f45038acabf708697c2c5903d6c817066becb329a2ca13f39d203ca5cec146",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.choose.help",
      "title": "If inward attention does not fit",
      "text": "You may use an external focus agreed with your therapist. This is an option, not a promise that it will feel safe or helpful. Stop and seek support if it does not fit.",
      "sha256": "7b69499359864171556976634c356ae0e06399dc0eb71e0d55822727b69fc674",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.observe",
      "title": "Observe: notice without having to name",
      "text": "Let yourself notice what is present through a way that is accessible to you. You might notice a visible feature, a sound, or another agreed experience. You do not need to hunt for details or force a sensation.\n\nFor an Observe try, leave naming and explaining for later. If a thought or feeling appears, you can notice that it is present without following it or pushing it away. When attention moves, gently come back to your chosen focus if it still fits.",
      "sha256": "e20b9019bb4939a06a98f5b60d32b3c59560d3cecd8c41f81f7ed177d5291818",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.observe.help",
      "title": "If words keep appearing",
      "text": "That can happen. You do not have to make the mind silent. Notice the words as something that showed up, then return if you choose. Describe is a different skill you can choose at another moment.",
      "sha256": "5716f912e5eb6c12301290d3a06d6199319885c3fcff443b27bf9f7c3bacaefb",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.describe",
      "title": "Describe: put what you notice into words",
      "text": "Choose Describe when you want to name what you have observed. Use plain words for the event or experience. A thought can be named as a thought and a feeling as a feeling, rather than treated as proof about the world.\n\nSeparate what you notice from a guess about why it happened or what someone else thinks. For example, \"The reply has not arrived\" describes a fact; \"They do not care\" is an interpretation. You can name uncertainty instead of filling the gap.",
      "sha256": "e68cf9c61df10b404850b8a6d74b0a345f1226be23b5fb60d26d71b05bcf8d55",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.describe.help",
      "title": "If a word is hard to find",
      "text": "A short phrase, sign, symbol or private spoken description may be enough. You can leave it unclear. The page does not classify feelings, correct your words or decide that a thought is true.",
      "sha256": "833a4e0083fad83e52ffcc01f6f034c111aaea4f799d75a2ca6a74204351fef9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.participate",
      "title": "Participate: join in the activity",
      "text": "Choose Participate when it fits to enter the activity itself. Let yourself do the familiar action, rather than watch yourself from the outside, describe each move or keep checking how well you are doing.\n\nStay responsive to what is happening. You can step back to observe, ask a question, change the action or stop when needed. Joining in does not mean losing awareness, ignoring a limit or doing what someone demands.",
      "sha256": "0ecde868a1cf034bcdf40001f30dae9ba4740aa57c971a02e9c8d6f91bdb1e7a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.participate.help",
      "title": "If self-monitoring keeps pulling you away",
      "text": "Notice that briefly and return to the activity if it fits. Do not make perfect absorption the goal. Keep any checks the activity needs for safety or access, and change the practice with your therapist if needed.",
      "sha256": "870af41777783ec4bec760a542944b1142aa71d960be1f2ca48e70d905e7daed",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.nonjudgmental",
      "title": "Nonjudgmentally: separate labels from facts",
      "text": "Notice labels such as \"good,\" \"bad,\" \"useless\" or \"perfect.\" What are the facts, effects or preferences beneath the label? You may prefer one result or recognize harm without turning the whole person or moment into a verdict.\n\nIf you catch yourself judging, notice that too. Adding \"I am bad at this\" is another judgment, not a reason to punish yourself. Return to the experience or useful description without demanding a judgment-free mind.",
      "sha256": "f452d74653fe37652811ce40e8f3780b378249b16a96eb09677541206ca5fe75",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.nonjudgmental.help",
      "title": "If something is harmful or unfair",
      "text": "You can name harm, set limits and act to protect yourself. Nonjudgmental practice is not approval, false balance or an instruction to accept abuse. You do not have to remove emotion from your account.",
      "sha256": "22ff725a6b70b328e3f9855c55ce5ad023358d987822589d2ed56488e5247dff",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.onemindful",
      "title": "One-Mindfully: return to what you are doing",
      "text": "Choose one focus or activity for this moment. When attention moves elsewhere, notice and return if the task still fits. Returning is part of practice, not evidence that you failed.\n\nYou may reduce an optional distraction or use a needed aid. Do not remove important alerts, support or safety checks. If something else needs your attention, deliberately switch to it rather than forcing the old plan.",
      "sha256": "dd42c2fdfe427eafeb4bdef28eed4b9166db8397dc4094a3b6b5b1025fb93119",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.onemindful.help",
      "title": "If attention is difficult to hold",
      "text": "No fixed span of attention is required. Shorter practice, movement, another sense or an access aid may fit. Attention differences, fatigue and interruptions are not proof of poor effort.",
      "sha256": "0be301944e7767f4c50aff7e55d9bd93e8b9932a433e61a10fc13af4255e7b83",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.effective",
      "title": "Effectively: respond to the real situation",
      "text": "What are you trying to do in this moment? What does the situation actually allow or need? Choose a response that serves the aim while respecting safety, values and everyone's limits.\n\nYou can change a method that is not working instead of insisting that reality should be different. This does not mean giving in to harm, hiding unfairness or getting the result at any cost. A boundary, help or a pause may be the fitting response.",
      "sha256": "48a98bbfccc261b6b55cb8a80f8f004bbc8a0c8dcb7e52aa3f85a9eb6645e435",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.effective.help",
      "title": "If you want to prove you are right",
      "text": "Being right and choosing a useful response are different questions. You may keep your view and still change how you respond. The aim is not to win approval, silence an objection or give up a needed boundary.",
      "sha256": "34b1406c241c11dca06c8b141be7e57a5edfde667924f6876ab231d499caa513",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.plan",
      "title": "Choose one What, with the How skills",
      "text": "For this try, choose Observe, Describe or Participate. You do not need to work through all three. The earlier sections are options to learn and return to, not a required ladder.\n\nConsider how to approach it without a verdict, with attention to one thing, and in a way that fits the aim. You do not need to monitor or score all three How skills while practising. Choose the part you want to pay attention to with your therapist.\n\nSet a small amount or stopping point that fits you. Check any support and what would be a reason to pause or stop. This page has no required timer and does not approve a practice.",
      "sha256": "894ef623c4a44350d61deba0bb124df05f6720eb12dda938391e669850be18ce",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.plan.help",
      "title": "If you are not ready to choose",
      "text": "Read the example, discuss the choice in your session or finish. You do not have to use a personal situation or write a plan to continue using the page.",
      "sha256": "3f3682fd65352fc44573918c5045a58994039ee533d5f345091814198995e08e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.try",
      "title": "Try the chosen skill, if it still fits",
      "text": "Read the guidance you need, then give the chosen practice a little space. Observe, Describe or Participate as you agreed, using the How skills to guide your approach. You can keep this page open without writing while you practise.\n\nYou may stop, change to another suitable skill or not begin. If you change What skills, do one at a time. Keep needed awareness and support. Nothing here marks an attempt or measures your attention.\n\nWhen you are ready, return to review. Pressing Next or reading an example is not the practice itself. If you leave or reload, notes here will clear; keep selected notes first if you want them.",
      "sha256": "36eb48942f88ec6144cdd7f55eccaa23e8ac38762c5c1e3e6f89cde8964c076f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.try.help",
      "title": "If the practice increases distress",
      "text": "Stop or change focus with support. You do not need to keep watching a thought, feeling or sensation to make it go away. Contact your therapist or appropriate support if you need help; this page is not monitored.",
      "sha256": "43c419e5014e6ad17641b2b4dcb93993ca1bb01338caf9e76b5dab4f230fe5c4",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.review",
      "title": "Review the try you actually made",
      "text": "What did you actually try, change, stop or not begin? Which What skill were you using, and when did you switch if you did? If you did not practise, there is no result to invent; you can still discuss fit or barriers.\n\nWhat did you notice about the experience and the How skills? Perhaps you shifted from noticing to describing, constant checking interrupted participation, or a useful change helped the task fit. Describe your own result, including uncertainty or no clear change.\n\nWas the practice workable with your needs and limits? Any calm or discomfort is information, not a pass or fail. Do not treat noticing a judgment or wandering attention as a defect to erase.",
      "sha256": "e8688fc9bff528e60c3792248edcbf14fd0a2573ff1dd4fbd0e1718669389e28",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.review.help",
      "title": "If the result was mixed or unhelpful",
      "text": "Keep that information. You do not owe the exercise a positive review. Discuss a shorter try, another skill, better support or no further practice before repeating something that did not fit.",
      "sha256": "e040a36d7072e017938defc4969658c46e16aa77fbc1b47e6f3fff9f61a24932",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "dbt-mindfulness-what-how.practice.next",
      "title": "Choose what to bring to your therapist",
      "text": "What would you keep, adapt or ask about? A next practice may use the same What skill or another one, with the How qualities. You do not need to finish a set or build a streak.\n\nAgree any next step with your therapist. The choice may be to pause this practice while you find a better fit. You can bring only the notes you choose, or describe the experience in your own way.",
      "sha256": "9feb245b3d35870f8781162dec5fdb79a744338a7cf2c93e89cf4c22f574f89e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "dbt-mindfulness-what-how.practice.next.help",
      "title": "If you want to keep a note",
      "text": "Choose notes to keep shows only what you select for preview, copy or download. Nothing is sent to your therapist and no practice history is stored after you leave.",
      "sha256": "594063dc6d0ad37fd42983a9fed08e02105c72a42576b274e23a813ff91f30ee",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
