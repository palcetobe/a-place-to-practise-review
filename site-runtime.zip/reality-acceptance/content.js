window.RealityAcceptanceContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/radical",
  "resourceId": "tool/reality-acceptance",
  "routeProposal": "/reality-acceptance/",
  "title": "Reality Acceptance Skills",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Practise facing one ordinary fact without giving up your rights, needs or choices.",
  "groupedSetStatus": "One existing grouped canonical entry, classic/radical. Radical Acceptance, Turning the Mind, Willingness, Half-Smiling and Willing Hands, and Mindfulness of Current Thoughts are distinct related components. The integrated ordinary-context written practice does not establish complete DBT treatment, clinical acceptance or a new count for each component.",
  "implementedComponentIds": [
    "component/radical/radical-acceptance",
    "component/radical/turning-the-mind",
    "component/radical/willingness",
    "component/radical/half-smiling-and-willing-hands",
    "component/radical/mindfulness-of-current-thoughts"
  ],
  "clinicalContract": {
    "learningObjective": "Distinguish acknowledging a real fact from approval or resignation; practise acceptance, rechoosing it, and an effective willing response while respecting safety and capacity.",
    "practiceObjective": "Use one therapist-introduced ordinary fact; notice resistance without blame; practise mind/body openness with optional named techniques; rehearse a fitting response; review actual experience without requiring acceptance or emotion change.",
    "sourcePopulationContext": "Linehan professional DBT teaching material establishes component methods, not validation of this isolated digital adaptation or universal age suitability. No blanket adult-only or 16+ rule. Individually adapt development, safeguarding, culture, power, health, communication and disability/access needs.",
    "exclusions": [
      "No approval, forgiveness, blame, obedience, resignation or remaining in danger implied",
      "No trauma reconstruction, severe-loss processing, crisis treatment or compelled exposure in this bounded tool",
      "No treating feared future outcomes, hostile interpretations or global self-judgments as established facts",
      "No required body change, inward attention, breath manipulation, smile or physical performance",
      "No forced commitment, disclosure, achieved-acceptance verdict or distress-reduction score"
    ],
    "adaptations": [
      "Wholly original client text, prompts and example; no Linehan handout/worksheet wording or copyrighted source pages reproduced",
      "One ordinary therapist-introduced fact rather than an unrestricted trauma/crisis exercise",
      "Named components retain distinct procedures and source roles; optional use does not imply equivalence",
      "Body practice can be skipped, kept mental, or replaced with ordinary external orientation without claiming identical physical practice",
      "Thought observation does not label real harm imaginary or dispute thought content",
      "Review includes not trying, stopping, no change, more distress, uncertainty and support needs"
    ],
    "reviewGates": [
      "Owner/clinician method and wording review, including five named component boundaries",
      "Individual developmental, safeguarding, cultural and medical/access fit",
      "Human comprehension at intended reading level; no validated grade-five claim",
      "Real integrated desktop/mobile/keyboard/screen-reader and exit/support/privacy acceptance",
      "Authorized narration generation, exact-script listening and media controls before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use an ordinary situation introduced with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Practise my chosen situation",
          "startSectionId": "reality-acceptance.practice.fact"
        },
        {
          "value": "review",
          "label": "Review a practice",
          "startSectionId": "reality-acceptance.practice.review"
        }
      ]
    },
    "entryGate": "Visible therapist-introduced fit and boundaries before explicit entry choice. Choice does not certify safety or achieved acceptance. Example/Learn/Finish/support remain available.",
    "focus": "One meaningful prompt group with free jump, Show all, Previous and Finish. No required writing, movement or completion lock.",
    "reviewAccess": "Direct blank review with no attempt or stored answers required. Navigating is not evidence that any component was practised.",
    "writing": "Hidden and optional initially; fiction never fills notes. Hide removes private display and invalidates export selection.",
    "persistence": "Open-page memory only; internal readings and navigation retain notes. Clear/restart/leaving/reload/history/BFCache clear. Visibility change alone retains notes.",
    "export": "Choose individual notes; exact preview; copy/download only selected text. No default selection. Edit/hide/mode change invalidates export.",
    "narration": "Exact fixed public paragraph/help scopes only, not notes. Script-only; no media, TTS, autoplay or activation.",
    "timer": "None. Brief practice is self-paced, with no required duration, breath count or physiological target.",
    "completion": "No achieved acceptance, willingness, success, attempt, mood, score or streak state."
  },
  "intro": {
    "id": "reality-acceptance.intro",
    "title": "Face a fact and keep your choices",
    "paragraphs": [
      "Reality acceptance means making room for what is true right now, even when you wish it were different. It does not mean liking it, saying it is fair, or giving up the chance to change what comes next.",
      "These DBT skills offer ways to practise that. You can face a fact, notice when you turn away from it, and choose a helpful response. You do not have to feel calm or say you accept something before you can stop."
    ]
  },
  "fit": {
    "id": "reality-acceptance.fit",
    "title": "Choose a small, ordinary fact",
    "paragraphs": [
      "Start with a manageable situation your therapist has helped you choose, such as a changed plan. Use something known about the present or past, not a feared future event. This page cannot decide what fits you.",
      "Acceptance is not approval, blame or forgiveness. It does not mean staying unsafe, accepting unfair treatment as okay, or giving up help and action. If safety needs your attention, deal with that first. You do not need to finish a skill.",
      "This practice is not for going over trauma, abuse or a major loss on your own. If the topic feels too much, pause and ask for support. You can read the example or Learn more instead.",
      "All writing, inward attention and body movements are optional. Keep your eyes open if you prefer. Skip anything painful, distressing or hard for your body. There is no face, posture or feeling you need to produce."
    ]
  },
  "privacy": {
    "id": "reality-acceptance.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, private history and contact details are not needed. Notes stay while you use this open tool, including the example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes to your therapist. Optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "reality-acceptance.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can stop whether you tried a skill, skipped it, felt no change or are not ready to accept this fact. Acceptance is not a test you pass. You can seek help or take needed action without finishing.",
      "Return to a prompt if you wish, or choose notes to keep for your session. Finish and clear removes notes in this tool, not copies you have kept elsewhere."
    ]
  },
  "example": {
    "id": "reality-acceptance.example",
    "title": "Ari finds the class has been cancelled",
    "paragraphs": [
      "This is a made-up ordinary example, not a situation you need to copy. Ari and their therapist have used changed plans to learn reality acceptance. Ari arrives for a hobby class and reads a notice saying today's class is cancelled.",
      "Fact: The class will not happen today. Ari does not yet know why. \"They do not care about me\" is a guess, not part of the fact. Ari can still ask about the next class or a refund.",
      "Reaction: Ari feels upset and thinks, \"This should not have happened.\" Ari keeps checking the same notice. The feeling makes sense. Rechecking will not make today's class start.",
      "Radical Acceptance: Ari tries, \"I wanted the class. It is cancelled today. I can dislike that and still decide what to do.\" Ari does not need to know every cause or say the cancellation was fair.",
      "Body choice: Ari is comfortable letting their hands rest open on their lap. Ari skips the half-smile. These are choices, not proof of acceptance. Ari still feels upset.",
      "Thought practice: \"They do not care\" appears again. Ari notices it as a thought without trying to push it out or treat it as a fact. Ari looks back at the notice and at the choices now available.",
      "Turning the Mind: When \"This cannot be happening\" returns, Ari notices the pull to argue with the fact. Ari chooses to face it again for this moment. The thought returning does not erase the first choice.",
      "Willingness: Ari chooses to ask the desk when the class will next run. Ari quietly practises the question, then asks. The desk says it is not yet arranged. Ari decides to go home and check later, rather than keep asking for certainty.",
      "Review: Ari used some skills, not all of them. The plan changed and the upset did not disappear. Ari did ask a useful question and chose what to do next. Ari will discuss what helped and what was hard at the next session."
    ]
  },
  "learn": {
    "id": "reality-acceptance.learn",
    "title": "Five related skills, with different jobs",
    "paragraphs": [
      "Radical Acceptance means facing reality as fully as you can, with your mind and how you respond. \"Radical\" means whole. It does not mean liking what happened, excusing harm or deciding nothing can change.",
      "Turning the Mind is the choice to turn back toward acceptance when you notice you are fighting a fact again. Making that choice is not the same as already accepting. You may need to choose many times.",
      "Willingness means doing what helps in the situation, within your needs and limits. It can include asking for help, resting, setting a boundary or acting for change. It is not doing whatever someone tells you.",
      "Half-Smiling and Willing Hands are optional body practices that may support an open stance. They are not a demand to look happy or calm. Mindfulness of Current Thoughts means observing thoughts as mental events without clinging to them or pushing them away. It is not a test of whether a thought is true.",
      "A fact may be painful, and it may have causes you do not know. That does not make it deserved or okay. Facing what is here can go alongside protecting yourself and changing what you can.",
      "These skills differ from simply making room for a feeling or sorting what you control. Here you work with a fact, notice rejecting it, choose again, and try a fitting response. You can use support and familiar skills alongside this practice.",
      "People, needs or parts of life may still matter alongside this hard moment. You do not need to find a benefit in what happened, feel grateful or make yourself agree with a hopeful statement."
    ]
  },
  "practice": [
    {
      "id": "reality-acceptance.practice.fact",
      "title": "Name one fact, not the whole story",
      "paragraphs": [
        "Choose the small situation introduced with your therapist. What has happened, or is happening, that you wish were different? State one thing you know, in plain words.",
        "Keep unknowns separate. \"The class is cancelled today\" differs from \"Nothing ever works out for me.\" You do not have to accept a guess about the future or a judgment about your worth as fact."
      ],
      "fields": [
        {
          "key": "fact",
          "label": "One known fact",
          "optional": true
        },
        {
          "key": "unknowns",
          "label": "What is unknown or a guess",
          "optional": true
        }
      ],
      "help": {
        "title": "If you are not sure what is true",
        "text": "You can leave the fact open, seek information or take the question to your therapist. This practice does not ask you to ignore evidence, doubt your own experience or agree with another person's version."
      }
    },
    {
      "id": "reality-acceptance.practice.reaction",
      "title": "Notice the struggle without blaming yourself",
      "paragraphs": [
        "When you meet this fact, what thoughts, feelings or urges show up? You may notice \"It should not be this way\", pulling away, tensing or trying to make the past different. You may notice none of these.",
        "What happens when you keep arguing with this fact? What might change if you made a little room for it? Notice both the reasons you hold back and the possible costs. This is not a test of effort or character."
      ],
      "fields": [
        {
          "key": "reaction",
          "label": "Thoughts, feelings or urges I notice",
          "optional": true
        },
        {
          "key": "holding-back",
          "label": "What makes facing this hard",
          "optional": true
        },
        {
          "key": "effects",
          "label": "What the struggle does, and what making room might allow",
          "optional": true
        }
      ],
      "help": {
        "title": "If you feel unwilling or unable",
        "text": "Not being ready is not a failure. Pain, fear, fatigue, disability, lack of help or real danger may matter. Ask what you need. Do not label yourself difficult or force acceptance."
      }
    },
    {
      "id": "reality-acceptance.practice.meaning",
      "title": "Say what acceptance does and does not mean",
      "paragraphs": [
        "Try a sentence that names the fact without adding approval. For example: \"This has happened. I wish it had not. I can decide what to do next.\" Use your own words, or just read without saying them.",
        "What rights, needs or choices remain? You can accept that something happened and still make a complaint, ask for help, keep a boundary or try to change what comes next."
      ],
      "fields": [
        {
          "key": "acceptance-words",
          "label": "Words I could try, without approval",
          "optional": true
        },
        {
          "key": "rights-choices",
          "label": "Rights, needs and choices I keep",
          "optional": true
        }
      ],
      "help": {
        "title": "If the words feel false",
        "text": "You can try \"I am noticing how hard it is to face this fact\" or leave the sentence open. Do not tell yourself you accept it when you do not. This is practice, not a pledge."
      }
    },
    {
      "id": "reality-acceptance.practice.context",
      "title": "Leave room for causes and for change",
      "paragraphs": [
        "Many things can lead to an event. You may know some and not others. You do not need to trace a whole history or decide who deserved what happened. Understanding a cause does not excuse harm.",
        "Which part is already true and cannot be undone? What could still change now or later, with help if needed? You can stop trying to undo the past while still acting on a current problem."
      ],
      "fields": [
        {
          "key": "context",
          "label": "What I know or do not know about how this happened",
          "optional": true
        },
        {
          "key": "possible-change",
          "label": "What might still change, or where help is needed",
          "optional": true
        }
      ],
      "help": {
        "title": "If this turns into a search for every reason",
        "text": "You can stop the search. The aim is not to solve the whole past or prove why this had to happen. Return to the one fact, what you need now, or a question for your therapist."
      }
    },
    {
      "id": "reality-acceptance.practice.radical",
      "title": "Radical Acceptance: mind and body",
      "paragraphs": [
        "Read or think of the fact once, if it feels manageable. Notice whether you are treating it as something that must not exist. You might try, \"It is here, even though I do not want it.\" No words are required.",
        "If comfortable, notice how you are holding your body. Could you ease a little strain without forcing it? You can keep your usual posture and breathing. You can also look at a steady object around you instead of focusing inside.",
        "Feelings may stay, grow or change. Sadness may show up, or it may not. You do not have to push a feeling away, make one appear or feel accepting. If distress rises or you feel far away from the room, stop the exercise and use a familiar way to steady yourself or get support."
      ],
      "fields": [
        {
          "key": "mind-practice",
          "label": "What I tried with the fact",
          "optional": true
        },
        {
          "key": "body-choice",
          "label": "A body or outside-focus option, or what I skipped",
          "optional": true
        }
      ],
      "help": {
        "title": "If facing the fact feels too much",
        "text": "Pause, look around and reconnect with what is around you if that helps. Choose a smaller topic or leave this for your therapist. Staying distressed to finish the exercise is not required."
      }
    },
    {
      "id": "reality-acceptance.practice.body",
      "title": "Optional: Half-Smiling and Willing Hands",
      "paragraphs": [
        "Try either, both or neither, only if comfortable. For a half-smile, let your forehead, eyes and jaw rest as much as they easily can. Let the corners of your lips lift just a little. There is no need to grin, show teeth or hold a strained face.",
        "For willing hands, let your hands rest where they are supported. If comfortable, turn your palms upward and let your fingers lie loosely open. Do not stretch, force a position or move through pain.",
        "You can learn a gesture by itself first. To use it for acceptance, if it feels manageable, bring your chosen ordinary fact to mind while trying either gesture. You can skip the fact or stop. Learning the gesture alone is different from practising with the fact.",
        "Try briefly at your own pace, then return to your usual position. Notice any effect or no effect. You can keep your face and hands unchanged, or simply consider an open attitude. That choice is not a failed body practice. A gesture does not prove acceptance."
      ],
      "fields": [
        {
          "key": "body-notice",
          "label": "What I tried or skipped, and what I noticed",
          "optional": true
        }
      ],
      "help": {
        "title": "If smiling or moving does not fit",
        "text": "A smile is not owed to anyone. You do not have to appear happy about harm. Facial or hand movement may not fit your body, culture or needs. Skip it and use another part of the practice."
      }
    },
    {
      "id": "reality-acceptance.practice.thoughts",
      "title": "Optional: Mindfulness of Current Thoughts",
      "paragraphs": [
        "Notice one thought that is here, without searching for a painful one. You might quietly name it: \"I am noticing a thought.\" See whether you can watch it as something your mind is doing, without chasing it, arguing with it or pushing it out.",
        "Be curious about its words and how it shows up, without needing to explain it. Let the thought stay or move at its own pace. It is not a command or all of who you are. When attention gets caught in it, gently return to noticing. You do not need a blank mind or a new thought. A thought can matter without needing an answer at this moment.",
        "This does not turn real harm into \"just a thought\". If the practice feels unsettling, stop. You can look at an ordinary object, return to the room or ask for support instead."
      ],
      "fields": [
        {
          "key": "thought-noticed",
          "label": "A thought I noticed, if I want to note it",
          "optional": true
        },
        {
          "key": "thought-response",
          "label": "How I responded, or why I stopped or skipped",
          "optional": true
        }
      ],
      "help": {
        "title": "If observing thoughts becomes another struggle",
        "text": "You do not have to watch perfectly or make thoughts leave. Skip this part if it increases distress or makes you feel less present. Talk with your therapist about an option that fits."
      }
    },
    {
      "id": "reality-acceptance.practice.turn",
      "title": "Turning the Mind: choose again",
      "paragraphs": [
        "Notice a sign that you are fighting the same known fact again. It could be a phrase, an urge or an action. Just notice; do not scold yourself.",
        "If you are willing, choose to turn toward the fact for this moment. Try a short cue such as \"Back to what is here.\" Then return to one acceptance practice or a helpful action. Choosing the direction does not mean you have arrived at acceptance.",
        "If you turn away again, you can notice and choose again. There is no limit you must reach and no tally to keep. You may also need a pause or support before another try."
      ],
      "fields": [
        {
          "key": "turning-cue",
          "label": "How I might notice I am fighting this fact again",
          "optional": true
        },
        {
          "key": "turning-choice",
          "label": "A cue and a next step I could return to",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot choose acceptance now",
        "text": "You can acknowledge that too. Ask what makes the choice hard and what support you need. Turning the Mind is not a command to agree, stop protesting or stay in a harmful setting."
      }
    },
    {
      "id": "reality-acceptance.practice.willing",
      "title": "Willingness: rehearse a fitting response",
      "paragraphs": [
        "With this fact here, what response would help now and fit your needs and limits? It may be action, rest, asking for help, setting a boundary or waiting for more information. Willingness is not obedience.",
        "Choose one small response. If useful, say its first words quietly or picture the first step. You can describe it instead of using an image. Practise how you might act while facing the fact, without pretending to feel okay.",
        "What might get in the way? If you feel stuck, what seems at risk if you face the fact or try this response? Take real safety needs seriously. What support or smaller step could help? A response that asks more than you can do needs to change. You do not have to push past pain or give up protection to be willing."
      ],
      "fields": [
        {
          "key": "willing-response",
          "label": "A fitting response and how I could rehearse it",
          "optional": true
        },
        {
          "key": "willing-support",
          "label": "What might get in the way, and a smaller step or support",
          "optional": true
        }
      ],
      "help": {
        "title": "If someone calls a boundary willful",
        "text": "A label does not decide what is safe or right for you. Keep consent, care and needed protections. Discuss the situation and power differences with your therapist. An inability to act is not proof of unwillingness."
      }
    },
    {
      "id": "reality-acceptance.practice.use",
      "title": "Try only what fits, then leave space to review",
      "paragraphs": [
        "You may have already tried a small part while reading. Or you may have only read, planned or skipped it. This page does not decide what you did.",
        "If you choose a real-world next step, keep it small and within what you have discussed with your therapist. Check current needs, safety and support. Needed action does not have to wait until you feel accepting.",
        "Think of one time you might meet this fact again. If useful, rehearse your cue and first helpful response now, in words or your mind. You can stop here or return later to Review a practice. These notes do not stay when you leave or reload. Use Choose notes to keep first if you want a copy."
      ],
      "help": {
        "title": "If nothing changed",
        "text": "The aim is not to make a feeling disappear or prove you accepted. You can note no change, a harder moment or that the practice did not fit. That can guide the next conversation with your therapist."
      }
    },
    {
      "id": "reality-acceptance.practice.review",
      "title": "Review what you actually tried",
      "paragraphs": [
        "Recall or check the small fact and the part you tried. If you cannot remember, leave it open rather than invent an answer. You can review a full try, a brief try, stopping, or not trying at all.",
        "What did you notice in your thoughts, feelings or actions? What did you actually do next? Keep hoped-for results separate from what happened. No change or more distress is worth naming too.",
        "What was useful, unhelpful or unclear? Would a smaller topic, another skill or more support fit better? You do not have to claim acceptance or rate yourself.",
        "Bring any questions or concerns to your therapist. You can keep a useful cue, change the plan with support, or leave it here. This page does not send your notes or arrange help."
      ],
      "fields": [
        {
          "key": "actual-practice",
          "label": "What I tried, stopped, skipped or did not try",
          "optional": true
        },
        {
          "key": "actual-notice",
          "label": "What I noticed or actually did next",
          "optional": true
        },
        {
          "key": "learning",
          "label": "What was useful, hard or unclear",
          "optional": true
        },
        {
          "key": "therapy-review",
          "label": "What I want to keep, change or discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If you need more support",
        "text": "Use Support and urgent help to find help options. You do not need to complete this practice first. This tool is not monitored and does not alert your therapist or anyone else."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan: official DBT teaching notes",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-4teaching.pdf?t=1",
      "supports": "Distinct reality-acceptance components and their procedures: whole acceptance, repeated choice, effective willingness, optional body practices and observing thoughts.",
      "limits": "Professional teaching source; not validation of this digital adaptation or universal age suitability. Source pages and handout/worksheet wording are not reproduced. Public access is not permission to redistribute the source."
    },
    {
      "id": "Linehan: official DBT worksheet reference",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-worksheets.pdf?t=1",
      "supports": "Named component identities and distinction between practice and reflection.",
      "limits": "Reference only. This product does not reproduce or redistribute the copyrighted worksheets. Original wording and example require independent clinical and accessibility review."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Known fact, resistance, acceptance versus approval, causes/choice and whole-person practice",
      "componentId": "component/radical/radical-acceptance",
      "sections": [
        "practice.fact",
        "practice.reaction",
        "practice.meaning",
        "practice.context",
        "practice.radical",
        "practice.use",
        "learn"
      ],
      "source": "Linehan official teaching notes; original book pp38–39 for brief starting intent"
    },
    {
      "operation": "Notice rejecting the fact, choose direction, return repeatedly and plan a cue",
      "componentId": "component/radical/turning-the-mind",
      "sections": [
        "practice.turn",
        "practice.use"
      ],
      "source": "Linehan official teaching notes"
    },
    {
      "operation": "Effective response consistent with needs, rehearsal, obstacles and support",
      "componentId": "component/radical/willingness",
      "sections": [
        "practice.willing",
        "practice.use"
      ],
      "source": "Linehan official teaching notes; conservative rights/access safeguards"
    },
    {
      "operation": "Optional small unstrained facial change and relaxed open supported hands; notice without target feeling",
      "componentId": "component/radical/half-smiling-and-willing-hands",
      "sections": [
        "practice.body"
      ],
      "source": "Linehan official teaching notes; accessibility/choice adaptation"
    },
    {
      "operation": "Observe thoughts as events without clinging, suppression or content debate, return attention and stop if unsuitable",
      "componentId": "component/radical/mindfulness-of-current-thoughts",
      "sections": [
        "practice.thoughts"
      ],
      "source": "Linehan official teaching notes; external-orientation alternative"
    },
    {
      "operation": "Actual experience, non-use and support-informed review without acceptance score",
      "sections": [
        "practice.review"
      ],
      "source": "Original book reflection intent; conservative product adaptation"
    }
  ],
  "narrationSegments": [
    {
      "id": "reality-acceptance.intro",
      "title": "Face a fact and keep your choices",
      "text": "Reality acceptance means making room for what is true right now, even when you wish it were different. It does not mean liking it, saying it is fair, or giving up the chance to change what comes next.\n\nThese DBT skills offer ways to practise that. You can face a fact, notice when you turn away from it, and choose a helpful response. You do not have to feel calm or say you accept something before you can stop.",
      "sha256": "351ae157750bc6624e4afda0a990689ebfab3c369660dc50c3eab597782b0da1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.fit",
      "title": "Choose a small, ordinary fact",
      "text": "Start with a manageable situation your therapist has helped you choose, such as a changed plan. Use something known about the present or past, not a feared future event. This page cannot decide what fits you.\n\nAcceptance is not approval, blame or forgiveness. It does not mean staying unsafe, accepting unfair treatment as okay, or giving up help and action. If safety needs your attention, deal with that first. You do not need to finish a skill.\n\nThis practice is not for going over trauma, abuse or a major loss on your own. If the topic feels too much, pause and ask for support. You can read the example or Learn more instead.\n\nAll writing, inward attention and body movements are optional. Keep your eyes open if you prefer. Skip anything painful, distressing or hard for your body. There is no face, posture or feeling you need to produce.",
      "sha256": "ec73cf46501ee6d7b0b573ceb21e1abddcf2d3194170b3d6291625f06e043aa8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, private history and contact details are not needed. Notes stay while you use this open tool, including the example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes to your therapist. Optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "2a91333590159c7146c4a27d270b4e3208dd7d5b9ae9abfa1c443fea13d56d46",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.close",
      "title": "Leave the practice here",
      "text": "You can stop whether you tried a skill, skipped it, felt no change or are not ready to accept this fact. Acceptance is not a test you pass. You can seek help or take needed action without finishing.\n\nReturn to a prompt if you wish, or choose notes to keep for your session. Finish and clear removes notes in this tool, not copies you have kept elsewhere.",
      "sha256": "98bbf20214183d8ac70b0ade021fb335f8bfe23d35c05cfbe63601e79f24f7d3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.example",
      "title": "Ari finds the class has been cancelled",
      "text": "This is a made-up ordinary example, not a situation you need to copy. Ari and their therapist have used changed plans to learn reality acceptance. Ari arrives for a hobby class and reads a notice saying today's class is cancelled.\n\nFact: The class will not happen today. Ari does not yet know why. \"They do not care about me\" is a guess, not part of the fact. Ari can still ask about the next class or a refund.\n\nReaction: Ari feels upset and thinks, \"This should not have happened.\" Ari keeps checking the same notice. The feeling makes sense. Rechecking will not make today's class start.\n\nRadical Acceptance: Ari tries, \"I wanted the class. It is cancelled today. I can dislike that and still decide what to do.\" Ari does not need to know every cause or say the cancellation was fair.\n\nBody choice: Ari is comfortable letting their hands rest open on their lap. Ari skips the half-smile. These are choices, not proof of acceptance. Ari still feels upset.\n\nThought practice: \"They do not care\" appears again. Ari notices it as a thought without trying to push it out or treat it as a fact. Ari looks back at the notice and at the choices now available.\n\nTurning the Mind: When \"This cannot be happening\" returns, Ari notices the pull to argue with the fact. Ari chooses to face it again for this moment. The thought returning does not erase the first choice.\n\nWillingness: Ari chooses to ask the desk when the class will next run. Ari quietly practises the question, then asks. The desk says it is not yet arranged. Ari decides to go home and check later, rather than keep asking for certainty.\n\nReview: Ari used some skills, not all of them. The plan changed and the upset did not disappear. Ari did ask a useful question and chose what to do next. Ari will discuss what helped and what was hard at the next session.",
      "sha256": "5a42aa1687b7dced9404e67fd29bd67ebd3df2157487c42e270089f6fef0e8ab",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.learn",
      "title": "Five related skills, with different jobs",
      "text": "Radical Acceptance means facing reality as fully as you can, with your mind and how you respond. \"Radical\" means whole. It does not mean liking what happened, excusing harm or deciding nothing can change.\n\nTurning the Mind is the choice to turn back toward acceptance when you notice you are fighting a fact again. Making that choice is not the same as already accepting. You may need to choose many times.\n\nWillingness means doing what helps in the situation, within your needs and limits. It can include asking for help, resting, setting a boundary or acting for change. It is not doing whatever someone tells you.\n\nHalf-Smiling and Willing Hands are optional body practices that may support an open stance. They are not a demand to look happy or calm. Mindfulness of Current Thoughts means observing thoughts as mental events without clinging to them or pushing them away. It is not a test of whether a thought is true.\n\nA fact may be painful, and it may have causes you do not know. That does not make it deserved or okay. Facing what is here can go alongside protecting yourself and changing what you can.\n\nThese skills differ from simply making room for a feeling or sorting what you control. Here you work with a fact, notice rejecting it, choose again, and try a fitting response. You can use support and familiar skills alongside this practice.\n\nPeople, needs or parts of life may still matter alongside this hard moment. You do not need to find a benefit in what happened, feel grateful or make yourself agree with a hopeful statement.",
      "sha256": "fb892cac6698ad6c1988ad1f2c13da197f47aed473726adc492dce402321ab19",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.fact",
      "title": "Name one fact, not the whole story",
      "text": "Choose the small situation introduced with your therapist. What has happened, or is happening, that you wish were different? State one thing you know, in plain words.\n\nKeep unknowns separate. \"The class is cancelled today\" differs from \"Nothing ever works out for me.\" You do not have to accept a guess about the future or a judgment about your worth as fact.",
      "sha256": "f15b104f3d9fbba321a3826babe9ac893edd44393771d19683c2789d29df22c9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.fact.help",
      "title": "If you are not sure what is true",
      "text": "You can leave the fact open, seek information or take the question to your therapist. This practice does not ask you to ignore evidence, doubt your own experience or agree with another person's version.",
      "sha256": "1c514116adb99159b3a985dbdc8d5efa73f191886ac80d18c6b553af05563f01",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.reaction",
      "title": "Notice the struggle without blaming yourself",
      "text": "When you meet this fact, what thoughts, feelings or urges show up? You may notice \"It should not be this way\", pulling away, tensing or trying to make the past different. You may notice none of these.\n\nWhat happens when you keep arguing with this fact? What might change if you made a little room for it? Notice both the reasons you hold back and the possible costs. This is not a test of effort or character.",
      "sha256": "884916727ce151d7bcb6623b0bc7ded0e5c13f38bae534bf00bc25cf31cc7533",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.reaction.help",
      "title": "If you feel unwilling or unable",
      "text": "Not being ready is not a failure. Pain, fear, fatigue, disability, lack of help or real danger may matter. Ask what you need. Do not label yourself difficult or force acceptance.",
      "sha256": "f86bc1a829ee758b177a460498cff91d89d6364cddae83b380561196ab97f669",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.meaning",
      "title": "Say what acceptance does and does not mean",
      "text": "Try a sentence that names the fact without adding approval. For example: \"This has happened. I wish it had not. I can decide what to do next.\" Use your own words, or just read without saying them.\n\nWhat rights, needs or choices remain? You can accept that something happened and still make a complaint, ask for help, keep a boundary or try to change what comes next.",
      "sha256": "d3013350c7f16636a07f9d21c1ed17638351bb97379246a2c61e4110f6290bef",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.meaning.help",
      "title": "If the words feel false",
      "text": "You can try \"I am noticing how hard it is to face this fact\" or leave the sentence open. Do not tell yourself you accept it when you do not. This is practice, not a pledge.",
      "sha256": "c12e4754fb6d30609327f624b717afb5f7f38ec1cf356a031480dfedd97a64b4",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.context",
      "title": "Leave room for causes and for change",
      "text": "Many things can lead to an event. You may know some and not others. You do not need to trace a whole history or decide who deserved what happened. Understanding a cause does not excuse harm.\n\nWhich part is already true and cannot be undone? What could still change now or later, with help if needed? You can stop trying to undo the past while still acting on a current problem.",
      "sha256": "a7a85b3507522f20a74174b7a12b5a775dae07bb0249b41bf894cf13878d4fdf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.context.help",
      "title": "If this turns into a search for every reason",
      "text": "You can stop the search. The aim is not to solve the whole past or prove why this had to happen. Return to the one fact, what you need now, or a question for your therapist.",
      "sha256": "05be8bc4a5076b217c7456c6febdd30cbdfc4a42f1bb1beae97adf92702132f3",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.radical",
      "title": "Radical Acceptance: mind and body",
      "text": "Read or think of the fact once, if it feels manageable. Notice whether you are treating it as something that must not exist. You might try, \"It is here, even though I do not want it.\" No words are required.\n\nIf comfortable, notice how you are holding your body. Could you ease a little strain without forcing it? You can keep your usual posture and breathing. You can also look at a steady object around you instead of focusing inside.\n\nFeelings may stay, grow or change. Sadness may show up, or it may not. You do not have to push a feeling away, make one appear or feel accepting. If distress rises or you feel far away from the room, stop the exercise and use a familiar way to steady yourself or get support.",
      "sha256": "0a9729081b648ce7ba2331dea449f55832fb559bf8b4700bd27a1a0815adf1f5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.radical.help",
      "title": "If facing the fact feels too much",
      "text": "Pause, look around and reconnect with what is around you if that helps. Choose a smaller topic or leave this for your therapist. Staying distressed to finish the exercise is not required.",
      "sha256": "5bb4bcee39aa48087dbbb96f2d52e3c9453ffb61f45ea1766ee345557b2b0f2d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.body",
      "title": "Optional: Half-Smiling and Willing Hands",
      "text": "Try either, both or neither, only if comfortable. For a half-smile, let your forehead, eyes and jaw rest as much as they easily can. Let the corners of your lips lift just a little. There is no need to grin, show teeth or hold a strained face.\n\nFor willing hands, let your hands rest where they are supported. If comfortable, turn your palms upward and let your fingers lie loosely open. Do not stretch, force a position or move through pain.\n\nYou can learn a gesture by itself first. To use it for acceptance, if it feels manageable, bring your chosen ordinary fact to mind while trying either gesture. You can skip the fact or stop. Learning the gesture alone is different from practising with the fact.\n\nTry briefly at your own pace, then return to your usual position. Notice any effect or no effect. You can keep your face and hands unchanged, or simply consider an open attitude. That choice is not a failed body practice. A gesture does not prove acceptance.",
      "sha256": "fb8907035bd4c4ab365f19248ad628247207d65be6688ec7ad7eeac33d16e6a6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.body.help",
      "title": "If smiling or moving does not fit",
      "text": "A smile is not owed to anyone. You do not have to appear happy about harm. Facial or hand movement may not fit your body, culture or needs. Skip it and use another part of the practice.",
      "sha256": "695ffb788f2c6ac8b7c822969e9a91a2092f43cf38a4928ce8bd8cee607fcf6d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.thoughts",
      "title": "Optional: Mindfulness of Current Thoughts",
      "text": "Notice one thought that is here, without searching for a painful one. You might quietly name it: \"I am noticing a thought.\" See whether you can watch it as something your mind is doing, without chasing it, arguing with it or pushing it out.\n\nBe curious about its words and how it shows up, without needing to explain it. Let the thought stay or move at its own pace. It is not a command or all of who you are. When attention gets caught in it, gently return to noticing. You do not need a blank mind or a new thought. A thought can matter without needing an answer at this moment.\n\nThis does not turn real harm into \"just a thought\". If the practice feels unsettling, stop. You can look at an ordinary object, return to the room or ask for support instead.",
      "sha256": "67dc6e82d13700eac5f6b35081cfebf39f0764766d8c76dea9b9d8815638ad42",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.thoughts.help",
      "title": "If observing thoughts becomes another struggle",
      "text": "You do not have to watch perfectly or make thoughts leave. Skip this part if it increases distress or makes you feel less present. Talk with your therapist about an option that fits.",
      "sha256": "c7067c6dcd5e40d4e91aa1218e8699dd2f12f3ea8c02467b6e27b639d422ebaf",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.turn",
      "title": "Turning the Mind: choose again",
      "text": "Notice a sign that you are fighting the same known fact again. It could be a phrase, an urge or an action. Just notice; do not scold yourself.\n\nIf you are willing, choose to turn toward the fact for this moment. Try a short cue such as \"Back to what is here.\" Then return to one acceptance practice or a helpful action. Choosing the direction does not mean you have arrived at acceptance.\n\nIf you turn away again, you can notice and choose again. There is no limit you must reach and no tally to keep. You may also need a pause or support before another try.",
      "sha256": "24210a38635428e8e19283f42b074a2857b4c4093d82b5a329abc3a6080251ad",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.turn.help",
      "title": "If you cannot choose acceptance now",
      "text": "You can acknowledge that too. Ask what makes the choice hard and what support you need. Turning the Mind is not a command to agree, stop protesting or stay in a harmful setting.",
      "sha256": "1fd173bf0e9da695f0ec371f71aa5fe79e548e94f17ad6ad61b9c76e62494fcb",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.willing",
      "title": "Willingness: rehearse a fitting response",
      "text": "With this fact here, what response would help now and fit your needs and limits? It may be action, rest, asking for help, setting a boundary or waiting for more information. Willingness is not obedience.\n\nChoose one small response. If useful, say its first words quietly or picture the first step. You can describe it instead of using an image. Practise how you might act while facing the fact, without pretending to feel okay.\n\nWhat might get in the way? If you feel stuck, what seems at risk if you face the fact or try this response? Take real safety needs seriously. What support or smaller step could help? A response that asks more than you can do needs to change. You do not have to push past pain or give up protection to be willing.",
      "sha256": "647c7e24f87e4efef31b6e095fb39bc06070519a551f92590495aa3928d9538e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.willing.help",
      "title": "If someone calls a boundary willful",
      "text": "A label does not decide what is safe or right for you. Keep consent, care and needed protections. Discuss the situation and power differences with your therapist. An inability to act is not proof of unwillingness.",
      "sha256": "840bb09489104427477c5b0f556a25f3268aafbea6cd2d37aac751a566cc7576",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.use",
      "title": "Try only what fits, then leave space to review",
      "text": "You may have already tried a small part while reading. Or you may have only read, planned or skipped it. This page does not decide what you did.\n\nIf you choose a real-world next step, keep it small and within what you have discussed with your therapist. Check current needs, safety and support. Needed action does not have to wait until you feel accepting.\n\nThink of one time you might meet this fact again. If useful, rehearse your cue and first helpful response now, in words or your mind. You can stop here or return later to Review a practice. These notes do not stay when you leave or reload. Use Choose notes to keep first if you want a copy.",
      "sha256": "f1aebbc8636a53b0803c8b327c6f3d27d50d38fec81b01144debf23b33012975",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.use.help",
      "title": "If nothing changed",
      "text": "The aim is not to make a feeling disappear or prove you accepted. You can note no change, a harder moment or that the practice did not fit. That can guide the next conversation with your therapist.",
      "sha256": "301130deed828482b75c84f6b5c645b295b397e77f41c6d449eec9cbf1a2920e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "reality-acceptance.practice.review",
      "title": "Review what you actually tried",
      "text": "Recall or check the small fact and the part you tried. If you cannot remember, leave it open rather than invent an answer. You can review a full try, a brief try, stopping, or not trying at all.\n\nWhat did you notice in your thoughts, feelings or actions? What did you actually do next? Keep hoped-for results separate from what happened. No change or more distress is worth naming too.\n\nWhat was useful, unhelpful or unclear? Would a smaller topic, another skill or more support fit better? You do not have to claim acceptance or rate yourself.\n\nBring any questions or concerns to your therapist. You can keep a useful cue, change the plan with support, or leave it here. This page does not send your notes or arrange help.",
      "sha256": "6b486fac62e0513ccb6bde4570d827c6c09b822db0fb626cd6239fd2826315ca",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "reality-acceptance.practice.review.help",
      "title": "If you need more support",
      "text": "Use Support and urgent help to find help options. You do not need to complete this practice first. This tool is not monitored and does not alert your therapist or anyone else.",
      "sha256": "f9d6cbfb92707acf34acba842c276f88dc8b48a5f96bbdf5d40f8a029c920bea",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
