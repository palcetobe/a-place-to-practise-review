window.MiddlePathWiseMindContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/mindful",
  "componentId": "component/mindful/walking-the-middle-path-to-wise-mind",
  "resourceId": "tool/middle-path-wise-mind",
  "routeProposal": "/middle-path-wise-mind/",
  "title": "Walking the Middle Path to Wise Mind",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "A therapist-introduced mindfulness application: consider four named tensions, examine one ordinary behavior pattern against facts, context and your own values, choose a fitting adjustment, try it and review what happened.",
  "groupedSetStatus": "Existing uncounted component under classic/mindful. Complete bounded everyday application of Mindfulness Handout 10 and Worksheets 10/10a/10b, not their reproduced forms/calendars, a full mindfulness set, family/interpersonal middle-path curriculum or dialectical-abstinence treatment. Candidate route only; no new canonical count.",
  "clinicalContract": {
    "learningObjective": "Recognize the four source polarities and distinguish context-sensitive synthesis from compromise, equal shares, moral judgment or a guaranteed inner answer; preserve valid facts, emotions, goals, present experience, limits and enjoyment.",
    "practiceObjective": "Choose a manageable familiar dilemma, describe observable too-much/too-little patterns without forcing imbalance, check facts and individual values/access/context, identify what both sides contribute, choose one feasible behavior adjustment, distinguish actual rehearsal and later practice, then evaluate concrete fit and remaining needs.",
    "sourcePopulationContext": "2015 author/publisher DBT optional mindfulness teaching informs this original adaptation and assumes relevant prior learning. It does not validate a digital tool. No age floor or all-age suitability claim; therapist checks clinical, developmental, cultural, communication, safeguarding and access fit.",
    "exclusions": [
      "No full adolescent/family/interpersonal middle-path curriculum, comprehensive DBT, addiction treatment or dialectical-abstinence procedure",
      "No numeric balance score, fixed 50–50 split, productivity norm, moderation target or personality classification",
      "No eating, exercise, medicine or substance-use plan; no withdrawal, restriction, care-plan change or compromise with a safety limit",
      "No false equivalence, accepting abuse, compulsory forgiveness, reconciliation, obedience or positive interpretation of harm",
      "No forced body/breath focus, closed eyes, trauma recall, exposure, sensory task or mobility assumption",
      "No claim of calm, inner certainty, equal validity of factual claims, successful behavior change or effect on another person"
    ],
    "adaptations": [
      "Original plain-language four-pair orientation and single-episode self-analysis, not copied worksheet, example, diagram, rating scale or weekly calendar",
      "Preserve source pair names while explaining practical contributions without moralizing disability, rest, enjoyment, resource limits or real support needs",
      "Source self-review and future behavior adjustment retained using an individually suitable opportunity and narrative review rather than weekly fields and optional calendar/rating formats",
      "Added accessible actual rehearsal before optional real-world use, with explicit distinction between planning, rehearsal and actual attempt",
      "Contextual safety, consent and care-plan limits are explicit; no generic advice to split the difference or change a harmful behavior by moderation"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of bounded source scope and source-use rights",
      "Individual prior learning, clinical, developmental, cultural, communication, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration generation and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose preparation or review",
      "options": [
        {
          "value": "prepare",
          "label": "Consider and try a small adjustment",
          "startSectionId": "middle-path-wise-mind.practice.situation"
        },
        {
          "value": "review",
          "label": "Review what I tried or did not try",
          "startSectionId": "middle-path-wise-mind.practice.review"
        }
      ]
    },
    "entryGate": "Scope and safety visible before entry. No default selection or clinical fit approved by choosing a mode.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence, writing, change or action.",
    "reviewAccess": "Direct blank review without a stored plan, inferred practice or result. Both modes expose all groups.",
    "writing": "Optional and hidden initially. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording or autoplay.",
    "timer": "None. No fixed practice duration, balance ratio, daily calendar or quota.",
    "completion": "No inferred balance, wise state, safety, rehearsal, action, improved outcome or learning."
  },
  "intro": {
    "id": "middle-path-wise-mind.intro",
    "title": "Find a response that keeps what matters",
    "paragraphs": [
      "The middle path brings useful parts of two different pulls together. It is not always halfway between them. What fits one person or moment may not fit another.",
      "This DBT mindfulness practice looks at four familiar pairs, then helps you examine one small pattern in what you do. You can choose a fitting change, try it and review it with your therapist. You do not have to find something wrong with yourself or make a change.",
      "Use this after your therapist has taught the relevant mindfulness skills. It is different from the full family or relationship middle-path programme. There is no need to walk, breathe in a special way, feel calm or find a perfect answer."
    ]
  },
  "fit": {
    "id": "middle-path-wise-mind.fit",
    "title": "Choose an ordinary pattern with support",
    "paragraphs": [
      "Choose a manageable, low-risk situation with your therapist, or use the made-up example. Keep health, energy, development, access, care needs and real limits in view. Rest, support or less pressure may be what fits.",
      "Do not use this practice to set or change eating, exercise, medicine or substance-use plans. Keep your care and safety plans. It does not teach addiction treatment or say to do a smaller amount of a harmful action.",
      "This is not a way to accept abuse, meet a threat halfway or make both factual claims true. You can protect a firm limit and seek help. Urgent safety needs come before reflection; use your existing urgent support if needed.",
      "Think, speak, sign or use a communication aid. Keep useful cues and support. If the exercise increases distress, checking or a sense of being cut off from your surroundings, pause and discuss it with your therapist. This page does not assess safety or provide urgent help."
    ]
  },
  "privacy": {
    "id": "middle-path-wise-mind.privacy",
    "title": "Writing and sharing are your choice",
    "paragraphs": [
      "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.",
      "Notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them from this tool. To keep notes, select only the parts you want, check the preview, then copy or download. Copies remain wherever you save them.",
      "Hiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may access writing when shown. Clearing this tool does not erase browser history, device activity or saved copies. The session shortcut keeps no answers and is not a saved item in your usual Toolbox."
    ]
  },
  "close": {
    "id": "middle-path-wise-mind.close",
    "title": "Finish without a balance score",
    "paragraphs": [
      "You can finish after reading, considering, rehearsing, trying or deciding not to practise. There is no required feeling, correct balance point or proof that you changed.",
      "If useful, bring a chosen observation or question to your therapist. No report, reminder or next task is created. Leaving removes notes from this tool, not copies elsewhere."
    ]
  },
  "example": {
    "id": "middle-path-wise-mind.example",
    "title": "Made-up example: a rainy drawing day",
    "paragraphs": [
      "Avery planned to draw outdoors, but rain changed the plan. Avery wants the weather to clear and keeps looking out of the window instead of using the available time. Avery is disappointed and starts to think the whole drawing day is lost.",
      "With the practice learned in therapy, Avery chooses the pair of wanting change and accepting the present. The concrete pattern is repeated weather checking and not starting a drawing. The rain is a fact right now; the claim that no drawing is possible is not. There is a suitable indoor place and no urgent task or access barrier in this example.",
      "Avery values making art and still wants an outdoor session. The middle path is not pretending to like the rain or giving up that wish. Avery chooses to acknowledge the wet weather and draw the tree from indoors for a small part of the free time.",
      "Avery rehearses an opening: \"I wish it were dry. It is raining now, and I can begin here.\" In the made-up follow-up, Avery actually places the paper by the window and draws a few lines. A new urge to check the forecast comes up. Avery returns to the chosen drawing, without claiming the weather or disappointment has changed.",
      "In review, Avery separates rehearsal from the later attempt. There was less repeated checking and some drawing, but the picture is unfinished and the outdoor plan is still on hold. Avery can keep, change or leave the practice. This does not prove that one response will fit every rainy day."
    ]
  },
  "learn": {
    "id": "middle-path-wise-mind.learn",
    "title": "Four pairs, not four tests of character",
    "paragraphs": [
      "Reasonable Mind and Emotion Mind: facts and practical thinking matter, and so do feelings and values. A feeling can be real while a guess about its cause is uncertain. Bringing them together does not make every guess true.",
      "Doing Mind and Being Mind: work toward what matters while noticing this moment. Awareness and useful action can happen together. This is not a rule to earn rest or split time evenly between work and breaks.",
      "Intense desire for change and Radical Acceptance: you can strongly want things to be different and face what is true now. Acceptance is not approval, surrender or giving up action that could help. Wanting change does not have to disappear.",
      "The source calls the fourth pair Self-Denial and Self-Indulgence: holding back from something you want, and giving yourself something you want. Each can fit or go too far, depending on the situation. The aim is fitting limits with room for enjoyment. A small pleasure is not wrong, and rest or basic care is not something to earn. This is not advice about food, health or substance use.",
      "Here the next step is specific: examine what you do, check the facts and your own values, and consider a small adjustment. A neat sentence alone is not a record of changing behavior. Balance may stay uncertain and can shift with context."
    ]
  },
  "practice": [
    {
      "id": "middle-path-wise-mind.practice.situation",
      "title": "Choose one manageable pattern",
      "paragraphs": [
        "Choose a familiar ordinary situation that fits your therapist’s guidance, or use Avery’s example. What makes you curious about trying a different response? You can also decide that no adjustment is needed.",
        "Name what happened without calling yourself a type of person. Include real limits, support needs and anything you do not know. This is not a review of everything you do or a search for faults."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The ordinary situation or made-up example",
          "optional": true
        },
        {
          "key": "context-and-fit",
          "label": "Why it may fit, and any limits or support needs",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot find a suitable pattern",
        "text": "Use the example, leave the question for therapy or finish. You do not need to invent an imbalance to use the page."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.pair",
      "title": "Choose a pair that helps describe it",
      "paragraphs": [
        "Consider the four pairs in Learn more: feelings with reason; useful doing with present awareness; wanting change with accepting what is here; and fitting limits with room for enjoyment. These are ways to look at a situation, not labels for people.",
        "Which pair fits the behavior you want to examine? Choose one you have learned with your therapist. The two sides may both have something useful to offer. If none fits, leave that open rather than force your situation into a pair."
      ],
      "fields": [
        {
          "key": "chosen-pair",
          "label": "The pair I am considering, or why none fits",
          "optional": true
        }
      ],
      "help": {
        "title": "If the fourth pair feels judging",
        "text": "You do not have to use it. Explore what counts as a real limit and what gives you needed care or enjoyment with your therapist. Having needs or wanting pleasure is not a fault."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.pattern",
      "title": "Describe what you do more and less",
      "paragraphs": [
        "In this situation, what specific action may be taking up more space than fits? What useful action may be getting less room? Describe an example that someone could notice, rather than words such as lazy, selfish or too emotional.",
        "Also keep what is already helpful. More and less are not automatic goals. An action can fit in one setting and not another. There may be nothing to change, or the problem may be a real barrier rather than your behavior."
      ],
      "fields": [
        {
          "key": "more-pattern",
          "label": "A concrete action that may be taking too much space",
          "optional": true
        },
        {
          "key": "less-pattern",
          "label": "A useful action that may be getting too little room",
          "optional": true
        },
        {
          "key": "already-helpful",
          "label": "What already fits, or why no change is needed",
          "optional": true
        }
      ],
      "help": {
        "title": "If someone else says it is too much",
        "text": "Check a concrete example, context and your own needs and values. Someone’s preference alone does not establish that you are out of balance."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.facts",
      "title": "Check the account before changing it",
      "paragraphs": [
        "What evidence supports your description? What is a fact, a guess, a feeling or a label? You can reword a judgment as a specific action, while leaving unknowns unknown. Feelings do not need proof to deserve care.",
        "Check energy, disability, resources, access, unfair demands and other conditions. Do not call a needed rest, care task or lack of support an excess or a failure. A fitting adjustment may be to the demand or support, rather than asking more of yourself."
      ],
      "fields": [
        {
          "key": "facts-and-unknowns",
          "label": "What is observed, felt, guessed or still unknown",
          "optional": true
        },
        {
          "key": "revised-pattern",
          "label": "A fairer description after checking the context",
          "optional": true
        }
      ],
      "help": {
        "title": "If two claims conflict",
        "text": "You do not have to make both true. Keep known facts, feelings and uncertainties separate. A fuller account can still include a firm boundary or an unanswered question."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.values",
      "title": "Check what matters to you",
      "paragraphs": [
        "What do you want your response to serve in this situation? It might be care, learning, enjoyment, fairness or another value. Include real responsibilities without assuming every demand is a valid duty.",
        "Does the possible change fit your own values and needs, not only another person’s idea of balance? A therapist can help you work through competing needs. There is no universal amount of doing, feeling or enjoyment that this page can prescribe."
      ],
      "fields": [
        {
          "key": "own-values",
          "label": "What matters to me in this situation",
          "optional": true
        },
        {
          "key": "values-fit",
          "label": "How a change or no change could fit my needs and real duties",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am unsure what my own view is",
        "text": "You can pause and explore it in therapy. You do not have to adopt someone else’s standard to complete this exercise."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.synthesis",
      "title": "Keep the useful contribution of each side",
      "paragraphs": [
        "What would each side add if it had a fitting place? For example, Avery can care about drawing outside and face the rain now. Neither the wish nor the fact needs to be removed.",
        "Try an account or response that keeps the useful parts together. It need not use the word and or split things halfway. Check that it does not deny a fact, erase a feeling or trade away safety, consent or a real limit."
      ],
      "fields": [
        {
          "key": "useful-parts",
          "label": "What each side can usefully contribute",
          "optional": true
        },
        {
          "key": "combined-response",
          "label": "A response that keeps what matters, or a question still open",
          "optional": true
        }
      ],
      "help": {
        "title": "If my answer is only a nice sentence",
        "text": "A sentence can help you think. The next question is what, if anything, you would actually do differently. You can also conclude that more support or no change is the right next step."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.plan",
      "title": "Choose one small, specific adjustment",
      "paragraphs": [
        "If a change fits, choose one concrete action to try at a suitable opportunity. It may mean doing less of something, making room for another action, or changing how you do it. Keep the useful purpose and the real limits in view.",
        "Make it small enough for your energy, skills and setting. Decide a natural place to begin and stop, and any support needed. This is a chosen experiment in your response, not an instruction to make the task harder or change a care plan."
      ],
      "fields": [
        {
          "key": "chosen-adjustment",
          "label": "One specific adjustment, or why I am not choosing one",
          "optional": true
        },
        {
          "key": "opportunity-and-support",
          "label": "A suitable opportunity, ending and support",
          "optional": true
        }
      ],
      "help": {
        "title": "If I want to change everything",
        "text": "Choose one manageable pattern with your therapist. You can leave other things alone. A longer plan is not proof of a wiser one."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.rehearse",
      "title": "Try the response in rehearsal if useful",
      "paragraphs": [
        "You can actually run through how you would start, silently, aloud, in writing, signing or with a communication aid. Keep the page as a cue if useful. Rehearse the action or words you chose rather than only listing what you intend to do.",
        "If an ordinary obstacle fits, try a response to it too. For example, Avery can practise noticing the wish for sun and returning to drawing. Do not create distress or a risky test. Rehearsal is not the same as trying it in the real situation."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I actually rehearsed or did not rehearse",
          "optional": true
        },
        {
          "key": "rehearsal-change",
          "label": "What to keep, change or ask about after rehearsal",
          "optional": true
        }
      ],
      "help": {
        "title": "If I do not rehearse",
        "text": "That is a valid choice. You can discuss the plan or finish. Do not record an imagined future result as something that happened."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.try",
      "title": "Try only when the opportunity fits",
      "paragraphs": [
        "At an agreed suitable time, you may try the small action with the support and limits you chose. Notice the situation as it is, rather than checking whether you feel perfectly balanced. Keep necessary safety checks and access aids.",
        "If the situation or your needs change, adjust, pause or get support. You do not have to keep going until you feel better. The opportunity may be later or may not happen. A plan on this page does not record an attempt or set a reminder."
      ],
      "fields": [
        {
          "key": "actual-try",
          "label": "What I actually tried, or why I did not try",
          "optional": true
        },
        {
          "key": "during-try",
          "label": "What I noticed or changed during a real attempt",
          "optional": true
        }
      ],
      "help": {
        "title": "If it feels like another performance test",
        "text": "Pause. This is not a score of character, productivity or calmness. Bring that pressure to your therapist and consider whether the practice fits at all."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.review",
      "title": "Review the behavior and its fit",
      "paragraphs": [
        "You can review without earlier notes. What did you actually do: read, consider, rehearse, try, stop or not practise? Keep no opportunity separate from choosing not to act. Rehearsal is not a real-world attempt.",
        "If you tried, compare what happened with the pattern you described. Was there a concrete change in what you did? Did the useful parts of both sides have room? Include unchanged behavior, difficulty, costs, help needed and what you cannot tell.",
        "Did the response fit your values, needs and situation? Calm, praise or a completed task is not proof. A difficult feeling can remain, and a seemingly balanced plan can turn out not to fit. Use those observations for discussion rather than a score."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What I actually did or did not do",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What changed, stayed the same or remains unknown",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What fitted, did not fit or needs support",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot judge the effect",
        "text": "Leave it uncertain. One attempt cannot prove a cause or a wise state. A concrete observation or question can still help the next discussion."
      }
    },
    {
      "id": "middle-path-wise-mind.practice.next",
      "title": "Keep, adjust or leave the practice",
      "paragraphs": [
        "With your therapist, decide whether to keep this adjustment, change it, use another skill or leave it for now. What fits may change with your circumstances. There is no daily quota or missed-practice debt.",
        "If useful, choose when and how to review a later attempt with your therapist. You can bring a question without written notes. Nothing here books that discussion, sends a report or creates a reminder."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What I might keep, change, pause or leave",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any support or review question to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If the pattern returns",
        "text": "That is information, not proof of failure. Check the setting, needs and support again. You do not have to repeat the exercise until the pattern disappears."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Handout 10",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed p. 74: four named polarities and synthesis rather than an either-or choice.",
      "limits": "Original words and example, not a reproduced balance-beam diagram, handout or source example. Historical Second Edition, not exact revised-2025 verification."
    },
    {
      "id": "Linehan/Guilford: 2015 mindfulness teaching, section XVI",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Printed pp. 225–227: prior learning, individual context, specific behavior descriptions and realistic adjustments; balance need not be equal shares.",
      "limits": "Distinct from the separate interpersonal/family middle-path curriculum. The section’s dialectical-abstinence application is not taught here. Source teaching is not digital efficacy evidence."
    },
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Worksheets 10, 10a and 10b",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed pp. 105–108: choose a dilemma, inspect concrete more/less behavior, check facts and own values, choose realistic action and review actual use.",
      "limits": "Original optional single-situation adaptation, not recreated forms, weekly calendar, score or copied worked example. Uses a chosen opportunity and narrative review instead of the source’s weekly fields and optional calendar/rating formats."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal, meaningful communication and access to support.",
      "limits": "Rights guidance, not clinical validation of this adaptation."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from the individual purchaser duplication licence.",
      "limits": "Accessible sources do not grant public app rights. Clinical and release-rights decisions remain open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Four-polarity orientation and selection of one fitting ordinary pattern",
      "sections": [
        "intro",
        "learn",
        "practice.situation",
        "practice.pair"
      ],
      "source": "Mindfulness Handout10; ManualXVI A; Worksheet10a, step1; no forced deficit"
    },
    {
      "operation": "Observable behavior, facts/context and own values",
      "sections": [
        "practice.pattern",
        "practice.facts",
        "practice.values"
      ],
      "source": "Worksheet10a, steps2–3; ManualXVI individualized and nonjudgmental application"
    },
    {
      "operation": "Synthesis and realistic specific adjustment",
      "sections": [
        "practice.synthesis",
        "practice.plan"
      ],
      "source": "Handout10; Worksheet10a, step4; no equal-share or morality rule"
    },
    {
      "operation": "Accessible rehearsal, optional real use, review and revision",
      "sections": [
        "practice.rehearse",
        "practice.try",
        "practice.review",
        "practice.next"
      ],
      "source": "Worksheet10/10a/10b actual-use review; original accessible rehearsal and non-calendar between-session adaptation"
    }
  ],
  "narrationSegments": [
    {
      "id": "middle-path-wise-mind.intro",
      "title": "Find a response that keeps what matters",
      "text": "The middle path brings useful parts of two different pulls together. It is not always halfway between them. What fits one person or moment may not fit another.\n\nThis DBT mindfulness practice looks at four familiar pairs, then helps you examine one small pattern in what you do. You can choose a fitting change, try it and review it with your therapist. You do not have to find something wrong with yourself or make a change.\n\nUse this after your therapist has taught the relevant mindfulness skills. It is different from the full family or relationship middle-path programme. There is no need to walk, breathe in a special way, feel calm or find a perfect answer.",
      "sha256": "0a19e3e626d7844d076fdda48fc738a60e14f2c65246f3e4fa4cd2f550d28afd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.fit",
      "title": "Choose an ordinary pattern with support",
      "text": "Choose a manageable, low-risk situation with your therapist, or use the made-up example. Keep health, energy, development, access, care needs and real limits in view. Rest, support or less pressure may be what fits.\n\nDo not use this practice to set or change eating, exercise, medicine or substance-use plans. Keep your care and safety plans. It does not teach addiction treatment or say to do a smaller amount of a harmful action.\n\nThis is not a way to accept abuse, meet a threat halfway or make both factual claims true. You can protect a firm limit and seek help. Urgent safety needs come before reflection; use your existing urgent support if needed.\n\nThink, speak, sign or use a communication aid. Keep useful cues and support. If the exercise increases distress, checking or a sense of being cut off from your surroundings, pause and discuss it with your therapist. This page does not assess safety or provide urgent help.",
      "sha256": "4a80c20e753665e6473574ab7201025585046ee26b7c56feb6c1b163ff1bfda7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.privacy",
      "title": "Writing and sharing are your choice",
      "text": "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.\n\nNotes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them from this tool. To keep notes, select only the parts you want, check the preview, then copy or download. Copies remain wherever you save them.\n\nHiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may access writing when shown. Clearing this tool does not erase browser history, device activity or saved copies. The session shortcut keeps no answers and is not a saved item in your usual Toolbox.",
      "sha256": "0ab139ff7a4ed87a86a5927e22f9ef5d5b7428cb34fb49b0ba28f2199cb5d659",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.close",
      "title": "Finish without a balance score",
      "text": "You can finish after reading, considering, rehearsing, trying or deciding not to practise. There is no required feeling, correct balance point or proof that you changed.\n\nIf useful, bring a chosen observation or question to your therapist. No report, reminder or next task is created. Leaving removes notes from this tool, not copies elsewhere.",
      "sha256": "87c0ea2d30f0e1ff66a638ca4918331504587eaa19e3b6beac55370ccfe4c2fd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.example",
      "title": "Made-up example: a rainy drawing day",
      "text": "Avery planned to draw outdoors, but rain changed the plan. Avery wants the weather to clear and keeps looking out of the window instead of using the available time. Avery is disappointed and starts to think the whole drawing day is lost.\n\nWith the practice learned in therapy, Avery chooses the pair of wanting change and accepting the present. The concrete pattern is repeated weather checking and not starting a drawing. The rain is a fact right now; the claim that no drawing is possible is not. There is a suitable indoor place and no urgent task or access barrier in this example.\n\nAvery values making art and still wants an outdoor session. The middle path is not pretending to like the rain or giving up that wish. Avery chooses to acknowledge the wet weather and draw the tree from indoors for a small part of the free time.\n\nAvery rehearses an opening: \"I wish it were dry. It is raining now, and I can begin here.\" In the made-up follow-up, Avery actually places the paper by the window and draws a few lines. A new urge to check the forecast comes up. Avery returns to the chosen drawing, without claiming the weather or disappointment has changed.\n\nIn review, Avery separates rehearsal from the later attempt. There was less repeated checking and some drawing, but the picture is unfinished and the outdoor plan is still on hold. Avery can keep, change or leave the practice. This does not prove that one response will fit every rainy day.",
      "sha256": "614e096476d3e953adb54aece945182f281ef0a82c35ac9e3b8559d7d87eb217",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.learn",
      "title": "Four pairs, not four tests of character",
      "text": "Reasonable Mind and Emotion Mind: facts and practical thinking matter, and so do feelings and values. A feeling can be real while a guess about its cause is uncertain. Bringing them together does not make every guess true.\n\nDoing Mind and Being Mind: work toward what matters while noticing this moment. Awareness and useful action can happen together. This is not a rule to earn rest or split time evenly between work and breaks.\n\nIntense desire for change and Radical Acceptance: you can strongly want things to be different and face what is true now. Acceptance is not approval, surrender or giving up action that could help. Wanting change does not have to disappear.\n\nThe source calls the fourth pair Self-Denial and Self-Indulgence: holding back from something you want, and giving yourself something you want. Each can fit or go too far, depending on the situation. The aim is fitting limits with room for enjoyment. A small pleasure is not wrong, and rest or basic care is not something to earn. This is not advice about food, health or substance use.\n\nHere the next step is specific: examine what you do, check the facts and your own values, and consider a small adjustment. A neat sentence alone is not a record of changing behavior. Balance may stay uncertain and can shift with context.",
      "sha256": "f1665606bfc7461852c6c384f841640905f201631c5ae60423b880df438057b9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.situation",
      "title": "Choose one manageable pattern",
      "text": "Choose a familiar ordinary situation that fits your therapist’s guidance, or use Avery’s example. What makes you curious about trying a different response? You can also decide that no adjustment is needed.\n\nName what happened without calling yourself a type of person. Include real limits, support needs and anything you do not know. This is not a review of everything you do or a search for faults.",
      "sha256": "6e434fa0e99bf9587a1edae6e178a77b446e251aee984ac7af9d24bda3a75739",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.situation.help",
      "title": "If I cannot find a suitable pattern",
      "text": "Use the example, leave the question for therapy or finish. You do not need to invent an imbalance to use the page.",
      "sha256": "06739f70697c25c84f3d8ebb32770c84d11c3b0950d883de64f54de48f1cb857",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.pair",
      "title": "Choose a pair that helps describe it",
      "text": "Consider the four pairs in Learn more: feelings with reason; useful doing with present awareness; wanting change with accepting what is here; and fitting limits with room for enjoyment. These are ways to look at a situation, not labels for people.\n\nWhich pair fits the behavior you want to examine? Choose one you have learned with your therapist. The two sides may both have something useful to offer. If none fits, leave that open rather than force your situation into a pair.",
      "sha256": "45ec8d33764425ced1de99f9bcb09f2c389b3d807033b4c1b5a7f8bd017e6bbb",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.pair.help",
      "title": "If the fourth pair feels judging",
      "text": "You do not have to use it. Explore what counts as a real limit and what gives you needed care or enjoyment with your therapist. Having needs or wanting pleasure is not a fault.",
      "sha256": "0fab3cb0a16b6da81f2e334f050b20dfd52a354647f4c9b8efc6820bbd011101",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.pattern",
      "title": "Describe what you do more and less",
      "text": "In this situation, what specific action may be taking up more space than fits? What useful action may be getting less room? Describe an example that someone could notice, rather than words such as lazy, selfish or too emotional.\n\nAlso keep what is already helpful. More and less are not automatic goals. An action can fit in one setting and not another. There may be nothing to change, or the problem may be a real barrier rather than your behavior.",
      "sha256": "16e1cbd43eba6a57df3a025559fa8ae5fff2f83f5976c1495a42481720675fdb",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.pattern.help",
      "title": "If someone else says it is too much",
      "text": "Check a concrete example, context and your own needs and values. Someone’s preference alone does not establish that you are out of balance.",
      "sha256": "a0b96423ffe3bc13ee0f3df82be1afaeee74c853eb4cc6c7fe0d4abc91211c98",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.facts",
      "title": "Check the account before changing it",
      "text": "What evidence supports your description? What is a fact, a guess, a feeling or a label? You can reword a judgment as a specific action, while leaving unknowns unknown. Feelings do not need proof to deserve care.\n\nCheck energy, disability, resources, access, unfair demands and other conditions. Do not call a needed rest, care task or lack of support an excess or a failure. A fitting adjustment may be to the demand or support, rather than asking more of yourself.",
      "sha256": "a65e52639b0ac5647db007ff826413b04aac683ce162f5636211b71a2de95280",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.facts.help",
      "title": "If two claims conflict",
      "text": "You do not have to make both true. Keep known facts, feelings and uncertainties separate. A fuller account can still include a firm boundary or an unanswered question.",
      "sha256": "e570e6ba3268141f9fc43f84f50b7a6d246b0d2cb3998a05ef4b77aeed6099dd",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.values",
      "title": "Check what matters to you",
      "text": "What do you want your response to serve in this situation? It might be care, learning, enjoyment, fairness or another value. Include real responsibilities without assuming every demand is a valid duty.\n\nDoes the possible change fit your own values and needs, not only another person’s idea of balance? A therapist can help you work through competing needs. There is no universal amount of doing, feeling or enjoyment that this page can prescribe.",
      "sha256": "d95964d9259642e84fbe024c6f2bc6f5112bb605ad48411fea02facc931a6e99",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.values.help",
      "title": "If I am unsure what my own view is",
      "text": "You can pause and explore it in therapy. You do not have to adopt someone else’s standard to complete this exercise.",
      "sha256": "67c583cc5bd58b091e84e3ee2452e2b8db42bb21636169e6da79f0b878ec1fc8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.synthesis",
      "title": "Keep the useful contribution of each side",
      "text": "What would each side add if it had a fitting place? For example, Avery can care about drawing outside and face the rain now. Neither the wish nor the fact needs to be removed.\n\nTry an account or response that keeps the useful parts together. It need not use the word and or split things halfway. Check that it does not deny a fact, erase a feeling or trade away safety, consent or a real limit.",
      "sha256": "07077da9f66bb84f48557eb7ac115113013c6187d1cef105cfb8b45437f621d3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.synthesis.help",
      "title": "If my answer is only a nice sentence",
      "text": "A sentence can help you think. The next question is what, if anything, you would actually do differently. You can also conclude that more support or no change is the right next step.",
      "sha256": "a85b063f3afa035b8acfc44c994032096d378e40a058b6b68b3f9702af334a5a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.plan",
      "title": "Choose one small, specific adjustment",
      "text": "If a change fits, choose one concrete action to try at a suitable opportunity. It may mean doing less of something, making room for another action, or changing how you do it. Keep the useful purpose and the real limits in view.\n\nMake it small enough for your energy, skills and setting. Decide a natural place to begin and stop, and any support needed. This is a chosen experiment in your response, not an instruction to make the task harder or change a care plan.",
      "sha256": "7c9e9eab7296dff4ddfbcfd05f54d475da3062e1a3a8d6a487f7ce9ff36fb3f0",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.plan.help",
      "title": "If I want to change everything",
      "text": "Choose one manageable pattern with your therapist. You can leave other things alone. A longer plan is not proof of a wiser one.",
      "sha256": "9486a8261c201cf466eb96f3c27e1c2e32027e694e893f93b52d43e27bfefdce",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.rehearse",
      "title": "Try the response in rehearsal if useful",
      "text": "You can actually run through how you would start, silently, aloud, in writing, signing or with a communication aid. Keep the page as a cue if useful. Rehearse the action or words you chose rather than only listing what you intend to do.\n\nIf an ordinary obstacle fits, try a response to it too. For example, Avery can practise noticing the wish for sun and returning to drawing. Do not create distress or a risky test. Rehearsal is not the same as trying it in the real situation.",
      "sha256": "1aa6abc03a8df20ca9fc184caf6ee58af3fa58b328863a2b02e1343cca1c9227",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.rehearse.help",
      "title": "If I do not rehearse",
      "text": "That is a valid choice. You can discuss the plan or finish. Do not record an imagined future result as something that happened.",
      "sha256": "e9d6b3b2910761cfde849f159f589810d1be675340d3c9d8fea0847393bb5185",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.try",
      "title": "Try only when the opportunity fits",
      "text": "At an agreed suitable time, you may try the small action with the support and limits you chose. Notice the situation as it is, rather than checking whether you feel perfectly balanced. Keep necessary safety checks and access aids.\n\nIf the situation or your needs change, adjust, pause or get support. You do not have to keep going until you feel better. The opportunity may be later or may not happen. A plan on this page does not record an attempt or set a reminder.",
      "sha256": "0c7612cbfdc52373d3a0a8460c4f2a58f92816ca09dd9632d47b7c73e45c9199",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.try.help",
      "title": "If it feels like another performance test",
      "text": "Pause. This is not a score of character, productivity or calmness. Bring that pressure to your therapist and consider whether the practice fits at all.",
      "sha256": "adb25255a495a45fc90568949b4e4bc65ef6cd7e0e40643c16c6f5a187b5ed7e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.review",
      "title": "Review the behavior and its fit",
      "text": "You can review without earlier notes. What did you actually do: read, consider, rehearse, try, stop or not practise? Keep no opportunity separate from choosing not to act. Rehearsal is not a real-world attempt.\n\nIf you tried, compare what happened with the pattern you described. Was there a concrete change in what you did? Did the useful parts of both sides have room? Include unchanged behavior, difficulty, costs, help needed and what you cannot tell.\n\nDid the response fit your values, needs and situation? Calm, praise or a completed task is not proof. A difficult feeling can remain, and a seemingly balanced plan can turn out not to fit. Use those observations for discussion rather than a score.",
      "sha256": "f72cdc98910994607d87464dd921fe7e1e2454104a186fa82fe854420fc5c3d9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.review.help",
      "title": "If I cannot judge the effect",
      "text": "Leave it uncertain. One attempt cannot prove a cause or a wise state. A concrete observation or question can still help the next discussion.",
      "sha256": "4193559a7de9b6c005c311be94f17b5bf82be52f228c396a1c5713e48ee43b44",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "middle-path-wise-mind.practice.next",
      "title": "Keep, adjust or leave the practice",
      "text": "With your therapist, decide whether to keep this adjustment, change it, use another skill or leave it for now. What fits may change with your circumstances. There is no daily quota or missed-practice debt.\n\nIf useful, choose when and how to review a later attempt with your therapist. You can bring a question without written notes. Nothing here books that discussion, sends a report or creates a reminder.",
      "sha256": "8bee18d70725f0e0001d3ccdf8cce93f6cb5fd25e45211c3e8642263d4317ac5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "middle-path-wise-mind.practice.next.help",
      "title": "If the pattern returns",
      "text": "That is information, not proof of failure. Check the setting, needs and support again. You do not have to repeat the exercise until the pattern disappears.",
      "sha256": "cd8d1d9499573e52e6c1d985dec1c9dd679f64677f955886d14998276acf1841",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
