window.RelationshipBuildingContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/relationships",
  "componentId": "component/relationships/finding-and-getting-people-to-like-you",
  "resourceId": "tool/relationship-building",
  "routeProposal": "/relationship-building/",
  "title": "Finding and Getting People to Like You",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Explore a chance for mutual connection, practise a conversation or joining a group, and review what actually happens.",
  "groupedSetStatus": "Existing uncounted DBT Finding and Getting People to Like You component under classic/relationships. DA19 conversation/relationship-building gap. Not the whole Building Relationships and Ending Destructive Ones suite; Mindfulness of Others and Ending Relationships remain separate. No new canonical count.",
  "clinicalContract": {
    "learningObjective": "Understand opportunities for mutual connection through repeated ordinary contact, genuine common interests, reciprocal conversation, chosen disclosure, appreciation and joining welcoming groups without treating approval as controllable.",
    "practiceObjective": "Choose a therapist-agreed ordinary setting, consider practical access and mutual availability, prepare and rehearse suitable conversation/group-entry actions, choose real use or no contact, then review observed use/non-use and revise.",
    "sourcePopulationContext": "Author/publisher DBT teaching establishes the named component, not efficacy of this isolated adaptation or universal suitability. No age floor. Individual developmental, clinical, cultural, safeguarding, communication and access review is required.",
    "exclusions": [
      "No guarantee of friendship, approval, inclusion or reduced loneliness",
      "No forced contact, disclosure, praise, conformity, social masking, eye contact, touch or continued participation",
      "No tracking a person, pursuing a refusal, private access requests or manufactured common interests",
      "No dating, contact with unsafe people, handling abuse or relationship-ending advice",
      "No autonomous graded exposure, behavioural experiment, diagnostic or safety assessment",
      "No automatic invitation, message, group enrolment, recording, storage, reminder or inferred outcome"
    ],
    "adaptations": [
      "Original explanatory text and fictional example, not a source handout/worksheet reproduction",
      "All named opportunity/conversation/group operations are taught; each is a choice, not a mandatory checklist for every interaction",
      "Group cues are context-dependent hints, not a body-language test or evidence of consent; direct clarification and leaving are valid",
      "Choosing an organized group includes repeated meetings, genuine shared interests and cooperative activity, with access and safety support",
      "Mutual interest and personal preference replace demands to obtain liking; refusals and uncertain outcomes remain literal",
      "No compulsory self-disclosure matching, eye contact, posture or timed turn-taking; different communication forms allowed"
    ],
    "reviewGates": [
      "Owner/clinician review of complete bounded named component, source adaptations and rights",
      "Individual clinical, developmental, cultural, communication, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not a validated reading level",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation/lifecycle and selected-copy/download acceptance",
      "Authorized narration generation, exact-script listening and binding review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose preparation or review",
      "options": [
        {
          "value": "prepare",
          "label": "Prepare a connection practice",
          "startSectionId": "relationship-building.practice.purpose"
        },
        {
          "value": "review",
          "label": "Review a practice or no use",
          "startSectionId": "relationship-building.practice.review"
        }
      ]
    },
    "entryGate": "Therapist-introduced context/safety visible before mode selection; no person or group is approved by the page.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish; no required writing or completed sequence.",
    "reviewAccess": "Direct blank review without a stored plan, contact or inferred attempt. Both modes expose all groups.",
    "writing": "Optional, hidden initially, never filled by fiction. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only. Internal reading/mode changes retain; clear/restart/leaving/reload/history/BFCache clear; offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only; edits, hiding, mode and stage changes invalidate export. Nothing is sent.",
    "narration": "Exact static public text/help only; never notes. No audio, TTS, upload, recording or autoplay.",
    "timer": "None. No contact quota, social score or reminder.",
    "completion": "No inferred rehearsal, group attendance, message, consent, friendship, approval or improvement."
  },
  "intro": {
    "id": "relationship-building.intro",
    "title": "Explore a chance for mutual connection",
    "paragraphs": [
      "This DBT skill has the name \"Finding and Getting People to Like You.\" You cannot make someone like you. Here the aim is to notice suitable chances to connect and practise taking part while keeping both people’s choices.",
      "You might want a brief friendly exchange, people to share an interest with, or a chance to know someone over time. You do not have to want lots of friends. Another person’s response is not a measure of your worth.",
      "The practice covers places to meet people, real common interests, conversation, sharing a little about yourself, showing genuine appreciation and joining a welcoming group. You can choose what fits, rehearse, decide about real use and review it."
    ]
  },
  "fit": {
    "id": "relationship-building.fit",
    "title": "Start with a suitable, ordinary setting",
    "paragraphs": [
      "Use this after your therapist has taught the skill, checked your understanding and helped choose an ordinary situation. They can help with age, language, culture, communication needs, access and safe support. A setting that fits one person may not fit another.",
      "Do not use this to win over someone who harms you, work around a refusal, contact a person who has asked for no contact, or enter a risky group. It is not dating advice, a plan to end a relationship or a way to manage abuse. If there is a safety concern, seek suitable support instead.",
      "Choose how you communicate. Speech, signing, typing, a communication aid or a safe agreed supporter may fit. Eye contact, smiling, touch, standing close and quick replies are not required. You do not have to hide your needs or copy someone’s interests to earn a place.",
      "You can use a fictional example, practise privately, pause or choose no contact. Do not create distress or keep going until fear drops. This page does not replace practical help, safeguarding or an agreed care plan."
    ]
  },
  "privacy": {
    "id": "relationship-building.privacy",
    "title": "No contact happens through this page",
    "paragraphs": [
      "You can think, speak privately, use paper or add optional notes. Keep names, contact details and private stories out if you do not need them. This tool does not record speech, look people up, send messages, join groups or contact your therapist.",
      "Notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. If you want a copy, choose notes, check the preview, then copy or download. Check the copy yourself.",
      "Other people, device tools or a screen reader may read words kept on a device. Skill narration never reads your notes. Copies outside the tool remain until you remove them. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "relationship-building.close",
    "title": "Keep the outcome honest",
    "paragraphs": [
      "Preparing, rehearsing, attending and having a conversation are different. You can finish at any point, with or without notes or contact. No new friendship, approval or change in feeling is needed.",
      "Keep selected notes if useful, or leave them to clear. Finish and clear removes notes here, not outside copies. Choose what to bring to your therapist in your own way."
    ]
  },
  "example": {
    "id": "relationship-building.example",
    "title": "Tavi tries a shared puzzle table",
    "paragraphs": [
      "This is made up, not an invitation to follow. Tavi likes puzzles and wants occasional company during an activity. With the therapist, Tavi considers a library puzzle table that meets each week and welcomes newcomers. The group works together on a picture rather than competing. A quieter table and written communication are available.",
      "Tavi prepares one opening and a small fact to share, then rehearses with the therapist. The therapist tries both a welcoming reply and a reply saying the group is busy. When the therapist says, \"This table is closed for now,\" Tavi practises replying, \"Okay, I will ask which tables are open.\" Tavi does not argue for a yes. This is still rehearsal; no real visit has happened yet.",
      "On a later visit, Tavi checks with the organizer that joining is welcome. During a pause, Tavi types, \"Is there space for me to work on this edge?\" A member says yes and moves some pieces. Tavi joins at the offered space. The invitation is real information; guessing from someone’s gaze would not have been enough.",
      "Tavi asks, \"Which part are you working on?\" The member explains the sky section. Tavi listens, then adds, \"I like pictures with lots of colour. I usually start with the edge.\" This is a small true detail, not a private history. When the member shows a sorting idea, Tavi says, \"That helps me find the blue pieces.\" The appreciation is genuine, not a way to ask for a favour.",
      "Tavi works alongside the group, then says, \"I am going to stop here for today.\" The member says goodbye. In review, Tavi notes a short shared activity, some tension and that typing worked. Tavi does not know whether anyone wants a friendship. A future visit is an option to discuss, not an event already completed."
    ]
  },
  "learn": {
    "id": "relationship-building.learn",
    "title": "Connection is shared, not earned by a perfect performance",
    "paragraphs": [
      "Regular ordinary contact can give people chances to become familiar. Real common interests may give them something to do or talk about. Neither makes a relationship certain. People also differ in access, time, safety, energy and what connection they want.",
      "Conversation involves offering and receiving. You can ask, answer, listen, share a little and leave room for another turn. It is not an interview or a test of perfect timing. Clear ways to ask for more time or explain a communication need can help both people.",
      "Sharing can grow with mutual interest and trust. You choose what is private. Another person’s disclosure does not create a duty to match it. Honest appreciation may show interest; praise does not buy attention, consent or a favour.",
      "An organized group offers a setting for repeated shared activity. Joining a conversation already in progress is a different moment within such a setting. Both need a check that participation is welcome; body position or silence alone cannot tell you.",
      "This is the finding-people and conversation component of DBT relationship skills. GIVE, listening and other practices may support it, but this is not the full relationship suite, Mindfulness of Others, a friendship test or relationship-ending guidance."
    ]
  },
  "practice": [
    {
      "id": "relationship-building.practice.purpose",
      "title": "Choose the kind of connection you want",
      "paragraphs": [
        "What would you like: a brief exchange, company for an activity, or a chance to know people over time? Choose one aim that matters to you, not a number of friends you think you should have.",
        "Name what needs to fit, such as shared interests, quiet space, communication support, cost, transport, culture or energy. Wanting connection does not mean every available setting is right for you."
      ],
      "fields": [
        {
          "key": "connection-aim",
          "label": "The kind of connection I want",
          "optional": true
        },
        {
          "key": "needs",
          "label": "Needs, limits and support to keep in view",
          "optional": true
        }
      ],
      "help": {
        "title": "If you do not want more contact right now",
        "text": "You can choose no practice or discuss a different need with your therapist. Being alone by choice and feeling painfully isolated are not the same. This page does not decide what your social life should be."
      }
    },
    {
      "id": "relationship-building.practice.setting",
      "title": "Look for ordinary chances to meet again",
      "paragraphs": [
        "Consider places or activities you can use legitimately where casual contact may happen more than once. Familiarity has room to grow over time; it does not require following a particular person or arranging to appear wherever they go.",
        "An organized group may help if it has repeated meetings, a genuine shared interest and chances to cooperate on something. Check whether it welcomes you, its purpose and rules, and any cost, access or support needs. A group name alone does not show that it is suitable or safe.",
        "Choose a possible setting with your therapist. Joining, paying, travelling or contacting an organizer are separate choices outside this page. You can decide not to proceed."
      ],
      "fields": [
        {
          "key": "setting",
          "label": "An ordinary setting or organized group to consider",
          "optional": true
        },
        {
          "key": "access-check",
          "label": "What to check about welcome, access, support or practical limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If no suitable place is available",
        "text": "Treat that as a real barrier, not a lack of effort. Your therapist may help find access support or a different way to connect. Do not enter an unsafe setting just to have an option."
      }
    },
    {
      "id": "relationship-building.practice.common",
      "title": "Find a real point of common interest",
      "paragraphs": [
        "What do you actually enjoy, care about or want to learn that may fit this setting? A shared task, topic or value can offer a starting point. You do not have to agree on everything or be alike in background.",
        "Let common ground come from what people choose to share, not guesses based on appearance or identity. Do not invent preferences, hide a needed boundary or reveal private information to seem similar."
      ],
      "fields": [
        {
          "key": "common-ground",
          "label": "A genuine topic, activity or value to start from",
          "optional": true
        },
        {
          "key": "private-limit",
          "label": "What I want to keep private or not pretend",
          "optional": true
        }
      ],
      "help": {
        "title": "If there is little in common",
        "text": "You can stay curious, share a small difference or choose another setting. A difference is not proof that either person is wrong, and agreement is not a price for friendship."
      }
    },
    {
      "id": "relationship-building.practice.open",
      "title": "Prepare a simple opening",
      "paragraphs": [
        "Choose one brief greeting, question or comment that fits the activity. A question about the shared task can be easier to answer than a personal one. You do not need a clever line.",
        "Consider whether the person is available. Look at the setting and any direct information, not one gesture or expression. You may ask whether now is a good time. If the person declines, gives no reply or stays focused on their task, give them space rather than repeating the opening to obtain a reply."
      ],
      "fields": [
        {
          "key": "opening",
          "label": "A greeting, question or comment in my own form",
          "optional": true
        },
        {
          "key": "availability",
          "label": "How to check availability and allow no response",
          "optional": true
        }
      ],
      "help": {
        "title": "If their meaning is unclear",
        "text": "A brief check may help if appropriate. You can also pause or leave without deciding they dislike you. No response is not consent to keep approaching and is not a verdict about your worth."
      }
    },
    {
      "id": "relationship-building.practice.exchange",
      "title": "Practise a shared conversation",
      "paragraphs": [
        "Ask and answer, rather than only asking questions or only talking. If you wish, add one small relevant detail beyond a short answer. Listen or read what comes back and respond to that, rather than following a fixed script regardless of the reply.",
        "Share only what fits your comfort, the setting and trust so far. Notice how much the other person shares, but do not feel you must match a personal disclosure. You can keep it light or say you would rather not discuss something.",
        "Leave room for turns in a way that fits both people. If turns overlap or you need more time, you can name that and try again. Eye contact, exact pauses and a particular speaking style are not required. Learning about an activity may offer topics; it is not homework to become more interesting."
      ],
      "fields": [
        {
          "key": "exchange",
          "label": "One possible question, answer and small true detail",
          "optional": true
        },
        {
          "key": "communication",
          "label": "Privacy, turn-taking or communication support I want",
          "optional": true
        }
      ],
      "help": {
        "title": "If small talk is not useful for you",
        "text": "Try a shared task or a clear topic if that fits the other person too. You may explain that you prefer direct questions or need time to respond. The aim is mutual understanding, not copying a social style."
      }
    },
    {
      "id": "relationship-building.practice.appreciation",
      "title": "Show genuine interest if you want",
      "paragraphs": [
        "If you notice something you honestly like or appreciate, you may say so in a simple way. A specific part of a shared activity can be enough. You can also show interest through a relevant question or taking part.",
        "Do not force praise, flatter someone to get a favour or keep complimenting when it is not welcome. You do not owe affection, touch or personal comments. Another person does not owe closeness in return."
      ],
      "fields": [
        {
          "key": "appreciation",
          "label": "Something genuine I might express, or no compliment",
          "optional": true
        },
        {
          "key": "mutual-choice",
          "label": "How I will keep both people’s choice",
          "optional": true
        }
      ],
      "help": {
        "title": "If praise feels false or too personal",
        "text": "Leave it out or choose another truthful response. An ordinary interested exchange does not need a compliment to count as practice."
      }
    },
    {
      "id": "relationship-building.practice.group",
      "title": "Check before joining a group conversation",
      "paragraphs": [
        "If you want to join a conversation already happening, first check whether newcomers are welcome. An open invitation or an organizer’s guidance can help. A private discussion may not be open, even in a public place.",
        "Pauses, a general topic or people making room may be useful hints. Body position, gaze, volume or silence alone are not reliable tests across people, cultures or communication styles. If uncertain, ask briefly at a suitable pause or seek the organizer’s help rather than guessing.",
        "If invited, join in the offered way, listen to the current topic and make a relevant contribution. If declined, not answered or the setting does not fit, step back or choose another time or activity. Do not keep trying to enter the same closed exchange."
      ],
      "fields": [
        {
          "key": "group-entry",
          "label": "How I might check whether joining is welcome",
          "optional": true
        },
        {
          "key": "group-response",
          "label": "How I could join, pause or step back",
          "optional": true
        }
      ],
      "help": {
        "title": "If a group is not part of your chosen practice",
        "text": "You can learn this option and leave it unused. A one-to-one exchange or quiet shared activity may fit better. You do not need to try every part in one visit."
      }
    },
    {
      "id": "relationship-building.practice.rehearse",
      "title": "Try the chosen parts privately",
      "paragraphs": [
        "Choose the parts that fit your plan. Try an opening, a brief exchange or a group-entry question privately or with your therapist. Use the form of communication and support you would actually want. This is rehearsal, not a real contact.",
        "Try a welcoming reply and a neutral, busy or declining reply. Practise listening, offering a small relevant response, and pausing or leaving. Use ordinary words, not insults or vivid distress. Adjust what feels unclear or too much."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I actually rehearsed, or did not try",
          "optional": true
        },
        {
          "key": "rehearsal-learning",
          "label": "What to change in words, support or scope",
          "optional": true
        }
      ],
      "help": {
        "title": "If rehearsal feels like a test of being acceptable",
        "text": "Pause and discuss it. You are learning choices, not proving that you deserve connection. No calm feeling, perfect performance or number of repetitions is required."
      }
    },
    {
      "id": "relationship-building.practice.try",
      "title": "Choose whether real use fits",
      "paragraphs": [
        "With your therapist, agree whether to try one suitable opportunity, wait, seek more support or make no contact. If you choose real use, decide when and where, the parts to try and a way to pause or leave.",
        "Recheck welcome, consent, access and safety in the actual setting. A previous plan does not require you to continue. Respect another person’s no and your own limits. Do not delay needed help to finish the exercise.",
        "A visit or conversation happens outside these buttons. If you leave this page, its notes clear; keep selected notes first only if you want them."
      ],
      "fields": [
        {
          "key": "use-plan",
          "label": "The agreed opportunity, or choice not to try",
          "optional": true
        },
        {
          "key": "exit-support",
          "label": "Support, limits and a way to pause or leave",
          "optional": true
        }
      ],
      "help": {
        "title": "If you do not try it",
        "text": "You can review that honestly. Access, energy, timing, safety or preference may have changed. There is no result to invent and no need to make contact just to complete a plan."
      }
    },
    {
      "id": "relationship-building.practice.review",
      "title": "Review what actually happened",
      "paragraphs": [
        "Was this planning, rehearsal, attendance, an exchange or no use? Which parts did you actually try? Keep a thought about future contact separate from an event that happened.",
        "What did you observe or hear? What did you do, and what remains unknown? A brief reply is not proof of friendship or rejection. Include a quiet, mixed, awkward or unwanted result without filling in someone else’s mind.",
        "Did the activity and communication fit your needs and choices? Was participation welcome? What helped or got in the way? Approval or reduced anxiety is not the test of whether there is useful learning."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What actually happened or did not happen",
          "optional": true
        },
        {
          "key": "observed",
          "label": "What I observed and what is still unknown",
          "optional": true
        },
        {
          "key": "fit-review",
          "label": "What fitted, helped or got in the way",
          "optional": true
        }
      ],
      "help": {
        "title": "If you felt excluded or were treated unfairly",
        "text": "That is not proof that you failed a skill or need to try harder to be liked. Seek support and consider the setting. Discrimination, access barriers and harm are not solved by a better greeting."
      }
    },
    {
      "id": "relationship-building.practice.next",
      "title": "Choose a next step without chasing approval",
      "paragraphs": [
        "With your therapist, decide whether to keep this approach, change the setting or support, practise a different part, pause or stop. Any later contact needs to remain wanted and suitable for everyone involved.",
        "You may revisit a welcoming shared activity if it fits, but repeated attendance does not oblige anyone to become a friend. A refusal or a lack of reply is not a challenge to overcome. You can choose another opportunity or none for now."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, change, pause or stop",
          "optional": true
        },
        {
          "key": "therapy-review",
          "label": "Questions or support to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want more closeness than the other person does",
        "text": "You can notice the wish without pressuring them or blaming yourself. Discuss your needs and other supports with your therapist. This component does not tell you how to change or end a relationship."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 Interpersonal Effectiveness Handouts 11 and 11a",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Handout11, printed pp140–141 (PDF viewer pp70–71), teaches finding potential friends, conversation, genuine liking and joining an open group. Handout11a is an optional learning check.",
      "limits": "Original adaptation only, not a copied handout or optional quiz. No guarantee of liking, required nonverbal style, compulsory disclosure or group-entry certainty. No claim of exact-current revised-edition fidelity or app efficacy."
    },
    {
      "id": "Linehan/Guilford: DBT Skills Training Manual teaching notes",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "SectionXI, printed pp270–276 (PDF indices41–47), explains finding friends, repeated contact, common interests, conversation, expressing liking and organized-group opportunities.",
      "limits": "2015 clinician teaching material. Full relationship suite and whole DBT treatment are not implemented here. Source recognition does not establish developmental fit, clinical acceptance or a validated digital adaptation."
    },
    {
      "id": "Linehan/Guilford: 2015 Interpersonal Effectiveness Worksheet 8",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Worksheet8, printed p183, links opportunity planning with actual use/non-use and review of connection and conversation skills.",
      "limits": "No worksheet grid, counts, wording, score or requirement to list every opportunity copied. Product keeps rehearsal, attendance and real exchange distinct; it does not infer consent or relationship status."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Communication access, meaningful choice, refusal and support inform the flexible communication safeguards.",
      "limits": "Rights guidance, not validation of this component or evidence that one format fits every learner."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "PDF copyright page ii limits purchaser duplication to personal/individual-client use and excludes electronic redistribution without written permission.",
      "limits": "Public availability and source links do not grant release permission. Original prose/examples only; no rights approval requested or granted."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Chosen connection aim, repeated contact and organized-group opportunity",
      "sections": [
        "practice.purpose",
        "practice.setting"
      ],
      "source": "ManualXI pp270–276; context/access/consent safeguards are explicit adaptations"
    },
    {
      "operation": "Genuine shared interests, reciprocal conversation and selective disclosure",
      "sections": [
        "practice.common",
        "practice.open",
        "practice.exchange"
      ],
      "source": "Handout11 and ManualXI; no assumed similarity, compulsory disclosure or rigid turn/eye-contact rule"
    },
    {
      "operation": "Genuine liking and joining an open group conversation",
      "sections": [
        "practice.appreciation",
        "practice.group"
      ],
      "source": "Handout11; source nonverbal cues treated as uncertain context, with clarification and no-pressure refusal"
    },
    {
      "operation": "Rehearsal, actual use/non-use and review",
      "sections": [
        "practice.rehearse",
        "practice.try",
        "practice.review",
        "practice.next"
      ],
      "source": "ManualXI teaching and Worksheet8; not a contact quota, exposure task or promise of friendship"
    },
    {
      "operation": "Choice, access and privacy",
      "sections": [
        "fit",
        "privacy"
      ],
      "source": "ASHA/NJC rights and conservative product safeguards; not a safety assessment or validated access protocol"
    }
  ],
  "narrationSegments": [
    {
      "id": "relationship-building.intro",
      "title": "Explore a chance for mutual connection",
      "text": "This DBT skill has the name \"Finding and Getting People to Like You.\" You cannot make someone like you. Here the aim is to notice suitable chances to connect and practise taking part while keeping both people’s choices.\n\nYou might want a brief friendly exchange, people to share an interest with, or a chance to know someone over time. You do not have to want lots of friends. Another person’s response is not a measure of your worth.\n\nThe practice covers places to meet people, real common interests, conversation, sharing a little about yourself, showing genuine appreciation and joining a welcoming group. You can choose what fits, rehearse, decide about real use and review it.",
      "sha256": "e0150591e3269fee12ce06eabfc925a01d762be0a4f3df75374eeee685edc399",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.fit",
      "title": "Start with a suitable, ordinary setting",
      "text": "Use this after your therapist has taught the skill, checked your understanding and helped choose an ordinary situation. They can help with age, language, culture, communication needs, access and safe support. A setting that fits one person may not fit another.\n\nDo not use this to win over someone who harms you, work around a refusal, contact a person who has asked for no contact, or enter a risky group. It is not dating advice, a plan to end a relationship or a way to manage abuse. If there is a safety concern, seek suitable support instead.\n\nChoose how you communicate. Speech, signing, typing, a communication aid or a safe agreed supporter may fit. Eye contact, smiling, touch, standing close and quick replies are not required. You do not have to hide your needs or copy someone’s interests to earn a place.\n\nYou can use a fictional example, practise privately, pause or choose no contact. Do not create distress or keep going until fear drops. This page does not replace practical help, safeguarding or an agreed care plan.",
      "sha256": "f2370be5b8f0e202232157e502c85e78dbf5d704c2a5047fa34e0a3a350e6b0f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.privacy",
      "title": "No contact happens through this page",
      "text": "You can think, speak privately, use paper or add optional notes. Keep names, contact details and private stories out if you do not need them. This tool does not record speech, look people up, send messages, join groups or contact your therapist.\n\nNotes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. If you want a copy, choose notes, check the preview, then copy or download. Check the copy yourself.\n\nOther people, device tools or a screen reader may read words kept on a device. Skill narration never reads your notes. Copies outside the tool remain until you remove them. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "08113f2de88153be5f07008cfde4dbb757b369b6529595446d8d3fbfeb64c68a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.close",
      "title": "Keep the outcome honest",
      "text": "Preparing, rehearsing, attending and having a conversation are different. You can finish at any point, with or without notes or contact. No new friendship, approval or change in feeling is needed.\n\nKeep selected notes if useful, or leave them to clear. Finish and clear removes notes here, not outside copies. Choose what to bring to your therapist in your own way.",
      "sha256": "4cbbce5f582113a939e6072c4958808fe947271708864d5f78ed3d0e7a771b54",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.example",
      "title": "Tavi tries a shared puzzle table",
      "text": "This is made up, not an invitation to follow. Tavi likes puzzles and wants occasional company during an activity. With the therapist, Tavi considers a library puzzle table that meets each week and welcomes newcomers. The group works together on a picture rather than competing. A quieter table and written communication are available.\n\nTavi prepares one opening and a small fact to share, then rehearses with the therapist. The therapist tries both a welcoming reply and a reply saying the group is busy. When the therapist says, \"This table is closed for now,\" Tavi practises replying, \"Okay, I will ask which tables are open.\" Tavi does not argue for a yes. This is still rehearsal; no real visit has happened yet.\n\nOn a later visit, Tavi checks with the organizer that joining is welcome. During a pause, Tavi types, \"Is there space for me to work on this edge?\" A member says yes and moves some pieces. Tavi joins at the offered space. The invitation is real information; guessing from someone’s gaze would not have been enough.\n\nTavi asks, \"Which part are you working on?\" The member explains the sky section. Tavi listens, then adds, \"I like pictures with lots of colour. I usually start with the edge.\" This is a small true detail, not a private history. When the member shows a sorting idea, Tavi says, \"That helps me find the blue pieces.\" The appreciation is genuine, not a way to ask for a favour.\n\nTavi works alongside the group, then says, \"I am going to stop here for today.\" The member says goodbye. In review, Tavi notes a short shared activity, some tension and that typing worked. Tavi does not know whether anyone wants a friendship. A future visit is an option to discuss, not an event already completed.",
      "sha256": "db04019fd22d7f53988e833cd4233eaee8ece3e010383b56cc2d3a86614b4123",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.learn",
      "title": "Connection is shared, not earned by a perfect performance",
      "text": "Regular ordinary contact can give people chances to become familiar. Real common interests may give them something to do or talk about. Neither makes a relationship certain. People also differ in access, time, safety, energy and what connection they want.\n\nConversation involves offering and receiving. You can ask, answer, listen, share a little and leave room for another turn. It is not an interview or a test of perfect timing. Clear ways to ask for more time or explain a communication need can help both people.\n\nSharing can grow with mutual interest and trust. You choose what is private. Another person’s disclosure does not create a duty to match it. Honest appreciation may show interest; praise does not buy attention, consent or a favour.\n\nAn organized group offers a setting for repeated shared activity. Joining a conversation already in progress is a different moment within such a setting. Both need a check that participation is welcome; body position or silence alone cannot tell you.\n\nThis is the finding-people and conversation component of DBT relationship skills. GIVE, listening and other practices may support it, but this is not the full relationship suite, Mindfulness of Others, a friendship test or relationship-ending guidance.",
      "sha256": "7964f507790eac37ed500de424c616ec45fbffb6231fba6e3686780400191202",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.purpose",
      "title": "Choose the kind of connection you want",
      "text": "What would you like: a brief exchange, company for an activity, or a chance to know people over time? Choose one aim that matters to you, not a number of friends you think you should have.\n\nName what needs to fit, such as shared interests, quiet space, communication support, cost, transport, culture or energy. Wanting connection does not mean every available setting is right for you.",
      "sha256": "89b426b7eb8ef6bbb34d7cba151a7f5f58eb84d62e53764f00c3f6e881268b24",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.purpose.help",
      "title": "If you do not want more contact right now",
      "text": "You can choose no practice or discuss a different need with your therapist. Being alone by choice and feeling painfully isolated are not the same. This page does not decide what your social life should be.",
      "sha256": "4a660f47e00cc7b9d060084988ab684a5e501d63111e186702820ced7de9ee53",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.setting",
      "title": "Look for ordinary chances to meet again",
      "text": "Consider places or activities you can use legitimately where casual contact may happen more than once. Familiarity has room to grow over time; it does not require following a particular person or arranging to appear wherever they go.\n\nAn organized group may help if it has repeated meetings, a genuine shared interest and chances to cooperate on something. Check whether it welcomes you, its purpose and rules, and any cost, access or support needs. A group name alone does not show that it is suitable or safe.\n\nChoose a possible setting with your therapist. Joining, paying, travelling or contacting an organizer are separate choices outside this page. You can decide not to proceed.",
      "sha256": "c4ac1ad64889472e6d7b7d1413cf7c1a78de29adad03ebc6f9d9f3a94b19fc33",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.setting.help",
      "title": "If no suitable place is available",
      "text": "Treat that as a real barrier, not a lack of effort. Your therapist may help find access support or a different way to connect. Do not enter an unsafe setting just to have an option.",
      "sha256": "450f6716dfa3e28a6ad4a54375b17e1f4af74c817cc3c292e04932e320f421a9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.common",
      "title": "Find a real point of common interest",
      "text": "What do you actually enjoy, care about or want to learn that may fit this setting? A shared task, topic or value can offer a starting point. You do not have to agree on everything or be alike in background.\n\nLet common ground come from what people choose to share, not guesses based on appearance or identity. Do not invent preferences, hide a needed boundary or reveal private information to seem similar.",
      "sha256": "01d3b2859a7974e6b7937748795f4c3e7dd79d39dd0e547bb4d32938553753b4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.common.help",
      "title": "If there is little in common",
      "text": "You can stay curious, share a small difference or choose another setting. A difference is not proof that either person is wrong, and agreement is not a price for friendship.",
      "sha256": "3997f6ab8afc44a6964ac4d29220bc6455262547eddc8fccb50818855d04de34",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.open",
      "title": "Prepare a simple opening",
      "text": "Choose one brief greeting, question or comment that fits the activity. A question about the shared task can be easier to answer than a personal one. You do not need a clever line.\n\nConsider whether the person is available. Look at the setting and any direct information, not one gesture or expression. You may ask whether now is a good time. If the person declines, gives no reply or stays focused on their task, give them space rather than repeating the opening to obtain a reply.",
      "sha256": "911571e361cd0a8e724957a0b402a88d3cc7939ff39405b255c7a8d721d94780",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.open.help",
      "title": "If their meaning is unclear",
      "text": "A brief check may help if appropriate. You can also pause or leave without deciding they dislike you. No response is not consent to keep approaching and is not a verdict about your worth.",
      "sha256": "70ada506479fd0b15acc35ed2684153c0b2c23c3e1f58e6185245e2ce506facf",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.exchange",
      "title": "Practise a shared conversation",
      "text": "Ask and answer, rather than only asking questions or only talking. If you wish, add one small relevant detail beyond a short answer. Listen or read what comes back and respond to that, rather than following a fixed script regardless of the reply.\n\nShare only what fits your comfort, the setting and trust so far. Notice how much the other person shares, but do not feel you must match a personal disclosure. You can keep it light or say you would rather not discuss something.\n\nLeave room for turns in a way that fits both people. If turns overlap or you need more time, you can name that and try again. Eye contact, exact pauses and a particular speaking style are not required. Learning about an activity may offer topics; it is not homework to become more interesting.",
      "sha256": "027bfe06fe48df16419fae4c107b732db9d020b50a42c285591782cdd2ae36b7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.exchange.help",
      "title": "If small talk is not useful for you",
      "text": "Try a shared task or a clear topic if that fits the other person too. You may explain that you prefer direct questions or need time to respond. The aim is mutual understanding, not copying a social style.",
      "sha256": "2396d041789ee9f8b2bd36aefed6cdb0c71aeb1db355612f36dfb315801af425",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.appreciation",
      "title": "Show genuine interest if you want",
      "text": "If you notice something you honestly like or appreciate, you may say so in a simple way. A specific part of a shared activity can be enough. You can also show interest through a relevant question or taking part.\n\nDo not force praise, flatter someone to get a favour or keep complimenting when it is not welcome. You do not owe affection, touch or personal comments. Another person does not owe closeness in return.",
      "sha256": "8fc894013eb4c695ad327b13e16e435a4e121643d10846beb720b7de0d658f05",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.appreciation.help",
      "title": "If praise feels false or too personal",
      "text": "Leave it out or choose another truthful response. An ordinary interested exchange does not need a compliment to count as practice.",
      "sha256": "4fbecbd694db82e08c1a513d3cfef4e26fd9300265fd8bb3a62cab4e201676eb",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.group",
      "title": "Check before joining a group conversation",
      "text": "If you want to join a conversation already happening, first check whether newcomers are welcome. An open invitation or an organizer’s guidance can help. A private discussion may not be open, even in a public place.\n\nPauses, a general topic or people making room may be useful hints. Body position, gaze, volume or silence alone are not reliable tests across people, cultures or communication styles. If uncertain, ask briefly at a suitable pause or seek the organizer’s help rather than guessing.\n\nIf invited, join in the offered way, listen to the current topic and make a relevant contribution. If declined, not answered or the setting does not fit, step back or choose another time or activity. Do not keep trying to enter the same closed exchange.",
      "sha256": "975e69a35b382514603721dea007d9263ea56a5e1d3c453a524892953796484a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.group.help",
      "title": "If a group is not part of your chosen practice",
      "text": "You can learn this option and leave it unused. A one-to-one exchange or quiet shared activity may fit better. You do not need to try every part in one visit.",
      "sha256": "c2e218a23031972548db49982f9733a4d9202da8b54b98476b4fb916a2b4c411",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.rehearse",
      "title": "Try the chosen parts privately",
      "text": "Choose the parts that fit your plan. Try an opening, a brief exchange or a group-entry question privately or with your therapist. Use the form of communication and support you would actually want. This is rehearsal, not a real contact.\n\nTry a welcoming reply and a neutral, busy or declining reply. Practise listening, offering a small relevant response, and pausing or leaving. Use ordinary words, not insults or vivid distress. Adjust what feels unclear or too much.",
      "sha256": "45956f74497514f4774015500100be5b899c59626b1caaedd34968d9a89ab902",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.rehearse.help",
      "title": "If rehearsal feels like a test of being acceptable",
      "text": "Pause and discuss it. You are learning choices, not proving that you deserve connection. No calm feeling, perfect performance or number of repetitions is required.",
      "sha256": "12ab5921e7a52920230f89a44d8ef452b23fef0f1f7381365791d6edc9662ecb",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.try",
      "title": "Choose whether real use fits",
      "text": "With your therapist, agree whether to try one suitable opportunity, wait, seek more support or make no contact. If you choose real use, decide when and where, the parts to try and a way to pause or leave.\n\nRecheck welcome, consent, access and safety in the actual setting. A previous plan does not require you to continue. Respect another person’s no and your own limits. Do not delay needed help to finish the exercise.\n\nA visit or conversation happens outside these buttons. If you leave this page, its notes clear; keep selected notes first only if you want them.",
      "sha256": "c3d038797e228ba5375687fcd14b0fe11ff1878aa3a7837dbd3cc452e6fcf88f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.try.help",
      "title": "If you do not try it",
      "text": "You can review that honestly. Access, energy, timing, safety or preference may have changed. There is no result to invent and no need to make contact just to complete a plan.",
      "sha256": "7847b56dfb77f05c6f3a08bcf4e3827cd48842ebef5cea0bee79d5326c6cd824",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.review",
      "title": "Review what actually happened",
      "text": "Was this planning, rehearsal, attendance, an exchange or no use? Which parts did you actually try? Keep a thought about future contact separate from an event that happened.\n\nWhat did you observe or hear? What did you do, and what remains unknown? A brief reply is not proof of friendship or rejection. Include a quiet, mixed, awkward or unwanted result without filling in someone else’s mind.\n\nDid the activity and communication fit your needs and choices? Was participation welcome? What helped or got in the way? Approval or reduced anxiety is not the test of whether there is useful learning.",
      "sha256": "9a02350455fe7724a3954a4fd03ef3334b8a0181e7493fab3ef9d440fe9f5540",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.review.help",
      "title": "If you felt excluded or were treated unfairly",
      "text": "That is not proof that you failed a skill or need to try harder to be liked. Seek support and consider the setting. Discrimination, access barriers and harm are not solved by a better greeting.",
      "sha256": "6982837b93583e82063874baf6029c4cc4b0e426198b51182a42444fb4abcb2e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "relationship-building.practice.next",
      "title": "Choose a next step without chasing approval",
      "text": "With your therapist, decide whether to keep this approach, change the setting or support, practise a different part, pause or stop. Any later contact needs to remain wanted and suitable for everyone involved.\n\nYou may revisit a welcoming shared activity if it fits, but repeated attendance does not oblige anyone to become a friend. A refusal or a lack of reply is not a challenge to overcome. You can choose another opportunity or none for now.",
      "sha256": "dd7f1558d234b31984fe62a8e4c405fa85b9ec923da16c8575e04157f1dc4c5c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "relationship-building.practice.next.help",
      "title": "If you want more closeness than the other person does",
      "text": "You can notice the wish without pressuring them or blaming yourself. Discuss your needs and other supports with your therapist. This component does not tell you how to change or end a relationship.",
      "sha256": "6c7f7deec0c2f38a4e97fabd4bcd89f5f7ce18e3db51476804c0105ba6a7edb4",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
