window.MindfulnessEventsContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/mindful",
  "componentId": "component/mindful/mindfulness-of-pleasant-and-unpleasant-events",
  "resourceId": "tool/mindfulness-events",
  "routeProposal": "/mindfulness-events/",
  "title": "Mindfulness of Pleasant and Unpleasant Events",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Therapist-introduced single-event mindfulness: notice an ordinary event and its pleasant or mildly unpleasant feel as it happens, then distinguish event-time awareness, body sensations, emotions and thoughts from present experience during later review.",
  "groupedSetStatus": "Existing uncounted component under classic/mindful. Complete bounded single-event adaptation covering both source event types, not a copied daily calendar, full mindfulness set, MBSR/MBCT programme, exposure or emotion-change protocol. Candidate route only; no new canonical count.",
  "clinicalContract": {
    "learningObjective": "Distinguish event-time awareness of pleasantness or unpleasantness from later reconstruction; notice body sensations, emotions and thoughts without moral judgment, forced feeling or a claim about cause; preserve present experience during review as a separate time.",
    "practiceObjective": "Check fit and an ordinary opportunity with a therapist, read the noticing guide, actually attend to a naturally occurring manageable event when suitable without typing a running log, then describe only known event-time observations and freshly notice current review experience, leaving skipped/unnoticed/uncertain material explicit.",
    "sourcePopulationContext": "2015 author/publisher DBT optional mindfulness teaching and Worksheets 8/9 inform this original adaptation. Relevant prior mindfulness learning and therapist introduction are needed. No age floor or all-age efficacy claim; individual clinical, developmental, cultural, communication, safeguarding and access fit remain necessary.",
    "exclusions": [
      "No deliberate unpleasant-event induction, exposure, pain exercise, trauma recall, unsafe waiting or instruction to tolerate abuse",
      "No requirement to manufacture pleasure, stay until discomfort falls, prolong a pleasant feeling or produce a positive interpretation",
      "No body scan, symptom checking, breathing manipulation, posture, closed eyes, required sensory channel or deliberate physical arousal",
      "No emotional-diary inference of cause, thought challenging, behavioral activation programme, diagnostic/risk score or automatic valence classification",
      "No copied calendar, compulsory daily logging, assigned repetition or claim that partial/skipped noticing is full method completion",
      "No full MBSR/MBCT treatment, whole mindfulness curriculum or efficacy claim for this digital adaptation"
    ],
    "adaptations": [
      "Original shared prepare/review flow and two fictional event accounts, not copied source calendar, examples or form layout",
      "Single-event optional record replaces source calendar-based daily recording; frequency belongs to individualized therapist planning",
      "Retain explicit source-based body noticing; allow skipping, unknown or unavailable sensations without substitution or claiming equivalent full completion",
      "Mixed, neutral or unclear tone can be recorded honestly rather than forced into either source category; no new named neutral-event protocol claimed",
      "Separate preparation, event-time practice, retrospective-only review, current review experience, stopping and no use; optional notes and later review never prove an actual attempt"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of bounded single-event scope, adaptations and source-use rights",
      "Individual prior learning, clinical, developmental, cultural, communication, safeguarding and access fit, including body-attention suitability",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration generation and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose preparation or review",
      "options": [
        {
          "value": "prepare",
          "label": "Prepare to notice an ordinary event",
          "startSectionId": "mindfulness-events.practice.situation"
        },
        {
          "value": "review",
          "label": "Review what I noticed or did not try",
          "startSectionId": "mindfulness-events.practice.event"
        }
      ]
    },
    "entryGate": "Scope and safety visible before entry. No default event type, mode or clinical fit inferred.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence, writing, event, sensation or feeling.",
    "reviewAccess": "Direct blank review begins at the later event account, with optional forward access to tone, body, thoughts and current review. No prior plan or event-time awareness inferred. No-event users can jump to the summary or finish; all groups remain freely available.",
    "writing": "Optional and hidden initially; intended for later review, not a required live-event log. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording or autoplay.",
    "timer": "None. No required duration, daily calendar, quota, discomfort rating or exposure hierarchy.",
    "completion": "No inferred event, valence, in-the-moment awareness, full noticing, calm, improvement or learning."
  },
  "intro": {
    "id": "mindfulness-events.intro",
    "title": "Notice the event, then notice the later review",
    "paragraphs": [
      "Some ordinary moments feel pleasant; others feel unpleasant. This practice invites you to notice that feel while a suitable event is happening, along with thoughts, emotions and body sensations that you can notice safely.",
      "Later, look back at what you actually noticed and what you did not. Then notice what is happening in you now as you review. These are two different times. A feeling during review does not prove it was there during the event.",
      "Use this after learning mindfulness with your therapist. You can prepare, use the examples, review an earlier attempt or finish. This is not a task to create pleasure, seek discomfort or explain why you reacted."
    ]
  },
  "fit": {
    "id": "mindfulness-events.fit",
    "title": "Keep the event ordinary and manageable",
    "paragraphs": [
      "Agree a suitable everyday context with your therapist. For unpleasant events, keep to mild moments that happen on their own. Do not create, seek out, replay or prolong something upsetting to practise. This is not exposure or trauma work.",
      "Do not practise while driving, using dangerous equipment, supervising a situation that needs full attention or dealing with urgent care or safety needs. Respond to pain, danger, abuse or a real problem instead of waiting to finish this exercise. Keep your agreed care and support plans.",
      "Body sensations are part of the source practice, but you can skip that part or stop. No body scan, changed breathing, closed eyes or special position is required. If attention to your body increases distress, checking or feeling cut off from your surroundings, pause and discuss the fit with your therapist.",
      "Use thoughts, speech, signing or a communication aid. Keep helpful cues and support. You do not need to use every sense, give an emotion a perfect name or notice something on demand. The page does not assess safety or provide urgent help."
    ]
  },
  "privacy": {
    "id": "mindfulness-events.privacy",
    "title": "Notes are optional and for later",
    "paragraphs": [
      "You do not need to write while the event happens. A short note later is enough if you want one. You can use the made-up examples without entering private details. This tool records no voice and sends no notes or messages.",
      "Writing stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.",
      "Hiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox."
    ]
  },
  "close": {
    "id": "mindfulness-events.close",
    "title": "Finish without needing a different feeling",
    "paragraphs": [
      "You can finish after reading, noticing, reviewing, stopping or choosing not to practise. There is no need to find a lesson, feel better or complete every part.",
      "If useful, bring one observation or question to your therapist. No reminder, report or next task is created. Leaving clears notes from this tool, not copies elsewhere."
    ]
  },
  "example": {
    "id": "mindfulness-events.example",
    "title": "Two made-up moments: a tune and a closed book",
    "paragraphs": [
      "In a pleasant example, Rowan hears a familiar tune during a suitable quiet break. Rowan notices enjoyment while the tune plays, a light feeling around the face, and the thought, \"I like this part.\" Rowan does not try to hold the feeling or restart the tune to get more.",
      "Later, Rowan remembers noticing the pleasant feel at the time. While reviewing, Rowan now feels quiet, notices no clear body change, and thinks, \"I might have missed that little moment.\" The later thought is recorded as later, not added to the earlier event.",
      "In a separate mildly unpleasant example, Rowan’s book slips shut while copying a small sketch. Rowan notices annoyance at the time, a tighter grip on the pencil, and the thought, \"I lost my place.\" Rowan opens the book to find the page. There is no need to keep it shut or stay annoyed to practise.",
      "Later, Rowan still feels a little annoyed and notices a looser grip now. A new thought is, \"A bookmark could help.\" Those are current review observations, not proof that mindfulness changed the feeling or caused the grip to loosen. Both examples are made up; they do not predict your experience."
    ]
  },
  "learn": {
    "id": "mindfulness-events.learn",
    "title": "Feeling tone is not a verdict",
    "paragraphs": [
      "Pleasant and unpleasant describe how an experience feels to you at a time. They do not decide whether an event is safe, right or wrong. The feel can be mixed, neutral, unclear or change quickly. You do not have to force it into one box.",
      "This practice includes awareness while the event happens. Remembering it later can still be useful, but does not prove that you noticed it then. If you only noticed afterward, say so. Do not create missing details to complete an account.",
      "Body sensations, emotions and thoughts can occur together without being the same thing. A tight grip is a body detail; annoyance is an emotion; \"I lost my place\" is a thought. A thought is something you noticed, not automatically a fact or a cause.",
      "The later review is another present moment. Notice any current sensations, emotions and thoughts that are clear enough and safe to notice. They may match the earlier experience, differ or remain unclear. No change is required.",
      "This is different from planning pleasant activities, mapping causes or trying to change an emotion. The source uses daily calendars. This page offers one optional event review instead; your therapist can discuss whether and when another practice fits."
    ]
  },
  "practice": [
    {
      "id": "mindfulness-events.practice.situation",
      "title": "Choose a suitable ordinary opportunity",
      "paragraphs": [
        "With your therapist’s guidance, consider a familiar setting where an everyday event might be noticed. You do not need to arrange an event or make it feel a certain way. The example is enough if no personal practice fits.",
        "Check what needs your attention, what support helps and what would be a reason to stop. If you are reviewing a past moment, use what really occurred rather than inventing a plan you did not have."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The ordinary context or made-up example",
          "optional": true
        },
        {
          "key": "fit-and-support",
          "label": "Limits, support and whether practice fits",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot find a pleasant moment",
        "text": "You do not need to search harder or make yourself enjoy something. Use the example, leave the practice for another time or discuss it with your therapist."
      }
    },
    {
      "id": "mindfulness-events.practice.prepare",
      "title": "Read the noticing guide before you try",
      "paragraphs": [
        "During a suitable event, the guide is to notice what is happening, whether it feels pleasant or unpleasant, and any body sensations, emotions or thoughts you can notice safely. You are not required to collect every detail.",
        "Read the questions below now if useful, then let the event have your attention when it occurs. Keep the page as a cue if needed, but there is no running written log to complete. Notes can wait until afterward."
      ],
      "fields": [
        {
          "key": "noticing-guide",
          "label": "A simple cue I may use, if helpful",
          "optional": true
        },
        {
          "key": "parts-to-skip",
          "label": "Any part to skip or discuss before trying",
          "optional": true
        }
      ],
      "help": {
        "title": "If body noticing is not a fit",
        "text": "Skip it or stay with the example and discuss it with your therapist. Noticing other parts is not the same as having done the body part. You do not need to fill that gap."
      }
    },
    {
      "id": "mindfulness-events.practice.try",
      "title": "Actually notice when a suitable event happens",
      "paragraphs": [
        "If a manageable event is happening and the practice fits, let yourself notice it as it unfolds. Notice its pleasant or mildly unpleasant feel, along with any clear body, emotion or thought detail. No special breathing or prolonged focus is needed.",
        "You can respond to the situation, let a pleasant moment end, pause or stop. Do not wait for an unpleasant feeling to fade or replay an event to make it stronger. If no suitable event happens, you have prepared rather than tried this part."
      ],
      "fields": [
        {
          "key": "actual-try",
          "label": "What I actually tried, stopped or did not try",
          "optional": true
        },
        {
          "key": "event-time-noticing",
          "label": "What I noticed while it was happening, if anything",
          "optional": true
        }
      ],
      "help": {
        "title": "If the event passed before I noticed",
        "text": "You can review that honestly. Later recall is not a failure, but it is different from noticing at the time. Do not repeat the event just to make this count."
      }
    },
    {
      "id": "mindfulness-events.practice.event",
      "title": "Later, describe the event briefly",
      "paragraphs": [
        "Afterward, choose whether to review. If there is no event to review, use \"Review what was actually noticed\" or finish; no event needs to be invented. What happened and what was the setting? Use a short concrete description, not a full history. Keep the event separate from the meaning you gave it.",
        "You can use a past event without earlier notes. Say if you are remembering now rather than reporting something noticed during it. Leave uncertain details open instead of treating current feelings as proof about then."
      ],
      "fields": [
        {
          "key": "event-description",
          "label": "What happened and the relevant setting",
          "optional": true
        },
        {
          "key": "memory-limits",
          "label": "What I remember, did not notice or am unsure about",
          "optional": true
        }
      ],
      "help": {
        "title": "If remembering becomes upsetting",
        "text": "Stop reviewing and use suitable support. This is not a task to relive the event or recover every detail."
      }
    },
    {
      "id": "mindfulness-events.practice.tone",
      "title": "Separate the feel from awareness of it",
      "paragraphs": [
        "How did the event feel at the time: pleasant, mildly unpleasant, mixed, neutral or unclear? This is your experience, not a judgment of whether you ought to have liked it. It may have changed during the moment.",
        "Were you aware of that feel while the event was happening, only afterward, or are you unsure? Those are different observations. Do not turn a later answer into a claim of earlier awareness."
      ],
      "fields": [
        {
          "key": "feeling-tone",
          "label": "How the event seemed to feel at the time",
          "optional": true
        },
        {
          "key": "awareness-timing",
          "label": "When I noticed that feel, or why I am unsure",
          "optional": true
        }
      ],
      "help": {
        "title": "If the feel was mixed or neutral",
        "text": "Keep that account rather than forcing a pleasant or unpleasant label. It is not proof that the practice went wrong. You can discuss whether another example with your therapist would help."
      }
    },
    {
      "id": "mindfulness-events.practice.body",
      "title": "Keep body details tied to the event",
      "paragraphs": [
        "If this part fits, what body sensation did you actually notice during the event? Describe only what was available, such as a change in grip or a feeling in the face. No particular body sign is expected.",
        "You may not have noticed, may not remember or may have skipped this part. Leave that clear. Do not scan your body now, recreate a sensation or copy an example to fill in what happened then. Current sensations belong to the later review."
      ],
      "fields": [
        {
          "key": "body-then",
          "label": "Body sensations noticed during the event, if any",
          "optional": true
        },
        {
          "key": "body-limits",
          "label": "Not noticed, unknown, skipped or another limit",
          "optional": true
        }
      ],
      "help": {
        "title": "If there was no clear body detail",
        "text": "That can remain blank or unknown. The source includes body awareness, but this page never assumes it happened. You can review the other parts without claiming a full set of observations."
      }
    },
    {
      "id": "mindfulness-events.practice.thoughts",
      "title": "Describe emotions and thoughts from that time",
      "paragraphs": [
        "What emotions or mood did you notice while the event was happening? What words, images or thoughts were present? Use your own words; more than one feeling or no clear label can fit.",
        "Keep these as observations, not a demand to explain the event or change a thought. If you remember a thought only now, note the uncertainty. A new thought during review belongs to now, even if it is about the same event."
      ],
      "fields": [
        {
          "key": "emotions-then",
          "label": "Emotions or mood noticed at the time",
          "optional": true
        },
        {
          "key": "thoughts-then",
          "label": "Thoughts or images from that time, with any uncertainty",
          "optional": true
        }
      ],
      "help": {
        "title": "If I start debating whether a thought was true",
        "text": "You can simply record that a thought occurred, or leave it for a separate therapist-guided skill. This practice does not need an explanation or a more positive thought."
      }
    },
    {
      "id": "mindfulness-events.practice.now",
      "title": "Notice this review as a new moment",
      "paragraphs": [
        "As you review now, pause if it fits and notice your present experience. Are any emotions, mood or body sensations clear and safe to notice? No body scan is needed, and you can skip body attention here too.",
        "What thoughts or images are present now? They might concern the event, this exercise or something else. Keep these current observations separate from the earlier ones. Nothing needs to change, and you can stop without a complete account."
      ],
      "fields": [
        {
          "key": "current-feelings",
          "label": "Emotions, mood and any body sensations now, or skipped/unclear",
          "optional": true
        },
        {
          "key": "current-thoughts",
          "label": "Thoughts or images during review now",
          "optional": true
        }
      ],
      "help": {
        "title": "If reviewing feels like going back into the event",
        "text": "Pause or stop. You are in the current setting, not required to relive the earlier moment. Use agreed support and discuss whether this practice is suitable."
      }
    },
    {
      "id": "mindfulness-events.practice.review",
      "title": "Review what was actually noticed",
      "paragraphs": [
        "What did you actually do: read, prepare, notice an event as it happened, recall it later, review, stop or not practise? You can enter here without notes or an attempt. No opportunity and choosing not to try are different facts.",
        "Which details were noticed during the event, which appeared during review, and which stayed unknown or were skipped? A partial account is allowed. The page does not turn completed boxes into proof of full practice.",
        "What fitted, felt difficult or needs support? A better mood, a calmer body or a positive lesson is not the test. You can finish with the same feelings and an open question."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What I actually did or did not do",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What I noticed then versus now, and any gaps",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What fitted, did not fit or needs discussion",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing useful seemed to happen",
        "text": "Record that if you want. It does not prove that you failed or that the practice fits you. Your therapist can help decide whether to adapt or leave it."
      }
    },
    {
      "id": "mindfulness-events.practice.next",
      "title": "Choose whether another practice fits",
      "paragraphs": [
        "With your therapist, decide whether to try again, change the context, use support, leave out a part or stop using this practice. If a part is left out, keep that clear rather than treating it as the same full procedure.",
        "You can agree a suitable opportunity and review without setting a daily quota. No missed-practice debt, reminder or report is created. A question brought to therapy can be enough; writing is not required."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, change, pause or leave",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any support or review question to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If I start watching every moment",
        "text": "Pause and discuss that pressure with your therapist. This is not a demand to monitor yourself all day or keep checking whether an event feels pleasant enough."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Worksheets 8 and 9",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed pp. 101–104: awareness of ordinary pleasant/unpleasant events as they occur, body/emotion/thought observations, later recording and current experience.",
      "limits": "Original single-event adaptation covering both source types, not copied daily calendars, source examples or form layout. Daily recording format is deliberately not implemented."
    },
    {
      "id": "Linehan/Guilford: 2015 mindfulness teaching, section XV",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Printed pp. 222–223 explain attention to present sensations, moods, feelings and thoughts during practice and also while reviewing/writing; prior mindfulness teaching and individual assignment.",
      "limits": "Historical Second Edition, not verified revised-2025 equivalence. Bounded practice is not the full doing/being method or evidence for this app’s efficacy."
    },
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Handout 9a",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed pp. 72–73: everyday awareness of pleasant and unpleasant events, including small experiences.",
      "limits": "No source example or other optional exercise copied. No Three-minute Wise Mind sequence, full MBSR/MBCT, body scan or exposure procedure supplied."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal, meaningful communication and access to support.",
      "limits": "Rights guidance, not clinical validation or proof of equivalent effects for every adaptation."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from the individual purchaser duplication licence.",
      "limits": "Accessible source text does not grant public app rights. Clinical and release-rights decisions remain open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Individual fit and prospective event-time noticing",
      "sections": [
        "practice.situation",
        "practice.prepare",
        "practice.try"
      ],
      "source": "Worksheets8/9 instructions and ManualXV; original low-risk, no-induction and accessible stop boundaries"
    },
    {
      "operation": "Concrete event, feeling tone and timing of awareness",
      "sections": [
        "practice.event",
        "practice.tone"
      ],
      "source": "Worksheets8/9 event description and awareness during event; original explicit later/unknown/mixed distinctions"
    },
    {
      "operation": "Body, emotions and thoughts during the event",
      "sections": [
        "practice.body",
        "practice.thoughts"
      ],
      "source": "Worksheets8/9; retain body invitation with transparent skip/unknown rather than substitute or infer completion"
    },
    {
      "operation": "Fresh present review, honest participation and individual follow-up",
      "sections": [
        "practice.now",
        "practice.review",
        "practice.next"
      ],
      "source": "Worksheets8/9 current experience and ManualXV review-time noticing; original single-event optional record instead of daily calendars"
    }
  ],
  "narrationSegments": [
    {
      "id": "mindfulness-events.intro",
      "title": "Notice the event, then notice the later review",
      "text": "Some ordinary moments feel pleasant; others feel unpleasant. This practice invites you to notice that feel while a suitable event is happening, along with thoughts, emotions and body sensations that you can notice safely.\n\nLater, look back at what you actually noticed and what you did not. Then notice what is happening in you now as you review. These are two different times. A feeling during review does not prove it was there during the event.\n\nUse this after learning mindfulness with your therapist. You can prepare, use the examples, review an earlier attempt or finish. This is not a task to create pleasure, seek discomfort or explain why you reacted.",
      "sha256": "892a4e530e814c465ea6209cd18e67a65847d66793c1547ab186cf86707d23e8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.fit",
      "title": "Keep the event ordinary and manageable",
      "text": "Agree a suitable everyday context with your therapist. For unpleasant events, keep to mild moments that happen on their own. Do not create, seek out, replay or prolong something upsetting to practise. This is not exposure or trauma work.\n\nDo not practise while driving, using dangerous equipment, supervising a situation that needs full attention or dealing with urgent care or safety needs. Respond to pain, danger, abuse or a real problem instead of waiting to finish this exercise. Keep your agreed care and support plans.\n\nBody sensations are part of the source practice, but you can skip that part or stop. No body scan, changed breathing, closed eyes or special position is required. If attention to your body increases distress, checking or feeling cut off from your surroundings, pause and discuss the fit with your therapist.\n\nUse thoughts, speech, signing or a communication aid. Keep helpful cues and support. You do not need to use every sense, give an emotion a perfect name or notice something on demand. The page does not assess safety or provide urgent help.",
      "sha256": "ccd66635929eee6393bae4b3a0c17139be49f9dfbc877c85c46c0d9985c5e518",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.privacy",
      "title": "Notes are optional and for later",
      "text": "You do not need to write while the event happens. A short note later is enough if you want one. You can use the made-up examples without entering private details. This tool records no voice and sends no notes or messages.\n\nWriting stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.\n\nHiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox.",
      "sha256": "e7e753049b40816b281ecc0966995ebed92c8dab4665438b40f5ea7aadaabe97",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.close",
      "title": "Finish without needing a different feeling",
      "text": "You can finish after reading, noticing, reviewing, stopping or choosing not to practise. There is no need to find a lesson, feel better or complete every part.\n\nIf useful, bring one observation or question to your therapist. No reminder, report or next task is created. Leaving clears notes from this tool, not copies elsewhere.",
      "sha256": "e4dee933786158bfb82b6a6df042b20a7e0a4831804ded7ade0eb7da625eb118",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.example",
      "title": "Two made-up moments: a tune and a closed book",
      "text": "In a pleasant example, Rowan hears a familiar tune during a suitable quiet break. Rowan notices enjoyment while the tune plays, a light feeling around the face, and the thought, \"I like this part.\" Rowan does not try to hold the feeling or restart the tune to get more.\n\nLater, Rowan remembers noticing the pleasant feel at the time. While reviewing, Rowan now feels quiet, notices no clear body change, and thinks, \"I might have missed that little moment.\" The later thought is recorded as later, not added to the earlier event.\n\nIn a separate mildly unpleasant example, Rowan’s book slips shut while copying a small sketch. Rowan notices annoyance at the time, a tighter grip on the pencil, and the thought, \"I lost my place.\" Rowan opens the book to find the page. There is no need to keep it shut or stay annoyed to practise.\n\nLater, Rowan still feels a little annoyed and notices a looser grip now. A new thought is, \"A bookmark could help.\" Those are current review observations, not proof that mindfulness changed the feeling or caused the grip to loosen. Both examples are made up; they do not predict your experience.",
      "sha256": "9de30ea71b1867c460c89c69e7b5828545b1e2033350692cea59bf2bdcc9657c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.learn",
      "title": "Feeling tone is not a verdict",
      "text": "Pleasant and unpleasant describe how an experience feels to you at a time. They do not decide whether an event is safe, right or wrong. The feel can be mixed, neutral, unclear or change quickly. You do not have to force it into one box.\n\nThis practice includes awareness while the event happens. Remembering it later can still be useful, but does not prove that you noticed it then. If you only noticed afterward, say so. Do not create missing details to complete an account.\n\nBody sensations, emotions and thoughts can occur together without being the same thing. A tight grip is a body detail; annoyance is an emotion; \"I lost my place\" is a thought. A thought is something you noticed, not automatically a fact or a cause.\n\nThe later review is another present moment. Notice any current sensations, emotions and thoughts that are clear enough and safe to notice. They may match the earlier experience, differ or remain unclear. No change is required.\n\nThis is different from planning pleasant activities, mapping causes or trying to change an emotion. The source uses daily calendars. This page offers one optional event review instead; your therapist can discuss whether and when another practice fits.",
      "sha256": "33cc47db2763736548c328adb77368e878404739ad71c6ae173645ca49821090",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.situation",
      "title": "Choose a suitable ordinary opportunity",
      "text": "With your therapist’s guidance, consider a familiar setting where an everyday event might be noticed. You do not need to arrange an event or make it feel a certain way. The example is enough if no personal practice fits.\n\nCheck what needs your attention, what support helps and what would be a reason to stop. If you are reviewing a past moment, use what really occurred rather than inventing a plan you did not have.",
      "sha256": "4e96a59804eb743b4168c841fec2ad5ed816c4fc92639d643c954e98f645dcf1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.situation.help",
      "title": "If I cannot find a pleasant moment",
      "text": "You do not need to search harder or make yourself enjoy something. Use the example, leave the practice for another time or discuss it with your therapist.",
      "sha256": "537dd6158002e402cb7616e9a2715130d79b4446b85050b416b26b0bdfe3b1ac",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.prepare",
      "title": "Read the noticing guide before you try",
      "text": "During a suitable event, the guide is to notice what is happening, whether it feels pleasant or unpleasant, and any body sensations, emotions or thoughts you can notice safely. You are not required to collect every detail.\n\nRead the questions below now if useful, then let the event have your attention when it occurs. Keep the page as a cue if needed, but there is no running written log to complete. Notes can wait until afterward.",
      "sha256": "ad79f9f1eaa8ac32ead9bb30705840281c4327c1722356bf0a98b6cc78329202",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.prepare.help",
      "title": "If body noticing is not a fit",
      "text": "Skip it or stay with the example and discuss it with your therapist. Noticing other parts is not the same as having done the body part. You do not need to fill that gap.",
      "sha256": "dc642f205fca694c570cc3cc698aaa8255d664d38229b5b19717cef8d8460283",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.try",
      "title": "Actually notice when a suitable event happens",
      "text": "If a manageable event is happening and the practice fits, let yourself notice it as it unfolds. Notice its pleasant or mildly unpleasant feel, along with any clear body, emotion or thought detail. No special breathing or prolonged focus is needed.\n\nYou can respond to the situation, let a pleasant moment end, pause or stop. Do not wait for an unpleasant feeling to fade or replay an event to make it stronger. If no suitable event happens, you have prepared rather than tried this part.",
      "sha256": "e0949ef5b58f999afe5349f35cae7627a4073e40cb4eb5b45765567a6fbb7150",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.try.help",
      "title": "If the event passed before I noticed",
      "text": "You can review that honestly. Later recall is not a failure, but it is different from noticing at the time. Do not repeat the event just to make this count.",
      "sha256": "8c6777128a2074c499e2e2ed486957ee7bb6dc941d71f4812176ff4f0f7f8713",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.event",
      "title": "Later, describe the event briefly",
      "text": "Afterward, choose whether to review. If there is no event to review, use \"Review what was actually noticed\" or finish; no event needs to be invented. What happened and what was the setting? Use a short concrete description, not a full history. Keep the event separate from the meaning you gave it.\n\nYou can use a past event without earlier notes. Say if you are remembering now rather than reporting something noticed during it. Leave uncertain details open instead of treating current feelings as proof about then.",
      "sha256": "132367d2fb5f59fd3d743d95f78558e721a3bb528eb623fa6c8de07f46614327",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.event.help",
      "title": "If remembering becomes upsetting",
      "text": "Stop reviewing and use suitable support. This is not a task to relive the event or recover every detail.",
      "sha256": "52a914b8cbcc05c511d60f730d2beeab1a148d3422baa7026de16a87d6401842",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.tone",
      "title": "Separate the feel from awareness of it",
      "text": "How did the event feel at the time: pleasant, mildly unpleasant, mixed, neutral or unclear? This is your experience, not a judgment of whether you ought to have liked it. It may have changed during the moment.\n\nWere you aware of that feel while the event was happening, only afterward, or are you unsure? Those are different observations. Do not turn a later answer into a claim of earlier awareness.",
      "sha256": "345f8ab05d516c758e2d9f7353b654a49d3a2d58b163c282137e087aa0b98475",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.tone.help",
      "title": "If the feel was mixed or neutral",
      "text": "Keep that account rather than forcing a pleasant or unpleasant label. It is not proof that the practice went wrong. You can discuss whether another example with your therapist would help.",
      "sha256": "638815552dcf82c9ca538004a3958893adcaa8360615cfffa218004120e77064",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.body",
      "title": "Keep body details tied to the event",
      "text": "If this part fits, what body sensation did you actually notice during the event? Describe only what was available, such as a change in grip or a feeling in the face. No particular body sign is expected.\n\nYou may not have noticed, may not remember or may have skipped this part. Leave that clear. Do not scan your body now, recreate a sensation or copy an example to fill in what happened then. Current sensations belong to the later review.",
      "sha256": "ca806cbd72aebadd3293cb935e8e5cda06838ae79454102ddf9c241860aa5b14",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.body.help",
      "title": "If there was no clear body detail",
      "text": "That can remain blank or unknown. The source includes body awareness, but this page never assumes it happened. You can review the other parts without claiming a full set of observations.",
      "sha256": "8044a654ea9bfcab1b9ac4de73223f3e09459950541c3da870f2dfd206b6ef08",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.thoughts",
      "title": "Describe emotions and thoughts from that time",
      "text": "What emotions or mood did you notice while the event was happening? What words, images or thoughts were present? Use your own words; more than one feeling or no clear label can fit.\n\nKeep these as observations, not a demand to explain the event or change a thought. If you remember a thought only now, note the uncertainty. A new thought during review belongs to now, even if it is about the same event.",
      "sha256": "e492692d65150d39dc2d4a966b554d4523a6eb53e8de782b34963e943b90ed9d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.thoughts.help",
      "title": "If I start debating whether a thought was true",
      "text": "You can simply record that a thought occurred, or leave it for a separate therapist-guided skill. This practice does not need an explanation or a more positive thought.",
      "sha256": "2d1c4c768883d1749a91f28cbe2ba4251b620562a0414a1c114efc3477d2849f",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.now",
      "title": "Notice this review as a new moment",
      "text": "As you review now, pause if it fits and notice your present experience. Are any emotions, mood or body sensations clear and safe to notice? No body scan is needed, and you can skip body attention here too.\n\nWhat thoughts or images are present now? They might concern the event, this exercise or something else. Keep these current observations separate from the earlier ones. Nothing needs to change, and you can stop without a complete account.",
      "sha256": "a2d0b0887dbc8e307182ea2e774b1607ae8edd789b83dc4a212f646ae1b78bd5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.now.help",
      "title": "If reviewing feels like going back into the event",
      "text": "Pause or stop. You are in the current setting, not required to relive the earlier moment. Use agreed support and discuss whether this practice is suitable.",
      "sha256": "fcc8632532d890c87cc62acecc293493f53846e13ee882a61dc8c1074440c54a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.review",
      "title": "Review what was actually noticed",
      "text": "What did you actually do: read, prepare, notice an event as it happened, recall it later, review, stop or not practise? You can enter here without notes or an attempt. No opportunity and choosing not to try are different facts.\n\nWhich details were noticed during the event, which appeared during review, and which stayed unknown or were skipped? A partial account is allowed. The page does not turn completed boxes into proof of full practice.\n\nWhat fitted, felt difficult or needs support? A better mood, a calmer body or a positive lesson is not the test. You can finish with the same feelings and an open question.",
      "sha256": "c7af347b091a4524b3a93ba4c0e1b7d32b280a6d3ee050d38f2c965a35fec0bf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.review.help",
      "title": "If nothing useful seemed to happen",
      "text": "Record that if you want. It does not prove that you failed or that the practice fits you. Your therapist can help decide whether to adapt or leave it.",
      "sha256": "af1515b1e0cb3db6cd7919b9e37a560e2438213e1b6ec2c599ca8a7f92c325ff",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-events.practice.next",
      "title": "Choose whether another practice fits",
      "text": "With your therapist, decide whether to try again, change the context, use support, leave out a part or stop using this practice. If a part is left out, keep that clear rather than treating it as the same full procedure.\n\nYou can agree a suitable opportunity and review without setting a daily quota. No missed-practice debt, reminder or report is created. A question brought to therapy can be enough; writing is not required.",
      "sha256": "db2338a0f578e075ea7a2d0a87da4e7fc45c4a683bdd278a9efa3234f4b4712e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-events.practice.next.help",
      "title": "If I start watching every moment",
      "text": "Pause and discuss that pressure with your therapist. This is not a demand to monitor yourself all day or keep checking whether an event feels pleasant enough.",
      "sha256": "5e0e988c84ffd88b736487eb1051ab86dfc4697d086b76f34edb082b9d045dd8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
