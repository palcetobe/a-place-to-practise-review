window.EveningSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "breathing.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Frozen authored scripts only until exact asset, perceptual listening and integration gates pass. No personal words in audio. Existing audio assets do not imply these new words are voiced.",
    "timer": "None unless explicitly specified in practiceAid.",
    "visual": "Optional neutral code-native timing marker, not lungs or an expanding volume-shaped circle; text-equivalent and reduced-motion safe. No new icon.",
    "fictionalPractice": "Show optional fictional practice before prompts and keep available contextually. Do not prefill or evaluate private words. Reading the example is not marked as actual practice."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/breathing",
  "title": "Paced Breathing",
  "subtitle": "Find a gentle rhythm that fits",
  "scope": "Comfortable no-hold breathing practice; not Box Breathing, interoceptive exposure, respiratory treatment or the full DBT TIP protocol.",
  "resourceId": "tool/paced-breathing",
  "routeProposal": "tool/paced-breathing",
  "version": "2026-11-02-evening-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Explain that pacing concerns a comfortable rhythm, not a larger breath, a breath hold or a target that must be met.",
    "practiceObjective": "If appropriate, try a few gentle no-hold cycles at a comfortable rhythm, optionally using a cue; notice fit and adjust or stop without requiring calm.",
    "observedPractice": "Private consideration, actual optional practice and review are separate from reading; no typing, rating, symptom reduction or claim of mastery required.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Adult source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "intro": {
    "id": "breathing.intro",
    "title": "A gentle rhythm, not a test",
    "paragraphs": [
      "This practice offers a comfortable, regular in-and-out rhythm. You do not need a deep breath, a long count or a breath hold.",
      "Start with your own breathing. If a paced rhythm does not fit, leave your breathing alone, look around the room, or finish. Choosing not to change your breathing is a valid option, not the same as practising paced breathing."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "breathing.fit",
    "title": "Check comfort and fit",
    "paragraphs": [
      "Use this with your therapist between sessions. Sit or rest somewhere safe; do not use the visual guide while driving or doing something needing close attention.",
      "If you have a breathing or other health condition, follow your healthcare professional’s advice about whether and how to practise. This is not treatment for new or unexplained breathlessness or chest pain. Seek appropriate medical help rather than assume those symptoms are anxiety.",
      "Stop changing your breathing if you feel dizzy, breathless, strained or uncomfortable. Let it return to its usual rhythm and seek help if symptoms are concerning or do not settle. You never need to keep up with a guide."
    ]
  },
  "learn": {
    "id": "breathing.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "Stress can come with a quicker or less comfortable breathing rhythm. Gently pacing breathing is one way to practise a steadier rhythm, when it suits you. It is not a guarantee that anxiety will reduce.",
      "Bigger breaths are not the aim. A quiet, comfortable breath may be enough. Counting or a visual cue is optional; neither measures your body or tells you the right rate for you.",
      "This page uses a no-hold practice. Other breathing patterns are not interchangeable, and this exercise does not replace a personal healthcare plan."
    ]
  },
  "example": {
    "id": "breathing.example",
    "title": "Example — adapting the guide",
    "paragraphs": [
      "Morgan sits comfortably before an ordinary meeting. Morgan tries a gentle count while breathing in and out, without holding. A count of five feels too long, so Morgan uses a shorter count rather than taking more air.",
      "Morgan tries two comfortable cycles and then lets breathing return to its usual rhythm. Worry about the meeting remains.",
      "In review, Morgan notices that the shorter count fitted better. Next time Morgan can use that approach, use no count, discuss fit with a therapist, or not practise. Matching a number was never the goal."
    ]
  },
  "practiceScenario": {
    "id": "breathing.scenario",
    "title": "If you prefer to read first",
    "paragraphs": [
      "Imagine helping Morgan choose what to do when a count feels too long. Would you ask Morgan to force a bigger breath, or shorten or leave the count?",
      "Reading this can clarify the method; it does not mean you changed your own breathing. You can read, try a little if suitable, or finish."
    ]
  },
  "practice": [
    {
      "id": "breathing.practice.settle",
      "title": "Begin with ordinary breathing",
      "paragraphs": [
        "Find a supported, comfortable position. Eyes can stay open. Let your breathing happen in its usual way for a moment.",
        "You can remain here without changing it, or continue if a gentle paced practice is suitable."
      ],
      "help": {
        "title": "If breathing is not a useful focus",
        "text": "Look at an ordinary object or leave the practice. You do not have to work through discomfort to use the library."
      }
    },
    {
      "id": "breathing.practice.rhythm",
      "title": "Try a comfortable rhythm",
      "paragraphs": [
        "Let a breath come in gently, then flow out gently, with no hold between. If helpful, use a short, steady count for each part. Use a count you can manage without strain; do not force five or take more air to fill the count.",
        "Try one or a few cycles, only while comfortable. You can adjust, return to usual breathing or stop at any point. The optional guide below is a cue, not a prescription."
      ],
      "help": {
        "title": "If the pace does not fit",
        "text": "Ignore or stop the cue. Use a shorter or different comfortable rhythm, or let breathing return to normal. Never hold your breath while waiting for the display."
      }
    },
    {
      "id": "breathing.practice.review",
      "title": "Notice what fitted",
      "paragraphs": [
        "Let breathing return to its usual rhythm. Was the approach comfortable, awkward or not useful? An unchanged feeling is a possible result.",
        "Keep an observation if useful. You do not need another round or a new plan."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I noticed, if I want to write",
          "optional": true
        }
      ],
      "help": {
        "title": "If you stopped or only read",
        "text": "You can finish here. Reading, trying and deciding not to continue are different; none needs to be scored as success or failure."
      }
    }
  ],
  "practiceAid": {
    "id": "breathing.guide",
    "title": "Optional breathing guide",
    "paragraphs": [
      "The guide marks time, not how much air to take. Keep each breath gentle; do not take extra air or try to keep up. Choose a timing only if it feels comfortable. You can ignore the guide and breathe normally at any time.",
      "The displayed starting setting is not a recommended rate for everyone. There are no breath holds. Changing the timing stops the guide so you can restart when ready.",
      "You can use the text cue without motion, or skip the guide. A one-minute limit is optional and only ends the cue; it is not a required practice dose. Stop the guide before switching tabs or apps, and let your breathing follow its usual rhythm."
    ],
    "kind": "optional-no-hold-pacer",
    "placement": "Alongside breathing.practice.rhythm only; not auto-started or required to advance",
    "default": "Off; own rhythm is default. Timing selector starts at3seconds per phase as a visible editable UI starting setting, not prescribed dose.",
    "settings": {
      "phaseSeconds": {
        "min": 2,
        "max": 6,
        "step": 1,
        "initial": 3,
        "label": "Seconds for each in and out cue"
      },
      "timeLimit": {
        "options": [
          "No time limit",
          "Stop guide after one minute"
        ],
        "initial": "No time limit"
      },
      "motion": {
        "options": [
          "Gentle motion",
          "Text cue only"
        ],
        "initial": "Respect prefers-reduced-motion; user may select text only"
      }
    },
    "labels": {
      "start": "Start optional guide",
      "pause": "Pause guide",
      "resume": "Restart guide",
      "stop": "Stop guide",
      "in": "Gentle breath in, if comfortable",
      "out": "Let breath flow out, if comfortable",
      "paused": "Guide paused. Let your breathing flow normally; do not hold.",
      "stopped": "Guide stopped. Breathe in your usual way.",
      "ended": "Time limit ended. Breathe in your usual way."
    },
    "semantics": [
      "Only In→Out→In, equal user-selected phase durations, no hold phase or pause-hold prompt.",
      "No breathing-volume implication, no sound forcing a rhythm, no inhale/exhale speech over practice.",
      "Pause/stop/change settings/navigation/hidden tab/Finish cancel cue immediately. Pause is not a request to hold breath. Restart begins a new cue only after explicit activation.",
      "No timing/pace compliance scoring or inference that user followed cue. Optional60second endpoint stops cue with normal-breath message, including midphase.",
      "Static text phase is the complete reduced-motion equivalent. No animation before explicit start.",
      "Starting narration stops guide; starting guide stops narration. Do not resume either automatically.",
      "Keep Stop, Finish and fit/support reachable outside focus collapse."
    ]
  },
  "close": {
    "id": "breathing.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "Let your breathing follow its usual rhythm. You can finish without feeling calmer or completing any number of breaths. If the practice did not fit, discuss that with your therapist."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "id": "nhs-breathing",
      "url": "https://www.nhs.uk/mental-health/self-help/guides-tools-and-activities/breathing-exercises-for-stress/",
      "reviewed": "2026-11-02",
      "supports": "Gentle comfortable breathing, optional steady counting with shorter count if needed. Source suggests5minutes; this bounded introductory rehearsal does not claim equivalent dose."
    },
    {
      "id": "nhs-safety",
      "url": "https://asph.nhs.uk/nervous-system-regulation",
      "reviewed": "2026-11-02",
      "supports": "Search-indexed NHS source supports comfort/no forced depth and stopping for dizziness; direct re-open timed out2026-11-02. Supplementary safety context, not evidence for digital timing."
    },
    {
      "id": "nhs-relaxation-fit",
      "url": "https://www.nhsinform.scot/healthy-living/preventing-falls/fear-and-anxiety-about-falling/relaxation-techniques-to-help-prevent-falls/",
      "reviewed": "2026-11-02",
      "supports": "Search-indexed professional-fit caution for breathing/medical conditions. Direct re-open403 on2026-11-02; not a claim of respiratory treatment."
    }
  ],
  "productAdaptations": [
    "Existing paced-breathing identity, no-hold subset only. Box reminders/holds and interoceptive exposure not restored.",
    "Original Morgan example and short optional rehearsal.",
    "Optional visual2–6seconds per phase, initial3seconds, and60second stop are product controls, not source-mandated or clinically validated dose. Own rhythm remains default.",
    "Ordinary-breath alternative and stop/medical-fit safeguards; no guarantee of symptom change."
  ],
  "narrationSegments": [
    {
      "id": "breathing.intro",
      "title": "A gentle rhythm, not a test",
      "text": "This practice offers a comfortable, regular in-and-out rhythm. You do not need a deep breath, a long count or a breath hold.\n\nStart with your own breathing. If a paced rhythm does not fit, leave your breathing alone, look around the room, or finish. Choosing not to change your breathing is a valid option, not the same as practising paced breathing.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.fit",
      "title": "Check comfort and fit",
      "text": "Use this with your therapist between sessions. Sit or rest somewhere safe; do not use the visual guide while driving or doing something needing close attention.\n\nIf you have a breathing or other health condition, follow your healthcare professional’s advice about whether and how to practise. This is not treatment for new or unexplained breathlessness or chest pain. Seek appropriate medical help rather than assume those symptoms are anxiety.\n\nStop changing your breathing if you feel dizzy, breathless, strained or uncomfortable. Let it return to its usual rhythm and seek help if symptoms are concerning or do not settle. You never need to keep up with a guide.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.learn",
      "title": "Why this skill may help",
      "text": "Stress can come with a quicker or less comfortable breathing rhythm. Gently pacing breathing is one way to practise a steadier rhythm, when it suits you. It is not a guarantee that anxiety will reduce.\n\nBigger breaths are not the aim. A quiet, comfortable breath may be enough. Counting or a visual cue is optional; neither measures your body or tells you the right rate for you.\n\nThis page uses a no-hold practice. Other breathing patterns are not interchangeable, and this exercise does not replace a personal healthcare plan.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.example",
      "title": "Example — adapting the guide",
      "text": "Morgan sits comfortably before an ordinary meeting. Morgan tries a gentle count while breathing in and out, without holding. A count of five feels too long, so Morgan uses a shorter count rather than taking more air.\n\nMorgan tries two comfortable cycles and then lets breathing return to its usual rhythm. Worry about the meeting remains.\n\nIn review, Morgan notices that the shorter count fitted better. Next time Morgan can use that approach, use no count, discuss fit with a therapist, or not practise. Matching a number was never the goal.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.scenario",
      "title": "If you prefer to read first",
      "text": "Imagine helping Morgan choose what to do when a count feels too long. Would you ask Morgan to force a bigger breath, or shorten or leave the count?\n\nReading this can clarify the method; it does not mean you changed your own breathing. You can read, try a little if suitable, or finish.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.practice.settle",
      "title": "Begin with ordinary breathing",
      "text": "Find a supported, comfortable position. Eyes can stay open. Let your breathing happen in its usual way for a moment.\n\nYou can remain here without changing it, or continue if a gentle paced practice is suitable.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.practice.settle.help",
      "title": "If breathing is not a useful focus",
      "text": "Look at an ordinary object or leave the practice. You do not have to work through discomfort to use the library.",
      "status": "Script only"
    },
    {
      "id": "breathing.practice.rhythm",
      "title": "Try a comfortable rhythm",
      "text": "Let a breath come in gently, then flow out gently, with no hold between. If helpful, use a short, steady count for each part. Use a count you can manage without strain; do not force five or take more air to fill the count.\n\nTry one or a few cycles, only while comfortable. You can adjust, return to usual breathing or stop at any point. The optional guide below is a cue, not a prescription.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.practice.rhythm.help",
      "title": "If the pace does not fit",
      "text": "Ignore or stop the cue. Use a shorter or different comfortable rhythm, or let breathing return to normal. Never hold your breath while waiting for the display.",
      "status": "Script only"
    },
    {
      "id": "breathing.practice.review",
      "title": "Notice what fitted",
      "text": "Let breathing return to its usual rhythm. Was the approach comfortable, awkward or not useful? An unchanged feeling is a possible result.\n\nKeep an observation if useful. You do not need another round or a new plan.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.practice.review.help",
      "title": "If you stopped or only read",
      "text": "You can finish here. Reading, trying and deciding not to continue are different; none needs to be scored as success or failure.",
      "status": "Script only"
    },
    {
      "id": "breathing.guide",
      "title": "Optional breathing guide",
      "text": "The guide marks time, not how much air to take. Keep each breath gentle; do not take extra air or try to keep up. Choose a timing only if it feels comfortable. You can ignore the guide and breathe normally at any time.\n\nThe displayed starting setting is not a recommended rate for everyone. There are no breath holds. Changing the timing stops the guide so you can restart when ready.\n\nYou can use the text cue without motion, or skip the guide. A one-minute limit is optional and only ends the cue; it is not a required practice dose. Stop the guide before switching tabs or apps, and let your breathing follow its usual rhythm.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.close",
      "title": "Leave it here for now",
      "text": "Let your breathing follow its usual rhythm. You can finish without feeling calmer or completing any number of breaths. If the practice did not fit, discuss that with your therapist.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "breathing.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; generation/listening/integration not asserted"
    }
  ]
}
;
