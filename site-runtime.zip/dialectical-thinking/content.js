window.EmotionSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "dialectics.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "contextReview": {
      "placement": "support/synthesis/review prompts",
      "fields": [
        "partA",
        "partB",
        "support",
        "synthesis"
      ],
      "behavior": "Keep the two entered parts available together beside the synthesis/review prompt, with an adjacent edit/back affordance retaining notes. Only show private echoes when writing is shown; no auto-composed statement, assessment or prefill. Hide all echoes when writing hidden; clear with tool notes; never narrate."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/dialectics",
  "title": "Dialectical Thinking",
  "subtitle": "Keep the parts that can both be true",
  "scope": "Bounded both-and and synthesis component; not the complete adolescent Walking the Middle Path module or a requirement to compromise.",
  "version": "2026-11-02-emotion-batch-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish two supported perspectives or needs from mutually incompatible factual claims and from false equivalence about harm.",
    "practiceObjective": "Identify a tension, check what is valid or uncertain in each part, then try a fuller account that preserves supported parts or names an unresolved question, and review what it leaves out.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.guilford.com/books/DBT-Skills-Training-Manual/Marsha-Linehan/9781462556359/contents",
      "reviewed": "2026-11-02",
      "supports": "Current 2025 revised edition and module scope confirmed from publisher.",
      "limits": "Public contents are not exact procedure text; no assertion of equivalence to unavailable revised teaching notes."
    },
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-02",
      "supports": "Interpersonal Effectiveness handouts 15–16c: multiple perspectives, balancing valid tensions, both-and thinking and synthesis; this is a bounded subset, not the full module.",
      "limits": "Original app language only. Restricted reproduction licence; no copied handouts or complete DBT/effectiveness claim."
    }
  ],
  "resourceId": "tool/dialectical-thinking",
  "routeProposal": "tool/dialectical-thinking",
  "componentId": "component/dialectics/both-and",
  "intro": {
    "id": "dialectics.intro",
    "title": "Make room without forcing agreement",
    "paragraphs": [
      "A situation can contain more than one valid need or perspective. Dialectical thinking looks for a fuller account instead of forcing an either-or choice.",
      "It does not mean every claim is true or that you must meet someone halfway. You can protect a boundary while recognising another part of the situation."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "dialectics.fit",
    "title": "Choose an ordinary tension",
    "paragraphs": [
      "Use this with your therapist between sessions. Choose a manageable situation or the fictional example.",
      "Do not use “both sides” to excuse abuse, discrimination or coercion, or to bargain away rights or safety. Understanding a context does not remove responsibility for harm.",
      "If two accounts contradict about the same fact, keep the conflict unresolved or seek relevant information. This page cannot decide whose account is true, and you do not need to contact another person."
    ]
  },
  "learn": {
    "id": "dialectics.learn",
    "title": "Why look for a fuller account?",
    "paragraphs": [
      "An either-or account can leave out a need, context or possibility. Looking for another valid part can make the account more accurate and open up choices, without requiring agreement.",
      "Describe each part, check what supports it, then consider how the parts relate. A useful synthesis preserves what is valid rather than averaging the positions or simply inserting the word “and.”",
      "Some tensions remain. “I don’t know how these fit yet” can be more honest than a neat answer. The aim is flexibility with accuracy, not positivity or forced compromise."
    ]
  },
  "example": {
    "id": "dialectics.example",
    "title": "Example — caring and needing rest",
    "paragraphs": [
      "Nia thinks, “If I care about my friend, I must accept every invitation.” Nia values the friendship and is tired after a demanding week. Those are two supported parts; neither proves the friend requires constant availability.",
      "Nia tries, “I care about my friend, and I need rest tonight.” On review Nia notices the original either-or rule is not a fact. Nia expands the account: “Caring does not mean always being available; I can decide about this invitation without deciding the whole friendship.”",
      "Nia still feels uneasy. The fuller account keeps both care and rest, without promising the friend’s reaction. Nia has not yet replied, and this practice does not require a message or compromise."
    ]
  },
  "practiceScenario": {
    "id": "dialectics.scenario",
    "title": "Optional fictional practice — Arun",
    "paragraphs": [
      "Arun is disappointed about a mistake in an ordinary personal project and is also glad to have learned a useful technique. Arun thinks, “Either it was a failure or I should feel pleased.”",
      "Try an account that keeps the disappointment and the learning without pretending the mistake did not matter. You can use your own manageable tension or just read."
    ]
  },
  "practice": [
    {
      "id": "dialectics.practice.parts",
      "title": "Name the tension",
      "paragraphs": [
        "What are the two parts or perspectives? They might be needs, feelings, observations or interpretations. Identify which kind each part is.",
        "Use your own situation or Arun’s example. You do not need to invent an opposing view just to have two sides."
      ],
      "fields": [
        {
          "key": "partA",
          "label": "One part",
          "optional": true
        },
        {
          "key": "partB",
          "label": "Another part, if there is one",
          "optional": true
        }
      ],
      "help": {
        "title": "If only one part is clear",
        "text": "Keep it. Ask what may be missing rather than making up another person’s motives."
      }
    },
    {
      "id": "dialectics.practice.support",
      "title": "Check what belongs in the account",
      "paragraphs": [
        "What supports each part? What is assumed or unknown? Both feelings can be present even when interpretations about the cause are uncertain.",
        "If two claims cannot both be factually true in the same way at the same time, do not join them as facts. Leave that disagreement open."
      ],
      "fields": [
        {
          "key": "support",
          "label": "What is supported, uncertain or conflicting",
          "optional": true
        }
      ],
      "help": {
        "title": "No false balance",
        "text": "“I was harmed” does not need an excuse for the harm as its opposite. You may acknowledge complexity while keeping a firm boundary."
      }
    },
    {
      "id": "dialectics.practice.synthesis",
      "title": "Try a fuller account",
      "paragraphs": [
        "Form a statement that keeps the valid parts and makes their relationship clearer. You might use “and,” “at the same time,” or “this part is still uncertain.”",
        "For Arun, disappointment about the mistake and appreciation of learning can coexist. Neither feeling has to cancel the other. Your own wording can differ."
      ],
      "fields": [
        {
          "key": "synthesis",
          "label": "A fuller account or unresolved question",
          "optional": true
        }
      ],
      "help": {
        "title": "If it is just two sentences joined together",
        "text": "Ask what the combined account changes about the either-or rule. It may reveal that two needs coexist, that a boundary remains, or that more information is needed—not necessarily a compromise."
      }
    },
    {
      "id": "dialectics.practice.review",
      "title": "Check what your account leaves out",
      "paragraphs": [
        "Does the account preserve what matters without inventing certainty or minimising harm? Would you keep it, change it or leave it unresolved?",
        "Notice whether it opens a choice or question. You do not have to act, contact anyone, feel differently or agree with another person."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I would keep, revise or leave open",
          "optional": true
        }
      ],
      "help": {
        "title": "If the tension remains",
        "text": "A more complete account does not always solve the problem. It is fine to finish with uncertainty or bring it to your therapist."
      }
    }
  ],
  "close": {
    "id": "dialectics.close",
    "title": "No forced resolution",
    "paragraphs": [
      "You can finish with a fuller statement, a question or the original tension. A boundary can remain firm. There is no required compromise or next task."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "New original Nia/Arun cases and short support/synthesis/review flow; no copying/import of retired Practice Room both-and-thinking source.",
    "No automated truth adjudication, mandatory compromise, contact or broad adolescent-module claim."
  ],
  "narrationSegments": [
    {
      "id": "dialectics.intro",
      "title": "Make room without forcing agreement",
      "text": "A situation can contain more than one valid need or perspective. Dialectical thinking looks for a fuller account instead of forcing an either-or choice.\n\nIt does not mean every claim is true or that you must meet someone halfway. You can protect a boundary while recognising another part of the situation.",
      "status": "Script only"
    },
    {
      "id": "dialectics.fit",
      "title": "Choose an ordinary tension",
      "text": "Use this with your therapist between sessions. Choose a manageable situation or the fictional example.\n\nDo not use “both sides” to excuse abuse, discrimination or coercion, or to bargain away rights or safety. Understanding a context does not remove responsibility for harm.\n\nIf two accounts contradict about the same fact, keep the conflict unresolved or seek relevant information. This page cannot decide whose account is true, and you do not need to contact another person.",
      "status": "Script only"
    },
    {
      "id": "dialectics.learn",
      "title": "Why look for a fuller account?",
      "text": "An either-or account can leave out a need, context or possibility. Looking for another valid part can make the account more accurate and open up choices, without requiring agreement.\n\nDescribe each part, check what supports it, then consider how the parts relate. A useful synthesis preserves what is valid rather than averaging the positions or simply inserting the word “and.”\n\nSome tensions remain. “I don’t know how these fit yet” can be more honest than a neat answer. The aim is flexibility with accuracy, not positivity or forced compromise.",
      "status": "Script only"
    },
    {
      "id": "dialectics.example",
      "title": "Example — caring and needing rest",
      "text": "Nia thinks, “If I care about my friend, I must accept every invitation.” Nia values the friendship and is tired after a demanding week. Those are two supported parts; neither proves the friend requires constant availability.\n\nNia tries, “I care about my friend, and I need rest tonight.” On review Nia notices the original either-or rule is not a fact. Nia expands the account: “Caring does not mean always being available; I can decide about this invitation without deciding the whole friendship.”\n\nNia still feels uneasy. The fuller account keeps both care and rest, without promising the friend’s reaction. Nia has not yet replied, and this practice does not require a message or compromise.",
      "status": "Script only"
    },
    {
      "id": "dialectics.scenario",
      "title": "Optional fictional practice — Arun",
      "text": "Arun is disappointed about a mistake in an ordinary personal project and is also glad to have learned a useful technique. Arun thinks, “Either it was a failure or I should feel pleased.”\n\nTry an account that keeps the disappointment and the learning without pretending the mistake did not matter. You can use your own manageable tension or just read.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.parts",
      "title": "Name the tension",
      "text": "What are the two parts or perspectives? They might be needs, feelings, observations or interpretations. Identify which kind each part is.\n\nUse your own situation or Arun’s example. You do not need to invent an opposing view just to have two sides.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.parts.help",
      "title": "If only one part is clear",
      "text": "Keep it. Ask what may be missing rather than making up another person’s motives.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.support",
      "title": "Check what belongs in the account",
      "text": "What supports each part? What is assumed or unknown? Both feelings can be present even when interpretations about the cause are uncertain.\n\nIf two claims cannot both be factually true in the same way at the same time, do not join them as facts. Leave that disagreement open.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.support.help",
      "title": "No false balance",
      "text": "“I was harmed” does not need an excuse for the harm as its opposite. You may acknowledge complexity while keeping a firm boundary.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.synthesis",
      "title": "Try a fuller account",
      "text": "Form a statement that keeps the valid parts and makes their relationship clearer. You might use “and,” “at the same time,” or “this part is still uncertain.”\n\nFor Arun, disappointment about the mistake and appreciation of learning can coexist. Neither feeling has to cancel the other. Your own wording can differ.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.synthesis.help",
      "title": "If it is just two sentences joined together",
      "text": "Ask what the combined account changes about the either-or rule. It may reveal that two needs coexist, that a boundary remains, or that more information is needed—not necessarily a compromise.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.review",
      "title": "Check what your account leaves out",
      "text": "Does the account preserve what matters without inventing certainty or minimising harm? Would you keep it, change it or leave it unresolved?\n\nNotice whether it opens a choice or question. You do not have to act, contact anyone, feel differently or agree with another person.",
      "status": "Script only"
    },
    {
      "id": "dialectics.practice.review.help",
      "title": "If the tension remains",
      "text": "A more complete account does not always solve the problem. It is fine to finish with uncertainty or bring it to your therapist.",
      "status": "Script only"
    },
    {
      "id": "dialectics.close",
      "title": "No forced resolution",
      "text": "You can finish with a fuller statement, a question or the original tension. A boundary can remain firm. There is no required compromise or next task.",
      "status": "Script only"
    },
    {
      "id": "dialectics.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    }
  ]
}
;
