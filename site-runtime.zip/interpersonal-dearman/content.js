window.InterpersonalContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass.",
    "All named method elements have an actual optional attempt, not only acronym definitions.",
    "Response selection reveals only that branch and asks for a next-turn attempt; changing branch stops old audio and warns that retained response notes may refer to the prior branch.",
    "Source example text, selected-note export, existing guide linkage and saved identities preserved or explicitly version-reconciled.",
    "No renderer may claim selected export works until the adapter, preview and user-selected download/copy are tested.",
    "No runtime claims from this script-only contract; content, integration, accessibility and listening approvals remain separate."
  ],
  "id": "classic/dear",
  "resourceId": "tool/dearman",
  "routeProposal": "tool/dearman",
  "title": "DEAR MAN",
  "subtitle": "Make a clear request or refusal",
  "version": "2026-11-03-interpersonal-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "The complete named DEAR MAN element set in an original guided rehearsal. Not the whole interpersonal effectiveness module, a safety assessment or comprehensive DBT.",
  "clinicalContract": {
    "learningObjective": "DEAR MAN helps you prepare a request or refusal and stay with its purpose as the conversation develops.",
    "practiceObjective": "Rehearse all seven elements as relevant to one request/refusal, then try a second turn that maintains the objective while respecting limits and safety.",
    "sourcePopulationContext": "Therapist-introduced practice with individual developmental, communication, consent, privacy, safeguarding and support review. No universal age gate or all-age validation claim. Historical and revised DBT sources do not validate this specific digital adaptation.",
    "observedPractice": "A privately spoken, imagined or optionally written attempt and a possible-response rehearsal. Reading, rehearsing and having a real conversation are distinct; no automatic completion inference."
  },
  "privacy": {
    "id": "dear.privacy",
    "title": "Writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay in this open tool while you use its practice, example and help.",
      "Leaving this tool, reloading, clearing or starting again removes the notes here. If you choose to keep notes, only the notes you explicitly select are included in the copy or download you request. That copy remains outside this tool until you remove it.",
      "Saving this tool keeps a shortcut, not your writing. Nothing is sent to your therapist or read aloud. This tool is not monitored."
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; free jump, Show all, Back and Finish remain available. Practice enters or resumes practice directly; no duplicated intro Start button.",
    "writing": "Hidden by default, optional; hide all private echoes and previews when hidden. No mandatory field or automatic analysis.",
    "modes": [
      "practice"
    ],
    "persistence": "In-memory active-tool session only. Internal help/example/back preserves choice and notes. Leave/reload/restart/clear removes notes and echoes. Selected-note copy/download only by explicit selection and separate user action; no backend, localStorage or diary.",
    "narration": "Script only; no asset assumed to match. Listen/Pause/Resume; Replay unavailable until actual playback of that exact current clip. No TTS, new provider, private-answer narration or approval claim.",
    "timer": "None",
    "visual": "Method letters and textual labels orient; no score, streak, mastery badge or success animation.",
    "fictionalPractice": "Explicit optional personal / retained fictional example choice, no default inference or personal input prefill. Neither choice is a completion gate. Changing context preserves existing notes but visibly warns they may refer to earlier context; clear only on explicit reset or leaving.",
    "responsePractice": "One explicitly selected authored possible reply is visible at a time. It is a possibility, not a prediction. Prompt a second-turn attempt, then optional revision. No AI interlocutor or automatic scoring. Unselected branches are not narrated.",
    "pendingSharedPatterns": "Candidate only: critique may redirect shell, focus, choice presentation and closure. Preserve clinical meaning and privacy invariants when adapting."
  },
  "intro": {
    "id": "dear.intro",
    "title": "DEAR MAN",
    "paragraphs": [
      "DEAR MAN helps you prepare a request or refusal and stay with its purpose as the conversation develops.",
      "Choose an ordinary conversation where it is reasonably safe to practise, or use the fictional example. You can rehearse silently, aloud or with optional notes. You do not have to contact anyone."
    ],
    "actions": []
  },
  "fit": {
    "id": "dear.fit",
    "title": "Check whether this fits",
    "paragraphs": [
      "Use this with your therapist’s guidance and a situation that is manageable for you. You can leave out personal details, use fiction, or stop.",
      "If someone may threaten, control, punish or harm you for speaking up, start with support and safety rather than a communication script. This tool cannot assess what is safe. You do not have to keep engaging with threats or abuse.",
      "A clear, respectful response does not control another person’s reaction. Lack of agreement does not mean you failed."
    ]
  },
  "practice": [
    {
      "id": "dear.practice.prepare",
      "title": "Choose the conversation and priority",
      "paragraphs": [
        "Use Rae’s extra-cover example or choose your own manageable situation. What matters most here: a specific request or refusal, the relationship, or how you act in relation to your values?",
        "These priorities may overlap or conflict. Choose a focus for this practice without treating the others as unimportant. You can switch to a related skill or finish."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "Situation, if I want to write",
          "optional": true
        },
        {
          "key": "priority",
          "label": "What matters most here",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot choose a priority",
        "text": "You can try the fictional example or discuss the situation with your therapist. This is not a score that decides how forceful to be."
      }
    },
    {
      "id": "dear.practice.describe",
      "title": "D: Describe",
      "paragraphs": [
        "Name the relevant observable facts briefly. Leave out guesses about what the other person intended."
      ],
      "fields": [
        {
          "key": "dm-d",
          "label": "Facts",
          "optional": true
        }
      ],
      "help": {
        "title": "If the description turns into blame",
        "text": "Try what happened, when relevant, instead of a label for the person. You do not have to prove every detail before making an ordinary request."
      }
    },
    {
      "id": "dear.practice.express",
      "title": "E: Express",
      "paragraphs": [
        "Say how the situation affects you or what you think about it, if useful. Speak from your perspective rather than telling the other person what they feel."
      ],
      "fields": [
        {
          "key": "dm-e",
          "label": "Feelings or perspective",
          "optional": true
        }
      ],
      "help": {
        "title": "If an emotion word is difficult",
        "text": "A plain statement such as “This is difficult for me to plan around” can express your experience. You do not need a particular feeling or an emotional disclosure."
      }
    },
    {
      "id": "dear.practice.assert",
      "title": "A: Assert",
      "paragraphs": [
        "Try one direct request or refusal. What exactly are you asking for, or saying no to? You can use a short sentence."
      ],
      "fields": [
        {
          "key": "dm-a",
          "label": "Request or refusal",
          "optional": true
        }
      ],
      "help": {
        "title": "If you keep hinting",
        "text": "Try making the request or refusal explicit once. Direct does not mean harsh, loud or certain of getting agreement."
      }
    },
    {
      "id": "dear.practice.reinforce",
      "title": "R: Reinforce",
      "paragraphs": [
        "Identify a real benefit of cooperation or acknowledge willingness to consider the request. Do not invent a reward, promise or consequence to obtain agreement."
      ],
      "fields": [
        {
          "key": "dm-r",
          "label": "Why this could help",
          "optional": true
        }
      ],
      "help": {
        "title": "If there is no benefit to offer",
        "text": "You can acknowledge consideration without adding a bargain. Do not threaten or make agreement the price of your care."
      }
    },
    {
      "id": "dear.practice.mindful",
      "title": "M: Stay Mindful",
      "paragraphs": [
        "Choose the point you want to return to if the conversation drifts. Rehearse saying it again without following every criticism into a new argument.",
        "Repetition is not a way to override someone’s refusal. You can accept a limit, pause or stop; you do not have to ignore threats."
      ],
      "fields": [
        {
          "key": "dm-m",
          "label": "The point I may return to",
          "optional": true
        }
      ],
      "help": {
        "title": "If I get pulled into a different argument",
        "text": "Pause and return to the specific request if safe and useful. If the exchange becomes harmful, stopping takes priority over staying on script."
      }
    },
    {
      "id": "dear.practice.confident",
      "title": "A: Appear confident",
      "paragraphs": [
        "Try saying or communicating the request clearly in a way that is comfortable for you. You can feel nervous while making a clear request.",
        "No particular eye contact, posture, fluent speech, volume or facial expression is required. Text or another accessible communication method may fit."
      ],
      "fields": [
        {
          "key": "dm-confidence",
          "label": "How I want to communicate, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If I do not feel confident",
        "text": "Try the words once without waiting for confidence. The aim here is a comprehensible request, not hiding a disability, anxiety or communication difference."
      }
    },
    {
      "id": "dear.practice.negotiate",
      "title": "N: Negotiate",
      "paragraphs": [
        "Consider what, if anything, you are willing to change. Practise offering an acceptable alternative or asking what might work.",
        "You can keep an important limit or accept that there is no agreement. Do not offer something you cannot or do not want to do."
      ],
      "fields": [
        {
          "key": "dm-n",
          "label": "Possible alternatives and limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing is negotiable",
        "text": "A clear refusal or accepting the other person’s no remains possible. You do not need to add a compromise merely to finish this step."
      }
    },
    {
      "id": "dear.practice.rehearse",
      "title": "Rehearse the opening",
      "paragraphs": [
        "Try your opening once, privately, aloud or in optional notes. You can try just the part you are working on rather than a polished speech.",
        "Then choose a possible response below if you want to rehearse the next turn. Another person may respond differently."
      ],
      "fields": [
        {
          "key": "opening",
          "label": "My opening attempt, if useful",
          "optional": true
        }
      ]
    },
    {
      "id": "dear.practice.respond",
      "title": "Practise a possible next turn",
      "paragraphs": [
        "Choose one possible response. Read it, then try what you might say or do next. A pause or ending the exchange can be a response.",
        "If no branch fits, you can imagine your own ordinary reply or leave this step. Nothing is selected for you."
      ],
      "fields": [
        {
          "key": "response",
          "label": "My possible next response, if useful",
          "optional": true
        }
      ]
    },
    {
      "id": "dear.practice.review",
      "title": "Review and, if useful, try again",
      "paragraphs": [
        "Did you make the request or refusal clear? In the next turn, did you return to the point, communicate accessibly and consider only options you could accept? These are reflection questions, not a score.",
        "Try one revised response if you want. You can also leave the practice here with uncertainty, discomfort or no change."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I noticed or might revise",
          "optional": true
        }
      ]
    }
  ],
  "close": {
    "id": "dear.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can finish after reading, rehearsing, revising or stopping. Agreement, confidence and a change in feeling are not required.",
      "You can return to any part, keep only notes you deliberately select, save a shortcut to the tool, or finish and clear the notes here."
    ],
    "actions": [
      "Back to practice",
      "Choose notes to keep",
      "Save this tool",
      "Finish and clear"
    ],
    "reflectionReview": {
      "legacyOptions": [
        "Helpful",
        "No change",
        "Unsure",
        "Uncomfortable",
        "Skip"
      ],
      "status": "Preserve as retained provenance, not automatically rendered. Usefulness-versus-outcome ambiguity needs independent/shared-pattern review. No rating required."
    }
  },
  "sources": [
    {
      "id": "linehan-handouts-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical interpersonal handouts 4–7 establish priorities and 7/4/4 named elements; not copied client worksheets.",
      "limits": "Not exact revised 2025 wording or evidence validating this app. Restricted reproduction license."
    },
    {
      "id": "linehan-worksheets-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Interpersonal worksheets 3–5 include priorities, mental/spoken rehearsal and reviewing use.",
      "limits": "Original app copy and examples only; no worksheet redistribution."
    },
    {
      "id": "linehan-revised-2025",
      "url": "https://www.guilford.com/books/DBT-Skills-Training-Handouts-and-Worksheets/Marsha-Linehan/9781462556342",
      "reviewed": "2026-11-03",
      "supports": "Current revised edition and inclusive-language update.",
      "limits": "Accessible sample does not contain the target handouts; exact revised target procedure not verified."
    },
    {
      "id": "rathus-miller",
      "url": "https://www.guilford.com/excerpts/rathus_ch1.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Developmentally informed adolescent DBT and differing support needs.",
      "limits": "No universal age threshold or all-age/app validation inference."
    }
  ],
  "learn": {
    "id": "dear.learn",
    "title": "The objective is a clear request or refusal",
    "paragraphs": [
      "DEAR helps organise what you say. MAN helps you stay with the purpose, communicate clearly and consider options as the conversation develops. You can use them together without reciting seven lines.",
      "GIVE focuses on the relationship; FAST focuses on fairness and self-respect. They can support this conversation, but they are not interchangeable with making the request or refusal.",
      "Negotiating is an option, not permission to wear someone down or a requirement to give up an important limit."
    ]
  },
  "example": {
    "id": "dear.example",
    "title": "Example: Rae is asked for extra cover",
    "paragraphs": [
      "Rae is asked to cover another Saturday after agreeing to Tuesday coverage. Rae says: “We agreed I’d cover Tuesday, and now you’re asking about Saturday. I’m stretched this week. I can’t take Saturday; can we check other cover? Knowing early will help us plan.”",
      "Rae can stay focused on the request, speak clearly while nervous, and consider an alternative they are actually willing to offer. If the answer is no, the skill has not failed; Rae can ask what is possible, keep the limit or end the discussion."
    ]
  },
  "practiceScenario": {
    "id": "dear.scenario",
    "title": "Practise with Rae",
    "paragraphs": [
      "Use Rae’s ordinary extra-cover conversation if that context feels suitable. Treat it as a fictional rehearsal, not advice to confront someone who could retaliate.",
      "Rae has already agreed to Tuesday and is declining Saturday. Try the next turn in your own words; do not add availability or promises Rae has not offered."
    ]
  },
  "choices": [
    {
      "id": "request-kind",
      "label": "What are you practising?",
      "options": [
        {
          "id": "request",
          "label": "A request",
          "text": "Say the specific change or action you are asking for."
        },
        {
          "id": "refusal",
          "label": "A refusal",
          "text": "Say clearly what you are declining. You can acknowledge the request without agreeing to it."
        }
      ],
      "default": null,
      "placement": "dear.practice.assert",
      "stateWarning": "Your earlier notes may refer to a different request or refusal. They have not been changed."
    }
  ],
  "responses": [
    {
      "id": "agree",
      "label": "They agree",
      "reply": {
        "id": "dear.response.agree.reply",
        "title": "One possible reply",
        "paragraphs": [
          "“Yes, that works.”"
        ]
      },
      "practice": {
        "id": "dear.response.agree.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Rehearse checking what was agreed, without adding an extra promise.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Rae: “Thanks. I’m still covering Tuesday, and Saturday needs other cover.”"
        }
      }
    },
    {
      "id": "limit",
      "label": "They say no or offer a limit",
      "reply": {
        "id": "dear.response.limit.reply",
        "title": "One possible reply",
        "paragraphs": [
          "“We do not have other cover yet.”"
        ]
      },
      "practice": {
        "id": "dear.response.limit.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try acknowledging that fact and keeping the limit, or asking about an option you are genuinely willing to consider.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Rae: “I understand there’s a gap. I still can’t take Saturday. Can we check another option?”"
        }
      }
    },
    {
      "id": "redirect",
      "label": "They change the topic",
      "reply": {
        "id": "dear.response.redirect.reply",
        "title": "One possible reply",
        "paragraphs": [
          "“You never help enough.”"
        ]
      },
      "practice": {
        "id": "dear.response.redirect.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try returning to the specific request or refusal rather than defending your whole history. You can pause or stop the exchange.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Rae: “I am covering Tuesday. I can’t take Saturday.” If there are threats or abuse, do not keep repeating the script; prioritise support and safety."
        }
      }
    }
  ],
  "methodElements": [
    "Describe",
    "Express",
    "Assert",
    "Reinforce",
    "Mindful",
    "Appear confident",
    "Negotiate"
  ],
  "legacyCompatibility": {
    "savedIdentity": {
      "passage": "interpersonal",
      "card": "card-interpersonal-dearman-ask-for-what-you-need-or-say-no"
    },
    "guide": {
      "status": "Retain route association; exact current PDF compatibility must be checked or explicitly versioned before replacement."
    },
    "selectedExport": "Preserve NativeRefinements.selectedExport behavior through an explicit adapter: no default-selected private content, preview exact selected notes, separate copy/download action, include built draft only if explicitly selected. Hide every private echo when writing hides. No automatic export on Finish.",
    "preview": "Legacy note-preview behavior must remain available or be explicitly reconciled, not silently replaced by a generic assembled conversation. New method/rehearsal notes can be individually selected without changing original field meaning.",
    "records": "Preserve original narration entries and text/asset hashes as provenance; no new text may inherit an old recording merely because route or title matches.",
    "previewDetails": "Join only entered dm-d/dm-e/dm-a/dm-r in source order. Optional dm-add-closing defaults false and appends the existing negotiated closing only when explicitly selected. New MAN fields are separate notes, not automatically inserted into the speech."
  },
  "productAdaptations": [
    "Original guided prompts and second-turn rehearsals deepen existing named practice, not official numbered worksheet steps.",
    "Retained Rae/Kit/Ali example paragraphs preserved exactly from retained written examples; extra fictional replies explicitly authored candidates.",
    "No universal age gate, mandatory gaze/humour/speech fluency, coerced negotiation, guaranteed agreement or automatic clinical fit.",
    "Seven/four/four elements remain visible and practicable; no field is required; all prompts can be jumped to or left."
  ],
  "implementationGates": {
    "capabilityClaims": "Do not render or narrate privacy/close claims until verified session retention/clearing, shortcut save, explicit selected-note preview/copy/download, and accurate external-copy warning work in the actual candidate renderer. Otherwise keep the contract unimplemented; do not silently omit actions or promise unsupported behavior.",
    "gatedSectionIds": [
      "dear.privacy",
      "dear.close"
    ],
    "testsRequired": [
      "Internal example/help/back retains notes and choices",
      "Leave/reload/restart/clear erases notes and every echo",
      "Save shortcut preserves correct legacy identity and saves no notes",
      "No selected export by default; exact explicit selection and preview before copy/download",
      "Hiding writing hides selected previews and all private echoes"
    ]
  },
  "narrationSegments": [
    {
      "id": "dear.privacy",
      "title": "Writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay in this open tool while you use its practice, example and help.\n\nLeaving this tool, reloading, clearing or starting again removes the notes here. If you choose to keep notes, only the notes you explicitly select are included in the copy or download you request. That copy remains outside this tool until you remove it.\n\nSaving this tool keeps a shortcut, not your writing. Nothing is sent to your therapist or read aloud. This tool is not monitored.",
      "textSha256": "16d3bdc898d6fedb141c993bad0bb7cf436026c064bd1822ff0aabab7f149047",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "capabilityGate": "Do not bind or make this script available until implementationGates capability tests pass in the actual renderer.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.intro",
      "title": "DEAR MAN",
      "text": "DEAR MAN helps you prepare a request or refusal and stay with its purpose as the conversation develops.\n\nChoose an ordinary conversation where it is reasonably safe to practise, or use the fictional example. You can rehearse silently, aloud or with optional notes. You do not have to contact anyone.",
      "textSha256": "f2561d89db38b23169fbc8fbed083ef11ea5e54f28bd626620ac73dc8fd659f7",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.fit",
      "title": "Check whether this fits",
      "text": "Use this with your therapist’s guidance and a situation that is manageable for you. You can leave out personal details, use fiction, or stop.\n\nIf someone may threaten, control, punish or harm you for speaking up, start with support and safety rather than a communication script. This tool cannot assess what is safe. You do not have to keep engaging with threats or abuse.\n\nA clear, respectful response does not control another person’s reaction. Lack of agreement does not mean you failed.",
      "textSha256": "6cbf0a98205bf1dddc8f916022fb17924642c763c5445cafc9ac1407708de583",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.learn",
      "title": "The objective is a clear request or refusal",
      "text": "DEAR helps organise what you say. MAN helps you stay with the purpose, communicate clearly and consider options as the conversation develops. You can use them together without reciting seven lines.\n\nGIVE focuses on the relationship; FAST focuses on fairness and self-respect. They can support this conversation, but they are not interchangeable with making the request or refusal.\n\nNegotiating is an option, not permission to wear someone down or a requirement to give up an important limit.",
      "textSha256": "1f1146d5b721dbcb7fbfe1765ed722e5a192fa1be21148c11a1574b6c4d5a44c",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.example",
      "title": "Example: Rae is asked for extra cover",
      "text": "Rae is asked to cover another Saturday after agreeing to Tuesday coverage. Rae says: “We agreed I’d cover Tuesday, and now you’re asking about Saturday. I’m stretched this week. I can’t take Saturday; can we check other cover? Knowing early will help us plan.”\n\nRae can stay focused on the request, speak clearly while nervous, and consider an alternative they are actually willing to offer. If the answer is no, the skill has not failed; Rae can ask what is possible, keep the limit or end the discussion.",
      "textSha256": "a8f3abaff8564d93b143e4979892118df7c655d4e146aab742f0713fdbe14533",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": [
        "full-dearman-example"
      ]
    },
    {
      "id": "dear.scenario",
      "title": "Practise with Rae",
      "text": "Use Rae’s ordinary extra-cover conversation if that context feels suitable. Treat it as a fictional rehearsal, not advice to confront someone who could retaliate.\n\nRae has already agreed to Tuesday and is declining Saturday. Try the next turn in your own words; do not add availability or promises Rae has not offered.",
      "textSha256": "dc71bdcc02421ace5677e37fd1418b3c534dbac6c81e14d3a06a0cbd9a9a8199",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.prepare",
      "title": "Choose the conversation and priority",
      "text": "Use Rae’s extra-cover example or choose your own manageable situation. What matters most here: a specific request or refusal, the relationship, or how you act in relation to your values?\n\nThese priorities may overlap or conflict. Choose a focus for this practice without treating the others as unimportant. You can switch to a related skill or finish.",
      "textSha256": "80720e3e5bdfd981542af3fb056db46ea77bc4af9dcbf353f606b95f667d4045",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.prepare.help",
      "title": "If I cannot choose a priority",
      "text": "You can try the fictional example or discuss the situation with your therapist. This is not a score that decides how forceful to be.",
      "textSha256": "f9eff6512039008a0485ff1d5397bd6a36b38ee3d5a5033f12001c35a0f7e104",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.describe",
      "title": "D: Describe",
      "text": "Name the relevant observable facts briefly. Leave out guesses about what the other person intended.",
      "textSha256": "bb030c2867aa4d519532a5cb47a7a0b7fbba2a544eea152e539d0e202b08e624",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.describe.help",
      "title": "If the description turns into blame",
      "text": "Try what happened, when relevant, instead of a label for the person. You do not have to prove every detail before making an ordinary request.",
      "textSha256": "02a61a9e433971e2a72da6946080fc95ae7e53866aed6f28851ef3876e60b339",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.express",
      "title": "E: Express",
      "text": "Say how the situation affects you or what you think about it, if useful. Speak from your perspective rather than telling the other person what they feel.",
      "textSha256": "e7b8439e9714373c95cd92b397ad6cc4ada5178900be321f1827ca7763b243b1",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.express.help",
      "title": "If an emotion word is difficult",
      "text": "A plain statement such as “This is difficult for me to plan around” can express your experience. You do not need a particular feeling or an emotional disclosure.",
      "textSha256": "d7e00f1bb2079c8b61b3f29c3cc85992ea33a6a97da11ac41bedf6338d73f164",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.assert",
      "title": "A: Assert",
      "text": "Try one direct request or refusal. What exactly are you asking for, or saying no to? You can use a short sentence.",
      "textSha256": "7e8f0882e28d612011c942801fbbc08c19bee4e3fee0e3a3ea8f6d673726ecd2",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.assert.help",
      "title": "If you keep hinting",
      "text": "Try making the request or refusal explicit once. Direct does not mean harsh, loud or certain of getting agreement.",
      "textSha256": "93b6a240dd1f75d55164c3180f0f45323c894a2bd457849991e86246815115f7",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.reinforce",
      "title": "R: Reinforce",
      "text": "Identify a real benefit of cooperation or acknowledge willingness to consider the request. Do not invent a reward, promise or consequence to obtain agreement.",
      "textSha256": "8c10e18fdc1b8aa4dac65888af6bb3c8a0823d3e0480c3e9c61081a415d4a40a",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.reinforce.help",
      "title": "If there is no benefit to offer",
      "text": "You can acknowledge consideration without adding a bargain. Do not threaten or make agreement the price of your care.",
      "textSha256": "5bc33d63c8702564b6d7332484e0ce9c6cc4427c65998ebce808339a493644e4",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.mindful",
      "title": "M: Stay Mindful",
      "text": "Choose the point you want to return to if the conversation drifts. Rehearse saying it again without following every criticism into a new argument.\n\nRepetition is not a way to override someone’s refusal. You can accept a limit, pause or stop; you do not have to ignore threats.",
      "textSha256": "c0c92b49c7988c909df282583fb48ec0b7caa01dd0d9f40100e3ad7b137169f9",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.mindful.help",
      "title": "If I get pulled into a different argument",
      "text": "Pause and return to the specific request if safe and useful. If the exchange becomes harmful, stopping takes priority over staying on script.",
      "textSha256": "4fd45813462677d24086e36bf988522539ebfa5002978c8e98c8e885d9c4c10c",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.confident",
      "title": "A: Appear confident",
      "text": "Try saying or communicating the request clearly in a way that is comfortable for you. You can feel nervous while making a clear request.\n\nNo particular eye contact, posture, fluent speech, volume or facial expression is required. Text or another accessible communication method may fit.",
      "textSha256": "10aa16168570561ac4502453ac7f69ab0afed7f3f7b0edc20bbafc19ebfcdeba",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.confident.help",
      "title": "If I do not feel confident",
      "text": "Try the words once without waiting for confidence. The aim here is a comprehensible request, not hiding a disability, anxiety or communication difference.",
      "textSha256": "e203dea4b86a693ee0d212a456bf2c795dbe482686d3590e44c47b9dc76b7594",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.negotiate",
      "title": "N: Negotiate",
      "text": "Consider what, if anything, you are willing to change. Practise offering an acceptable alternative or asking what might work.\n\nYou can keep an important limit or accept that there is no agreement. Do not offer something you cannot or do not want to do.",
      "textSha256": "c2f6c5d57a2ceb104a1673394277439424594bb355c94fe064f964dbc3c5de47",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.negotiate.help",
      "title": "If nothing is negotiable",
      "text": "A clear refusal or accepting the other person’s no remains possible. You do not need to add a compromise merely to finish this step.",
      "textSha256": "901a29c30e1dd868f14d449f7c94a9dc53431141fe05f198eef49943af44ac8d",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.rehearse",
      "title": "Rehearse the opening",
      "text": "Try your opening once, privately, aloud or in optional notes. You can try just the part you are working on rather than a polished speech.\n\nThen choose a possible response below if you want to rehearse the next turn. Another person may respond differently.",
      "textSha256": "5f2a3eca8f75a47a3e9d287b7fbf5f4879c1109a96c73c0892fb658e255f8a01",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.respond",
      "title": "Practise a possible next turn",
      "text": "Choose one possible response. Read it, then try what you might say or do next. A pause or ending the exchange can be a response.\n\nIf no branch fits, you can imagine your own ordinary reply or leave this step. Nothing is selected for you.",
      "textSha256": "c949599d21f2c903ce6aebf4579eef7e1497a0f4c802ea0c5e40f7d7e1eaae1d",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.practice.review",
      "title": "Review and, if useful, try again",
      "text": "Did you make the request or refusal clear? In the next turn, did you return to the point, communicate accessibly and consider only options you could accept? These are reflection questions, not a score.\n\nTry one revised response if you want. You can also leave the practice here with uncertainty, discomfort or no change.",
      "textSha256": "6e11930daabd443f7881d57d53dce5de3eb6a8c6c36e4ff9deccbf18728c8075",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.agree.reply",
      "title": "One possible reply",
      "text": "“Yes, that works.”",
      "textSha256": "966feb3ef6b2762155de7a03c76491960185a9a1d24ab926f274a821c96b3c1b",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.agree.practice",
      "title": "Try your next response",
      "text": "Rehearse checking what was agreed, without adding an extra promise.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "6404207843e8ce747d64c76b2bd7d67465c31bf88a9ce8d78e1f40efadfa2619",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.agree.practice.help",
      "title": "If you want a starting point",
      "text": "For Rae: “Thanks. I’m still covering Tuesday, and Saturday needs other cover.”",
      "textSha256": "8b78e4760eae6bf50f99091d10b832919f4b8d46d9bf9e0ed053f11cc9370cc5",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.limit.reply",
      "title": "One possible reply",
      "text": "“We do not have other cover yet.”",
      "textSha256": "e4867b0e8df28ca6444cce47eda25abaa139eeea06f96fcb41f1c0acd669b7e9",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.limit.practice",
      "title": "Try your next response",
      "text": "Try acknowledging that fact and keeping the limit, or asking about an option you are genuinely willing to consider.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "2bbb5fd9a5d148ae0f99a927d014bbc3375afaec473007c7a1ed133a633a8c45",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.limit.practice.help",
      "title": "If you want a starting point",
      "text": "For Rae: “I understand there’s a gap. I still can’t take Saturday. Can we check another option?”",
      "textSha256": "0be24d269c035137fba2aad5ba2b8f166ef78c02b761cd62217367e56a2b8f62",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.redirect.reply",
      "title": "One possible reply",
      "text": "“You never help enough.”",
      "textSha256": "764c3b5acdadbf4d3927f80fa61f763e65086813c9b1b84a9e3361e02dba87b5",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.redirect.practice",
      "title": "Try your next response",
      "text": "Try returning to the specific request or refusal rather than defending your whole history. You can pause or stop the exchange.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "145a1939043b6460777dfbe921992c0c46f3af5beb50bbb8256cc994d27812d9",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.response.redirect.practice.help",
      "title": "If you want a starting point",
      "text": "For Rae: “I am covering Tuesday. I can’t take Saturday.” If there are threats or abuse, do not keep repeating the script; prioritise support and safety.",
      "textSha256": "7d0c48162b6b9d3cf2fcf9edf38e32a4830a65565a7f3263302c35ff3f929615",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "dear.close",
      "title": "Leave the practice here",
      "text": "You can finish after reading, rehearsing, revising or stopping. Agreement, confidence and a change in feeling are not required.\n\nYou can return to any part, keep only notes you deliberately select, save a shortcut to the tool, or finish and clear the notes here.",
      "textSha256": "98842bb1caa1cd4c7f24055cbd5db61e5c4e89be997ac002d557721caab6ffd3",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "capabilityGate": "Do not bind or make this script available until implementationGates capability tests pass in the actual renderer.",
      "legacyExactMatchIds": []
    }
  ]
};
