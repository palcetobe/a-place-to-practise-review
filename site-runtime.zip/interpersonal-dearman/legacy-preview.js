window.InterpersonalLegacy = {
  "closing": "I want to find something that works for both of us — can we talk about this?",
  "preview": []
};
