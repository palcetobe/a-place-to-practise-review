window.InterpersonalPilotContent = {
  "schema": "a-place-to-practise.optional-fictional-pilot.v1",
  "id": "pilot/dear-recovery",
  "canonicalId": "classic/dear",
  "resourceId": "tool/dearman",
  "title": "Keep Rae’s refusal in view",
  "version": "2026-11-03-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "integration": {
    "anchorIds": [
      "dear.practice.mindful",
      "dear.practice.respond"
    ],
    "placement": "One optional teaching exercise opened from a quiet text action beside the stated prompt or contextual help. Not a new required step, top-level mode, route, tool or catalogue entry.",
    "preserve": "All existing 7/4/4 prompts, original examples, three adjacent Practice this skill / See an example / Learn more actions, note preview/export/guide behavior, saved IDs and safety/support remain unchanged.",
    "entry": "No automatic opening. Keep the precise originating prompt, active context, response choice, scroll/focus and notes; opening this fiction exercise does not select fictional context in the underlying personal practice.",
    "exit": "Close/Back returns to the precise originating prompt and state. Finish/support/leave obey existing tool-wide clear policy. No required choices or completion event.",
    "state": "Only authored fictional selection state inside this optional exercise; no persistence or analytics. Switching unrelated pilot scenarios resets their local edits, never personal practice notes. Closing resets local pilot selections and stops its audio; the main practice is untouched.",
    "privacy": "Do not read, import, infer, copy into, overwrite, score or narrate any private field. This fictional-only pilot has no personal writing input, microphone, recording, timer or automatic export.",
    "narration": "Exact static visible section only, explicit Listen/Pause/Resume; Replay unavailable until that exact clip actually plays. Stop before any panel/choice/scenario/phrase/action change, close, navigation or focus return. No autoplay, composite-script speech, hidden-branch audio, TTS or new provider.",
    "support": "Existing support/finish remain reachable. No safety questionnaire, safety determination or instruction to test a boundary with another person.",
    "entryLabel": "Explore a fictional change of topic",
    "responseAnchor": "Beside redirect branch help when that branch is selected, or the Mindful prompt; do not require selecting redirect to access it from Mindful."
  },
  "sources": [
    {
      "id": "linehan-handouts-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical interpersonal handouts 4–7 provide the distinctions between objective, relationship and self-respect skills; this is original fictional teaching, not a reproduced worksheet.",
      "limits": "Not exact 2025 wording, digital efficacy evidence or permission to redistribute publisher materials."
    },
    {
      "id": "linehan-worksheets-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Interpersonal worksheet 4 supports mental/spoken rehearsal.",
      "limits": "Does not test the proposed interaction or establish its superiority."
    }
  ],
  "acceptance": [
    "No required click, rating, score, streak, mastery badge, good/bad response label or controlled-outcome claim.",
    "Every fictional choice and stopping option is reachable without personal input or audio.",
    "Fictional exercise does not change current practice context, notes, selected response or export selections.",
    "No snippet or action can invent a private interpretation, obligation or promise.",
    "All new audio remains unavailable until exact approved assets and integration/listening checks; existing recordings are not reassigned.",
    "Targeted source/content review required before any freeze; separate model, DOM, browser, accessibility, privacy and audio review for implementation."
  ],
  "learningObjective": "Notice when a response shifts discussion away from the immediate refusal, and rehearse returning or pausing without treating repetition as a way to compel agreement.",
  "intro": {
    "id": "pilot.dear.intro",
    "title": "A fictional change of topic",
    "paragraphs": [
      "Rae agreed to cover Tuesday and is declining Saturday. This short example explores what Rae might say when the other person changes the topic.",
      "You can look at any response, rehearse one privately, or return to the practice. This is a demonstration, not a prediction of what someone will do."
    ]
  },
  "pin": {
    "id": "pilot.dear.pin",
    "title": "Rae’s refusal",
    "paragraphs": [
      "I can’t take Saturday; can we check other cover?"
    ]
  },
  "pushback": {
    "id": "pilot.dear.pushback",
    "title": "One possible reply",
    "paragraphs": [
      "“You never help enough.”"
    ]
  },
  "moves": [
    {
      "id": "return",
      "label": "Return to Saturday",
      "line": {
        "id": "pilot.dear.return.line",
        "title": "A possible response",
        "paragraphs": [
          "“I’m covering Tuesday. I can’t take Saturday; can we check other cover?”"
        ]
      },
      "notice": {
        "id": "pilot.dear.return.notice",
        "title": "What this response does",
        "paragraphs": [
          "Rae restates the existing commitment and brings the discussion back to Saturday. The other person may still disagree or continue the criticism.",
          "Keeping the point clear does not require repeating it indefinitely, raising your voice or obtaining agreement."
        ]
      }
    },
    {
      "id": "follow",
      "label": "Respond to the criticism",
      "line": {
        "id": "pilot.dear.follow.line",
        "title": "A possible response",
        "paragraphs": [
          "“I’m covering Tuesday. Why do you say I never help enough?”"
        ]
      },
      "notice": {
        "id": "pilot.dear.follow.notice",
        "title": "What this response does",
        "paragraphs": [
          "Rae is now asking about the wider criticism. That may be worth discussing, but the conversation has moved away from arranging Saturday cover.",
          "You can explore returning to the immediate refusal, pause, or leave this example. A change of topic is not automatically a mistake."
        ]
      }
    },
    {
      "id": "pause",
      "label": "Pause the exchange",
      "line": {
        "id": "pilot.dear.pause.line",
        "title": "A possible response",
        "paragraphs": [
          "“I’m going to pause this conversation.”"
        ]
      },
      "notice": {
        "id": "pilot.dear.pause.notice",
        "title": "What this response does",
        "paragraphs": [
          "Rae pauses without promising another conversation or agreeing to Saturday. The practical issue may remain unresolved.",
          "Pausing is an available practice option, not another letter in DEAR MAN. If there are threats or retaliation concerns, support and safety take priority over completing a script."
        ]
      }
    }
  ],
  "recovery": {
    "id": "pilot.dear.recovery",
    "title": "Try returning, if you want",
    "paragraphs": [
      "After responding to the criticism, Rae could say: “I want to come back to Saturday. I can’t take that shift.”",
      "Think or say this response once, or try your own wording privately. You can choose to pause instead; you do not have to keep practising until the other person accepts the refusal."
    ]
  },
  "recoveryBehavior": {
    "placement": "Optional action after follow notice; also accessible by the exercise outline. Never presented as a corrective punishment or automatic next screen.",
    "label": "Explore returning to Saturday",
    "effect": "Show only the authored recovery section; no additional counterparty message generated. Keep the fictional pin visible.",
    "alternatives": [
      "Explore pausing",
      "Back to practice"
    ]
  },
  "behavior": {
    "initial": "Show intro, labelled fictional pin, single authored pushback and three unselected move controls. No line/notice until chosen.",
    "selection": "Display only selected line/notice, not a transcript accumulating different alternative replies as if they all happened. Pin remains visible and static.",
    "rehearsal": "Optional recovery or any selected line can be tried mentally or off-device. No Done requirement, voice analysis, play-through count or outcome.",
    "privatePin": "Explicitly out of scope. Do not pin, shorten, classify or read any personal assertion, including dm-a/dm-m.",
    "exactSourceReuse": "Pin/pushback are short exact retained excerpts, but are new narration scopes; no old full-example recording may play over them."
  },
  "close": {
    "id": "pilot.dear.close",
    "title": "Return when you are ready",
    "paragraphs": [
      "You can return to the practice with a response in mind or leave the choice open. Nothing needs to be agreed or resolved here."
    ]
  },
  "narrationSegments": [
    {
      "id": "pilot.dear.intro",
      "title": "A fictional change of topic",
      "text": "Rae agreed to cover Tuesday and is declining Saturday. This short example explores what Rae might say when the other person changes the topic.\n\nYou can look at any response, rehearse one privately, or return to the practice. This is a demonstration, not a prediction of what someone will do.",
      "textSha256": "a33697206c678f41daf393b940bff2e0f18e95fb2357906cbd7c57c0a4a34e8d",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.pin",
      "title": "Rae’s refusal",
      "text": "I can’t take Saturday; can we check other cover?",
      "textSha256": "ce6791d272bbf7121cebc0392ca1bc277f956579b97a08122780875b0315697e",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.pushback",
      "title": "One possible reply",
      "text": "“You never help enough.”",
      "textSha256": "764c3b5acdadbf4d3927f80fa61f763e65086813c9b1b84a9e3361e02dba87b5",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.return.line",
      "title": "A possible response",
      "text": "“I’m covering Tuesday. I can’t take Saturday; can we check other cover?”",
      "textSha256": "0c0ed87ca8f7a8ac0479b66ae13a8fcd045907a37d210438acf8fbc8c20ade29",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.return.notice",
      "title": "What this response does",
      "text": "Rae restates the existing commitment and brings the discussion back to Saturday. The other person may still disagree or continue the criticism.\n\nKeeping the point clear does not require repeating it indefinitely, raising your voice or obtaining agreement.",
      "textSha256": "dcfa53c5a47e59a614430a0e6ffde1b50f7806d1c1e95615d576907578625939",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.follow.line",
      "title": "A possible response",
      "text": "“I’m covering Tuesday. Why do you say I never help enough?”",
      "textSha256": "05085761253350706f17232f0ccd44f396ff995ace786554882b1e71b09932cc",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.follow.notice",
      "title": "What this response does",
      "text": "Rae is now asking about the wider criticism. That may be worth discussing, but the conversation has moved away from arranging Saturday cover.\n\nYou can explore returning to the immediate refusal, pause, or leave this example. A change of topic is not automatically a mistake.",
      "textSha256": "7390b6369a9f2e76b15f5f5334142ce699b8ce334ffdc55af6a06eae56c2fe1a",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.pause.line",
      "title": "A possible response",
      "text": "“I’m going to pause this conversation.”",
      "textSha256": "8e91ae05d6d395a6f9dfaa024e334930b74c768be312fc4e5973fd3574f3175a",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.pause.notice",
      "title": "What this response does",
      "text": "Rae pauses without promising another conversation or agreeing to Saturday. The practical issue may remain unresolved.\n\nPausing is an available practice option, not another letter in DEAR MAN. If there are threats or retaliation concerns, support and safety take priority over completing a script.",
      "textSha256": "63728d71a84e7707c4e0dc47893d8bf64428e0838d0b20137d8bcb94cc87a9da",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.recovery",
      "title": "Try returning, if you want",
      "text": "After responding to the criticism, Rae could say: “I want to come back to Saturday. I can’t take that shift.”\n\nThink or say this response once, or try your own wording privately. You can choose to pause instead; you do not have to keep practising until the other person accepts the refusal.",
      "textSha256": "55c663d6fa3a2a582215ae7944e2765fa513f5c3aaa5aab330b9dce78f57e5b6",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.dear.close",
      "title": "Return when you are ready",
      "text": "You can return to the practice with a response in mind or leave the choice open. Nothing needs to be agreed or resolved here.",
      "textSha256": "a9ac3af8b5b16bb12827d58f2426cdfa5243a4855ae1a740a360c65367d5ad9b",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    }
  ]
};
