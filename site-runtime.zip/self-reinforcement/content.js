window.SelfReinforcementContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/changing-behaviour",
  "componentId": "component/changing-behaviour/reinforcement",
  "resourceId": "tool/self-reinforcement",
  "routeProposal": "/self-reinforcement/",
  "title": "Positive Reinforcement for Your Own Routine",
  "version": "2026-11-05-public-review-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. No recordings are provided for this practice; scripts are prepared and listening approval is not asserted.",
  "scope": "Therapist-introduced positive self-reinforcement for one freely chosen ordinary action: define it, arrange a safe wanted extra immediately afterward, actually use that action-consequence link, and review later occurrence at comparable opportunities without inferring causation or personal worth.",
  "groupedSetStatus": "Complete bounded initial positive self-use application within existing component/changing-behaviour/reinforcement. The broader Reinforcement component and classic/changing-behaviour remain incomplete. Negative reinforcement, shaping, intermittent schedules, extinction, punishment and changing another person are not implemented. No new canonical count.",
  "componentComplete": false,
  "implementedSubset": "initial-positive-self-use",
  "clinicalContract": {
    "learningObjective": "Distinguish a planned reward from a demonstrated reinforcer: a consequence is reinforcing only when it increases later occurrence of the action. Distinguish this contingent process from scheduling a pleasant activity, task grading or mastery.",
    "practiceObjective": "Choose a routine action within current ability, define a suitable opportunity and observable occurrence, note available starting information, select a safe personally wanted extra, arrange prompt contingent delivery, actually use the pair, and review future comparable opportunities, fit and uncertainty before keeping, changing or stopping the plan.",
    "sourcePopulationContext": "2015 author/publisher DBT Interpersonal Handouts20/22, Worksheet14 self-use branch and ManualXVII inform this bounded adaptation. Therapist introduction and individual choice/fit are required. No age floor or all-age efficacy claim; developmental, communication, cultural, safeguarding, clinical and access fit remain necessary.",
    "exclusions": [
      "No control of another person, parent/partner behavior programme, coercion, imposed compliance or removal of consent",
      "No punishment, deprivation, response cost, removal of previously available rights, essential care or ordinary support",
      "No negative reinforcement application, shaping progression, extinction, satiation, token economy or intermittent reward schedule",
      "No medical, eating, exercise, sleep, substance-use, self-harm, trauma/exposure or compulsive-checking targets",
      "No automatic rewards, purchases, monitoring, streaks, scores, quotas or verification of behavior",
      "No guarantee of changed behavior, increased motivation, better mood or causal proof from a brief informal observation"
    ],
    "adaptations": [
      "Original low-stakes positive self-use subset of the source self/other branches, with clear broader component incompleteness",
      "Essential care, communication, safety, needed rest and ordinary support are never conditional; source deprivation and other-person applications excluded",
      "One action already within ability rather than teaching or escalating successive approximations; shaping remains a separate unimplemented component",
      "Initial action-consequence link reviewed across suitable comparable opportunities; no fixed schedule, variable reward system or automatic thinning",
      "Optional private record and explicit missing/uncertain information; no copied worksheet, compulsory score or assumption that a pleasant consequence reinforced behavior"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of narrow positive self-use scope, exclusions, source adaptation and release rights",
      "Individual chosen goal, present ability, consent, developmental/communication/cultural/safeguarding/access and clinical fit",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration production and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose planning or review",
      "options": [
        {
          "value": "prepare",
          "label": "Plan a positive self-reinforcement practice",
          "startSectionId": "self-reinforcement.practice.situation"
        },
        {
          "value": "review",
          "label": "Review what actually happened",
          "startSectionId": "self-reinforcement.practice.result"
        }
      ]
    },
    "entryGate": "Scope, free choice and safety boundaries visible before entry. No default mode, action, consequence or fit inferred.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing, sequence, reward, attempt or successful result.",
    "reviewAccess": "Direct blank review begins with the actual action and consequence, then later occurrence and revision. No prior plan, paired delivery or reinforcement effect inferred.",
    "writing": "Optional and hidden initially; hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording or autoplay.",
    "timer": "None. No required duration, frequency, reward amount, score, quota or streak.",
    "completion": "No inferred action, delivered consequence, reinforcement effect, improved mood, full component completion or clinical suitability."
  },
  "intro": {
    "id": "self-reinforcement.intro",
    "title": "Try a wanted extra after one chosen action",
    "paragraphs": [
      "What happens after an action can affect how often we do it again. Here, you choose one ordinary action and plan a small, wanted extra right after it. Later, you check what actually happened and whether the action became more common.",
      "The extra is only a possible reinforcer at first. Enjoying it once does not show that it helped the action happen again. No change, fewer chances to try or unclear information are all possible results.",
      "Use this after your therapist has introduced it and checked the fit. You can plan, use the made-up example, review an earlier attempt or finish. This page is for your own freely chosen routine, not for changing someone else."
    ]
  },
  "fit": {
    "id": "self-reinforcement.fit",
    "title": "Keep choice, care and safety outside the reward",
    "paragraphs": [
      "Choose an ordinary action you want for your own reasons and can already do with suitable support. Do not choose a task someone is forcing on you, an action that hurts, or a rule that grows into constant checking or pressure.",
      "Food, water, medication, safety, toileting, communication aids, needed rest, care and ordinary support are never things to earn. Do not take away something you need, create discomfort or remove a usual pleasure to make the extra seem more valuable. No punishment or lost reward debt belongs here.",
      "Do not use this page to plan changes in eating, exercise, sleep, medication, substance use, self-harm or other high-risk behavior. Such goals need their own professional care. This is not a way to push through danger, abuse, distress or health limits.",
      "Keep the action and extra safe, affordable, accessible and under your control. You can use private thought, speech, signing, a communication aid or the example. No writing, purchase, body attention or particular sense is required. Pause if the plan increases shame, pressure or compulsive behavior; discuss it with your therapist."
    ]
  },
  "privacy": {
    "id": "self-reinforcement.privacy",
    "title": "Notes are optional and stay in this page",
    "paragraphs": [
      "Use a few words if helpful, or keep the plan in mind. This tool does not watch you, give rewards, record voice or send a report to anyone.",
      "Writing stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.",
      "Hiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox."
    ]
  },
  "close": {
    "id": "self-reinforcement.close",
    "title": "Finish without earning the right to stop",
    "paragraphs": [
      "You can finish after reading, planning, trying, reviewing, stopping or choosing not to practise. The result does not measure your worth. You do not have to feel proud, motivated or different.",
      "If useful, take one observation or question to your therapist. No reminder or new task is created. Leaving clears notes from this tool, not outside copies."
    ]
  },
  "example": {
    "id": "self-reinforcement.example",
    "title": "A made-up plan: putting one pencil back",
    "paragraphs": [
      "Mira wants to put a drawing pencil in its holder when a short drawing session ends. Mira can already do this, with the holder nearby. From recent memory, it happened at about two of five similar sessions; the count is only a rough starting point, not a target.",
      "Mira enjoys adding a sticker from an existing set to a personal art card. With a therapist, Mira chooses that small extra after putting the pencil away. The sticker set is beside the holder so the extra can follow straight away. Meals, rest, other art and normal pleasures stay available either way.",
      "At the next suitable session, Mira puts the pencil away but forgets the sticker. The action happened; the planned pair did not. Mira does not label this a reward test that worked or punish the missed step. A simple cue may make the plan easier next time.",
      "Across later suitable sessions, Mira uses the action and sticker together and notices the pencil is put away more often. The nearby holder, the cue or other changes may also have helped. Mira likes the plan and chooses to discuss keeping it for now, without making the task harder or the reward bigger. These made-up observations do not predict your result."
    ]
  },
  "learn": {
    "id": "self-reinforcement.learn",
    "title": "A reward is a possibility, not proof",
    "paragraphs": [
      "Positive reinforcement means that something added after an action makes that action happen more often later. Positive means adding something; it does not mean the action makes you a good person. An intended reward is not a proven reinforcer just because you like it.",
      "This differs from planning a pleasant activity. Here, the chosen extra follows a defined action, and the review asks about later action, not just a good feeling. It also differs from dividing a hard task or learning steps toward a bigger skill.",
      "A useful extra depends on you, the setting and the amount. Something welcome in one moment may be unwanted in another. It can be small and cost nothing. The page does not pick it for you.",
      "Reinforcement is a wider topic. Negative reinforcement means that removing something unpleasant after an action makes that action more likely later. It is not the same as punishment. This page does not teach that approach, shaping, changing another person or changing how often rewards are given. It covers only an initial positive self-use plan.",
      "A few observations can guide your next plan but cannot prove what caused a change. More reminders, an easier setting or more chances may also matter. Keep uncertainty honest. If the plan does not help, review its fit rather than blame yourself."
    ]
  },
  "practice": [
    {
      "id": "self-reinforcement.practice.situation",
      "title": "Choose a routine you want to support",
      "paragraphs": [
        "What ordinary part of life would you freely like to do a little more often? Choose your own reason, not a test of being good, busy or pleasing someone. You can use Mira’s example instead.",
        "Check this choice with your therapist and keep the safety limits in view. If the goal needs new teaching, treatment or a different kind of support, start there rather than add a reward."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The routine I freely want to support",
          "optional": true
        },
        {
          "key": "reason",
          "label": "Why it matters to me, or why it may not fit",
          "optional": true
        }
      ],
      "help": {
        "title": "If the goal belongs to someone else",
        "text": "You can decline this practice or discuss whose goal it is. It is not a plan for gaining control over you or another person."
      }
    },
    {
      "id": "self-reinforcement.practice.target",
      "title": "Define one action and its opportunity",
      "paragraphs": [
        "What exact action would you be able to notice? Use something within your current ability, such as putting one item in its place. “Be better” or “feel motivated” is not a clear action.",
        "Name the ordinary occasion when it can happen, and what counts as that chosen action. Keep needed support and access. A small action can be the whole target; you do not need to build a ladder or increase it later."
      ],
      "fields": [
        {
          "key": "target",
          "label": "The specific action and what counts as doing it",
          "optional": true
        },
        {
          "key": "opportunity",
          "label": "The suitable occasion and support it needs",
          "optional": true
        }
      ],
      "help": {
        "title": "If the action is still too hard",
        "text": "Ask for help with the skill, size or access. A bigger reward does not make an unsafe or impossible task suitable."
      }
    },
    {
      "id": "self-reinforcement.practice.starting",
      "title": "Look at what usually happens",
      "paragraphs": [
        "At recent similar chances, how often did this action happen, if you know? A rough description may be enough. You can say “I do not know” instead of inventing a count.",
        "Notice whether those chances really match the planned setting and support. Your therapist may suggest a brief record before trying the plan if useful. Do not delay needed care or watch yourself all day to get a starting picture."
      ],
      "fields": [
        {
          "key": "starting-pattern",
          "label": "What I know about recent similar opportunities",
          "optional": true
        },
        {
          "key": "starting-limits",
          "label": "What is missing, different or uncertain",
          "optional": true
        }
      ],
      "help": {
        "title": "If I have no starting information",
        "text": "Keep that clear. You can discuss how to learn more without a required log. Later improvement will be harder to judge; the page will not fill in the gap."
      }
    },
    {
      "id": "self-reinforcement.practice.extra",
      "title": "Choose a safe extra you actually want",
      "paragraphs": [
        "What small extra would you welcome after this action? Choose something available, safe and affordable that you can provide for yourself. It could be a small creative extra or a brief activity you enjoy; the choice is yours.",
        "Check whether its size and setting fit. Avoid anything unwanted, harmful, costly or dependent on another person’s reaction. Keep essential needs and normal pleasures available. This is a possible reinforcer to try, not something already shown to work."
      ],
      "fields": [
        {
          "key": "extra",
          "label": "The wanted extra I might add",
          "optional": true
        },
        {
          "key": "extra-fit",
          "label": "Why it fits, and any safety, access or cost limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing seems rewarding",
        "text": "Do not deprive yourself to make a reward work. Use the example, discuss other support or leave this method for now."
      }
    },
    {
      "id": "self-reinforcement.practice.link",
      "title": "Make the action-to-extra link clear",
      "paragraphs": [
        "For this practice, arrange the chosen extra to follow the defined action straight away when possible. Have it ready so a long delay is not built in. A reminder before the action may help, but it is different from the consequence after it.",
        "Keep the link specific: this action, then this extra. If the action or extra does not happen, record that honestly rather than count the pair as done. Nothing is taken away, and care, rest and ordinary activities remain available. Do not add penalties or change the rule after the event."
      ],
      "fields": [
        {
          "key": "link-rule",
          "label": "The action, then the extra, in plain words",
          "optional": true
        },
        {
          "key": "timing",
          "label": "How the extra can be available right afterward",
          "optional": true
        }
      ],
      "help": {
        "title": "If there will be a delay",
        "text": "Discuss whether a more immediate suitable extra would fit. Keep any real delay in the later record; do not claim immediate delivery if it did not happen."
      }
    },
    {
      "id": "self-reinforcement.practice.plan",
      "title": "Plan a short, workable try and review",
      "paragraphs": [
        "Agree with your therapist when this plan could fit and when to look at it again. At the suitable opportunities you agree to try, keep the same clear action-to-extra link. No fixed number of tries or reward schedule is set by this page.",
        "What cue, equipment or support needs to be ready? What would mean pause? Decide how you might remember actual action, actual extra and later similar chances. Notes can be brief or absent; no automatic record is made."
      ],
      "fields": [
        {
          "key": "plan-context",
          "label": "The agreed opportunities, cue and support",
          "optional": true
        },
        {
          "key": "plan-limits",
          "label": "Reasons to pause or change the plan",
          "optional": true
        },
        {
          "key": "plan-review",
          "label": "When and how I may review with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If tracking starts to feel like pressure",
        "text": "Keep the record simpler or stop and review the fit. You do not need perfect counts or a streak to use this page."
      }
    },
    {
      "id": "self-reinforcement.practice.try",
      "title": "Actually use the plan when it fits",
      "paragraphs": [
        "At an agreed suitable opportunity, try the chosen action. When it happens, add the chosen extra as planned, without waiting for the action to become perfect or feel good.",
        "You can stop, miss a chance or find that either part was not possible. That is information, not a debt to repay. Do not invent an attempt or keep doing the action over and over to earn more extras. Return later to review what really occurred."
      ],
      "fields": [
        {
          "key": "actual-try",
          "label": "What I actually tried, stopped or did not try",
          "optional": true
        },
        {
          "key": "try-context",
          "label": "Relevant support, interruptions or changed circumstances",
          "optional": true
        }
      ],
      "help": {
        "title": "If I only read or planned",
        "text": "You have prepared, not used the action-to-extra pair. That can be enough for this visit."
      }
    },
    {
      "id": "self-reinforcement.practice.result",
      "title": "Review the action and the extra separately",
      "paragraphs": [
        "Which action and extra are you reviewing? At the actual occasion, did the action happen as defined, partly happen or not happen? You can start here without a saved plan or an attempt.",
        "Was the extra actually added afterward, and how soon? Record a missed extra, a delay or a different event as it happened. Then notice whether it was welcome, neutral, uncomfortable or unclear. Liking it alone does not show a reinforcement effect."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "The action and what actually happened",
          "optional": true
        },
        {
          "key": "received",
          "label": "The actual extra, timing, or no extra",
          "optional": true
        },
        {
          "key": "experience",
          "label": "How the extra or plan felt, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot remember both parts",
        "text": "Keep the missing detail unknown. A planned reward is not proof it was received, and receiving it is not proof the action increased."
      }
    },
    {
      "id": "self-reinforcement.practice.compare",
      "title": "Look at later similar chances",
      "paragraphs": [
        "At later suitable opportunities, did the same action occur more often, about the same, less often or is it still too soon to tell? Compare how many chances there were, not just how often you did the action. More free time alone can give you more chances.",
        "At those later chances, was the extra actually added after the action, and how soon? Note missing extras or changes in delivery. Use the starting information only if it is real and the situations are similar enough. Different support, settings, cues or health can affect the pattern. One action or one pleasant extra is not enough to conclude that the extra reinforced it.",
        "What do you know, and what remains uncertain? This is a practical review, not proof of cause. No change, a mixed pattern or too little information can remain the result."
      ],
      "fields": [
        {
          "key": "observations",
          "label": "Later action and extra at similar chances",
          "optional": true
        },
        {
          "key": "comparison-limits",
          "label": "Starting information, changed context and uncertainty",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What this may suggest, or a question for my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If there have been no later opportunities",
        "text": "The effect is not yet known. You can finish and discuss whether another suitable chance fits; do not create extra tasks just to get an answer."
      }
    },
    {
      "id": "self-reinforcement.practice.adjust",
      "title": "Keep, change or stop the plan",
      "paragraphs": [
        "With your therapist, review whether the action was clear and possible, the extra was wanted and well timed, and the later chances were similar enough. If the pattern did not change, those are questions to explore rather than reasons for blame.",
        "You might keep the plan, choose a better-fitting extra, improve access or stop. Do not automatically make rewards bigger, remove pleasures, raise the task demand or switch to unpredictable rewards. A change is a new plan to agree before trying it."
      ],
      "fields": [
        {
          "key": "adjustment",
          "label": "What to keep, change, pause or leave",
          "optional": true
        },
        {
          "key": "adjustment-reason",
          "label": "Why that choice fits the actual observations",
          "optional": true
        }
      ],
      "help": {
        "title": "If the action became more common",
        "text": "That may be useful, but the cause can still be unclear. You do not have to make the target harder or turn it into a new obligation."
      }
    },
    {
      "id": "self-reinforcement.practice.next",
      "title": "Choose what to take forward",
      "paragraphs": [
        "Keep one useful observation or question if you want. The plan can end here. If another practice fits, agree its limits and review with your therapist rather than let the page set a schedule.",
        "This visit does not complete the wider Reinforcement method or Changing Behavior set. It can show what you tried and what still needs discussion. You do not need a changed feeling or a successful result to finish."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What I want to take forward or leave here",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any support or question for the next session",
          "optional": true
        }
      ],
      "help": {
        "title": "If the plan feels controlling",
        "text": "Pause it. Your choice, needs and support do not depend on meeting a target. Discuss whether a different approach would fit better."
      }
    }
  ],
  "sources": [
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed pp.161 and163: consequence-based definition, timely delivery, person/context/amount fit and observed behavior change.",
      "limits": "Positive self-use subset only. Negative reinforcement, shaping, intermittent schedules, extinction and punishment are not taught; source forms and examples are not copied.",
      "label": "Linehan/Guilford: 2015 Interpersonal Handouts20 and22"
    },
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed p.194 explicitly includes self-use: prospective action/consequence, actual use, observations, feelings and revision.",
      "limits": "Original optional record, not the source worksheet or its other-person branch. Future-frequency review makes the functional definition explicit without claiming causal proof.",
      "label": "Linehan/Guilford: 2015 Interpersonal Worksheet14"
    },
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Printed pp.306–310 and314–316: reinforcement definition, safe realistic choice, timing and review of actual effects.",
      "limits": "Historical Second Edition, not revised-2025 equivalence or validation of this digital adaptation. Deprivation and controlling-other-person examples are explicitly excluded.",
      "label": "Linehan/Guilford: 2015 teaching manual sectionXVII"
    },
    {
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal and access to communication and support.",
      "limits": "Rights guidance, not clinical validation or proof of equivalent effects for every adaptation.",
      "label": "ASHA/NJC: Communication Bill of Rights"
    },
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from purchaser duplication permission.",
      "limits": "Source access does not grant public app rights. Clinical and release-rights decisions remain open.",
      "label": "Guilford: Limited duplication licence"
    }
  ],
  "narrationSegments": [
    {
      "id": "self-reinforcement.intro",
      "title": "Try a wanted extra after one chosen action",
      "text": "What happens after an action can affect how often we do it again. Here, you choose one ordinary action and plan a small, wanted extra right after it. Later, you check what actually happened and whether the action became more common.\n\nThe extra is only a possible reinforcer at first. Enjoying it once does not show that it helped the action happen again. No change, fewer chances to try or unclear information are all possible results.\n\nUse this after your therapist has introduced it and checked the fit. You can plan, use the made-up example, review an earlier attempt or finish. This page is for your own freely chosen routine, not for changing someone else.",
      "sha256": "5b4e398d953475d41059f6b5f88d45ab8e5b65322bac6c920bfaced462baa583",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.fit",
      "title": "Keep choice, care and safety outside the reward",
      "text": "Choose an ordinary action you want for your own reasons and can already do with suitable support. Do not choose a task someone is forcing on you, an action that hurts, or a rule that grows into constant checking or pressure.\n\nFood, water, medication, safety, toileting, communication aids, needed rest, care and ordinary support are never things to earn. Do not take away something you need, create discomfort or remove a usual pleasure to make the extra seem more valuable. No punishment or lost reward debt belongs here.\n\nDo not use this page to plan changes in eating, exercise, sleep, medication, substance use, self-harm or other high-risk behavior. Such goals need their own professional care. This is not a way to push through danger, abuse, distress or health limits.\n\nKeep the action and extra safe, affordable, accessible and under your control. You can use private thought, speech, signing, a communication aid or the example. No writing, purchase, body attention or particular sense is required. Pause if the plan increases shame, pressure or compulsive behavior; discuss it with your therapist.",
      "sha256": "5159ca15850a99b6f65e2c8b1e16e1574c6f708c02e454810c124adee87010fe",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.privacy",
      "title": "Notes are optional and stay in this page",
      "text": "Use a few words if helpful, or keep the plan in mind. This tool does not watch you, give rewards, record voice or send a report to anyone.\n\nWriting stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.\n\nHiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox.",
      "sha256": "c577f59ed715da0e7b72f473214636a3e16c999dc8fdc9879841e158c52f7117",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.close",
      "title": "Finish without earning the right to stop",
      "text": "You can finish after reading, planning, trying, reviewing, stopping or choosing not to practise. The result does not measure your worth. You do not have to feel proud, motivated or different.\n\nIf useful, take one observation or question to your therapist. No reminder or new task is created. Leaving clears notes from this tool, not outside copies.",
      "sha256": "99f168868254c8dfe1ff911626c32cc9409296f391ce3b17f363aad1817cb902",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.example",
      "title": "A made-up plan: putting one pencil back",
      "text": "Mira wants to put a drawing pencil in its holder when a short drawing session ends. Mira can already do this, with the holder nearby. From recent memory, it happened at about two of five similar sessions; the count is only a rough starting point, not a target.\n\nMira enjoys adding a sticker from an existing set to a personal art card. With a therapist, Mira chooses that small extra after putting the pencil away. The sticker set is beside the holder so the extra can follow straight away. Meals, rest, other art and normal pleasures stay available either way.\n\nAt the next suitable session, Mira puts the pencil away but forgets the sticker. The action happened; the planned pair did not. Mira does not label this a reward test that worked or punish the missed step. A simple cue may make the plan easier next time.\n\nAcross later suitable sessions, Mira uses the action and sticker together and notices the pencil is put away more often. The nearby holder, the cue or other changes may also have helped. Mira likes the plan and chooses to discuss keeping it for now, without making the task harder or the reward bigger. These made-up observations do not predict your result.",
      "sha256": "47447438573bc5b7bfbbfe786dd55708c298b6dfeb7cee0a3472f9cb876843f5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.learn",
      "title": "A reward is a possibility, not proof",
      "text": "Positive reinforcement means that something added after an action makes that action happen more often later. Positive means adding something; it does not mean the action makes you a good person. An intended reward is not a proven reinforcer just because you like it.\n\nThis differs from planning a pleasant activity. Here, the chosen extra follows a defined action, and the review asks about later action, not just a good feeling. It also differs from dividing a hard task or learning steps toward a bigger skill.\n\nA useful extra depends on you, the setting and the amount. Something welcome in one moment may be unwanted in another. It can be small and cost nothing. The page does not pick it for you.\n\nReinforcement is a wider topic. Negative reinforcement means that removing something unpleasant after an action makes that action more likely later. It is not the same as punishment. This page does not teach that approach, shaping, changing another person or changing how often rewards are given. It covers only an initial positive self-use plan.\n\nA few observations can guide your next plan but cannot prove what caused a change. More reminders, an easier setting or more chances may also matter. Keep uncertainty honest. If the plan does not help, review its fit rather than blame yourself.",
      "sha256": "77b82e6003b0d70054d30cba9cf5978c5e22d199a1e5f93dd14b53d55b2c09a3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.situation",
      "title": "Choose a routine you want to support",
      "text": "What ordinary part of life would you freely like to do a little more often? Choose your own reason, not a test of being good, busy or pleasing someone. You can use Mira’s example instead.\n\nCheck this choice with your therapist and keep the safety limits in view. If the goal needs new teaching, treatment or a different kind of support, start there rather than add a reward.",
      "sha256": "44d1d8cf130832771fe581c2944c04c645254ba40e06fb8809b5d772e945376c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.situation.help",
      "title": "If the goal belongs to someone else",
      "text": "You can decline this practice or discuss whose goal it is. It is not a plan for gaining control over you or another person.",
      "sha256": "f14221bb23db5ad34c17c5b3638876add0cabc3bd26e1ee86a5839a7464a482d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.target",
      "title": "Define one action and its opportunity",
      "text": "What exact action would you be able to notice? Use something within your current ability, such as putting one item in its place. “Be better” or “feel motivated” is not a clear action.\n\nName the ordinary occasion when it can happen, and what counts as that chosen action. Keep needed support and access. A small action can be the whole target; you do not need to build a ladder or increase it later.",
      "sha256": "8ee5ad0db72841189848959df4350563e95be11754f97548bfff05ba116e2e97",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.target.help",
      "title": "If the action is still too hard",
      "text": "Ask for help with the skill, size or access. A bigger reward does not make an unsafe or impossible task suitable.",
      "sha256": "9b8212e75190f728125cff1a3692f9550bc584716475e3789608e512dba3b13c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.starting",
      "title": "Look at what usually happens",
      "text": "At recent similar chances, how often did this action happen, if you know? A rough description may be enough. You can say “I do not know” instead of inventing a count.\n\nNotice whether those chances really match the planned setting and support. Your therapist may suggest a brief record before trying the plan if useful. Do not delay needed care or watch yourself all day to get a starting picture.",
      "sha256": "5d507ef4b841300d6b9bc1d91940aec71287b2013c1dde34dcf14dc929f8c491",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.starting.help",
      "title": "If I have no starting information",
      "text": "Keep that clear. You can discuss how to learn more without a required log. Later improvement will be harder to judge; the page will not fill in the gap.",
      "sha256": "c922b5378d59b9db7d81f52ea953e67e7e549a8737e4707e1f6ed4912cec414e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.extra",
      "title": "Choose a safe extra you actually want",
      "text": "What small extra would you welcome after this action? Choose something available, safe and affordable that you can provide for yourself. It could be a small creative extra or a brief activity you enjoy; the choice is yours.\n\nCheck whether its size and setting fit. Avoid anything unwanted, harmful, costly or dependent on another person’s reaction. Keep essential needs and normal pleasures available. This is a possible reinforcer to try, not something already shown to work.",
      "sha256": "3baa20a13e13bb1931cc42ed74dfa8caf72f219e44f0ddfae30850846a966a92",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.extra.help",
      "title": "If nothing seems rewarding",
      "text": "Do not deprive yourself to make a reward work. Use the example, discuss other support or leave this method for now.",
      "sha256": "db054498b8e6d365713dbcee7f138c8c3f6f289770275365b957e11147ee37a6",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.link",
      "title": "Make the action-to-extra link clear",
      "text": "For this practice, arrange the chosen extra to follow the defined action straight away when possible. Have it ready so a long delay is not built in. A reminder before the action may help, but it is different from the consequence after it.\n\nKeep the link specific: this action, then this extra. If the action or extra does not happen, record that honestly rather than count the pair as done. Nothing is taken away, and care, rest and ordinary activities remain available. Do not add penalties or change the rule after the event.",
      "sha256": "8e7c4c471fb13883ff7cb3e2280b184c797a9ebf113f5591fea0a286dd950001",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.link.help",
      "title": "If there will be a delay",
      "text": "Discuss whether a more immediate suitable extra would fit. Keep any real delay in the later record; do not claim immediate delivery if it did not happen.",
      "sha256": "dfa007ea4f1b98363037ab02d10eea8392fefd278e26785527dcda810d64bd46",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.plan",
      "title": "Plan a short, workable try and review",
      "text": "Agree with your therapist when this plan could fit and when to look at it again. At the suitable opportunities you agree to try, keep the same clear action-to-extra link. No fixed number of tries or reward schedule is set by this page.\n\nWhat cue, equipment or support needs to be ready? What would mean pause? Decide how you might remember actual action, actual extra and later similar chances. Notes can be brief or absent; no automatic record is made.",
      "sha256": "ed9d5e6ebaa554869c0c75555159e58601106406823bd609a1929504aaf9b644",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.plan.help",
      "title": "If tracking starts to feel like pressure",
      "text": "Keep the record simpler or stop and review the fit. You do not need perfect counts or a streak to use this page.",
      "sha256": "22f156d67ed737393455af5766065114da72e343b510dc510b5c2fa633183562",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.try",
      "title": "Actually use the plan when it fits",
      "text": "At an agreed suitable opportunity, try the chosen action. When it happens, add the chosen extra as planned, without waiting for the action to become perfect or feel good.\n\nYou can stop, miss a chance or find that either part was not possible. That is information, not a debt to repay. Do not invent an attempt or keep doing the action over and over to earn more extras. Return later to review what really occurred.",
      "sha256": "5d2c91f2c4b20ae795541c63c627b32abd026ef26ff4f9aca7f08eb9b3963b7b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.try.help",
      "title": "If I only read or planned",
      "text": "You have prepared, not used the action-to-extra pair. That can be enough for this visit.",
      "sha256": "eb127434f050e585c1966abff2bab561cd822ff50012ddfbdd347df45ffa2c6e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.result",
      "title": "Review the action and the extra separately",
      "text": "Which action and extra are you reviewing? At the actual occasion, did the action happen as defined, partly happen or not happen? You can start here without a saved plan or an attempt.\n\nWas the extra actually added afterward, and how soon? Record a missed extra, a delay or a different event as it happened. Then notice whether it was welcome, neutral, uncomfortable or unclear. Liking it alone does not show a reinforcement effect.",
      "sha256": "349ca1ed9a146100c962bddfac2cc9bb115ef5c3d010ad4736e25ba7ecdd2307",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.result.help",
      "title": "If I cannot remember both parts",
      "text": "Keep the missing detail unknown. A planned reward is not proof it was received, and receiving it is not proof the action increased.",
      "sha256": "76c6019c547483b11ee70839f3680801a348c4b298914f89a3661598c070ec21",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.compare",
      "title": "Look at later similar chances",
      "text": "At later suitable opportunities, did the same action occur more often, about the same, less often or is it still too soon to tell? Compare how many chances there were, not just how often you did the action. More free time alone can give you more chances.\n\nAt those later chances, was the extra actually added after the action, and how soon? Note missing extras or changes in delivery. Use the starting information only if it is real and the situations are similar enough. Different support, settings, cues or health can affect the pattern. One action or one pleasant extra is not enough to conclude that the extra reinforced it.\n\nWhat do you know, and what remains uncertain? This is a practical review, not proof of cause. No change, a mixed pattern or too little information can remain the result.",
      "sha256": "fbd38e548d7aeec98bbb9e91b843a3f5b1dc3763c9764f17cfa97ae12007d4b4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.compare.help",
      "title": "If there have been no later opportunities",
      "text": "The effect is not yet known. You can finish and discuss whether another suitable chance fits; do not create extra tasks just to get an answer.",
      "sha256": "4912c44c96ee9f7392aa707978fc263d26d0e0434e5e5a4d56fe1c0431238064",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.adjust",
      "title": "Keep, change or stop the plan",
      "text": "With your therapist, review whether the action was clear and possible, the extra was wanted and well timed, and the later chances were similar enough. If the pattern did not change, those are questions to explore rather than reasons for blame.\n\nYou might keep the plan, choose a better-fitting extra, improve access or stop. Do not automatically make rewards bigger, remove pleasures, raise the task demand or switch to unpredictable rewards. A change is a new plan to agree before trying it.",
      "sha256": "ee8180a0b7ebd2b3349f6b2ec9677137c1d55b9a0172a177764694fa79928448",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.adjust.help",
      "title": "If the action became more common",
      "text": "That may be useful, but the cause can still be unclear. You do not have to make the target harder or turn it into a new obligation.",
      "sha256": "c25d35130c87bd96e940a04f997cbb09211c10259472ed49553ca5df7a8c7042",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-reinforcement.practice.next",
      "title": "Choose what to take forward",
      "text": "Keep one useful observation or question if you want. The plan can end here. If another practice fits, agree its limits and review with your therapist rather than let the page set a schedule.\n\nThis visit does not complete the wider Reinforcement method or Changing Behavior set. It can show what you tried and what still needs discussion. You do not need a changed feeling or a successful result to finish.",
      "sha256": "614cbe3e0e1a0aa9016f3d1334efc9ec8adb2af05600d2f4c9d790af444d31fa",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-reinforcement.practice.next.help",
      "title": "If the plan feels controlling",
      "text": "Pause it. Your choice, needs and support do not depend on meeting a target. Discuss whether a different approach would fit better.",
      "sha256": "aa54687e5ed00ad95e9c8445290e9b52e3b88cac8edd0dd26a014ba07439833c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
