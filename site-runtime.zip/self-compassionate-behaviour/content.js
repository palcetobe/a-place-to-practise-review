window.CompassionBehaviourContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/compassion",
  "componentId": "component/compassion/self-compassionate-behaviour",
  "resourceId": "tool/self-compassionate-behaviour",
  "routeProposal": "/self-compassionate-behaviour/",
  "title": "Self-Compassionate Behaviour",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Plan and review one small, caring action that fits your needs, limits and therapist's guidance.",
  "groupedSetStatus": "Self-Compassionate Behaviour component of existing classic/compassion only. Letter and Thought Diary remain distinct formats. This is a bounded action-selection/planning/review adaptation, not all CCI module 6 procedures, a full compassion programme or grouped-set clinical acceptance. No new canonical count.",
  "clinicalContract": {
    "learningObjective": "Distinguish compassionate action from reward, compliance, self-sacrifice or productivity; consider self, others and practical needs, then choose a fitting action and review its real effects.",
    "practiceObjective": "Notice one ordinary need, consider all three source areas without requiring action in each, choose one therapist-agreed small action from a caring purpose, make time/limits/support concrete, actually try or decline it, and review actual benefit, cost, barriers and next choice without punishment.",
    "sourcePopulationContext": "Adult-framed CCI teaching and primary professional compassion sources establish related procedures, not validation of this isolated digital adaptation. No blanket age floor and no universal age-suitability claim. Individual clinical, developmental, safeguarding, cultural, health, communication and access needs require review.",
    "exclusions": [
      "No generic acting-opposite rule, unsupervised exposure/ERP, assumption that what others tolerate is safe for this person",
      "No health, food, medication, exercise, sleep or substance-use prescriptions or changes",
      "No forced forgiveness, unsafe relationship contact, touch, disclosure, spending, legal/financial commitments or self-sacrifice",
      "No required warmth, imagery, breathing change, body focus, daily quota or persistence through distress",
      "No claim that limited resources, disability, discrimination or fatigue are failures of motivation",
      "No action, completed task or other person's approval as proof of human worth"
    ],
    "adaptations": [
      "Original text, sequence layout and example; no source worksheet or activity list reproduced",
      "All three care areas taught; one agreed action and optional available-as-needed care; this adaptation sets no daily/weekly quota",
      "Non-imagery caring intention; broader source acting-opposite/exposure and health-related examples not implemented here",
      "Actual later review, non-use, adverse/mixed outcomes, consent and resource checks explicit",
      "No automatic calendar, messages, purchases, reminders, therapist report or stored action history",
      "Optional open-page notes and exact selected export only"
    ],
    "reviewGates": [
      "Owner/clinician and rights review of full bounded component and explicit source omissions",
      "Individual clinical, developmental, safeguarding and access fit",
      "Novice comprehension review; grade-five language is a target, not a validated reading level",
      "Real integrated desktop/mobile/keyboard/screen-reader and lifecycle/navigation acceptance",
      "Authorized narration generation, exact-script listening, binding and controls review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use the action you have agreed with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Plan one caring action",
          "startSectionId": "self-compassionate-behaviour.practice.need"
        },
        {
          "value": "review",
          "label": "Review my agreed action",
          "startSectionId": "self-compassionate-behaviour.practice.review"
        }
      ]
    },
    "entryGate": "Visible therapist-introduced scope before explicit mode selection. Not screening or approval of a proposed action. Example, Learn, Finish and support remain available.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing or completion lock.",
    "reviewAccess": "Direct blank review without saved plan or an assumed attempt. Both modes expose all groups.",
    "writing": "Optional and hidden initially. Fiction never fills notes. Hiding removes private displays and invalidates exports.",
    "persistence": "In-memory open-page notes only. Internal readings/navigation retain them; clear, restart, leaving/reloading, history navigation and BFCache return clear them. Offscreen visibility alone retains them.",
    "export": "No default note selection. Exact selected preview/copy/download; editing, hiding, mode/stage change and new selection invalidate it.",
    "narration": "Hashed fixed public paragraphs and help only, never notes. No media files, TTS, autoplay or activation.",
    "timer": "None. No reminders, daily quota or repetition schedule set by the tool.",
    "completion": "No inferred action, completion, compassion score, success, mood improvement or approval by others."
  },
  "intro": {
    "id": "self-compassionate-behaviour.intro",
    "title": "Let care guide a small action",
    "paragraphs": [
      "Compassion can show in what you do, not only in what you say to yourself. The aim is to notice a need and respond with care, while respecting limits and real conditions.",
      "A caring action might support you, show freely chosen care to someone else, or help with a practical matter. There is no single right action. With your therapist, you can choose one small step and learn from what actually happens."
    ]
  },
  "fit": {
    "id": "self-compassionate-behaviour.fit",
    "title": "Keep the action small and agreed",
    "paragraphs": [
      "Use this after your therapist has introduced the skill. Choose an ordinary need and an exact small action you have agreed is suitable. Until then, keep ideas as questions for your session. You can read the example without making a plan.",
      "Keep needed care, aids, boundaries and safety steps. This page does not prescribe changes to food, medicine, exercise, sleep, substance use or other health care. It is not for danger, abuse, trauma, major commitments or starting an exposure exercise (facing a fear as treatment).",
      "Caring for someone else is optional. It does not mean doing what they demand, giving up your needs, forgiving them or accepting harm. Respect their right to say no and your own right to stop.",
      "No warm feeling, special image or breathing change is required. If the action or the idea of care increases shame, threat, distress, painful memories or feeling numb or far away, pause or stop and seek support. Do not push on to prove that you are trying."
    ]
  },
  "privacy": {
    "id": "self-compassionate-behaviour.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes or messages, make bookings or purchases, set reminders, or tell your therapist what happened. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "self-compassionate-behaviour.close",
    "title": "You can leave the plan or review here",
    "paragraphs": [
      "A plan is not an action you have done. You can stop after reading, choosing, planning or reviewing. You do not have to complete a task, help someone or feel better to be worthy of care.",
      "You can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere."
    ]
  },
  "example": {
    "id": "self-compassionate-behaviour.example",
    "title": "Noa chooses care rather than another demand",
    "paragraphs": [
      "This is made up, not a plan you need to copy. Noa feels drained while trying to sort an old craft drawer. There is no urgent deadline. Noa and their therapist have agreed to practise making small choices from care rather than the rule \"I must finish everything before I can pause.\"",
      "They consider three areas. For Noa: read a familiar comic for up to five minutes at a planned quiet time. For someone else: a brief thank-you to a trusted relative, if freely chosen and welcome. For the practical matter: put three pens in one box, with permission to leave the rest. Noa does not need to do all three.",
      "Noa chooses the comic because rest and a change of focus fit the need today. The purpose is care, not a reward for finishing the drawer or a promise to feel calm. The other ideas remain options, not commitments.",
      "The agreed plan is to read the comic in the usual chair at four o'clock, for up to five minutes, with the usual reading aid. Noa can stop sooner. If interrupted, Noa can leave it or discuss another time. A familiar picture on the comic cover is also an easy care option during a hard moment, whether or not the planned reading happens.",
      "Actual use: Noa reads for three minutes, then feels restless and stops. Guilt about the drawer is still there. Noa notices one funny detail and also notices the effort of holding the book. The action was partly pleasant and partly tiring.",
      "Review: Noa did not fail by stopping, and the action did not solve the drawer problem. At the next session, Noa and the therapist discuss a book stand Noa already has and whether a different kind of pause would fit better. They also leave room to return to the practical task later.",
      "No further action has happened after this review. If Noa had not read at all, the review could still explore interruption, access, energy or a changed need without inventing a result. The thank-you was not sent and the pens were not sorted."
    ]
  },
  "learn": {
    "id": "self-compassionate-behaviour.learn",
    "title": "Care is the purpose, not a performance",
    "paragraphs": [
      "Compassionate behaviour begins with noticing difficulty and wanting to help in a wise, respectful way. The same action may fit one person and burden another. Check the purpose, the setting, the cost and the person's choice.",
      "There are three areas to consider: care for yourself, freely chosen care for others, and practical matters that need attention. They are not three tasks you must complete. Your own needs remain important when you help someone else.",
      "Care can be a pause, useful support, a boundary or a manageable practical step. It is not only comfort, and it is not simply doing more. Sometimes the fitting action is to ask for help, do less or stop.",
      "Self-Soothe teaches a sensory practice. Behavioural Activation looks at activity patterns and meaningful action. Problem-Solving compares ways to address a difficulty. Those tools may support an agreed action. This component adds choosing and reviewing behaviour from a caring purpose across the three areas; it does not replace those methods.",
      "This adapted practice does not tell you to do the opposite of every urge or face a fear on your own. A feeling may point to a real need or risk. What is safe or possible for someone else may not fit you.",
      "Care is not earned by finishing, being useful, feeling grateful or pleasing someone. Review what actually happened without turning the result into a verdict on your effort or worth. You and your therapist can change the plan or choose another approach."
    ]
  },
  "practice": [
    {
      "id": "self-compassionate-behaviour.practice.need",
      "title": "Notice the need and choose a caring purpose",
      "paragraphs": [
        "What ordinary difficulty or need are you working on with your therapist? Briefly notice what is hard and what matters now. You do not need to search for a deeper cause or recall a painful event.",
        "What would you like care to offer here: support, steadiness, protection, connection, a manageable step or something else? Name the purpose before choosing an activity. It is not a demand to feel better."
      ],
      "fields": [
        {
          "key": "need",
          "label": "The ordinary need or difficulty",
          "optional": true
        },
        {
          "key": "purpose",
          "label": "What I want a caring response to offer",
          "optional": true
        }
      ],
      "help": {
        "title": "If the problem is outside your control",
        "text": "Lack of money, access, safety or fair treatment is not a failure of self-care. The need may be practical support, a boundary or wider change. Do not use a small activity to dismiss the real problem."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.self",
      "title": "Consider care for yourself",
      "paragraphs": [
        "What small, accessible action could show care to you? Choose something that fits your tastes, energy and circumstances. It need not cost money, use your senses in a certain way, involve touch or feel soothing.",
        "You may think of one action to make room for at a planned time, and one simple option available during a hard moment. These can be the same. You do not have to do either every day, and care does not depend on finishing work first."
      ],
      "fields": [
        {
          "key": "self-care",
          "label": "A care idea for me and a possible time",
          "optional": true
        },
        {
          "key": "available-care",
          "label": "An easy care option for a hard moment, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing sounds caring",
        "text": "You can leave it open. A small reduction in pressure or help from someone may fit better than an activity. Do not force yourself to like an idea from a list or keep doing something that feels threatening."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.others",
      "title": "Consider care for others without losing your needs",
      "paragraphs": [
        "If you want, consider a small act of kindness toward someone in a safe, appropriate setting. It should be freely chosen and welcome, not a way to earn approval or avoid saying no.",
        "What would respect both people's needs, privacy and limits? Check consent where needed. You can skip this area, keep your idea private, or decide not to act. You do not owe contact, touch, a gift, money or forgiveness."
      ],
      "fields": [
        {
          "key": "other-care",
          "label": "A freely chosen care idea for someone else, if wanted",
          "optional": true
        },
        {
          "key": "mutual-limits",
          "label": "Consent, safety and limits for both people",
          "optional": true
        }
      ],
      "help": {
        "title": "If helping is already taking too much",
        "text": "More helping may not be the caring choice. Your needs matter too. A boundary or less responsibility may be appropriate. Discuss pressure, guilt or unsafe demands with your therapist rather than treating compliance as compassion."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.practical",
      "title": "Consider one practical matter",
      "paragraphs": [
        "Is there an ordinary task or problem where a small step could reduce a burden? Consider what is yours to do, what needs help and what can wait. It is okay if the problem cannot be solved now.",
        "If you and your therapist choose a step, make it manageable with the support and aids you need. You can break it down or ask for help. This is not an instruction to work through exhaustion, pain, danger or lack of access."
      ],
      "fields": [
        {
          "key": "practical-need",
          "label": "A practical matter and what is within my control",
          "optional": true
        },
        {
          "key": "small-step",
          "label": "One manageable step or support I could discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If the task needs another skill or expert advice",
        "text": "Keep that need visible. Use a skill your therapist has already taught or ask for suitable help. This page does not supply exposure treatment, health advice, legal/financial advice or an instruction to ignore an urge."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.choose",
      "title": "Choose one action for this practice",
      "paragraphs": [
        "Look at the ideas that fit. Which one best serves the caring purpose you named, with the least unhelpful burden? You may choose care for yourself, care for someone else or a practical step. You do not need to cover every area.",
        "What does it ask of your time, energy, access, money and support? Is it wanted, safe and realistic for you? Check this with your therapist. Keep boundaries and necessary care. Choosing to pause or leave the action open is allowed."
      ],
      "fields": [
        {
          "key": "chosen-action",
          "label": "The one action we want to consider",
          "optional": true
        },
        {
          "key": "fit-and-cost",
          "label": "Why it may fit, and its limits or costs",
          "optional": true
        }
      ],
      "help": {
        "title": "If two needs compete",
        "text": "There may not be one perfect answer. Name both needs and ask what can reasonably fit now. Care does not require meeting everyone's needs at once or choosing the hardest option."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.plan",
      "title": "Make the agreed plan concrete",
      "paragraphs": [
        "Use the exact small action agreed with your therapist. What will you do, where, when or after what cue, and for how long or how much? Set a limit that lets you stop. This page does not approve an idea or schedule it for you.",
        "What support, access or consent do you need? What might get in the way? Agree a smaller option, a pause or no action if the plan no longer fits. Do not spend money, make a major promise or contact an unsafe person because of this page.",
        "What would help you learn about the action's fit: what you actually did, effort, access, comfort, pressure, or another effect? Warm feelings are not the test. Agree when and how to review, even if you do not try it."
      ],
      "fields": [
        {
          "key": "agreed-plan",
          "label": "The action, place, time or cue, and amount we agreed",
          "optional": true
        },
        {
          "key": "support-plan",
          "label": "Supports, consent and boundaries",
          "optional": true
        },
        {
          "key": "backup-plan",
          "label": "Possible barriers, stopping and backup choices",
          "optional": true
        },
        {
          "key": "review-plan",
          "label": "What to notice and how we will review",
          "optional": true
        }
      ],
      "help": {
        "title": "If there is no agreed action yet",
        "text": "Leave it as an idea for your next session, not an instruction to act. You can use the example or finish. Pressing a button does not approve a plan, make a booking, send a message or set a reminder."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.use",
      "title": "Try only what still fits",
      "paragraphs": [
        "Before the real action, check whether the need, setting or your capacity has changed. Use only the plan you agreed. You may try part, stop sooner, ask for help or not try.",
        "Keep the caring purpose in mind. If the action turns into punishment, proof of worth or a demand to feel good, pause and review. Do not repeat it until you get a better feeling or someone responds as you hoped.",
        "A real action happens in your life, not by pressing Next. You can leave and return to Review my agreed action. Notes here are not saved when you leave or reload. Choose notes to keep first if you want a copy."
      ],
      "fields": [
        {
          "key": "readiness",
          "label": "Anything that changed or needs checking before action",
          "optional": true
        }
      ],
      "help": {
        "title": "If care itself brings distress",
        "text": "You do not need to push through shame, grief, threat, painful memories or feeling numb. Stop or choose not to begin and seek support. Your therapist can help change the plan or the approach."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.review",
      "title": "Review what actually happened",
      "paragraphs": [
        "After the planned time, what did you do, partly do, change or not try? If there was no attempt, there is no action result to invent. You can still review what got in the way or why you chose not to act.",
        "What effects did you notice on you and, if relevant, the other person? Include helpful, tiring, awkward, neutral or unwanted effects. Keep what you observed apart from guesses about someone else's thoughts.",
        "Did the action serve the caring purpose in this setting? What did it cost or leave unmet? A pleasant feeling is not required. One result does not prove the action will always fit."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "What I actually did, changed or did not try",
          "optional": true
        },
        {
          "key": "observations",
          "label": "Effects I observed and what remains unknown",
          "optional": true
        },
        {
          "key": "purpose-review",
          "label": "How it fitted the caring purpose, including costs or unmet needs",
          "optional": true
        }
      ],
      "help": {
        "title": "If an action hurt or did not fit",
        "text": "Take that seriously. Stop and get support where needed. You do not have to call it helpful or blame yourself. Review before repeating or changing the plan. Support and urgent help has help options."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.adjust",
      "title": "Respond to the result with care",
      "paragraphs": [
        "What would a fair, caring response to this result say? Include real limits, interruptions, access and consent. Missed or changed plans do not call for punishment, catch-up or a bigger task.",
        "With your therapist, consider keeping, making smaller, changing, postponing or stopping the action. Rescheduling is one option, not a duty. If a practical need remains, note what other help may be needed rather than expecting one care activity to solve it."
      ],
      "fields": [
        {
          "key": "caring-review",
          "label": "A fair response to the attempt or non-use",
          "optional": true
        },
        {
          "key": "adjustment",
          "label": "What I might keep, change, pause or ask for help with",
          "optional": true
        }
      ],
      "help": {
        "title": "If someone did not appreciate the gesture",
        "text": "Their response does not decide your worth or oblige them to respond differently. Respect their choice. Check whether the gesture was wanted and whether your own limits were kept; do not repeat it to win approval."
      }
    },
    {
      "id": "self-compassionate-behaviour.practice.continue",
      "title": "Agree what happens next",
      "paragraphs": [
        "Bring the result, any discomfort and questions to your therapist. Agree any next action or review together. The next step can be no new action while you work out the fit.",
        "If useful, keep one accessible care option for a hard moment, alongside any planned activity. It is an option, not a rule or a way to avoid real help. You do not need a daily streak or a full schedule to practise care."
      ],
      "fields": [
        {
          "key": "therapy-review",
          "label": "What I want to review before another action",
          "optional": true
        },
        {
          "key": "future-care",
          "label": "A care option I may keep available, or leave open",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want to keep the plan or review",
        "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy. The tool keeps no action history after you leave."
      }
    }
  ],
  "sources": [
    {
      "id": "CCI: Self-Compassionate Behaviour, Module 6",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Building-Self-Compassion/Building-Self-Compassion---06---Self-Compassionate-Behaviour.pdf",
      "supports": "Care for self, freely chosen care for others and practical matters; manageable planned and available-as-needed care, concrete scheduling, noticing effects and responding without self-criticism.",
      "limits": "This is an original bounded adaptation, not the full module. Broader acting-opposite/exposure, health-related and forgiveness guidance and source worksheets are omitted. This version sets no required persistence or practice quota. Actual later review is explicit without requiring benefit or rescheduling."
    },
    {
      "id": "Neff and Germer: The Role of Self-Compassion in Psychotherapy (2022)",
      "url": "https://doi.org/10.1002/wps.20925",
      "supports": "Individual customization and careful pacing when compassion evokes distress.",
      "limits": "Professional clinical commentary, not validation of this component, its stop cues or suitability across ages. Distress is not presented as proof of healing."
    },
    {
      "id": "Kristin Neff: Self-Compassion Practices",
      "url": "https://self-compassion.org/self-compassion-practices/",
      "supports": "Self-compassion is not a technique to force pleasant feelings; pulling back and responding with care when overwhelmed can be appropriate.",
      "limits": "Author-origin practice guidance, not validation of this component. No breath/touch/imagery instruction, schedule or source script is copied."
    },
    {
      "id": "Self-Compassion LLC: Terms and Conditions",
      "url": "https://self-compassion.org/terms-and-conditions/",
      "supports": "Rights restrictions on the author-origin site materials; public viewing is not an open reuse licence.",
      "limits": "No original exercises, templates or source scripts reproduced. Website-access terms are not evidence of a clinical age threshold. Rights review remains open."
    },
    {
      "id": "CCI: Copyright and Disclaimer",
      "url": "https://www.cci.health.wa.gov.au/Home/Utilities/Copyright-and-Disclaimer",
      "supports": "Source-use restrictions and distinction between general educational materials and individual clinical care.",
      "limits": "Public access does not grant general republication rights. No original form, activity list, image or source script is reproduced; rights review remains open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Notice difficulty and adopt a caring purpose",
      "sections": [
        "practice.need"
      ],
      "source": "CCI module 6 pp2,5; explicit need/purpose and context gate are adaptation choices"
    },
    {
      "operation": "Consider self-care both planned and available when needed",
      "sections": [
        "practice.self",
        "practice.continue"
      ],
      "source": "CCI module 6 pp2–3,9–10; no mandatory daily dose or promised soothing"
    },
    {
      "operation": "Consider care for others without self-sacrifice or submission",
      "sections": [
        "practice.others"
      ],
      "source": "CCI module 6 pp4–5; explicit consent/privacy/unsafe-contact limits are safeguards"
    },
    {
      "operation": "Consider a manageable practical step",
      "sections": [
        "practice.practical"
      ],
      "source": "CCI module 6 pp5,7–8; generic acting-opposite/exposure and health instructions intentionally omitted"
    },
    {
      "operation": "Select, plan and actually use a bounded caring action",
      "sections": [
        "practice.choose",
        "practice.plan",
        "practice.use"
      ],
      "source": "CCI module 6 pp3,5,8–9; one agreed action, stopping and optional non-use are bounded adaptations"
    },
    {
      "operation": "Observe effects, review purpose and respond compassionately to use or non-use",
      "sections": [
        "practice.review",
        "practice.adjust",
        "practice.continue"
      ],
      "source": "CCI module 6 pp5,9; explicit later review and optional rescheduling are product adaptations"
    },
    {
      "operation": "Pace and stop when overwhelmed",
      "sections": [
        "fit",
        "practice.use",
        "practice.review"
      ],
      "source": "Neff and Germer 2022 for customization and pacing; Neff practice guidance for no required pleasant feeling and pulling back; plain-language cues are safeguards, not a validated screening rule"
    }
  ],
  "narrationSegments": [
    {
      "id": "self-compassionate-behaviour.intro",
      "title": "Let care guide a small action",
      "text": "Compassion can show in what you do, not only in what you say to yourself. The aim is to notice a need and respond with care, while respecting limits and real conditions.\n\nA caring action might support you, show freely chosen care to someone else, or help with a practical matter. There is no single right action. With your therapist, you can choose one small step and learn from what actually happens.",
      "sha256": "0640941648383346599a5e7568e6fe9d779fdcf941173827e937bedadd1d4bfd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.fit",
      "title": "Keep the action small and agreed",
      "text": "Use this after your therapist has introduced the skill. Choose an ordinary need and an exact small action you have agreed is suitable. Until then, keep ideas as questions for your session. You can read the example without making a plan.\n\nKeep needed care, aids, boundaries and safety steps. This page does not prescribe changes to food, medicine, exercise, sleep, substance use or other health care. It is not for danger, abuse, trauma, major commitments or starting an exposure exercise (facing a fear as treatment).\n\nCaring for someone else is optional. It does not mean doing what they demand, giving up your needs, forgiving them or accepting harm. Respect their right to say no and your own right to stop.\n\nNo warm feeling, special image or breathing change is required. If the action or the idea of care increases shame, threat, distress, painful memories or feeling numb or far away, pause or stop and seek support. Do not push on to prove that you are trying.",
      "sha256": "df5457b89195036c3147aaccc656eb8928811101edf708e251750e15aaf4c30b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes or messages, make bookings or purchases, set reminders, or tell your therapist what happened. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "15049e626e723420f6a447d52abed9f2741c9232e8a1f794dd79708f2a1e2f6d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.close",
      "title": "You can leave the plan or review here",
      "text": "A plan is not an action you have done. You can stop after reading, choosing, planning or reviewing. You do not have to complete a task, help someone or feel better to be worthy of care.\n\nYou can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere.",
      "sha256": "9caf45511357a3c371615cd2cf0a6c1e263a7c07e9303c24a4be8bfb3d7526d2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.example",
      "title": "Noa chooses care rather than another demand",
      "text": "This is made up, not a plan you need to copy. Noa feels drained while trying to sort an old craft drawer. There is no urgent deadline. Noa and their therapist have agreed to practise making small choices from care rather than the rule \"I must finish everything before I can pause.\"\n\nThey consider three areas. For Noa: read a familiar comic for up to five minutes at a planned quiet time. For someone else: a brief thank-you to a trusted relative, if freely chosen and welcome. For the practical matter: put three pens in one box, with permission to leave the rest. Noa does not need to do all three.\n\nNoa chooses the comic because rest and a change of focus fit the need today. The purpose is care, not a reward for finishing the drawer or a promise to feel calm. The other ideas remain options, not commitments.\n\nThe agreed plan is to read the comic in the usual chair at four o'clock, for up to five minutes, with the usual reading aid. Noa can stop sooner. If interrupted, Noa can leave it or discuss another time. A familiar picture on the comic cover is also an easy care option during a hard moment, whether or not the planned reading happens.\n\nActual use: Noa reads for three minutes, then feels restless and stops. Guilt about the drawer is still there. Noa notices one funny detail and also notices the effort of holding the book. The action was partly pleasant and partly tiring.\n\nReview: Noa did not fail by stopping, and the action did not solve the drawer problem. At the next session, Noa and the therapist discuss a book stand Noa already has and whether a different kind of pause would fit better. They also leave room to return to the practical task later.\n\nNo further action has happened after this review. If Noa had not read at all, the review could still explore interruption, access, energy or a changed need without inventing a result. The thank-you was not sent and the pens were not sorted.",
      "sha256": "4fbd8a3e6a0ce30be9df4f924d965caa8f97663691e82f52a221bbd467fcba43",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.learn",
      "title": "Care is the purpose, not a performance",
      "text": "Compassionate behaviour begins with noticing difficulty and wanting to help in a wise, respectful way. The same action may fit one person and burden another. Check the purpose, the setting, the cost and the person's choice.\n\nThere are three areas to consider: care for yourself, freely chosen care for others, and practical matters that need attention. They are not three tasks you must complete. Your own needs remain important when you help someone else.\n\nCare can be a pause, useful support, a boundary or a manageable practical step. It is not only comfort, and it is not simply doing more. Sometimes the fitting action is to ask for help, do less or stop.\n\nSelf-Soothe teaches a sensory practice. Behavioural Activation looks at activity patterns and meaningful action. Problem-Solving compares ways to address a difficulty. Those tools may support an agreed action. This component adds choosing and reviewing behaviour from a caring purpose across the three areas; it does not replace those methods.\n\nThis adapted practice does not tell you to do the opposite of every urge or face a fear on your own. A feeling may point to a real need or risk. What is safe or possible for someone else may not fit you.\n\nCare is not earned by finishing, being useful, feeling grateful or pleasing someone. Review what actually happened without turning the result into a verdict on your effort or worth. You and your therapist can change the plan or choose another approach.",
      "sha256": "0054b2fee029bc46ce244956385f28475c32373d0cff934aa29b46d29086c509",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.need",
      "title": "Notice the need and choose a caring purpose",
      "text": "What ordinary difficulty or need are you working on with your therapist? Briefly notice what is hard and what matters now. You do not need to search for a deeper cause or recall a painful event.\n\nWhat would you like care to offer here: support, steadiness, protection, connection, a manageable step or something else? Name the purpose before choosing an activity. It is not a demand to feel better.",
      "sha256": "3aa51c02e8c1ac91d953db8bf1796471b1e8d9bff4f959ea043481c581e42926",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.need.help",
      "title": "If the problem is outside your control",
      "text": "Lack of money, access, safety or fair treatment is not a failure of self-care. The need may be practical support, a boundary or wider change. Do not use a small activity to dismiss the real problem.",
      "sha256": "9839f43cd628b5d308dd972b571d5d7252951fe243e4e75840c4813a3d972df5",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.self",
      "title": "Consider care for yourself",
      "text": "What small, accessible action could show care to you? Choose something that fits your tastes, energy and circumstances. It need not cost money, use your senses in a certain way, involve touch or feel soothing.\n\nYou may think of one action to make room for at a planned time, and one simple option available during a hard moment. These can be the same. You do not have to do either every day, and care does not depend on finishing work first.",
      "sha256": "b64aba0259cfa1ab6ea13dd31add22a572ee7f7ba51cd125324ddcceed9aac43",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.self.help",
      "title": "If nothing sounds caring",
      "text": "You can leave it open. A small reduction in pressure or help from someone may fit better than an activity. Do not force yourself to like an idea from a list or keep doing something that feels threatening.",
      "sha256": "788c488d8d080e3f7723eeb055f6554ab48538108197725bc156dec271abefd9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.others",
      "title": "Consider care for others without losing your needs",
      "text": "If you want, consider a small act of kindness toward someone in a safe, appropriate setting. It should be freely chosen and welcome, not a way to earn approval or avoid saying no.\n\nWhat would respect both people's needs, privacy and limits? Check consent where needed. You can skip this area, keep your idea private, or decide not to act. You do not owe contact, touch, a gift, money or forgiveness.",
      "sha256": "4531384d964e29f5283ce5618bf4c329bd211d5a3eb80469b6bf702b0ecb077c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.others.help",
      "title": "If helping is already taking too much",
      "text": "More helping may not be the caring choice. Your needs matter too. A boundary or less responsibility may be appropriate. Discuss pressure, guilt or unsafe demands with your therapist rather than treating compliance as compassion.",
      "sha256": "6f3fcab8ae1035e082779b8de81ffbb0eb64e8b74106f1484a8607d435fe4c79",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.practical",
      "title": "Consider one practical matter",
      "text": "Is there an ordinary task or problem where a small step could reduce a burden? Consider what is yours to do, what needs help and what can wait. It is okay if the problem cannot be solved now.\n\nIf you and your therapist choose a step, make it manageable with the support and aids you need. You can break it down or ask for help. This is not an instruction to work through exhaustion, pain, danger or lack of access.",
      "sha256": "232ba154c9675bdb4f5dae5360b55d1da377980d4bfd5f3c34301427e72d700a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.practical.help",
      "title": "If the task needs another skill or expert advice",
      "text": "Keep that need visible. Use a skill your therapist has already taught or ask for suitable help. This page does not supply exposure treatment, health advice, legal/financial advice or an instruction to ignore an urge.",
      "sha256": "eae55935c860b39a57a23f7af773eec1bd2f443dc4e526f3bdfb0b1ce7ac2661",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.choose",
      "title": "Choose one action for this practice",
      "text": "Look at the ideas that fit. Which one best serves the caring purpose you named, with the least unhelpful burden? You may choose care for yourself, care for someone else or a practical step. You do not need to cover every area.\n\nWhat does it ask of your time, energy, access, money and support? Is it wanted, safe and realistic for you? Check this with your therapist. Keep boundaries and necessary care. Choosing to pause or leave the action open is allowed.",
      "sha256": "4ee977882226ff6bc6dfcc2b554426cd5bfb8e5a80c00b2c1462ed709ecb39b8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.choose.help",
      "title": "If two needs compete",
      "text": "There may not be one perfect answer. Name both needs and ask what can reasonably fit now. Care does not require meeting everyone's needs at once or choosing the hardest option.",
      "sha256": "d60abd975cbed8ab11f1546287be6d083fa6847f36ed8c7f7b414b5eb379dbaa",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.plan",
      "title": "Make the agreed plan concrete",
      "text": "Use the exact small action agreed with your therapist. What will you do, where, when or after what cue, and for how long or how much? Set a limit that lets you stop. This page does not approve an idea or schedule it for you.\n\nWhat support, access or consent do you need? What might get in the way? Agree a smaller option, a pause or no action if the plan no longer fits. Do not spend money, make a major promise or contact an unsafe person because of this page.\n\nWhat would help you learn about the action's fit: what you actually did, effort, access, comfort, pressure, or another effect? Warm feelings are not the test. Agree when and how to review, even if you do not try it.",
      "sha256": "0674356973b1461d19c44d001851b2cfdd3badadc9efddee82c757a9f49ebf39",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.plan.help",
      "title": "If there is no agreed action yet",
      "text": "Leave it as an idea for your next session, not an instruction to act. You can use the example or finish. Pressing a button does not approve a plan, make a booking, send a message or set a reminder.",
      "sha256": "caf6939db7f236a6f2d763c61622bc41d8f8a751899e09b0b47856b91853a073",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.use",
      "title": "Try only what still fits",
      "text": "Before the real action, check whether the need, setting or your capacity has changed. Use only the plan you agreed. You may try part, stop sooner, ask for help or not try.\n\nKeep the caring purpose in mind. If the action turns into punishment, proof of worth or a demand to feel good, pause and review. Do not repeat it until you get a better feeling or someone responds as you hoped.\n\nA real action happens in your life, not by pressing Next. You can leave and return to Review my agreed action. Notes here are not saved when you leave or reload. Choose notes to keep first if you want a copy.",
      "sha256": "d76909503d1685299ad7b45591b168092fd6272f0fa2e28678b6607365cfd2cd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.use.help",
      "title": "If care itself brings distress",
      "text": "You do not need to push through shame, grief, threat, painful memories or feeling numb. Stop or choose not to begin and seek support. Your therapist can help change the plan or the approach.",
      "sha256": "4ccf32be654a8bf4e96d4077e34521cff31e20ac4e8540c9788a138ccb375888",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.review",
      "title": "Review what actually happened",
      "text": "After the planned time, what did you do, partly do, change or not try? If there was no attempt, there is no action result to invent. You can still review what got in the way or why you chose not to act.\n\nWhat effects did you notice on you and, if relevant, the other person? Include helpful, tiring, awkward, neutral or unwanted effects. Keep what you observed apart from guesses about someone else's thoughts.\n\nDid the action serve the caring purpose in this setting? What did it cost or leave unmet? A pleasant feeling is not required. One result does not prove the action will always fit.",
      "sha256": "c02ef4f0ddd8a01e6fd265248f4993b56a34fffa4803dbcf4e9d288374968f1b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.review.help",
      "title": "If an action hurt or did not fit",
      "text": "Take that seriously. Stop and get support where needed. You do not have to call it helpful or blame yourself. Review before repeating or changing the plan. Support and urgent help has help options.",
      "sha256": "fc1f0c5456ffd7d54c3162aa005c8f88eea0d5866b8ac5af5aa5ce8ee24c18a5",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.adjust",
      "title": "Respond to the result with care",
      "text": "What would a fair, caring response to this result say? Include real limits, interruptions, access and consent. Missed or changed plans do not call for punishment, catch-up or a bigger task.\n\nWith your therapist, consider keeping, making smaller, changing, postponing or stopping the action. Rescheduling is one option, not a duty. If a practical need remains, note what other help may be needed rather than expecting one care activity to solve it.",
      "sha256": "9920099b66a023864a6701e0e5e55672ea17bf1fed52204e14f16f2a57b029d6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.adjust.help",
      "title": "If someone did not appreciate the gesture",
      "text": "Their response does not decide your worth or oblige them to respond differently. Respect their choice. Check whether the gesture was wanted and whether your own limits were kept; do not repeat it to win approval.",
      "sha256": "b05e63f35ef09a4a4d6765c4a009a5cc24fb3bcab3ba643e650ede189f643bc3",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "self-compassionate-behaviour.practice.continue",
      "title": "Agree what happens next",
      "text": "Bring the result, any discomfort and questions to your therapist. Agree any next action or review together. The next step can be no new action while you work out the fit.\n\nIf useful, keep one accessible care option for a hard moment, alongside any planned activity. It is an option, not a rule or a way to avoid real help. You do not need a daily streak or a full schedule to practise care.",
      "sha256": "a5cb8cfa53790175e35667a0464626c95405c302174f39c283641416948d3286",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "self-compassionate-behaviour.practice.continue.help",
      "title": "If you want to keep the plan or review",
      "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy. The tool keeps no action history after you leave.",
      "sha256": "c6e200844e85911d9639e6b6f725d3dc3b020697afc010666ec1cf3b2c0a06b1",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
