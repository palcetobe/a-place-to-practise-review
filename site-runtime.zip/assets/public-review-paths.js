(function () {
  'use strict';
  var script = document.currentScript;
  if (!script || !script.src) throw new Error('Public review path context is unavailable.');
  var root = new URL('../', script.src).href;
  function href(value) {
    if (typeof value !== 'string') throw new TypeError('Expected a destination string.');
    if (/^(?:https?:|mailto:|tel:)/i.test(value)) return value;
    if (/^[a-z][a-z0-9+.-]*:/i.test(value) || value.indexOf('//') === 0) {
      throw new Error('Unsupported destination.');
    }
    var target = new URL(value.replace(/^\/+/, ''), root);
    var base = new URL(root);
    if (target.origin !== base.origin || target.pathname.indexOf(base.pathname) !== 0) {
      throw new Error('Destination leaves the project.');
    }
    return target.href;
  }
  Object.defineProperty(window, 'PublicReviewPaths', {
    value: Object.freeze({get base() { return new URL(root); }, href: href}),
    writable: false,
    configurable: false
  });
}());
