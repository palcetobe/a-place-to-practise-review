
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.BehaviouralExperimentModel=api;})(typeof window!=='undefined'?window:globalThis,()=>{'use strict';
function create(D){const modes=D.interactionContract.modes,fields=D.practice.flatMap(p=>p.fields||[]),keys=new Set(fields.map(f=>f.key));let s,shortcut=false;
const prompts=(mode=s.mode)=>D.practice.filter(p=>!p.branch||p.branch===mode);
function invalidate(){s.selected=[];s.exportOpen=false;}
function reset(){s={stage:'intro',mode:modes.length===1?modes[0]:null,positions:Object.fromEntries(modes.map(m=>[m,Math.max(0,prompts(m).findIndex(p=>p.id===D.interactionContract.modeChoice?.options.find(o=>o.value===m)?.startSectionId))])),all:Object.fromEntries(modes.map(m=>[m,false])),notes:Object.create(null),writing:false,selected:[],exportOpen:false,branchChanged:false};}reset();
function entries(){return fields.filter(f=>s.notes[f.key]?.trim()&&(!D.examples||prompts().some(p=>p.fields?.some(x=>x.key===f.key)))).map(f=>({key:f.key,label:f.label,text:s.notes[f.key]}));}
return Object.freeze({snapshot:()=>({...s,notes:{...s.notes},positions:{...s.positions},all:{...s.all},selected:[...s.selected],shortcut}),prompts,reset,personal:()=>Object.values(s.notes).some(v=>v.trim()),
 note:(key,value)=>{if(!keys.has(key))throw Error('Unknown note');s.notes[key]=String(value);invalidate();},writing:value=>{s.writing=Boolean(value);if(!s.writing)invalidate();},
 mode:value=>{if(!modes.includes(value))throw Error('Unknown mode');s.branchChanged=Boolean(D.examples&&s.mode&&s.mode!==value&&Object.values(s.notes).some(v=>v.trim()));s.mode=value;invalidate();},
 position:(value,all=false)=>{if(!s.mode)return;s.positions[s.mode]=Math.max(0,Math.min(prompts().length-1,Number(value)||0));s.all[s.mode]=Boolean(all);},stage:value=>{if(!['intro','practice','close'].includes(value))throw Error('Unknown stage');s.stage=value;invalidate();},entries,
 openExport:()=>{s.writing=true;s.exportOpen=true;s.selected=[];},selectExport:(key,value)=>{if(!s.exportOpen||!entries().some(e=>e.key===key))throw Error('Unknown export item');s.selected=s.selected.filter(k=>k!==key);if(value)s.selected.push(key);},exportText:()=>s.writing&&s.exportOpen?entries().filter(e=>s.selected.includes(e.key)).map(e=>e.label+'\n'+e.text).join('\n\n'):'',
 saveShortcut:()=>{shortcut=true;return{canonicalId:D.id,resourceId:D.resourceId};},clearSession:()=>{shortcut=false;reset();}});}
return Object.freeze({create});});
