
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.ValidationOthersModel=api;})(typeof window!=='undefined'?window:globalThis,()=>{'use strict';
function create(D){const fields=[...D.practice,...D.approaches.map(a=>a.attempt),...D.responses.map(r=>r.content)].flatMap(p=>p.fields||[]),keys=new Set(fields.map(f=>f.key));let s,shortcut=false;
function invalidate(){s.selected=[];s.exportOpen=false;}
function reset(){s={stage:'intro',mode:'practice',approach:null,reply:null,positions:{practice:0},all:{practice:false},notes:Object.create(null),writing:false,selected:[],exportOpen:false,branchChanged:false};}reset();
const currentFields=()=>[...D.practice,...D.approaches.filter(a=>a.key===s.approach).map(a=>a.attempt),...D.responses.filter(r=>r.key===s.reply).map(r=>r.content)].flatMap(p=>p.fields||[]);
function entries(){return currentFields().filter(f=>s.notes[f.key]?.trim()).map(f=>({key:f.key,label:f.label,text:s.notes[f.key]}));}
function choice(type,value){const list=type==='approach'?D.approaches:D.responses;if(value!==null&&!list.some(x=>x.key===value))throw Error('Unknown '+type);if(s[type]!==value&&Object.values(s.notes).some(v=>v.trim()))s.branchChanged=true;s[type]=value;invalidate();}
return Object.freeze({snapshot:()=>({...s,notes:{...s.notes},positions:{...s.positions},all:{...s.all},selected:[...s.selected],shortcut}),prompts:()=>D.practice,reset,personal:()=>Object.values(s.notes).some(v=>v.trim()),
 note:(key,value)=>{if(!currentFields().some(f=>f.key===key))throw Error('Unknown or inactive note');if(['situation','known'].includes(key)&&s.notes[key]!==String(value)&&Object.values(s.notes).some(v=>v.trim()))s.branchChanged=true;s.notes[key]=String(value);invalidate();},writing:value=>{s.writing=Boolean(value);if(!s.writing)invalidate();},approach:value=>choice('approach',value),reply:value=>choice('reply',value),
 position:(value,all=false)=>{s.positions.practice=Math.max(0,Math.min(D.practice.length-1,Number(value)||0));s.all.practice=Boolean(all);},stage:value=>{if(!['intro','practice','close'].includes(value))throw Error('Unknown stage');s.stage=value;invalidate();},entries,
 openExport:()=>{s.writing=true;s.exportOpen=true;s.selected=[];},selectExport:(key,value)=>{if(!s.exportOpen||!entries().some(e=>e.key===key))throw Error('Unknown export item');s.selected=s.selected.filter(k=>k!==key);if(value)s.selected.push(key);},exportText:()=>s.writing&&s.exportOpen?entries().filter(e=>s.selected.includes(e.key)).map(e=>e.label+'\n'+e.text).join('\n\n'):'',
 saveShortcut:()=>{shortcut=true;return{canonicalId:D.id,componentId:D.componentId,resourceId:D.resourceId};},clearSession:()=>{shortcut=false;reset();}});}
return Object.freeze({create});});
