
(()=>{'use strict';
if(!/(?:^|\/)(worry-visual|urge-visual)\/(?:index\.html)?$/.test(location.pathname))return;
const original=document.querySelector('header.design-header');
if(!original||document.getElementById('shared-support-header'))return;
const oldTitle=document.title,header=document.createElement('header');
header.id='shared-support-header';header.className='design-header';header.hidden=true;
const brand=document.createElement('a');brand.className='brand';brand.href='../skills-library/';brand.textContent='A Place to Practise';
const mode=document.createElement('div');mode.className='design-mode';
const label=document.createElement('span');label.textContent='Shared support and urgent help';
const status=document.createElement('span');status.className='draft-tag';status.textContent='PUBLIC REVIEW';mode.append(label,status);
const nav=document.createElement('nav');nav.className='preview-nav';nav.setAttribute('aria-label','Shared support navigation');
const back=document.createElement('a');back.href='../skills-library/';back.textContent='Back to skills library';nav.append(back);
header.append(brand,mode,nav);original.after(header);
const css=document.createElement('style');css.textContent='body.shared-support-route > header.design-header:not(#shared-support-header){display:none!important}#shared-support-header[hidden]{display:none!important}';document.head.append(css);
function update(){
 const active=location.hash==='#page/urgent-support';
 document.body.classList.toggle('shared-support-route',active);header.hidden=!active;
 document.title=active?'Support and urgent help · A Place to Practise':oldTitle;
 if(active){const returnLink=document.querySelector('#crisis-now [data-preview-return]');if(returnLink){returnLink.textContent='Back to skills library';returnLink.setAttribute('href','../skills-library/');}}
}
addEventListener('hashchange',update);addEventListener('pageshow',update);update();
})();
