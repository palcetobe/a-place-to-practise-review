
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.InterpersonalPilotModel=api;})(typeof window!=='undefined'?window:globalThis,()=>{'use strict';
function create(D){let s;function reset(){s={move:null,recovery:false,version:null,reaction:null,scenario:null,phrase:null,actions:Object.create(null)};}reset();
function select(kind,id){const list={move:D.moves,version:D.versions,reaction:D.reactions,scenario:D.scenarios,phrase:D.scenarios?.find(x=>x.id===s.scenario)?.phrases}[kind];if(!list||(id!==null&&!list.some(x=>x.id===id)))throw Error('Unknown fictional choice');if(kind==='scenario'&&s.scenario!==id){s.actions=Object.create(null);s.phrase=null;}s[kind]=id;if(kind==='move')s.recovery=false;}
function act(id){if(!s.phrase||!D.actions.some(x=>x.id===id))throw Error('Unknown fictional action');s.actions[s.phrase]=id;}
function outputs(){return(D.scenarios?.find(x=>x.id===s.scenario)?.phrases||[]).map(p=>({id:p.id,text:s.actions[p.id]==='trim'?'':s.actions[p.id]==='change'?p.alternative:p.original,uncertain:s.actions[p.id]==='uncertain',action:s.actions[p.id]||null}));}
return Object.freeze({reset,select,act,snapshot:()=>({...s,actions:{...s.actions}}),recover:()=>{s.recovery=true;s.move=null;},outputs,preview:()=>outputs().map(x=>x.text).filter(Boolean).join(' ')});}
return Object.freeze({create});});
