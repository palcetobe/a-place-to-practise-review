
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.WiseMindGuidedModel=api;})(typeof window!=='undefined'?window:globalThis,()=>{'use strict';
function create(content){const keys=new Set(content.practice.flatMap(p=>p.fields.map(f=>f.key)));let state;
function reset(view='guided'){if(!['guided','retained'].includes(view))throw Error('Unknown view');state={view,stage:'intro',writing:false,notes:Object.create(null),position:0,showAll:false,scenarioOpen:true,paused:false,retainedNote:'',retainedAck:false,exportOpen:false,exportSelected:false};}reset();
const personal=()=>Object.values(state.notes).some(v=>v.trim())||Boolean(state.retainedNote.trim());
return Object.freeze({snapshot:()=>({...state,notes:{...state.notes}}),personal,
 note:(key,value)=>{if(state.view!=='guided'||!keys.has(key))throw Error('Unknown guided field');state.notes[key]=String(value);},
 retainedNote:value=>{if(state.view!=='retained')throw Error('Wrong note owner');state.retainedNote=String(value);state.exportOpen=false;state.exportSelected=false;state.retainedAck=false;},
 writing:show=>{state.writing=Boolean(show);if(!state.writing){state.exportOpen=false;state.exportSelected=false;}},
 position:(index,all=false)=>{state.position=Math.max(0,Math.min(content.practice.length-1,Number(index)||0));state.showAll=Boolean(all);state.paused=false;},
 practice:()=>{state.stage='practice';},intro:()=>{state.stage='intro';state.paused=false;},close:()=>{state.stage='close';state.paused=false;},
 pause:()=>{if(state.view!=='guided'||state.stage!=='practice'||(!state.showAll&&state.position!==1))throw Error('Pause belongs to the ask prompt');state.paused=true;},
 returnQuestion:()=>{state.paused=false;},consider:()=>{state.stage='practice';state.position=2;state.showAll=false;state.paused=false;},
 scenario:open=>{state.scenarioOpen=Boolean(open);},acknowledge:()=>{if(state.view!=='retained')throw Error('Wrong view');state.retainedAck=true;},
 openExport:()=>{if(state.view!=='retained')throw Error('No export in guided practice');state.writing=true;state.exportOpen=true;state.exportSelected=false;},
 selectExport:selected=>{state.exportSelected=state.view==='retained'&&state.exportOpen&&Boolean(state.retainedNote.trim())&&Boolean(selected);},
 closeExport:()=>{state.exportOpen=false;state.exportSelected=false;},
 exportText:()=>state.view==='retained'&&state.exportOpen&&state.exportSelected&&state.retainedNote.trim()?'What I considered\n'+state.retainedNote.trim():'',
 switchView:(next,confirmed=false)=>{if(!['guided','retained'].includes(next))throw Error('Unknown view');if(next===state.view)return true;if(personal()&&!confirmed)return false;reset(next);return true;},
 leave:(confirmed=false)=>{if(personal()&&!confirmed)return false;reset();return true;},reset});}
return Object.freeze({create});});
