
(()=>{'use strict';
const E=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
function audio(title){if(window.PracticeNarration)return window.PracticeNarration.control(title);const b=E('span','written-only-placeholder');b.hidden=true;b.disabled=true;b.setAttribute('aria-hidden','true');return b}
function focusWorkspace({sections,titles,resolveIndex=i=>i,initialIndex=0,initialAll=false,onPosition}){const workspace=E('div','practice-workspace'),nav=E('nav','prompt-navigation');nav.setAttribute('aria-label','Choose any practice prompt');const stageBox=E('div','focus-stage'),controls=E('div','focus-moves');let index=0,all=Boolean(initialAll);const jumpButtons=[];const show=(next,focus=true)=>{if(!sections.length)return;index=resolveIndex(Math.max(0,Math.min(sections.length-1,next)));sections.forEach((s,i)=>s.hidden=resolveIndex(i)!==i||(!all&&i!==index));jumpButtons.forEach((b,i)=>b.setAttribute('aria-current',i===index?'location':'false'));previous.disabled=index===0;nextButton.disabled=index===sections.length-1;counter.textContent='Prompt '+(index+1)+' of '+sections.length+' · not a score';onPosition?.(index,all);if(focus){const h=sections[index].querySelector('h3,h4,summary');if(h){if(h.tagName!=='SUMMARY')h.tabIndex=-1;h.focus({preventScroll:true});h.scrollIntoView({block:'nearest'})}}};sections.forEach((s,i)=>{const b=E('button','prompt-jump',titles[i]);b.type='button';b.onclick=()=>{all=false;allButton.textContent='Show all prompts';show(i)};nav.append(b);jumpButtons.push(b);stageBox.append(s)});const previous=E('button','secondary-action','Previous prompt'),nextButton=E('button','secondary-action','Next prompt'),counter=E('span','prompt-location'),allButton=E('button','text-action',all?'Show one prompt':'Show all prompts');for(const b of [previous,nextButton,allButton])b.type='button';previous.onclick=()=>show(index-1);nextButton.onclick=()=>show(index+1);allButton.onclick=()=>{all=!all;allButton.textContent=all?'Show one prompt':'Show all prompts';show(index,false)};controls.append(previous,counter,nextButton);nav.append(allButton);workspace.append(nav,stageBox,controls);show(initialIndex,false);return workspace}
function choices({mount,title,practice,onPractice,onReading,renderReading,panelId}){
 const strip=E('nav','skill-choices');strip.setAttribute('aria-label','Ways to use this skill');
 const panel=E('section','skill-reading');panel.hidden=true;panel.id=panelId||'guided-skill-reading';
 practice=practice||E('button','choice','Practice this skill');practice.textContent='Practice this skill';practice.classList.remove('primary-action');practice.classList.add('skill-choice');practice.type='button';
 const example=E('button','choice skill-choice','See an example'),learn=E('button','choice skill-choice','Learn more');
 const readingControls=[[example,'example'],[learn,'learn']];let lowerStrip=null,activeReading=null;
 function syncReading(){for(const [control,kind]of readingControls)control.setAttribute('aria-expanded',String(kind===activeReading));}
 function configureReading(control){control.type='button';control.setAttribute('aria-controls',panel.id);control.setAttribute('aria-expanded','false');}
 for(const b of [example,learn])configureReading(b);
 const close=()=>{panel.hidden=true;activeReading=null;syncReading();};
 practice.onclick=()=>{close();onPractice?.();};
 const show=kind=>{onReading?.(kind);panel.replaceChildren();panel.hidden=false;activeReading=kind;syncReading();const h=renderReading(kind,panel);if(h){if(h.tagName!=='SUMMARY')h.tabIndex=-1;h.focus({preventScroll:true});h.scrollIntoView({block:'nearest'});}};
 example.onclick=()=>show('example');learn.onclick=()=>show('learn');strip.append(practice,example,learn);title.after(strip);strip.after(panel);
 
 
 
 function repeatAfter(description){
  if(!description)return null;
  if(!lowerStrip){
   strip.setAttribute('aria-label','Ways to use this skill, above description');strip.dataset.choicePosition='above';
   lowerStrip=E('nav','skill-choices');lowerStrip.dataset.choicePosition='below';lowerStrip.setAttribute('aria-label','Ways to use this skill, below description');
   for(const [original,kind]of [[practice,'practice'],[example,'example'],[learn,'learn']]){
    const control=E('button',original.className,original.textContent);control.type='button';control.disabled=original.disabled;
    if(kind!=='practice'){configureReading(control);readingControls.push([control,kind]);}
    control.onclick=()=>original.click();lowerStrip.append(control);
   }
   syncReading();
  }
  description.after(lowerStrip);return lowerStrip;
 }
 if((mount.dataset.designStage||mount.dataset.stage)==='intro')repeatAfter(mount.querySelector('.orientation-sheet'));
 return {strip,panel,show,close,repeatAfter};
}
function secondaryNavigation({header,returnLink,introLink,historyLink,urgentLink}){if(!header)return;const nav=E('nav','preview-nav');nav.setAttribute('aria-label','Practice navigation');for(const [i,item]of [returnLink,introLink,historyLink,urgentLink].entries()){if(!item)continue;const a=item.tagName==='A'?item:E('a','',item.label);if(item.tagName!=='A')a.href=item.href;if(i===0)a.dataset.projectReturn='';nav.append(a)}const old=header.querySelector('.preview-nav');if(old)old.replaceWith(nav);else header.append(nav);return nav}
window.GuidedFocusComponents=Object.freeze({E,audio,focusWorkspace,choices,secondaryNavigation});
})();
