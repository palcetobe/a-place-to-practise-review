
(()=>{'use strict';
const home=document.getElementById('preview-home');if(!home)return;
const destination='#page/tool-library';
const tools=Object.freeze({
 urge:{route:'#tool/urge-surfing',copy:'Optional notes, ratings and choices are no longer in this practice.'},
 'looping-thought':{route:'#tool/looping-thought',copy:'Optional writing and choices are no longer in this practice.'}
});
let receipt=null,notice=null;
function invalidate(){receipt=null;if(notice)notice.remove();notice=null;}
function completed(tool,reason){
 invalidate();
 if(reason!=='finish-and-clear'||!Object.hasOwn(tools,tool)||location.hash!==tools[tool].route)return;
 receipt={tool,landed:false};
}
function hashOf(url){try{return new URL(url).hash}catch(_){return null}}
function route(event){
 const current=receipt;
 if(!current)return;
 
 
 if(current.landed||hashOf(event.oldURL)!==tools[current.tool].route||hashOf(event.newURL)!==destination||location.hash!==destination){invalidate();return;}
 current.landed=true;
 
 queueMicrotask(()=>{
  if(receipt!==current)return;
  if(location.hash!==destination||home.hidden){invalidate();return;}
  notice=document.createElement('section');notice.dataset.practiceCleared='';
  const heading=document.createElement('h2');heading.textContent='This practice has been cleared.';heading.tabIndex=-1;
  const detail=document.createElement('p');detail.textContent=tools[current.tool].copy;
  notice.append(heading,detail);home.prepend(notice);
  heading.focus({preventScroll:true});heading.scrollIntoView({block:'nearest',behavior:'instant'});
 });
}
addEventListener('hashchange',route);



addEventListener('popstate',()=>{if(receipt?.landed)invalidate()});
for(const event of ['pagehide','pageshow','mm:routechange'])addEventListener(event,invalidate);
addEventListener('storage',event=>{if(event.key==='mm_clear_epoch')invalidate()});
window.PracticeClearLanding=Object.freeze({completed,invalidate});
})();
