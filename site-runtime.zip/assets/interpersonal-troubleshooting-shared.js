
(()=>{'use strict';
const D=window.InterpersonalContent,P=window.InterpersonalTroubleshootingContent,C=window.GuidedFocusComponents,E=C.E,host=document.getElementById('interpersonal-host');let active=null;
const anchors={'tool/dearman':'dear.practice.review','tool/give':'give.practice.review','tool/fast':'fast.practice.review'};
function button(label,fn,key){const b=E('button','text-action',label);b.type='button';b.onclick=fn;b.dataset.troubleshootingControl=key;return b;}
function closeAll(returnFocus=false){if(!active)return;const old=active;active=null;old.view.clear();old.panel.remove();host.hidden=old.hostHidden;old.trigger.setAttribute('aria-expanded','false');if(returnFocus&&old.trigger.isConnected){old.trigger.focus({preventScroll:true});window.scrollTo?.(old.scrollX,old.scrollY);}}
function returnToHost(){if(!active)return;const old=active;if(old.view.personal()&&!confirm('Return to '+D.title+' and clear this troubleshooting practice’s optional writing? Your '+D.title+' notes stay in this open page.'))return;closeAll(true);}
function open(trigger,onExit){if(active||document.getElementById('interpersonal-priorities-panel'))return;window.InterpersonalPilots?.closeAll(false);
const panel=E('section');panel.id='interpersonal-troubleshooting-panel';panel.setAttribute('role','region');panel.setAttribute('aria-label',P.title+' within '+D.title);panel.dataset.canonicalId=P.id;panel.dataset.componentId=P.componentId;panel.dataset.resourceId=P.resourceId;panel.dataset.hostCanonicalId=D.id;panel.dataset.hostResourceId=D.resourceId;
const root=E('section','df-host clinical-guided');root.id='interpersonal-troubleshooting-host';root.setAttribute('aria-label',P.title);
panel.append(button('Return to '+D.title,returnToHost,'return-top'),E('p','source-note','Returning clears only this troubleshooting practice’s writing. Your '+D.title+' writing stays in this open page. No notes move between the two practices.'),root,button('Return to '+D.title,returnToHost,'return-bottom'));
panel.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation?.();returnToHost();}});
const hostHidden=host.hidden,scrollX=window.scrollX||0,scrollY=window.scrollY||0;host.after(panel);host.hidden=true;trigger.setAttribute('aria-expanded','true');
const view=window.InterpersonalTroubleshootingRenderer.mount(root,{embedded:true,onExit});active={panel,root,view,trigger,hostHidden,scrollX,scrollY};view.focus();}
function mount(part,parent,onExit){if(part.id!==anchors[D.resourceId])return;const trigger=button('Explore an interpersonal difficulty',()=>open(trigger,onExit),'open');trigger.dataset.troubleshootingOpen=P.componentId;trigger.setAttribute('aria-expanded','false');trigger.setAttribute('aria-controls','interpersonal-troubleshooting-panel');parent.append(trigger);}
document.addEventListener('visibilitychange',()=>{if(document.hidden)active?.view.pause();});
window.InterpersonalTroubleshooting=Object.freeze({mount,closeAll,personal:()=>Boolean(active?.view.personal())});
})();
