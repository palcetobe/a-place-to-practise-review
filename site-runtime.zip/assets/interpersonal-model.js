
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.InterpersonalModel=api;})(typeof window!=='undefined'?window:globalThis,()=>{'use strict';
function create(content,legacy){const fields=content.practice.flatMap(p=>p.fields||[]),keys=new Set(fields.map(f=>f.key));let s;
function reset(){s={stage:'intro',writing:false,notes:Object.create(null),context:null,response:null,choices:Object.create(null),stale:false,position:0,all:false,closing:false,selected:[],exportOpen:false,shortcut:false};}reset();
const personal=()=>Object.values(s.notes).some(v=>v.trim());
function invalidate(){s.selected=[];s.exportOpen=false;}
function choose(kind,id){let valid;if(kind==='context')valid=[null,'personal','fictional'].includes(id);else if(kind==='response')valid=id===null||content.responses.some(x=>x.id===id);else valid=id===null||content.choices?.find(x=>x.id===kind)?.options.some(x=>x.id===id);if(!valid)throw Error('Unknown choice');const old=['context','response'].includes(kind)?s[kind]:s.choices[kind];if(old!==id&&personal())s.stale=true;if(['context','response'].includes(kind))s[kind]=id;else s.choices[kind]=id;invalidate();}
function preview(){const n=s.notes;if(content.resourceId==='tool/dearman'){const parts=['dm-d','dm-e','dm-a','dm-r'].map(k=>(n[k]||'').trim()).filter(Boolean);if(parts.length&&s.closing)parts.push(legacy.closing);return parts.join(' ');}return legacy.preview.map(([key,prefix,suffix])=>n[key]?.trim()?prefix+n[key].trim()+(suffix||''):'').filter(Boolean).join('\n');}
function entries(){const rows=fields.filter(f=>s.notes[f.key]?.trim()).map(f=>({key:f.key,label:f.label,text:s.notes[f.key]}));const draft=preview();if(draft)rows.push({key:'built-preview',label:content.resourceId==='tool/dearman'?'DEAR draft':'Contextual note preview',text:draft});return rows;}
return Object.freeze({snapshot:()=>({...s,notes:{...s.notes},choices:{...s.choices},selected:[...s.selected]}),reset,personal,choose,preview,entries,
 note:(key,value)=>{if(!keys.has(key))throw Error('Unknown note');s.notes[key]=String(value);invalidate();if(!personal())s.stale=false;},
 writing:value=>{s.writing=Boolean(value);if(!s.writing)invalidate();},closing:value=>{s.closing=Boolean(value);invalidate();},
 stage:value=>{if(!['intro','practice','close'].includes(value))throw Error('Unknown stage');s.stage=value;},position:(value,all=false)=>{s.position=Math.max(0,Math.min(content.practice.length-1,Number(value)||0));s.all=Boolean(all);},
 openExport:()=>{s.writing=true;s.exportOpen=true;s.selected=[];},selectExport:(key,value)=>{if(!s.exportOpen||!entries().some(e=>e.key===key))throw Error('Unknown export item');s.selected=s.selected.filter(k=>k!==key);if(value)s.selected.push(key);},exportText:()=>s.writing&&s.exportOpen?entries().filter(e=>s.selected.includes(e.key)).map(e=>e.label+'\n'+e.text).join('\n\n'):'',
 saveShortcut:()=>{s.shortcut=true;return {canonicalId:content.id,resourceId:content.resourceId,...content.legacyCompatibility.savedIdentity};},history:inside=>{if(!inside)reset();}});}
return Object.freeze({create});});
