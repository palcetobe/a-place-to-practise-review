/* Optional draft recordings, bound only to exact authored text and registered renderer controls. */
(() => {
  'use strict';
  const base = window.PublicReviewPaths?.base;
  const data = window.PublicPracticeRecordings;
  if (!base || !data || location.origin !== base.origin || !location.pathname.startsWith(base.pathname)) return;
  const route = location.pathname.slice(base.pathname.length).replace(/index\.html$/, '').replace(/\/?$/, '/');
  const entries = new Map((data.routes[route] || []).map(x => [x.id, Object.freeze({...x})]));
  if (!entries.size) return;
  const forbidden = 'input,textarea,select,[contenteditable],[data-private-writing],[data-df-writing-field],[data-optional-notes],.private-echo,.context-entries,.writing-space,[data-df-transcript],[data-panel-transcript],.reading-script,.export-panel,.visual-private';
  const registered = new Map(), mutableLabels = new WeakSet();
  let active = null, generation = 0, scheduled = false;
  const same = (a, b) => a.length === b.length && a.every((n, i) => n === b[i]);
  const parents = n => { const a = []; for (let p = n.parentElement; p; p = p.parentElement) a.push(p); return a; };
  const children = scope => Array.from(scope.children).filter(n => n.hasAttribute('data-narration-text'));
  function visible(n) {
    if (!n?.isConnected || n.ownerDocument !== document || document.hidden) return false;
    for (let p = n; p; p = p.parentElement) {
      if (p.hidden || p.inert || p.getAttribute('aria-hidden') === 'true') return false;
      const css = getComputedStyle(p);
      if (css.display === 'none' || css.visibility === 'hidden' || css.visibility === 'collapse' || css.contentVisibility === 'hidden' || Number(css.opacity) === 0) return false;
      if (p.tagName === 'DETAILS' && !p.open && !p.querySelector(':scope > summary')?.contains(n)) return false;
    }
    return n.getClientRects().length > 0;
  }
  function safe(n) {
    return n.tagName === 'P' && !n.closest(forbidden) && !n.querySelector(forbidden) && visible(n) && Array.from(n.querySelectorAll('*')).every(visible);
  }
  function capture(binding) {
    const button = binding.button, id = button.dataset.narrationId, clip = entries.get(id);
    const scope = button.closest('[data-narration-segment]');
    if (!clip || !scope || scope.dataset.narrationSegment !== id || !scope.closest('main') || scope.closest(forbidden)) return false;
    const controls = Array.from(scope.querySelectorAll('[data-narration-id]')).filter(n => n.closest('[data-narration-segment]') === scope);
    const nodes = children(scope);
    if (controls.length !== 1 || controls[0] !== button || !nodes.length || nodes.some(n => n.tagName !== 'P' || n.closest(forbidden) || n.querySelector(forbidden))) return false;
    if (nodes.map(n => n.textContent).join('\n\n') !== clip.text) return false;
    binding.id = id; binding.clip = clip; binding.scope = scope; binding.nodes = nodes;
    return true;
  }
  function exact(binding) {
    const {button, scope, nodes, id, clip} = binding;
    return !!scope && button.isConnected && scope.isConnected && button.closest('[data-narration-segment]') === scope && scope.dataset.narrationSegment === id && button.dataset.narrationId === id &&
      same(nodes, children(scope)) && nodes.every(safe) && nodes.map(n => n.textContent).join('\n\n') === clip.text &&
      !scope.closest(forbidden) && visible(button) && visible(scope) &&
      same(binding.scopeParents, parents(scope)) && same(binding.buttonParents, parents(button)) &&
      Array.from(scope.querySelectorAll('[data-narration-id]')).filter(n => n.closest('[data-narration-segment]') === scope).length === 1;
  }
  function setText(n, s) { if (n.textContent !== s) n.textContent = s; }
  function paint(binding) {
    const mine = active?.binding === binding, phase = mine ? active.phase : 'idle';
    const label = phase === 'playing' ? 'Pause' : phase === 'paused' ? 'Resume' : phase === 'loading' ? 'Cancel loading' : 'Listen';
    setText(binding.button, label);
    binding.button.setAttribute('aria-label', label + ': ' + (binding.clip?.title || binding.title));
    binding.button.setAttribute('aria-pressed', String(phase === 'playing'));
    if (binding.stop) binding.stop.disabled = !mine;
    if (binding.replay) binding.replay.disabled = !mine || phase === 'loading';
  }
  function stop(message = 'Stopped.') {
    generation++;
    const previous = active; active = null;
    if (previous) {
      previous.audio.onplaying = previous.audio.onpause = previous.audio.onended = previous.audio.onerror = previous.audio.onwaiting = previous.audio.ontimeupdate = null;
      previous.audio.pause();
      previous.audio.removeAttribute('src');
      previous.audio.load();
      setText(previous.binding.status, message);
      paint(previous.binding);
    }
  }
  function current(session) { return active === session && generation === session.generation && exact(session.binding); }
  function play(binding, restart = false) {
    if (!exact(binding)) { stop(); refresh(); return; }
    if (!restart && active?.binding === binding) {
      if (active.phase === 'loading') { stop(); return; }
      if (active.phase === 'playing') { active.audio.pause(); active.phase = 'paused'; setText(binding.status, 'Paused.'); paint(binding); return; }
      if (active.phase === 'paused') { active.phase = 'loading'; paint(binding); begin(active); return; }
    }
    stop();
    const audio = new Audio(); audio.preload = 'none';
    const url = new URL('assets/narration/audio/' + binding.clip.file, base);
    if (url.origin !== base.origin || !url.pathname.startsWith(base.pathname + 'assets/narration/audio/')) return;
    const session = {binding, audio, generation, phase: 'loading'};
    active = session;
    audio.onplaying = () => { if (!current(session)) { audio.pause(); return; } session.phase = 'playing'; setText(binding.status, 'Playing draft recording.'); paint(binding); };
    audio.onpause = () => { if (!current(session) || session.phase === 'loading') return; session.phase = 'paused'; setText(binding.status, 'Paused.'); paint(binding); };
    audio.onended = () => { if (current(session)) stop('Recording ended.'); };
    audio.onerror = () => { if (current(session)) stop('Audio unavailable. You can read the text and try again.'); };
    audio.onwaiting = () => { if (current(session)) setText(binding.status, 'Loading draft recording…'); };
    audio.ontimeupdate = () => { if (active === session && !current(session)) stop(); };
    audio.src = url.href;
    setText(binding.status, 'Loading draft recording…'); paint(binding); begin(session);
  }
  function begin(session) {
    document.dispatchEvent(new CustomEvent('narration-start', {detail: {id: session.binding.id}}));
    observer.takeRecords();
    if (!current(session)) { if (active === session) stop(); return; }
    try {
      const pending = session.audio.play();
      pending?.catch(() => { if (current(session)) stop('Playback could not start. Select Listen to try again.'); });
    } catch (_) { if (current(session)) stop('Playback could not start. Select Listen to try again.'); }
  }
  function install(binding) {
    if (!capture(binding)) return;
    const group = document.createElement('span'); group.className = 'practice-narration-controls'; group.dataset.narrationControls = '';
    binding.button.before(group); group.append(binding.button); binding.group = group;
    binding.button.hidden = false; binding.button.removeAttribute('aria-hidden'); binding.button.className = 'narration';
    binding.button.title = 'Optional draft recording of the visible text. Listening and clinical review remain pending.';
    binding.stop = document.createElement('button'); binding.stop.type = 'button'; binding.stop.textContent = 'Stop'; binding.stop.className = 'narration'; binding.stop.setAttribute('aria-label', 'Stop: ' + binding.clip.title); binding.stop.onclick = () => stop();
    binding.replay = document.createElement('button'); binding.replay.type = 'button'; binding.replay.textContent = 'Replay'; binding.replay.className = 'narration'; binding.replay.setAttribute('aria-label', 'Replay: ' + binding.clip.title); binding.replay.onclick = () => play(binding, true);
    binding.status = document.createElement('span'); binding.status.className = 'practice-narration-status'; binding.status.setAttribute('role', 'status'); binding.status.setAttribute('aria-live', 'polite'); binding.status.textContent = 'Draft recording';
    group.append(binding.replay, binding.stop, binding.status);
    binding.scopeParents = parents(binding.scope); binding.buttonParents = parents(binding.button);
    binding.button.addEventListener('click', () => play(binding));
    mutableLabels.add(binding.button); mutableLabels.add(binding.status);
    binding.installed = true; paint(binding);
  }
  function refresh() {
    scheduled = false;
    for (const [button, binding] of registered) {
      if (!button.isConnected) {
        if (active?.binding === binding) stop();
        registered.delete(button);
        continue;
      }
      if (!binding.installed) install(binding);
      if (!binding.installed) continue;
      const ready = exact(binding);
      if (!ready && active?.binding === binding) stop();
      if (button.disabled === ready) button.disabled = !ready;
      paint(binding);
    }
  }
  function queue() { if (!scheduled) { scheduled = true; queueMicrotask(refresh); } }
  function control(title) {
    const button = document.createElement('button'); button.type = 'button'; button.hidden = true; button.disabled = true;
    button.setAttribute('aria-hidden', 'true');
    registered.set(button, {button, title, installed: false});
    return button;
  }
  Object.defineProperty(window, 'PracticeNarration', {value: Object.freeze({control}), writable: false, configurable: false});
  const observer = new MutationObserver(records => {
    const relevant = records.some(record => {
      const target = record.target.nodeType === 1 ? record.target : record.target.parentElement;
      if (record.type === 'attributes') return !target?.closest('[data-narration-controls]') || !['aria-label', 'aria-pressed', 'disabled'].includes(record.attributeName);
      return !mutableLabels.has(target);
    });
    if (relevant) { stop(); queue(); }
  });
  observer.observe(document.documentElement, {subtree: true, childList: true, characterData: true, attributes: true});
  document.addEventListener('click', event => { if (!event.target.closest('[data-narration-controls]')) stop(); }, true);
  for (const event of ['input', 'change']) document.addEventListener(event, () => stop(), true);
  document.addEventListener('toggle', () => { stop(); queue(); }, true);
  document.addEventListener('practice-aid-start', () => stop());
  document.addEventListener('practice-branch-change', () => { stop(); queue(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) stop(); queue(); });
  for (const event of ['pagehide', 'pageshow', 'hashchange', 'popstate']) window.addEventListener(event, () => { stop(); queue(); });
  window.addEventListener('resize', () => { if (active && !exact(active.binding)) stop(); });
  queue();
})();
