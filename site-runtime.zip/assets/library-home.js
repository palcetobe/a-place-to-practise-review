(function () {
  'use strict';
  // Preserve every non-home legacy route while making the current library the entrance.
  var script = document.currentScript;
  var library = new URL('../skills-library/', script.src);
  var redirecting = false;
  function routeHomeToLibrary() {
    if (!['', '#', '#home', '#page/home'].includes(window.location.hash)) {
      redirecting = false;
      return false;
    }
    if (!redirecting) {
      redirecting = true;
      library.search = window.location.search;
      window.location.replace(library.href);
    }
    return true;
  }
  Object.defineProperty(window, 'routeHomeToLibrary', {value: routeHomeToLibrary});
  // A restored document must be able to navigate Home again after browser Back.
  window.addEventListener('pageshow', function () { redirecting = false; });
  routeHomeToLibrary();
}());
