/* Explicit legacy renderer hook. Only fixed authored direct paragraphs are eligible. */
(() => {
  'use strict';
  const base = window.PublicReviewPaths?.base;
  if (!base || !window.PracticeNarration || location.origin !== base.origin) return;
  const route = location.pathname.slice(base.pathname.length).replace(/index\.html$/, '').replace(/\/?$/, '/');
  if (!['worry-visual/', 'urge-visual/'].includes(route)) return;
  const clips = new Map((window.PublicPracticeRecordings?.routes[route] || []).map(x => [x.id, x]));
  const forbidden = 'input,textarea,select,[contenteditable],[data-private-writing],[data-optional-notes],.writing-space,[data-panel-transcript]';
  function bind(host, id, values) {
    const clip = clips.get(id);
    if (!host || !clip || !Array.isArray(values) || values.join('\n\n') !== clip.text || host.closest(forbidden)) return false;
    if (host.hasAttribute('data-narration-segment')) {
      const controls = Array.from(host.querySelectorAll('[data-narration-id]')).filter(n => n.closest('[data-narration-segment]') === host);
      if (controls.length) return host.dataset.narrationSegment === id;
      host.removeAttribute('data-narration-segment');
    }
    const nodes = Array.from(host.children).filter(n => n.tagName === 'P' && values.includes(n.textContent));
    if (nodes.length !== values.length || nodes.some((n, i) => n.textContent !== values[i] || n.closest(forbidden) || n.querySelector(forbidden))) return false;
    host.dataset.narrationSegment = id;
    nodes.forEach(n => n.dataset.narrationText = '');
    const button = window.PracticeNarration.control(clip.title);
    button.dataset.narrationId = id;
    nodes[0].before(button);
    return true;
  }
  Object.defineProperty(window, 'LegacyPracticeNarration', {value: Object.freeze({bind}), writable: false, configurable: false});
})();
