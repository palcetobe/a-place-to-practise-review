/* Explicit retained renderer registrations. Only contiguous, literal authored paragraphs. */
(() => {
  'use strict';
  const base=window.PublicReviewPaths?.base;
  if(!base||!window.PracticeNarration||location.origin!==base.origin)return;
  const paths={'retained-classics/thought-record/native.html':'retained-classics/thought-record/','retained-classics/saying-no/native.html':'retained-classics/saying-no/'};
  const route=paths[location.pathname.slice(base.pathname.length)];if(!route)return;
  const clips=new Map((window.PublicPracticeRecordings?.routes[route]||[]).map(r=>[r.id,r]));
  const forbidden='input,textarea,select,[contenteditable],[data-private],[data-private-writing],[data-retained-private],[data-user-content],[data-dynamic-note],.record,.chosen-thought,.private-echo,.preview,#preview,.field';
  const direct=(host,tag)=>host?Array.from(host.children).filter(n=>n.tagName===tag):[];
  const ps=host=>direct(host,'P');
  const detail=(host,title)=>Array.from(host?.querySelectorAll('details')||[]).find(n=>n.querySelector(':scope>summary')?.textContent===title);
  const privateDetail=node=>{for(let p=node;p;p=p.parentElement)if(p.tagName==='DETAILS'&&p.querySelector(':scope>summary')?.textContent==='Review my scenario and first reply')return true;return false;};
  function apply(main,plans,validate){
    for(const [id,nodes,condition]of plans){
      const eligible=condition||validate;
      const clip=clips.get(id);if(!clip||!nodes.length||nodes.some(n=>!n||n.tagName!=='P'||!main.contains(n)||n.closest(forbidden)||n.querySelector(forbidden)||privateDetail(n)))continue;
      if(nodes.map(n=>n.textContent).join('\n\n')!==clip.text)continue;
      const parent=nodes[0].parentElement,children=Array.from(parent.children),start=children.indexOf(nodes[0]);
      if(nodes.some((n,i)=>n.parentElement!==parent||children[start+i]!==n)||!eligible())continue;
      const scope=document.createElement('section');scope.dataset.narrationSegment=id;
      parent.insertBefore(scope,nodes[0]);for(const p of nodes){p.dataset.narrationText='';scope.append(p);}
      const button=window.PracticeNarration.control(clip.title,()=>main.isConnected&&main.contains(scope)&&eligible()&&nodes.every(n=>!n.closest(forbidden)&&!n.querySelector(forbidden)&&!privateDetail(n)));button.dataset.narrationId=id;scope.prepend(button);
    }
  }
  function thought(main,current,isCurrent){
    if(route!=='retained-classics/thought-record/'||main!==document.querySelector('main')||current==='intro')return;
    const plans=[],add=(id,nodes)=>plans.push(['thought-modern.'+id,nodes]);
    if(current==='overview'){
      const intro=main.querySelector('.native-intro'),p=ps(intro),outline=ps(intro?.querySelector('.native-outline'));
      add('checking',[p[1]]);add('participation',[p[2]]);add('status',[outline[2]]);
    }
    if(['learn','learn/perspective'].includes(current))add('direct-practice',ps(main.querySelector('.native-direct-practice')));
    apply(main,plans,()=>isCurrent()&&main.dataset.route===current&&location.hash==='#'+current);
  }
  function boundary(main,readState){
    if(route!=='retained-classics/saying-no/'||main!==document.querySelector('main'))return;
    const state=Object.freeze({...readState()}),current=state.route,plans=[],add=(id,nodes,keys=[])=>plans.push(['boundary-modern.'+id,nodes,()=>{const next=readState();return main.dataset.route===current&&location.hash==='#'+current&&next.route===current&&keys.every(k=>next[k]===state[k]);}]);
    const stage=main.querySelector(':scope>section.native-focus-stage,:scope>section.skill-reading');if(!stage)return;
    const p=ps(stage);
    if(['intro','practise'].includes(current))add('fit',ps(stage.querySelector('aside.fit')));
    if(current==='practise')add('choose-situation',[p[2]]);
    if(['learn','choose','example'].includes(current)&&['friend','family'].includes(state.context)){
      const i=current==='learn'?5:current==='choose'?1:3;add('scenario-'+state.context,p.slice(i,i+2),['context']);
    }
    if(current==='choose'){
      add('choose-permission',[p[3]]);
      if(state.mode==='fictional'&&state.showFeedback&&['friend','family'].includes(state.context)&&['maybe','clear','blame'].includes(state.choice))add('compare-'+state.context+'-'+state.choice,ps(stage.querySelector('#feedback')),['mode','context','choice','showFeedback']);
    }
    if(current==='rehearse'){
      if(state.mode==='fictional')add('private-check',ps(detail(stage,'A private check')),['mode']);
      if(state.mode==='personal')add('starting-point',ps(detail(stage,'A starting point, if useful')),['mode']);
    }
    if(current==='response'&&['fictional','personal'].includes(state.mode))add('pressure-'+state.mode,ps(detail(stage,'If it turns into pressure')),['mode']);
    if(current==='reflection')add('reflection',[p[1]]);
    if(current==='complete'&&state.cleared)add('close',p.slice(1,3),['cleared']);
    if(current==='example'&&['friend','family'].includes(state.context)){
      add('example-interpretation',ps(stage.querySelector(':scope>.card')),['context']);
      if(state.context==='friend')add('example-friend-note',ps(detail(stage,'Read the exchange instead')),['context']);
    }
    apply(main,plans,()=>false);
  }
  Object.defineProperty(window,'RetainedPracticeNarration',{value:Object.freeze({thought,boundary}),writable:false,configurable:false});
})();
