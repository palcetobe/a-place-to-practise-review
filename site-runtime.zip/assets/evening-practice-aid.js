
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.EveningPracticeAid=api;})(typeof window!=='undefined'?window:globalThis,()=>{'use strict';
function create(contract,options={}){
 const paced=contract.kind==='optional-no-hold-pacer';if(!paced&&contract.kind!=='optional60second-container')throw Error('Unknown practice aid');
 const now=options.now||(()=>performance.now()),schedule=options.schedule||((fn,ms)=>setInterval(fn,ms)),cancel=options.cancel||clearInterval,isHidden=options.isHidden||(()=>false),onChange=options.onChange||(()=>{});
 const initialPhase=paced?contract.settings.phaseSeconds.initial:null;let phaseSeconds=initialPhase,limited=!paced,textOnly=Boolean(options.reducedMotion),status='off',elapsed=0,anchor=0,job=null,reason='initial';
 const clear=()=>{if(job!==null){cancel(job);job=null;}};
 const elapsedNow=()=>elapsed+(status==='running'?Math.max(0,now()-anchor):0);
 function snapshot(){const ms=elapsedNow(),phaseLength=phaseSeconds*1000,index=paced?Math.floor(ms/phaseLength)%2:0,progress=paced?(ms%phaseLength)/phaseLength:0;return {kind:contract.kind,status,reason,phaseSeconds,limited,textOnly,elapsedMs:ms,remainingSeconds:Math.max(0,Math.ceil((60000-ms)/1000)),phase:status==='running'&&paced?(index===0?'in':'out'):null,marker:status==='running'&&paced?(index===0?progress:1-progress):null,moving:status==='running'&&paced&&!textOnly};}
 function emit(){onChange(snapshot());}
 function tick(){if(status!=='running')return;if(isHidden()){stop('hidden');return;}if(limited&&elapsedNow()>=60000){elapsed=60000;status='ended';reason='time-limit';clear();}emit();}
 function start(resume=false){clear();if(isHidden()){status='stopped';elapsed=0;reason='hidden';emit();return false;}options.beforeStart?.();if(!(resume&&!paced&&status==='paused'))elapsed=0;status='running';reason='explicit-start';anchor=now();job=schedule(tick,paced?50:200);emit();return true;}
 function pause(){if(status!=='running')return;elapsed=paced?0:Math.min(60000,elapsedNow());status='paused';reason='manual-pause';clear();emit();}
 function stop(why='manual-stop'){clear();elapsed=0;status='stopped';reason=why;emit();}
 function configure(next){if('phaseSeconds'in next){const rule=contract.settings?.phaseSeconds,value=Number(next.phaseSeconds);if(!paced||!Number.isFinite(value)||value<rule.min||value>rule.max||(value-rule.min)%rule.step!==0)throw Error('Invalid phase timing');phaseSeconds=value;}if('limited'in next)limited=paced?Boolean(next.limited):true;if('textOnly'in next)textOnly=Boolean(next.textOnly);stop('settings');}
 function reset(){clear();phaseSeconds=initialPhase;limited=!paced;textOnly=Boolean(options.reducedMotion);status='off';elapsed=0;reason='reset';emit();}
 function hidden(value){if(value)stop('hidden');}
 return Object.freeze({snapshot,start,pause,stop,configure,reset,hidden,tick,destroy:()=>{clear();status='stopped';elapsed=0;reason='destroy';}});
}
return Object.freeze({create});});
