window.ABCComponentContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/abcplease",
  "componentId": "component/abcplease/cope-ahead",
  "resourceId": "tool/cope-ahead",
  "routeProposal": "/cope-ahead/",
  "title": "Cope Ahead",
  "version": "2026-11-03-abc-components-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "A therapist-introduced, ordinary-context coping rehearsal. Not trauma reliving, independent exposure, a safety plan or the full range of Cope Ahead applications.",
  "groupedSetStatus": "This is one uncounted component of classic/abcplease. Other ABC components and PLEASE have separate statuses. No new canonical count and no complete ABC PLEASE or DBT claim.",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always reachable outside focus folds, including before practice.",
    "destination": "Reuse verified project support route; do not invent contacts."
  },
  "clinicalContract": {
    "sourcePopulationContext": "Therapist-introduced and individually adapted for developmental, communication, safeguarding, health and access needs. No universal age gate or all-age/app validation claim.",
    "observedPractice": "Reading, planning, rehearsing, real-world attempting and reviewing are different. No automatic completion or success inference.",
    "learningObjective": "Prepare a familiar coping response by rehearsing its use in a particular anticipated situation.",
    "practiceObjective": "Actually rehearse being in the situation, carrying out the response and adapting to an ordinary complication, then settle and review without requiring relief."
  },
  "privacy": {
    "id": "cope-ahead.privacy",
    "title": "Writing is optional",
    "paragraphs": [
      "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.",
      "Leaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.",
      "Review session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored."
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "Practice enters/resumes directly; no duplicate Start. One focused prompt group by default; free jump, Show all, Back and Finish always available. No completion locks.",
    "writing": "Hidden by default and optional; hiding removes every private echo/preview from view. No required fields, analysis, ratings or generated feedback.",
    "persistence": "Active-tool memory only. Internal navigation retains choices/notes; leaving/reload/restart/clear erases them. No localStorage, backend, diary or automatic carry-forward. Returning later allows a fresh account or privately kept notes, never claims restoration.",
    "narration": "Exact static section text only, user-initiated Listen/Pause/Resume; Replay only after this exact current clip was actually played. Leaving section/branch/tool stops playback. No autoplay, concatenated hidden branches, private-answer speech or TTS fallback. No recording acceptance implied.",
    "timer": "None. Rehearsal and actual activity are user-paced; no countdown or prescribed dose.",
    "visual": "Textually labelled method map only. No scores, ticks implying completion, streaks, positive-outcome badges or forced reflection.",
    "context": "Use an ordinary personal situation or the self-contained fictional example without an extra mode selector. Never prefill private fields with fiction.",
    "modes": [
      "practice"
    ],
    "stateBoundary": "Keep a separate focus position for each real mode/branch. Accumulation notes are namespaced by short/long. Mastery plan and review are entry points into one challenge record, not separate duplicate records. Same-open-page activity while away from screen retains in-memory notes; actual leave/reload clears. Never infer attempted/completed state from clicks, fields or navigation.",
    "shortcut": "Existing public REVIEW session-only shortcut keyed by exact component/resource identity. No usual Toolbox write, durable persistence, localStorage or personal notes. Display the exact review-session lifetime notice; shortcut lifetime distinct from active-tool note clearing.",
    "reviewAccess": "Every review prompt freely accessible, including no attempt, partial attempt, changed activity or changed circumstances. No I did it gate, success confirmation, outcome flag or required account."
  },
  "close": {
    "id": "cope-ahead.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.",
      "Return to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here."
    ],
    "actions": [
      "Back to practice",
      "Choose notes to keep",
      "Save session shortcut",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "id": "linehan-er-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-3.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical official emotion-regulation handouts 14–19 and worksheets 10–13; exact component locations in methodTraceability.",
      "limits": "Original wording/examples only; no reproduction license for electronic display. Recognition and procedure evidence, not digital/adolescent validation or exact revised-2025 wording."
    },
    {
      "id": "linehan-er-teaching-2015",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-3teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Teacher explanation and practice/review distinctions, including not penalizing a different mastery activity than planned.",
      "limits": "Professional source, not a standalone client script. No efficacy or completeness certification for this app."
    }
  ],
  "implementationGates": {
    "capabilityClaims": "Privacy/close text must not be offered or narrated until exact persistence, explicit selected-note preview/copy/download and shortcut behaviors pass actual runtime tests. Implement the contract, do not silently remove capabilities or promise them before tests.",
    "gatedSectionIds": [
      "cope-ahead.privacy",
      "cope-ahead.close"
    ],
    "testsRequired": [
      "Internal Practice/Example/Learn/help/back retains notes and mode",
      "Leave/reload/restart/clear removes all notes and echoes",
      "Hidden writing hides all private previews",
      "No note selected by default; exact selection/preview before explicit copy/download",
      "Shortcut retains only distinct component identity in the open preview session; reload/session closure removes it; usual Toolbox is unchanged",
      "Audio contains only visible static current section, stops on navigation, and never uses private fields",
      "Free jump/Show all/Finish works without input, completion or improved emotion",
      "Later return is fresh; no planned or attempted status inferred"
    ]
  },
  "acceptance": [
    "Complete named component operations remain teachable and actually practicable, not just definitions.",
    "Original worked example includes actual rehearsal/attempt and neutral review.",
    "All help, fit and full teaching accessible without enforced reading.",
    "No writing, rating, emotion change or real-world activity required to leave.",
    "Content review is separate from clinical validation, UI testing, guide/export review and audio listening."
  ],
  "intro": {
    "id": "cope-ahead.intro",
    "title": "Cope Ahead",
    "paragraphs": [
      "Cope Ahead means practising how you will respond before an emotionally difficult situation arrives. Here you will choose a familiar response and rehearse using it, not only write a plan.",
      "Use a manageable upcoming situation agreed with your therapist, or the fictional example. You can imagine the scene, talk yourself through it or rehearse the actions privately. You do not need to contact anyone."
    ]
  },
  "fit": {
    "id": "cope-ahead.fit",
    "title": "Check whether this fits",
    "paragraphs": [
      "Choose an ordinary situation and a coping skill you already understand. If the skill itself is unfamiliar, learn it with your therapist before rehearsing it here.",
      "Do not use this exercise to revisit trauma, rehearse danger, test whether you are safe, or make yourself tolerate threats or abuse. When safety is uncertain, seek appropriate support rather than relying on rehearsal.",
      "If imagining the scene feels too intense, stop, notice where you are now and return to an ordinary activity that helps you settle. You can use a simple spoken walk-through without imagery, or leave the practice."
    ]
  },
  "learn": {
    "id": "cope-ahead.learn",
    "title": "Why rehearse rather than only plan?",
    "paragraphs": [
      "When a situation brings strong feelings, a useful response can be harder to bring to mind. Rehearsal gives you a chance to practise the actions and words you want available. It does not predict how the situation will go.",
      "The sequence here is: describe what you expect and what could get in the way; choose a familiar response; place yourself in the scene; practise the response and an ordinary complication; then settle and review.",
      "The source supports first-person mental rehearsal using visual imagery or words in your mind. A spoken or action-based walk-through is an additional accessibility adaptation here. This ordinary-context version leaves out worst-catastrophe rehearsal; it is not the full range of uses in the source manual.",
      "Planning alone does not count as rehearsal. Equally, you do not need to rehearse repeatedly until it feels certain or comfortable. A live attempt is a separate choice, not a requirement of this page."
    ]
  },
  "example": {
    "id": "cope-ahead.example",
    "title": "Example: Morgan asks about a room change",
    "paragraphs": [
      "Morgan is attending a familiar class in a different room. They expect to feel flustered and leave if they cannot find it. With their therapist they have already practised pausing and asking a clear question.",
      "Morgan chooses: stop at the reception desk, say “Could you tell me where the class is today?”, then listen. They imagine standing at the desk now, feeling rushed, noticing the urge to walk away, and actually saying the question quietly to themselves.",
      "They rehearse a manageable complication: the staff member says, “I need a moment to check.” Morgan imagines waiting to one side and saying “Thanks.” If no one can help, Morgan can contact the organiser later rather than wander into a restricted area.",
      "Morgan ends the scene, looks around the room they are actually in and lets their hands rest comfortably. They are still uneasy. Reviewing the rehearsal, they notice the first question was clear but the next step was vague. They try the waiting response once more and stop. The real class has not happened yet."
    ]
  },
  "practice": [
    {
      "id": "cope-ahead.practice.situation",
      "title": "Name the situation and what may get in the way",
      "paragraphs": [
        "Choose Morgan’s room-change example or an ordinary upcoming event. Describe where you will be and what you expect to happen, keeping assumptions separate from what you know.",
        "What feeling, thought or urge might make your usual response harder to use? Name it briefly; there is no need for a detailed personal story."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The anticipated situation",
          "optional": true
        },
        {
          "key": "interference",
          "label": "What may get in the way",
          "optional": true
        }
      ],
      "help": {
        "title": "If the scene already feels overwhelming",
        "text": "Choose something more manageable, use Morgan’s example or stop. Making the scene more intense is not the purpose."
      }
    },
    {
      "id": "cope-ahead.practice.response",
      "title": "Choose a response you already know",
      "paragraphs": [
        "Decide exactly what familiar coping action you could use. What will you do, think or say when the feeling or urge appears? Include any help or practical limit you need.",
        "For Morgan, the response is to pause at reception and ask where the class is, rather than leave immediately. For your own situation, use your agreed skill instead of copying a response that does not fit."
      ],
      "fields": [
        {
          "key": "coping",
          "label": "The familiar response I could use",
          "optional": true
        }
      ],
      "help": {
        "title": "If I only have “stay calm”",
        "text": "Make it an action you can rehearse, such as a familiar pause and a clear question. Feeling calm is not a step you have to achieve. If you do not know the skill, plan to learn it rather than inventing it here."
      }
    },
    {
      "id": "cope-ahead.practice.enter",
      "title": "Place yourself in the scene",
      "paragraphs": [
        "If imagery fits, imagine being there now, from your own point of view rather than watching yourself from outside. Notice only enough of the setting to recognise the moment when your response will be needed. Keep your eyes open if you prefer.",
        "Without a visual image, rehearse in words in your mind: “I am at reception. I feel rushed and want to leave.” The source supports verbal mental rehearsal. Saying the words aloud or walking through the actions is an additional adaptation here; visualization is not a test."
      ],
      "help": {
        "title": "If imagery is unclear or uncomfortable",
        "text": "You do not need a vivid picture. Use words and familiar actions, or stop and return attention to your actual surroundings."
      }
    },
    {
      "id": "cope-ahead.practice.rehearse",
      "title": "Now practise the response",
      "paragraphs": [
        "Take the time you need to rehearse carrying out your chosen response within that scene. Actually imagine doing it, quietly say the words, or walk through the agreed actions where you are. You can pause this page while you practise.",
        "For Morgan, rehearse noticing the urge to leave, stopping at the desk, asking the question and listening. Try your own sequence if you chose a different situation. There is no timer or need to feel better before moving on."
      ],
      "fields": [
        {
          "key": "attempt",
          "label": "Something I noticed while rehearsing",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am still only planning",
        "text": "Try carrying out the response in your imagination or with a spoken walk-through now. You can also choose not to rehearse; the page will not mark the plan as a completed practice."
      }
    },
    {
      "id": "cope-ahead.practice.complication",
      "title": "Rehearse one manageable complication",
      "paragraphs": [
        "Choose an ordinary interruption, not your worst feared outcome. Imagine it occurs, then rehearse what you could do next while keeping your limits.",
        "You can use Morgan’s example: the staff member needs a moment to check. Try waiting to one side and saying “Thanks,” or stopping and seeking help another way if that fits. An uncertain ending is allowed."
      ],
      "fields": [
        {
          "key": "complication",
          "label": "A manageable complication",
          "optional": true
        },
        {
          "key": "adjustment",
          "label": "What I rehearsed next",
          "optional": true
        }
      ],
      "help": {
        "title": "If I start searching for every possible problem",
        "text": "Leave the search here. This practice cannot prepare for every outcome. Return to your agreed response or stop rather than rehearsing until you feel certain."
      }
    },
    {
      "id": "cope-ahead.practice.settle",
      "title": "End the scene and settle",
      "paragraphs": [
        "Let the imagined scene end. Notice where you actually are. Use a familiar comfortable way of relaxing or settling, such as letting your hands rest and taking in the room around you. No particular breathing pattern is required.",
        "You can take your time or finish. A change in feeling is not required."
      ],
      "help": {
        "title": "If discomfort remains",
        "text": "Stop the rehearsal and use the support or guidance you already have. You do not need to repeat the scene to make discomfort disappear."
      }
    },
    {
      "id": "cope-ahead.practice.review",
      "title": "Review the rehearsal, if useful",
      "paragraphs": [
        "What part did you actually rehearse? Was there a step you could make clearer or a support you need before trying the real situation? You can rehearse one revision, bring a question to your therapist or leave it here.",
        "This was preparation, not evidence that a real event will go a certain way. If you return after the event, you can describe what actually happened without needing it to match the rehearsal."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I noticed or would adjust",
          "optional": true
        }
      ],
      "help": {
        "title": "If I did not rehearse",
        "text": "You can say that, or keep no note. Reading and deciding not to practise are valid ways to use the page; neither will be labelled a rehearsal."
      }
    }
  ],
  "methodElements": [
    "Situation and interfering response",
    "Specific familiar coping sequence",
    "First-person mental scene using imagery or words, or labelled spoken/action adaptation",
    "Actual coping rehearsal",
    "Manageable complication rehearsal",
    "Post-rehearsal settling",
    "Optional review"
  ],
  "methodTraceability": {
    "sourceLocation": "Emotion Regulation Handout 19, PDF page 51; teaching notes PDF pages 76–79",
    "componentIdentity": "Catalogue component/abcplease/cope-ahead; methodIds include cope; planningTargetId cope-ahead; sourceCandidate DA07/DA08 applies to group, not proven unique per component.",
    "historicalProposal": "Public focused-goal-data.js proposal id copingahead, label Cope Ahead rehearsal. Retain as provenance; do not silently repoint a live route.",
    "adaptations": [
      "Ordinary manageable context only; feared-catastrophe rehearsal excluded and disclosed.",
      "Verbal mental rehearsal is source-supported (teaching notes PDF page 78); broader spoken/action walk-through is an additional labelled adaptation.",
      "User-paced, no forced eyes closing, timed dose, repeated reassurance or automatic completion."
    ]
  },
  "relatedResources": {
    "status": "Preserve existing identities; links only after route verification in isolated runtime. No silent redirection/replacement.",
    "resources": [
      "classic/dear",
      "classic/give",
      "classic/fast",
      "classic/facts"
    ]
  },
  "narrationSegments": [
    {
      "id": "cope-ahead.privacy",
      "title": "Writing is optional",
      "text": "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.\n\nLeaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.\n\nReview session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored.",
      "textSha256": "08e5d33489f269867a52f82337eafbed695f22fd860232e4a1260c736a31d56d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "capabilityGate": "Unavailable until all relevant actual renderer capability tests pass."
    },
    {
      "id": "cope-ahead.intro",
      "title": "Cope Ahead",
      "text": "Cope Ahead means practising how you will respond before an emotionally difficult situation arrives. Here you will choose a familiar response and rehearse using it, not only write a plan.\n\nUse a manageable upcoming situation agreed with your therapist, or the fictional example. You can imagine the scene, talk yourself through it or rehearse the actions privately. You do not need to contact anyone.",
      "textSha256": "af4dbb392e688693bb499f3b0aca6b61addd7ef05fb667586770b22b1270414d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.fit",
      "title": "Check whether this fits",
      "text": "Choose an ordinary situation and a coping skill you already understand. If the skill itself is unfamiliar, learn it with your therapist before rehearsing it here.\n\nDo not use this exercise to revisit trauma, rehearse danger, test whether you are safe, or make yourself tolerate threats or abuse. When safety is uncertain, seek appropriate support rather than relying on rehearsal.\n\nIf imagining the scene feels too intense, stop, notice where you are now and return to an ordinary activity that helps you settle. You can use a simple spoken walk-through without imagery, or leave the practice.",
      "textSha256": "5bee7d50910b7efbfb496530cb7c26ad04eb1563dbef55b1bc336dbb80fc297e",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.learn",
      "title": "Why rehearse rather than only plan?",
      "text": "When a situation brings strong feelings, a useful response can be harder to bring to mind. Rehearsal gives you a chance to practise the actions and words you want available. It does not predict how the situation will go.\n\nThe sequence here is: describe what you expect and what could get in the way; choose a familiar response; place yourself in the scene; practise the response and an ordinary complication; then settle and review.\n\nThe source supports first-person mental rehearsal using visual imagery or words in your mind. A spoken or action-based walk-through is an additional accessibility adaptation here. This ordinary-context version leaves out worst-catastrophe rehearsal; it is not the full range of uses in the source manual.\n\nPlanning alone does not count as rehearsal. Equally, you do not need to rehearse repeatedly until it feels certain or comfortable. A live attempt is a separate choice, not a requirement of this page.",
      "textSha256": "b3e59709bb2997cb805d703accdd8945fc805105c68e8851276624ef83eefbea",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.example",
      "title": "Example: Morgan asks about a room change",
      "text": "Morgan is attending a familiar class in a different room. They expect to feel flustered and leave if they cannot find it. With their therapist they have already practised pausing and asking a clear question.\n\nMorgan chooses: stop at the reception desk, say “Could you tell me where the class is today?”, then listen. They imagine standing at the desk now, feeling rushed, noticing the urge to walk away, and actually saying the question quietly to themselves.\n\nThey rehearse a manageable complication: the staff member says, “I need a moment to check.” Morgan imagines waiting to one side and saying “Thanks.” If no one can help, Morgan can contact the organiser later rather than wander into a restricted area.\n\nMorgan ends the scene, looks around the room they are actually in and lets their hands rest comfortably. They are still uneasy. Reviewing the rehearsal, they notice the first question was clear but the next step was vague. They try the waiting response once more and stop. The real class has not happened yet.",
      "textSha256": "3a8f962e557543578c01e1849c7929faeb688a3278238aaa11ce0da8eaa1ac83",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.situation",
      "title": "Name the situation and what may get in the way",
      "text": "Choose Morgan’s room-change example or an ordinary upcoming event. Describe where you will be and what you expect to happen, keeping assumptions separate from what you know.\n\nWhat feeling, thought or urge might make your usual response harder to use? Name it briefly; there is no need for a detailed personal story.",
      "textSha256": "97e3bacc792d404584e640b2b22346ef9a12a97fcbda13446f4cfdc286342c15",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.situation.help",
      "title": "If the scene already feels overwhelming",
      "text": "Choose something more manageable, use Morgan’s example or stop. Making the scene more intense is not the purpose.",
      "textSha256": "e6fe11eb03c5d01f6d58600f3d73c488104b7a3cdced900e1f8c4fe5432917a7",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "cope-ahead.practice.response",
      "title": "Choose a response you already know",
      "text": "Decide exactly what familiar coping action you could use. What will you do, think or say when the feeling or urge appears? Include any help or practical limit you need.\n\nFor Morgan, the response is to pause at reception and ask where the class is, rather than leave immediately. For your own situation, use your agreed skill instead of copying a response that does not fit.",
      "textSha256": "2571f05e15c9810d0460634113430c2f5a01b63212599d1f1db75c7f24b784ff",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.response.help",
      "title": "If I only have “stay calm”",
      "text": "Make it an action you can rehearse, such as a familiar pause and a clear question. Feeling calm is not a step you have to achieve. If you do not know the skill, plan to learn it rather than inventing it here.",
      "textSha256": "d256e407f3910a2032063cd07c7a171ea744d6c602b2f090dd169e037da87446",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "cope-ahead.practice.enter",
      "title": "Place yourself in the scene",
      "text": "If imagery fits, imagine being there now, from your own point of view rather than watching yourself from outside. Notice only enough of the setting to recognise the moment when your response will be needed. Keep your eyes open if you prefer.\n\nWithout a visual image, rehearse in words in your mind: “I am at reception. I feel rushed and want to leave.” The source supports verbal mental rehearsal. Saying the words aloud or walking through the actions is an additional adaptation here; visualization is not a test.",
      "textSha256": "d5dd8805cd6271b21a90ac1ed75ddb89436cc886066a1bdae7ee1c57318051d4",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.enter.help",
      "title": "If imagery is unclear or uncomfortable",
      "text": "You do not need a vivid picture. Use words and familiar actions, or stop and return attention to your actual surroundings.",
      "textSha256": "aa1bd3e4db2e7b1aa1e7a12a6f7de7dbf58be6862b1ab780c47ab2a78a6c4a0d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "cope-ahead.practice.rehearse",
      "title": "Now practise the response",
      "text": "Take the time you need to rehearse carrying out your chosen response within that scene. Actually imagine doing it, quietly say the words, or walk through the agreed actions where you are. You can pause this page while you practise.\n\nFor Morgan, rehearse noticing the urge to leave, stopping at the desk, asking the question and listening. Try your own sequence if you chose a different situation. There is no timer or need to feel better before moving on.",
      "textSha256": "036c35f8c9f685cb2648c59fb2409977218f151f70eb1f77ab7aa9c4c098a115",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.rehearse.help",
      "title": "If I am still only planning",
      "text": "Try carrying out the response in your imagination or with a spoken walk-through now. You can also choose not to rehearse; the page will not mark the plan as a completed practice.",
      "textSha256": "7ece9d847318db98ddecabe364e2d953aee36b2cab1d1de56c2221c17489ec08",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "cope-ahead.practice.complication",
      "title": "Rehearse one manageable complication",
      "text": "Choose an ordinary interruption, not your worst feared outcome. Imagine it occurs, then rehearse what you could do next while keeping your limits.\n\nYou can use Morgan’s example: the staff member needs a moment to check. Try waiting to one side and saying “Thanks,” or stopping and seeking help another way if that fits. An uncertain ending is allowed.",
      "textSha256": "0ee2684a5b1efc1a1698aaccc58feec4ff2e0a2e357d80202db9c27029eaeca7",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.complication.help",
      "title": "If I start searching for every possible problem",
      "text": "Leave the search here. This practice cannot prepare for every outcome. Return to your agreed response or stop rather than rehearsing until you feel certain.",
      "textSha256": "7fe0775a9b3f4c7d94b285b164074b59a87845982620d814fc0587d34dac33c0",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "cope-ahead.practice.settle",
      "title": "End the scene and settle",
      "text": "Let the imagined scene end. Notice where you actually are. Use a familiar comfortable way of relaxing or settling, such as letting your hands rest and taking in the room around you. No particular breathing pattern is required.\n\nYou can take your time or finish. A change in feeling is not required.",
      "textSha256": "ecc7c4a63d5d0566346ce414402e0716068fe41119867561d0c63a22a090374e",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.settle.help",
      "title": "If discomfort remains",
      "text": "Stop the rehearsal and use the support or guidance you already have. You do not need to repeat the scene to make discomfort disappear.",
      "textSha256": "37bc46ee2f2190c81ace11404ba327d1231952b9dd8eef37f228fd41a084c58a",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "cope-ahead.practice.review",
      "title": "Review the rehearsal, if useful",
      "text": "What part did you actually rehearse? Was there a step you could make clearer or a support you need before trying the real situation? You can rehearse one revision, bring a question to your therapist or leave it here.\n\nThis was preparation, not evidence that a real event will go a certain way. If you return after the event, you can describe what actually happened without needing it to match the rehearsal.",
      "textSha256": "897391c0c7adaa37f3e5aa2d50dbf114a685f80b00aa3d558222f92d722550ea",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "cope-ahead.practice.review.help",
      "title": "If I did not rehearse",
      "text": "You can say that, or keep no note. Reading and deciding not to practise are valid ways to use the page; neither will be labelled a rehearsal.",
      "textSha256": "ff8c4a53726504d2d5bd4a09953a6b4a6e1b39a0e5de96dc7bed212dbfec7e07",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "cope-ahead.close",
      "title": "Leave the practice here",
      "text": "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.\n\nReturn to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here.",
      "textSha256": "c9171e9f0e25d189db3f09fbfa5ba8707d92ece31276d5ba3baa1b8bcbdbf102",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "capabilityGate": "Unavailable until all relevant actual renderer capability tests pass."
    }
  ],
  "staticTextCopyContract": {
    "scope": "An explicitly requested copy/download of authored teaching or narration transcript is separate from selected personal notes. No clipboard/export on navigation, Finish, Listen, mode selection or source visit.",
    "permissions": "No source PDF copying or redistribution. Cite sources; offer only original authored static content. Personal notes never appended by default."
  }
}
;
