window.MissingLinksContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/missing",
  "resourceId": "tool/missing-links-analysis",
  "routeProposal": "/missing-links-analysis/",
  "title": "Missing-Links Analysis",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Explore why one agreed helpful action did not happen, then choose an adjustment that fits.",
  "groupedSetStatus": "Existing individual canonical entry classic/missing. The conditional knowledge, willingness, remembering and remaining-barrier checks remain distinct from Chain Analysis, Maintenance Planning and Return after a gap. Later-use planning/review is an explicitly added follow-through, not a claimed source-prescribed branch. Zero new canonical count.",
  "clinicalContract": {
    "learningObjective": "Find a useful missing link without assuming nonaction means unwillingness; distinguish knowledge of what was agreed, choice, remembering and practical/skill/access barriers.",
    "practiceObjective": "Check one ordinary agreed action and occasion, stop diagnostic questions at a useful branch, choose a matched clarification/fit/cue/support adjustment, rehearse where useful and later review actual use.",
    "sourcePopulationContext": "Linehan professional teaching material defines the method, not validation of this isolated digital adaptation or universal age suitability. No blanket adult-only or 16+ rule. Clinician introduction and individual developmental, safeguarding, power/cultural, health, communication and disability/access review are required.",
    "exclusions": [
      "No missed medication or medical-treatment correction, alcohol/drug-use plan or crisis/urgent safety management",
      "No punishment, compliance scoring, forced catch-up, coerced agreement or automatic unwillingness inference",
      "No pressure to follow unsafe, inaccessible, outdated or never-agreed demands",
      "No diagnosis, proof of one cause, automatic notification, reminders or treatment change"
    ],
    "adaptations": [
      "Original wording/structure/example; source worksheets and prompts not reproduced",
      "Agreement/current-fit check before willingness to avoid classifying unagreed expectations as resistance",
      "Explicit optional branch-to-adjustment navigation without recording clinical labels",
      "Knowledge of what to do distinguished from ability/skill to carry it out",
      "No required branch answers, writing, motivation, attempt or outcome",
      "Later plan and actual-use review explicitly added follow-through; return may include no opportunity or changed goal",
      "Session-only optional notes and selected exact-preview export; no private text in narration"
    ],
    "reviewGates": [
      "Owner/clinician and rights review of conditional method and original expression",
      "Individual agreement, developmental/safeguarding/access/clinical suitability",
      "Human comprehension at intended reading level, not a validated grade-five claim",
      "Real integrated desktop/mobile/keyboard/screen-reader, branch focus, support and privacy testing",
      "Authorized narration generation, exact-script listening and controls before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use an ordinary action reviewed with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Explore the missed action",
          "startSectionId": "missing-links-analysis.practice.action"
        },
        {
          "value": "review",
          "label": "Review an adjustment",
          "startSectionId": "missing-links-analysis.practice.review"
        }
      ]
    },
    "entryGate": "Visible scope before explicit choice; the UI does not certify agreement, suitability or clinical participation. Example/Learn/Finish/support remain available.",
    "branching": "Knowledge → willingness → came-to-mind → remaining barriers only while useful. Every diagnostic branch offers a direct jump to adjustment. Navigation records position only, not answers or clinical classifications. Free jump and Show all remain available.",
    "focus": "One meaningful group, no required notes or branch answers, free Previous/Next/Finish. Branch buttons focus the selected target prompt.",
    "reviewAccess": "Direct blank later review with no stored plan, attempt or action required. Later-use review is explicitly a product follow-through.",
    "writing": "Hidden and optional initially. Fiction never fills notes. Hide removes private display and invalidates export.",
    "persistence": "Open-page memory only. Internal readers/navigation retain notes; clear/restart/leaving/reload/history/BFCache clear. Visibility change alone retains notes.",
    "export": "Explicit note selection, exact preview, selected-only copy/download. No preselection. Edit/hide/mode change invalidates export.",
    "narration": "Exact fixed public paragraphs/help only, never notes. No media/TTS/autoplay or audio activation.",
    "timer": "None. No reminders, scheduled tasks, follow-up notifications or timed completion.",
    "completion": "No completed, attempted, compliant, willing/unwilling, causal, success, score or streak verdict."
  },
  "intro": {
    "id": "missing-links-analysis.intro",
    "title": "Find what was missing, without blame",
    "paragraphs": [
      "Sometimes an action we agreed would help does not happen. Missing-Links Analysis asks what was missing between the plan and that moment. It does not assume you did not care or try hard enough.",
      "You check only the questions that help. Was the plan clear? Were you willing to try? Did it come to mind? What else got in the way? When you find a useful issue, stop the questions and work on an adjustment with your therapist."
    ]
  },
  "fit": {
    "id": "missing-links-analysis.fit",
    "title": "Check that the plan was truly agreed and still fits",
    "paragraphs": [
      "Use one ordinary action you and your therapist agreed could help. Choose one occasion when it did not happen. If the plan was never agreed, was unclear or no longer fits, start there. You do not have to defend yourself.",
      "This page is not for missed medicine, changes to medical care, alcohol or other drug use, or an urgent safety task. Get suitable professional help for those needs. You do not have to finish this exercise before getting support.",
      "A lack of time, energy, skill, access or help is not the same as choosing not to act. A boundary or changed circumstance may be a good reason to change the plan. No one should use this page to punish or pressure you.",
      "You can stop, skip a question, keep it open or read the example. The page does not decide the reason, send a report or make a new agreement for you."
    ]
  },
  "privacy": {
    "id": "missing-links-analysis.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, contact details and private health details are not needed. Notes stay while you use this open tool, including its example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes to your therapist. Optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "missing-links-analysis.close",
    "title": "Leave the review here",
    "paragraphs": [
      "You can finish with one useful question, an adjustment, a choice to pause or no answer yet. There is no need to catch up, prove willingness or promise success.",
      "You may return to a prompt or choose notes to keep for your session. Finish and clear removes the notes here, not any copies you kept elsewhere. Nothing is sent to your therapist."
    ]
  },
  "example": {
    "id": "missing-links-analysis.example",
    "title": "Rae forgets a coping-card plan",
    "paragraphs": [
      "This is made up. Rae and their therapist agree that after one usual phone call, Rae will look at a familiar coping card and choose whether a taught skill fits. The card plan does not happen that day.",
      "Agreement and clarity: Rae says the plan was theirs to choose and still seems useful. They knew what the action was and when they meant to try it. There is no need to treat this as unclear instructions.",
      "Willingness: Rae wanted to try it. The therapist does not infer lack of care from the missed action.",
      "Remembering: A doorbell rang as the call ended. Rae went to answer it and did not think of the card until later. This gives them a useful place to work. They stop the questions here rather than force Rae to answer every branch.",
      "Matched adjustment: Rae chooses a visible spot for the card beside the phone. This is a cue Rae will arrange, not a reminder set by this page. With the therapist, Rae practises ending a pretend call, noticing the card and deciding whether to use a familiar skill.",
      "Later use: After another usual call, Rae notices the card but finds part of it covered by papers. Rae moves a paper, reads the card and chooses one taught step. Rae does not feel calmer. Using the cue is different from changing a feeling.",
      "Actual review: At the next session they discuss what happened. The cue helped, and clutter still made it harder to use. Rae and the therapist choose a clearer spot and rehearse noticing it there. That revised location is a new plan, not something already tried at home.",
      "If there had been no suitable call, Rae could say there was no chance yet. If the plan no longer fit, they could change or stop it. Neither would prove Rae was unwilling."
    ]
  },
  "learn": {
    "id": "missing-links-analysis.learn",
    "title": "Match the adjustment to what was missing",
    "paragraphs": [
      "This method asks about an action that did not happen. Chain Analysis looks closely at a problem action and what led to and followed it. Your therapist may combine the methods when that helps. Return after a gap and Maintenance Planning can help with broader practice plans, but they do not replace these specific questions.",
      "Knowing what was agreed is one thing. Knowing how to do it is another. You might know you planned to ask for help but still need to practise the words. A clearer explanation, a demonstration or rehearsal may help more than another reminder.",
      "Willingness asks about your choice at that time, not your energy or ability. You can be willing and unable to act. You can also have concerns, disagree or need to change the goal. A choice deserves discussion, not a label.",
      "A plan may be clear and chosen but not come to mind when needed. Then a useful cue may help. If it did come to mind, look at what blocked action, such as time, skill, distress, resources, support or a changed setting.",
      "You do not need to answer every question. Stop when another question would not help, then work on a fitting change. There may be more than one issue. Treat your explanation as something to check, not a proven cause.",
      "This resource adds an optional later-use plan and review so you can see whether an adjustment helped. That is follow-through, not a promise to complete the action. No reminders, appointments or messages are arranged by this page."
    ]
  },
  "practice": [
    {
      "id": "missing-links-analysis.practice.action",
      "title": "Name the agreed action and the occasion",
      "paragraphs": [
        "What ordinary action did you and your therapist agree could help? Choose one time it did not happen. Keep the action separate from the result you hoped for: \"look at my card\" differs from \"feel calm\".",
        "Was it actually your agreement, and did the plan still fit that moment? If not, you can go straight to discussing a clearer or different plan. You do not need to answer questions about willingness to explain a task you never agreed to."
      ],
      "fields": [
        {
          "key": "action",
          "label": "The action I understood we had agreed",
          "optional": true
        },
        {
          "key": "occasion",
          "label": "The one occasion when it did not happen",
          "optional": true
        },
        {
          "key": "fit-check",
          "label": "Whether it was agreed and still fit",
          "optional": true
        }
      ],
      "help": {
        "title": "If you only know that things did not go well",
        "text": "Ask your therapist to help name a clear action, not a demand for a feeling or an outcome outside your control. You can leave the target open rather than guess."
      },
      "nextChoices": [
        {
          "label": "Clarify or change the agreement",
          "targetId": "missing-links-analysis.practice.adjust"
        },
        {
          "label": "The agreement fits: check what was clear",
          "targetId": "missing-links-analysis.practice.knowledge"
        }
      ]
    },
    {
      "id": "missing-links-analysis.practice.knowledge",
      "title": "Was the action clear at that time?",
      "paragraphs": [
        "At the time, did you understand what action was agreed and when it was meant to fit? This is about knowing the plan, not proving you could carry it out.",
        "If the plan was unclear, stop here and work on an adjustment. You might need clearer words, a smaller task or to check the agreement with your therapist. If it was clear, the next useful question may be about willingness."
      ],
      "fields": [
        {
          "key": "clarity",
          "label": "What was clear or needs explaining",
          "optional": true
        }
      ],
      "help": {
        "title": "If you knew what, but not how",
        "text": "Keep that difference. A skill may need a demonstration or practice together, even when the instructions were clear. You can go to the adjustment now or discuss that barrier later."
      },
      "nextChoices": [
        {
          "label": "Work on what was unclear",
          "targetId": "missing-links-analysis.practice.adjust"
        },
        {
          "label": "Check willingness next",
          "targetId": "missing-links-analysis.practice.willingness"
        }
      ]
    },
    {
      "id": "missing-links-analysis.practice.willingness",
      "title": "Were you choosing to try it then?",
      "paragraphs": [
        "At that moment, were you willing to try the agreed action, even if it was not easy? This asks about choice, not whether you had enough energy, skill or help.",
        "If you were not willing, felt mixed or had concerns, you can stop here and discuss them. What mattered to you? Did the plan ask too much, feel unsafe or conflict with a need? The goal can be changed. If you were willing, check whether the plan came to mind."
      ],
      "fields": [
        {
          "key": "choice-concerns",
          "label": "My choice, concerns or mixed feelings at the time",
          "optional": true
        }
      ],
      "help": {
        "title": "If willingness feels like a test of being good",
        "text": "It is not. You do not have to agree with someone else to pass this page. A lack of ability or support is not unwillingness. Discuss the plan and the real circumstances with your therapist."
      },
      "nextChoices": [
        {
          "label": "Work on fit or concerns",
          "targetId": "missing-links-analysis.practice.adjust"
        },
        {
          "label": "Check whether it came to mind",
          "targetId": "missing-links-analysis.practice.remembering"
        }
      ]
    },
    {
      "id": "missing-links-analysis.practice.remembering",
      "title": "Did the plan come to mind when needed?",
      "paragraphs": [
        "Think of the time the action could have happened. Did you remember the plan then, or only later? If you cannot recall, leave it open. Do not assume you remembered just because the plan seems clear now.",
        "If it did not come to mind, stop here and consider a cue that fits your day and access needs. If it did come to mind, the next question is what blocked the action. Forgetting is information, not a character fault."
      ],
      "fields": [
        {
          "key": "remembering",
          "label": "When the plan came to mind, or what I do not know",
          "optional": true
        }
      ],
      "help": {
        "title": "If reminders have not helped",
        "text": "More reminders are not always the answer. Check whether the cue was noticeable, came at a useful time and linked to a possible action. You may also need skill, time or support. This page creates no reminder."
      },
      "nextChoices": [
        {
          "label": "Work on a useful cue",
          "targetId": "missing-links-analysis.practice.adjust"
        },
        {
          "label": "Look at what blocked the action",
          "targetId": "missing-links-analysis.practice.barriers"
        }
      ]
    },
    {
      "id": "missing-links-analysis.practice.barriers",
      "title": "What blocked it even though you remembered?",
      "paragraphs": [
        "If the plan was clear, you were willing and it came to mind, what got between that and doing it? You may have needed time, a skill, equipment, access, help or a different setting. Feelings or competing needs may have mattered too.",
        "Knowing what to do does not mean knowing how. If a step was too hard or you had not learned it, ask for teaching or practice together. If circumstances changed, it may have been wise not to follow the old plan."
      ],
      "fields": [
        {
          "key": "obstacles",
          "label": "What got in the way at that moment",
          "optional": true
        },
        {
          "key": "needed-support",
          "label": "Skill, access, time or support that was missing",
          "optional": true
        }
      ],
      "help": {
        "title": "If several things got in the way",
        "text": "You do not have to pick one true cause. Start with a change that seems useful and possible. Your therapist can help look more closely if the same barrier keeps showing up."
      },
      "nextChoices": [
        {
          "label": "Work on a matched adjustment",
          "targetId": "missing-links-analysis.practice.adjust"
        }
      ]
    },
    {
      "id": "missing-links-analysis.practice.adjust",
      "title": "Choose a change that matches the issue",
      "paragraphs": [
        "Use the issue you found; you do not have to answer the other questions first. What is your best working idea, and what is still unclear? It can change when you learn more.",
        "If the plan was unclear, ask for a clear, shared next step. If you had concerns or did not choose it, discuss the goal, benefits, costs and fit. You can revise, pause or decline a plan rather than promise more effort.",
        "If it was forgotten, choose one cue you could notice at a useful moment. If you remembered but were blocked, match the change to that barrier: a smaller step, more time, an accessible option, help or teaching. Do not remove a needed aid or boundary.",
        "With your therapist, choose one feasible adjustment. If you need a skill, ask them to show it and practise it together. If useful, rehearse noticing a cue and the first action. A reminder alone cannot supply a skill or resource you do not have."
      ],
      "fields": [
        {
          "key": "working-idea",
          "label": "The issue I want to work on, and what is unclear",
          "optional": true
        },
        {
          "key": "adjustment",
          "label": "A fitting adjustment to discuss or use if agreed",
          "optional": true
        },
        {
          "key": "rehearsal",
          "label": "What I practised or want to learn with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If the best choice is to stop or change the goal",
        "text": "That can be a useful result. Check it with your therapist rather than keep a plan just to complete it. This page does not change your treatment or create an agreement."
      },
      "nextChoices": [
        {
          "label": "Plan an agreed next opportunity",
          "targetId": "missing-links-analysis.practice.plan"
        }
      ]
    },
    {
      "id": "missing-links-analysis.practice.plan",
      "title": "If useful, plan one next opportunity",
      "paragraphs": [
        "This follow-through is optional. For an adjustment agreed with your therapist, when might a suitable chance arise? Note the cue and first action, plus what support you need. A plan here does not set a reminder or appointment.",
        "What if the cue is missed, the chance does not arise, or the plan no longer fits? Choose a smaller option, support or a pause. There is no catch-up requirement or promise to keep trying until it works.",
        "After a real opportunity, you can return to Review an adjustment and describe what happened. You can also review no chance yet or a changed goal. Notes do not stay when you leave or reload; choose notes to keep first if you want a copy."
      ],
      "fields": [
        {
          "key": "cue-action",
          "label": "A suitable cue or opportunity and first action",
          "optional": true
        },
        {
          "key": "backup",
          "label": "A backup, support or reason to pause",
          "optional": true
        },
        {
          "key": "review-plan",
          "label": "How I will review this with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If you need help before the next opportunity",
        "text": "You can ask now. Ordinary practice does not replace professional advice or urgent support. Use Support and urgent help to find help options. No one monitors these notes."
      }
    },
    {
      "id": "missing-links-analysis.practice.review",
      "title": "Review the real opportunity and adjustment",
      "paragraphs": [
        "Recall or check the adjustment you agreed. If you cannot remember, leave it open and ask your therapist. Was there a suitable chance to use it? What did you actually try, change, stop or not try?",
        "What helped or still got in the way? Keep doing the action separate from a feeling improving or someone else responding as hoped. No suitable chance is different from choosing not to act.",
        "Review this with your therapist. You may keep the adjustment, revise it, get more teaching or support, change the goal or pause. Do not use one result as proof of your motivation or worth. A new plan is not required before you finish."
      ],
      "fields": [
        {
          "key": "opportunity",
          "label": "The real opportunity, no chance yet, or changed goal",
          "optional": true
        },
        {
          "key": "actual-use",
          "label": "What I actually tried, changed or did not try",
          "optional": true
        },
        {
          "key": "learning",
          "label": "What helped, got in the way or remains unclear",
          "optional": true
        },
        {
          "key": "therapy-review",
          "label": "What I want to review or change with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If the action still did not happen",
        "text": "That is another chance to understand the fit, not a reason for blame. You can revisit only a useful question or review it together. Do not keep repeating the exercise to earn approval."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan: General Handouts 6 and 8, official orientation reference",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-orientation.pdf?t=1",
      "supports": "Handout 6 distinguishes the main questions of chain and missing-links work; Handout 8 gives conditional knowledge, willingness, remembering and barrier checks with matched problem-solving.",
      "limits": "Handout 8: original p23, PDF viewer p17. Handout 6: PDF viewer p13. Professional method source, not isolated digital validation. Source handout wording/forms are not reproduced; electronic display rights are not granted by public access."
    },
    {
      "id": "Linehan: General Worksheet 3 reference",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-worksheets.pdf?t=1",
      "supports": "Stop at a relevant branch rather than require all questions, then work on the indicated problem.",
      "limits": "Original p38, PDF viewer p17. This candidate does not reproduce the worksheet, scale or prompts. Later-use planning and actual review are added follow-through, not attributed to this worksheet."
    },
    {
      "id": "Linehan: official teaching notes",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-all-teaching.pdf?t=1",
      "supports": "Stop questions when further ones are not useful, then problem-solve; collaborate and consider deeper assessment when barriers persist.",
      "limits": "Original p147, PDF viewer p27. Clinician teaching, not permission for unsupervised high-risk analysis or universal age suitability. No source pages redistributed."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Agreed useful target and current fit before diagnostic questions",
      "sections": [
        "practice.action"
      ],
      "source": "Linehan target distinction; conservative agreement/current-fit adaptation"
    },
    {
      "operation": "Conditional knowledge, willingness, came-to-mind and remaining-barrier checks with stop-to-adjustment routes",
      "sections": [
        "practice.knowledge",
        "practice.willingness",
        "practice.remembering",
        "practice.barriers"
      ],
      "source": "General Handout8, Worksheet3 and official teaching notes"
    },
    {
      "operation": "Matched clarification, goal discussion, cue, skill teaching/rehearsal or resource/support problem-solving",
      "sections": [
        "practice.adjust"
      ],
      "source": "General Handout8 and teaching notes; explicit what-versus-how explanation"
    },
    {
      "operation": "Optional future opportunity and actual-use review",
      "sections": [
        "practice.plan",
        "practice.review"
      ],
      "source": "Product follow-through extension, not claimed as original source-prescribed Missing-Links steps"
    }
  ],
  "narrationSegments": [
    {
      "id": "missing-links-analysis.intro",
      "title": "Find what was missing, without blame",
      "text": "Sometimes an action we agreed would help does not happen. Missing-Links Analysis asks what was missing between the plan and that moment. It does not assume you did not care or try hard enough.\n\nYou check only the questions that help. Was the plan clear? Were you willing to try? Did it come to mind? What else got in the way? When you find a useful issue, stop the questions and work on an adjustment with your therapist.",
      "sha256": "8c833d05ef24003ba23317f99d265558b4ae0e02b194b29d73bc2223a8d3bb45",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.fit",
      "title": "Check that the plan was truly agreed and still fits",
      "text": "Use one ordinary action you and your therapist agreed could help. Choose one occasion when it did not happen. If the plan was never agreed, was unclear or no longer fits, start there. You do not have to defend yourself.\n\nThis page is not for missed medicine, changes to medical care, alcohol or other drug use, or an urgent safety task. Get suitable professional help for those needs. You do not have to finish this exercise before getting support.\n\nA lack of time, energy, skill, access or help is not the same as choosing not to act. A boundary or changed circumstance may be a good reason to change the plan. No one should use this page to punish or pressure you.\n\nYou can stop, skip a question, keep it open or read the example. The page does not decide the reason, send a report or make a new agreement for you.",
      "sha256": "e946408dcd9fc868a947e3b564f8d5acbd08ecb69534015f7fed426a2bf477f2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, contact details and private health details are not needed. Notes stay while you use this open tool, including its example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes to your therapist. Optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "9fd84c0bdb83a92c3414ed9890ea3faa1ee46e4ad59cea81f8989677456db41d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.close",
      "title": "Leave the review here",
      "text": "You can finish with one useful question, an adjustment, a choice to pause or no answer yet. There is no need to catch up, prove willingness or promise success.\n\nYou may return to a prompt or choose notes to keep for your session. Finish and clear removes the notes here, not any copies you kept elsewhere. Nothing is sent to your therapist.",
      "sha256": "b8f142ab9f92c82e6bc2be54fd86d656944bd50fa42ff701c03635ecabffa805",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.example",
      "title": "Rae forgets a coping-card plan",
      "text": "This is made up. Rae and their therapist agree that after one usual phone call, Rae will look at a familiar coping card and choose whether a taught skill fits. The card plan does not happen that day.\n\nAgreement and clarity: Rae says the plan was theirs to choose and still seems useful. They knew what the action was and when they meant to try it. There is no need to treat this as unclear instructions.\n\nWillingness: Rae wanted to try it. The therapist does not infer lack of care from the missed action.\n\nRemembering: A doorbell rang as the call ended. Rae went to answer it and did not think of the card until later. This gives them a useful place to work. They stop the questions here rather than force Rae to answer every branch.\n\nMatched adjustment: Rae chooses a visible spot for the card beside the phone. This is a cue Rae will arrange, not a reminder set by this page. With the therapist, Rae practises ending a pretend call, noticing the card and deciding whether to use a familiar skill.\n\nLater use: After another usual call, Rae notices the card but finds part of it covered by papers. Rae moves a paper, reads the card and chooses one taught step. Rae does not feel calmer. Using the cue is different from changing a feeling.\n\nActual review: At the next session they discuss what happened. The cue helped, and clutter still made it harder to use. Rae and the therapist choose a clearer spot and rehearse noticing it there. That revised location is a new plan, not something already tried at home.\n\nIf there had been no suitable call, Rae could say there was no chance yet. If the plan no longer fit, they could change or stop it. Neither would prove Rae was unwilling.",
      "sha256": "e7067d7025a223233d77385bd66cc5a7333929c0cd54fb2725fcd459352f9621",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.learn",
      "title": "Match the adjustment to what was missing",
      "text": "This method asks about an action that did not happen. Chain Analysis looks closely at a problem action and what led to and followed it. Your therapist may combine the methods when that helps. Return after a gap and Maintenance Planning can help with broader practice plans, but they do not replace these specific questions.\n\nKnowing what was agreed is one thing. Knowing how to do it is another. You might know you planned to ask for help but still need to practise the words. A clearer explanation, a demonstration or rehearsal may help more than another reminder.\n\nWillingness asks about your choice at that time, not your energy or ability. You can be willing and unable to act. You can also have concerns, disagree or need to change the goal. A choice deserves discussion, not a label.\n\nA plan may be clear and chosen but not come to mind when needed. Then a useful cue may help. If it did come to mind, look at what blocked action, such as time, skill, distress, resources, support or a changed setting.\n\nYou do not need to answer every question. Stop when another question would not help, then work on a fitting change. There may be more than one issue. Treat your explanation as something to check, not a proven cause.\n\nThis resource adds an optional later-use plan and review so you can see whether an adjustment helped. That is follow-through, not a promise to complete the action. No reminders, appointments or messages are arranged by this page.",
      "sha256": "ac098e838dbd989d63a4aa418e12b4163dc131ac18341896ae8ed2e1f0792619",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.action",
      "title": "Name the agreed action and the occasion",
      "text": "What ordinary action did you and your therapist agree could help? Choose one time it did not happen. Keep the action separate from the result you hoped for: \"look at my card\" differs from \"feel calm\".\n\nWas it actually your agreement, and did the plan still fit that moment? If not, you can go straight to discussing a clearer or different plan. You do not need to answer questions about willingness to explain a task you never agreed to.",
      "sha256": "c8c1a1514312b3c8aeb5fe4a2b81799fd96cca361b1706c2429e964148fe7e12",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.action.help",
      "title": "If you only know that things did not go well",
      "text": "Ask your therapist to help name a clear action, not a demand for a feeling or an outcome outside your control. You can leave the target open rather than guess.",
      "sha256": "5f45b71414631265acc3692d41a950170766efba1be9ef841cce8bd961d74893",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "missing-links-analysis.practice.knowledge",
      "title": "Was the action clear at that time?",
      "text": "At the time, did you understand what action was agreed and when it was meant to fit? This is about knowing the plan, not proving you could carry it out.\n\nIf the plan was unclear, stop here and work on an adjustment. You might need clearer words, a smaller task or to check the agreement with your therapist. If it was clear, the next useful question may be about willingness.",
      "sha256": "ea1030a4d7170912c99bad5e7d19a3fef08824848fc6286f6fd904c32f31af59",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.knowledge.help",
      "title": "If you knew what, but not how",
      "text": "Keep that difference. A skill may need a demonstration or practice together, even when the instructions were clear. You can go to the adjustment now or discuss that barrier later.",
      "sha256": "0954c8511b4318dff1ec13c1de5be0a4c50b82bdb67b230867b7270504c1b1ce",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "missing-links-analysis.practice.willingness",
      "title": "Were you choosing to try it then?",
      "text": "At that moment, were you willing to try the agreed action, even if it was not easy? This asks about choice, not whether you had enough energy, skill or help.\n\nIf you were not willing, felt mixed or had concerns, you can stop here and discuss them. What mattered to you? Did the plan ask too much, feel unsafe or conflict with a need? The goal can be changed. If you were willing, check whether the plan came to mind.",
      "sha256": "cfd41321270312aebf45cf21c22ab35eb5e118002b6f3c414b1331897cafc41c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.willingness.help",
      "title": "If willingness feels like a test of being good",
      "text": "It is not. You do not have to agree with someone else to pass this page. A lack of ability or support is not unwillingness. Discuss the plan and the real circumstances with your therapist.",
      "sha256": "d71855c31d94b2b387f5f3a4351d724f70d4456e6668426d6bcee992b3aa15a8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "missing-links-analysis.practice.remembering",
      "title": "Did the plan come to mind when needed?",
      "text": "Think of the time the action could have happened. Did you remember the plan then, or only later? If you cannot recall, leave it open. Do not assume you remembered just because the plan seems clear now.\n\nIf it did not come to mind, stop here and consider a cue that fits your day and access needs. If it did come to mind, the next question is what blocked the action. Forgetting is information, not a character fault.",
      "sha256": "a7da251e2e7c82716a1922bcbfb9fcc0f172f4f7ef8dcdd9632a9c0d11e103f7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.remembering.help",
      "title": "If reminders have not helped",
      "text": "More reminders are not always the answer. Check whether the cue was noticeable, came at a useful time and linked to a possible action. You may also need skill, time or support. This page creates no reminder.",
      "sha256": "c335f6c65693bbf53e5b699a94eb872f86e37f129f4da3b59eaf9d598bfbd4aa",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "missing-links-analysis.practice.barriers",
      "title": "What blocked it even though you remembered?",
      "text": "If the plan was clear, you were willing and it came to mind, what got between that and doing it? You may have needed time, a skill, equipment, access, help or a different setting. Feelings or competing needs may have mattered too.\n\nKnowing what to do does not mean knowing how. If a step was too hard or you had not learned it, ask for teaching or practice together. If circumstances changed, it may have been wise not to follow the old plan.",
      "sha256": "e56c87e2f8ce90237e00b245143c3d3382e329b1b9926b73d5c8b3b5cccf4d27",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.barriers.help",
      "title": "If several things got in the way",
      "text": "You do not have to pick one true cause. Start with a change that seems useful and possible. Your therapist can help look more closely if the same barrier keeps showing up.",
      "sha256": "52a5eb3ff877f00038a91fe154d2db56e425e232bd3c0cfad3ff33ab47bb719c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "missing-links-analysis.practice.adjust",
      "title": "Choose a change that matches the issue",
      "text": "Use the issue you found; you do not have to answer the other questions first. What is your best working idea, and what is still unclear? It can change when you learn more.\n\nIf the plan was unclear, ask for a clear, shared next step. If you had concerns or did not choose it, discuss the goal, benefits, costs and fit. You can revise, pause or decline a plan rather than promise more effort.\n\nIf it was forgotten, choose one cue you could notice at a useful moment. If you remembered but were blocked, match the change to that barrier: a smaller step, more time, an accessible option, help or teaching. Do not remove a needed aid or boundary.\n\nWith your therapist, choose one feasible adjustment. If you need a skill, ask them to show it and practise it together. If useful, rehearse noticing a cue and the first action. A reminder alone cannot supply a skill or resource you do not have.",
      "sha256": "0922cbe737102ddd2df46862c67a663566b45b0b3fdf676411c1fd5a8f43f7dc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.adjust.help",
      "title": "If the best choice is to stop or change the goal",
      "text": "That can be a useful result. Check it with your therapist rather than keep a plan just to complete it. This page does not change your treatment or create an agreement.",
      "sha256": "e0af30a41b795e33cd2f0fcf4c5068ec92b34cb38d14076522af425cf7c28b92",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "missing-links-analysis.practice.plan",
      "title": "If useful, plan one next opportunity",
      "text": "This follow-through is optional. For an adjustment agreed with your therapist, when might a suitable chance arise? Note the cue and first action, plus what support you need. A plan here does not set a reminder or appointment.\n\nWhat if the cue is missed, the chance does not arise, or the plan no longer fits? Choose a smaller option, support or a pause. There is no catch-up requirement or promise to keep trying until it works.\n\nAfter a real opportunity, you can return to Review an adjustment and describe what happened. You can also review no chance yet or a changed goal. Notes do not stay when you leave or reload; choose notes to keep first if you want a copy.",
      "sha256": "44ba4807ca5cebcb91dbe5df65934edf992e441bd4c36a4327cd436b3e72c768",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.plan.help",
      "title": "If you need help before the next opportunity",
      "text": "You can ask now. Ordinary practice does not replace professional advice or urgent support. Use Support and urgent help to find help options. No one monitors these notes.",
      "sha256": "d2c7c4ebc75b0a3a74a5bade857f14fe6a70cee309fa1f68f3d7288826cdc169",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "missing-links-analysis.practice.review",
      "title": "Review the real opportunity and adjustment",
      "text": "Recall or check the adjustment you agreed. If you cannot remember, leave it open and ask your therapist. Was there a suitable chance to use it? What did you actually try, change, stop or not try?\n\nWhat helped or still got in the way? Keep doing the action separate from a feeling improving or someone else responding as hoped. No suitable chance is different from choosing not to act.\n\nReview this with your therapist. You may keep the adjustment, revise it, get more teaching or support, change the goal or pause. Do not use one result as proof of your motivation or worth. A new plan is not required before you finish.",
      "sha256": "e4799fa0699d50952b5911feae95250fea331a441d795dbed20bc3cc2c21328c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "missing-links-analysis.practice.review.help",
      "title": "If the action still did not happen",
      "text": "That is another chance to understand the fit, not a reason for blame. You can revisit only a useful question or review it together. Do not keep repeating the exercise to earn approval.",
      "sha256": "b49b21a095d4a20ab0eb8ffc15ea337d94ff52cf748d92774245d63116325993",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
