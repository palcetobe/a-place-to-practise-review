window.ABCComponentContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/abcplease",
  "componentId": "component/abcplease/accumulate",
  "resourceId": "tool/accumulating-positive-emotions",
  "routeProposal": "/accumulating-positive-emotions/",
  "title": "Accumulating Positive Emotions",
  "version": "2026-11-03-abc-components-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Both short-term pleasant engagement and long-term values-to-action procedures, as a bounded therapist-introduced ABC component. Not a promise of positive feeling, full Behavioural Activation or a complete values programme.",
  "groupedSetStatus": "This is one uncounted component of classic/abcplease. Other ABC components and PLEASE have separate statuses. No new canonical count and no complete ABC PLEASE or DBT claim.",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always reachable outside focus folds, including before practice.",
    "destination": "Reuse verified project support route; do not invent contacts."
  },
  "clinicalContract": {
    "sourcePopulationContext": "Therapist-introduced and individually adapted for developmental, communication, safeguarding, health and access needs. No universal age gate or all-age/app validation claim.",
    "observedPractice": "Reading, planning, rehearsing, real-world attempting and reviewing are different. No automatic completion or success inference.",
    "learningObjective": "Distinguish making room for a pleasant experience now from shaping longer-term opportunities through values-linked action.",
    "practiceObjective": "Choose and engage in an accessible pleasant activity with attention, or carry a chosen value through goals to an actual action step; review without requiring positive emotion."
  },
  "privacy": {
    "id": "accumulating-positive-emotions.privacy",
    "title": "Writing is optional",
    "paragraphs": [
      "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.",
      "Leaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.",
      "Review session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored."
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "Practice enters/resumes directly; no duplicate Start. One focused prompt group by default; free jump, Show all, Back and Finish always available. No completion locks.",
    "writing": "Hidden by default and optional; hiding removes every private echo/preview from view. No required fields, analysis, ratings or generated feedback.",
    "persistence": "Active-tool memory only. Internal navigation retains choices/notes; leaving/reload/restart/clear erases them. No localStorage, backend, diary or automatic carry-forward. Returning later allows a fresh account or privately kept notes, never claims restoration.",
    "narration": "Exact static section text only, user-initiated Listen/Pause/Resume; Replay only after this exact current clip was actually played. Leaving section/branch/tool stops playback. No autoplay, concatenated hidden branches, private-answer speech or TTS fallback. No recording acceptance implied.",
    "timer": "None. Rehearsal and actual activity are user-paced; no countdown or prescribed dose.",
    "visual": "Textually labelled method map only. No scores, ticks implying completion, streaks, positive-outcome badges or forced reflection.",
    "context": "Use an ordinary personal situation or the self-contained fictional example without an extra mode selector. Never prefill private fields with fiction.",
    "modes": [
      "short",
      "long"
    ],
    "modeChoice": {
      "title": "Which part would you like to practise?",
      "options": [
        {
          "value": "short",
          "label": "Pleasant experiences now",
          "startSectionId": "accumulating-positive-emotions.practice.short.choose"
        },
        {
          "value": "long",
          "label": "Values-linked steps over time",
          "startSectionId": "accumulating-positive-emotions.practice.long.value"
        }
      ],
      "purpose": "Two actual procedures; neither selected automatically. Learn explains both. Example follows selected branch, or offers these same two labelled choices if none selected. No third pseudo-mode.",
      "switching": "Stop narration and show only selected branch. Retain separate branch notes in this active tool; warn if any context changed. Never move short-term notes into long-term fields. Show all means all prompts in the selected branch, not silent mixing."
    },
    "stateBoundary": "Keep a separate focus position for each real mode/branch. Accumulation notes are namespaced by short/long. Mastery plan and review are entry points into one challenge record, not separate duplicate records. Same-open-page activity while away from screen retains in-memory notes; actual leave/reload clears. Never infer attempted/completed state from clicks, fields or navigation.",
    "shortcut": "Existing public REVIEW session-only shortcut keyed by exact component/resource identity. No usual Toolbox write, durable persistence, localStorage or personal notes. Display the exact review-session lifetime notice; shortcut lifetime distinct from active-tool note clearing.",
    "reviewAccess": "Every review prompt freely accessible, including no attempt, partial attempt, changed activity or changed circumstances. No I did it gate, success confirmation, outcome flag or required account."
  },
  "close": {
    "id": "accumulating-positive-emotions.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.",
      "Return to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here."
    ],
    "actions": [
      "Back to practice",
      "Choose notes to keep",
      "Save session shortcut",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "id": "linehan-er-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-3.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical official emotion-regulation handouts 14–19 and worksheets 10–13; exact component locations in methodTraceability.",
      "limits": "Original wording/examples only; no reproduction license for electronic display. Recognition and procedure evidence, not digital/adolescent validation or exact revised-2025 wording."
    },
    {
      "id": "linehan-er-teaching-2015",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-3teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Teacher explanation and practice/review distinctions, including not penalizing a different mastery activity than planned.",
      "limits": "Professional source, not a standalone client script. No efficacy or completeness certification for this app."
    }
  ],
  "implementationGates": {
    "capabilityClaims": "Privacy/close text must not be offered or narrated until exact persistence, explicit selected-note preview/copy/download and shortcut behaviors pass actual runtime tests. Implement the contract, do not silently remove capabilities or promise them before tests.",
    "gatedSectionIds": [
      "accumulating-positive-emotions.privacy",
      "accumulating-positive-emotions.close"
    ],
    "testsRequired": [
      "Internal Practice/Example/Learn/help/back retains notes and mode",
      "Leave/reload/restart/clear removes all notes and echoes",
      "Hidden writing hides all private previews",
      "No note selected by default; exact selection/preview before explicit copy/download",
      "Shortcut retains only distinct component identity in the open preview session; reload/session closure removes it; usual Toolbox is unchanged",
      "Audio contains only visible static current section, stops on navigation, and never uses private fields",
      "Free jump/Show all/Finish works without input, completion or improved emotion",
      "Later return is fresh; no planned or attempted status inferred"
    ]
  },
  "acceptance": [
    "Complete named component operations remain teachable and actually practicable, not just definitions.",
    "Original worked example includes actual rehearsal/attempt and neutral review.",
    "All help, fit and full teaching accessible without enforced reading.",
    "No writing, rating, emotion change or real-world activity required to leave.",
    "Content review is separate from clinical validation, UI testing, guide/export review and audio listening."
  ],
  "intro": {
    "id": "accumulating-positive-emotions.intro",
    "title": "Accumulating Positive Emotions",
    "paragraphs": [
      "This skill has two parts: making room for pleasant experiences in the short term, and taking values-linked steps that may create more of those opportunities over time.",
      "You can practise either part and return to the other. You do not have to feel happy, grateful or hopeful. The aim is to engage with something available and meaningful, not force an emotion."
    ]
  },
  "fit": {
    "id": "accumulating-positive-emotions.fit",
    "title": "Check whether this fits",
    "paragraphs": [
      "Use this with your therapist’s guidance and your current capacity, health, circumstances and resources in mind. An activity can be quiet, brief, familiar or supported. Rest and practical needs matter.",
      "Do not choose spending, physical activity, substances or other actions that conflict with your care, safety or responsibilities. If energy or mood has changed sharply, discuss suitable activity with your clinician instead of adding more demands here.",
      "During grief, low mood or hardship, pleasant feelings may be absent or mixed. You do not need to deny that reality, distract from a problem that needs attention or make yourself be positive."
    ]
  },
  "learn": {
    "id": "accumulating-positive-emotions.learn",
    "title": "Two ways of making room",
    "paragraphs": [
      "Short term: choose an accessible activity with some possibility of pleasure or interest, engage with it, and notice the experience as it happens. If worry about deserving it, losing it or what comes next takes over, gently return to the activity. A genuine urgent need may still require action.",
      "Long term: choose a personally important value, consider goals that express it, select one workable goal, identify steps and take a suitable step. Review what happens and continue or adjust over time.",
      "There is overlap with Behavioural Activation and values work. Here the short-term branch includes attending to the experience, while the long-term branch connects a value through goals to action and future opportunities. Neither selecting an activity nor naming a value completes the practice.",
      "The source encourages regular opportunities. This adaptation supports an individually agreed rhythm, not a daily quota. A single attempt does not establish lasting change or complete the whole ABC PLEASE set."
    ]
  },
  "examples": [
    {
      "id": "accumulating-positive-emotions.example.short",
      "title": "Example: Jules makes room for music",
      "paragraphs": [
        "Jules has little energy and no spare money. They choose to listen to a familiar song sitting in their usual chair, rather than plan an outing.",
        "During the song, Jules notices the rhythm, then starts thinking that they should be doing chores. The chore can wait, so they bring attention back to one instrument. They do not argue with the thought or demand enjoyment.",
        "Afterward Jules notices a brief moment of interest and still feels sad. They can leave it there. Another day they may try the same activity, choose something different or decide that rest is what they need."
      ],
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.example.long",
      "title": "Example: Rowan takes a step toward connection",
      "paragraphs": [
        "Rowan values connection but has felt isolated. Possible goals include staying in touch with an existing friend or finding a local shared-interest group. Rowan chooses the existing friendship because it feels more workable now.",
        "They break it into small steps: decide what contact would fit, draft an invitation and send it when ready. The first suitable step is writing a simple message asking whether the friend would like a short call.",
        "Rowan actually drafts the message and later chooses to send it. The friend replies that this week is busy. Rowan is disappointed and does not treat the reply as a verdict on the value of connection.",
        "In review, Rowan notes that sending was a real step but a call did not happen. They could suggest another time, contact someone else or pause. They do not need to keep contacting a person who does not want contact."
      ],
      "branch": "long"
    }
  ],
  "practice": [
    {
      "id": "accumulating-positive-emotions.practice.short.choose",
      "title": "Choose an accessible pleasant activity",
      "paragraphs": [
        "What small activity might offer some interest, comfort or pleasure today? It could be hearing a familiar song, looking at something you enjoy, or another activity that fits you. These are examples, not instructions.",
        "Consider energy, access, cost and any care guidance. Choose something possible, or use Jules’s example to explore the process without making a personal plan."
      ],
      "fields": [
        {
          "key": "short-activity",
          "label": "An activity I could choose",
          "optional": true
        },
        {
          "key": "short-fit",
          "label": "What would make it possible",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing sounds enjoyable",
        "text": "You can choose something mildly interesting or familiar without expecting pleasure. You can also stop and bring the difficulty to your therapist. This is not a test of gratitude."
      },
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.engage",
      "title": "Make room and engage",
      "paragraphs": [
        "When the opportunity fits, actually spend some time with the chosen activity. You can leave this page or set it aside. Let your attention rest on something about the experience rather than trying to measure how good you feel.",
        "If you are trying it now, take the time that fits you. If it needs another occasion, this is a plan for later, not a completed experience."
      ],
      "help": {
        "title": "If another task competes for attention",
        "text": "If it is safe and practical, leave the other task briefly and return to this experience. If a real responsibility needs attention, attend to it. The practice does not require ignoring what matters."
      },
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.return",
      "title": "Return attention when worry takes over",
      "paragraphs": [
        "During the activity, notice if your attention moves to whether you deserve it, when it will end or what others will expect. Without settling those questions, see whether you can return to one part of what you are doing.",
        "You can practise this now with something already available, or remember to try during the activity later. If the experience is unpleasant or does not fit, change it or stop."
      ],
      "fields": [
        {
          "key": "short-attention",
          "label": "Something I noticed while engaging",
          "optional": true
        }
      ],
      "help": {
        "title": "If positive and difficult feelings coexist",
        "text": "They can coexist. Returning attention is not a demand to suppress sadness, grief or anxiety. You do not have to stay with an activity that makes things worse."
      },
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.review",
      "title": "Review the experience, if useful",
      "paragraphs": [
        "What did you actually do or notice? Was the activity available and manageable? Would you repeat it, change it or leave it?",
        "An absence of pleasure is not failure, and a plan that was not tried is still only a plan. You can return later with a fresh account or keep no record."
      ],
      "fields": [
        {
          "key": "short-review",
          "label": "What I noticed or might change",
          "optional": true
        }
      ],
      "help": {
        "title": "If I never found the opportunity",
        "text": "Consider access, timing and support rather than blame. Adapt the opportunity or pause. Nothing needs to be scored."
      },
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.value",
      "title": "Choose a value to work with",
      "paragraphs": [
        "What matters to you about how you live or relate? Choose one personally important direction to give attention to now. It might concern connection, learning, care or something else you name.",
        "Use Rowan’s example if that helps. You do not have to select the most important value in your whole life, or a value someone else expects you to have."
      ],
      "fields": [
        {
          "key": "long-value",
          "label": "A value I want to work with",
          "optional": true
        }
      ],
      "help": {
        "title": "If values compete",
        "text": "Choose a manageable focus for now while respecting other responsibilities. This is not a ranking of your worth or a requirement to neglect another value."
      },
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.goals",
      "title": "Consider goals that express the value",
      "paragraphs": [
        "Think of a few specific changes or goals that could make this value more present in your life. Then choose one that is feasible enough to work toward now.",
        "For connection, Rowan considered keeping in touch with a friend and joining a group. Neither guarantees closeness. Goals can involve your own actions without controlling someone else."
      ],
      "fields": [
        {
          "key": "long-options",
          "label": "Possible goals",
          "optional": true
        },
        {
          "key": "long-goal",
          "label": "One goal to work toward",
          "optional": true
        }
      ],
      "help": {
        "title": "If I only have a large goal",
        "text": "Make one part more concrete and within your influence. “Build a social life” might begin with deciding what sort of contact you want, not forcing a friendship."
      },
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.steps",
      "title": "Find small actions and choose one",
      "paragraphs": [
        "What steps could move toward this goal? Identify the first workable action, what it needs, and an opportunity that fits. Include support or a boundary if needed.",
        "Choose a suitable step now if one is available. Otherwise name a realistic later opportunity. A step can be preparation, but it must be something you can actually do, not only a hope for an outcome."
      ],
      "fields": [
        {
          "key": "long-steps",
          "label": "Possible steps",
          "optional": true
        },
        {
          "key": "long-action",
          "label": "The step I could actually take and when",
          "optional": true
        }
      ],
      "help": {
        "title": "If resources are the obstacle",
        "text": "Make room for the real limit. Seeking information or support may fit; spending money, increasing activity or pushing past a limit is not required."
      },
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.act",
      "title": "Take a suitable step in your life",
      "paragraphs": [
        "If the step is appropriate now, you can leave this page and do it. If not, use the opportunity you chose later or decide not to proceed. You do not have to send a message or involve anyone to finish here.",
        "Return to review what actually happened. Notes are not saved after you leave; remember the step, use your own paper, or explicitly select a copy if you want one."
      ],
      "help": {
        "title": "If I only planned it",
        "text": "Planning can be useful preparation, but this page will not call it the action you intended to take. You can return to the steps or stop."
      },
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.review",
      "title": "Review and choose whether to continue",
      "paragraphs": [
        "What action did you actually take, if any? What happened, and what did it show about the goal, opportunity or support? Keep your action separate from outcomes you could not control.",
        "Would another small step, a different goal, more support or a pause fit? You can make no decision now. Building future opportunities takes time and does not require positive feelings after each action."
      ],
      "fields": [
        {
          "key": "long-actual",
          "label": "What I actually did or what prevented it",
          "optional": true
        },
        {
          "key": "long-review",
          "label": "What I might continue or adjust",
          "optional": true
        }
      ],
      "help": {
        "title": "If the outcome was disappointing",
        "text": "Acknowledge it without making a verdict about your worth or abandoning the value automatically. Review the practical fit, consent and available support. No repeated contact or forced persistence is required."
      },
      "branch": "long"
    }
  ],
  "methodElements": [
    "Short: feasible pleasant activity",
    "Short: actual engagement",
    "Short: mindful participation and return from worry",
    "Long: personally chosen value",
    "Long: options and chosen goal",
    "Long: actionable steps",
    "Long: actual suitable action",
    "Neutral review and ongoing adjustment in both branches"
  ],
  "methodTraceability": {
    "sourceLocation": "Emotion Regulation Handouts 15/17, PDF pages 43/47; worksheets 10–11b, PDF pages 83–88; source pleasant-events/values lists not reproduced.",
    "componentIdentity": "Existing component/abcplease/accumulate. component/abcplease/accumulate-positives--short-and-long-term is overlapping catalogue scope, not another count. No verified accepted standalone route; proposed tool/accumulating-positive-emotions and /accumulating-positive-emotions/ are distinct new local identities.",
    "adaptations": [
      "Short and long procedures separately navigable without marking either complete.",
      "Source daily frequency adapted to individually agreed opportunities, disclosed in teaching.",
      "Original low-resource examples and no forced positive emotion."
    ]
  },
  "componentAliases": [
    "component/abcplease/accumulate-positives--short-and-long-term"
  ],
  "identityBoundary": "Aliases identify the same accumulation component; preserve both catalogue labels, do not delete nodes, count twice or create a fourth skill.",
  "relatedResources": {
    "status": "Preserve existing identities; links only after route verification in isolated runtime. No silent redirection/replacement.",
    "resources": [
      "classic/ba",
      "classic/values"
    ]
  },
  "narrationSegments": [
    {
      "id": "accumulating-positive-emotions.privacy",
      "title": "Writing is optional",
      "text": "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.\n\nLeaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.\n\nReview session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored.",
      "textSha256": "08e5d33489f269867a52f82337eafbed695f22fd860232e4a1260c736a31d56d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "capabilityGate": "Unavailable until all relevant actual renderer capability tests pass."
    },
    {
      "id": "accumulating-positive-emotions.intro",
      "title": "Accumulating Positive Emotions",
      "text": "This skill has two parts: making room for pleasant experiences in the short term, and taking values-linked steps that may create more of those opportunities over time.\n\nYou can practise either part and return to the other. You do not have to feel happy, grateful or hopeful. The aim is to engage with something available and meaningful, not force an emotion.",
      "textSha256": "5f79b402d2b11791eb907b67e3ceabe4e592252aba3f84486a462b23e06038fc",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "accumulating-positive-emotions.fit",
      "title": "Check whether this fits",
      "text": "Use this with your therapist’s guidance and your current capacity, health, circumstances and resources in mind. An activity can be quiet, brief, familiar or supported. Rest and practical needs matter.\n\nDo not choose spending, physical activity, substances or other actions that conflict with your care, safety or responsibilities. If energy or mood has changed sharply, discuss suitable activity with your clinician instead of adding more demands here.\n\nDuring grief, low mood or hardship, pleasant feelings may be absent or mixed. You do not need to deny that reality, distract from a problem that needs attention or make yourself be positive.",
      "textSha256": "d9a8c2833c4637e2bbc7161268aeac48385f2a92b6966a101ba5ccaa9259a1e4",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "accumulating-positive-emotions.learn",
      "title": "Two ways of making room",
      "text": "Short term: choose an accessible activity with some possibility of pleasure or interest, engage with it, and notice the experience as it happens. If worry about deserving it, losing it or what comes next takes over, gently return to the activity. A genuine urgent need may still require action.\n\nLong term: choose a personally important value, consider goals that express it, select one workable goal, identify steps and take a suitable step. Review what happens and continue or adjust over time.\n\nThere is overlap with Behavioural Activation and values work. Here the short-term branch includes attending to the experience, while the long-term branch connects a value through goals to action and future opportunities. Neither selecting an activity nor naming a value completes the practice.\n\nThe source encourages regular opportunities. This adaptation supports an individually agreed rhythm, not a daily quota. A single attempt does not establish lasting change or complete the whole ABC PLEASE set.",
      "textSha256": "785e114725e972b30d4e880b0d2e6379eaf8a90baa376d19379b5aa1fd46cd1c",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "accumulating-positive-emotions.example.short",
      "title": "Example: Jules makes room for music",
      "text": "Jules has little energy and no spare money. They choose to listen to a familiar song sitting in their usual chair, rather than plan an outing.\n\nDuring the song, Jules notices the rhythm, then starts thinking that they should be doing chores. The chore can wait, so they bring attention back to one instrument. They do not argue with the thought or demand enjoyment.\n\nAfterward Jules notices a brief moment of interest and still feels sad. They can leave it there. Another day they may try the same activity, choose something different or decide that rest is what they need.",
      "textSha256": "5d0863dafc8a2d8fee408dc864a881806208e0f4085b7c896f9a8ac93c2f8802",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.example.long",
      "title": "Example: Rowan takes a step toward connection",
      "text": "Rowan values connection but has felt isolated. Possible goals include staying in touch with an existing friend or finding a local shared-interest group. Rowan chooses the existing friendship because it feels more workable now.\n\nThey break it into small steps: decide what contact would fit, draft an invitation and send it when ready. The first suitable step is writing a simple message asking whether the friend would like a short call.\n\nRowan actually drafts the message and later chooses to send it. The friend replies that this week is busy. Rowan is disappointed and does not treat the reply as a verdict on the value of connection.\n\nIn review, Rowan notes that sending was a real step but a call did not happen. They could suggest another time, contact someone else or pause. They do not need to keep contacting a person who does not want contact.",
      "textSha256": "9ec5d6d56027ea307c9e6a526b3d4726b16fb37dcc1fb4932e822bac4a849c90",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.choose",
      "title": "Choose an accessible pleasant activity",
      "text": "What small activity might offer some interest, comfort or pleasure today? It could be hearing a familiar song, looking at something you enjoy, or another activity that fits you. These are examples, not instructions.\n\nConsider energy, access, cost and any care guidance. Choose something possible, or use Jules’s example to explore the process without making a personal plan.",
      "textSha256": "cbd8b8477cf18089b494154993345b4bbf0aa66746e66409d8ad1b5e7ecd8e73",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.choose.help",
      "title": "If nothing sounds enjoyable",
      "text": "You can choose something mildly interesting or familiar without expecting pleasure. You can also stop and bring the difficulty to your therapist. This is not a test of gratitude.",
      "textSha256": "fc022feae3a2efc91f04322a523e2aa8b7f70d7a077f81eae641b84e2a6a33bd",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.engage",
      "title": "Make room and engage",
      "text": "When the opportunity fits, actually spend some time with the chosen activity. You can leave this page or set it aside. Let your attention rest on something about the experience rather than trying to measure how good you feel.\n\nIf you are trying it now, take the time that fits you. If it needs another occasion, this is a plan for later, not a completed experience.",
      "textSha256": "97e7cd5f7ec2439bf69e5d4ad6c31aeb9a485ae48580ba179f6760e512db1aff",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.engage.help",
      "title": "If another task competes for attention",
      "text": "If it is safe and practical, leave the other task briefly and return to this experience. If a real responsibility needs attention, attend to it. The practice does not require ignoring what matters.",
      "textSha256": "abf138705dd27acf1879dce59bc53f05552059edbad130a9e4b0154f6cfb4f2c",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.return",
      "title": "Return attention when worry takes over",
      "text": "During the activity, notice if your attention moves to whether you deserve it, when it will end or what others will expect. Without settling those questions, see whether you can return to one part of what you are doing.\n\nYou can practise this now with something already available, or remember to try during the activity later. If the experience is unpleasant or does not fit, change it or stop.",
      "textSha256": "3408239827e99840f66077bd4cb8370b04c9fe42a04621f6e9d2a7f6e21bead9",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.return.help",
      "title": "If positive and difficult feelings coexist",
      "text": "They can coexist. Returning attention is not a demand to suppress sadness, grief or anxiety. You do not have to stay with an activity that makes things worse.",
      "textSha256": "b8f86ca8852b09babc81fe4545300a4e486f0ca24d2e5ab044f783a28daf6695",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.review",
      "title": "Review the experience, if useful",
      "text": "What did you actually do or notice? Was the activity available and manageable? Would you repeat it, change it or leave it?\n\nAn absence of pleasure is not failure, and a plan that was not tried is still only a plan. You can return later with a fresh account or keep no record.",
      "textSha256": "63854fadd7000deca40fcd8d672120260a6929f4f6cf3f3a0aa8699c8f3b0c8f",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.short.review.help",
      "title": "If I never found the opportunity",
      "text": "Consider access, timing and support rather than blame. Adapt the opportunity or pause. Nothing needs to be scored.",
      "textSha256": "eb944d4d428c1231981e0d9718bf32d14b2698d957a0ff44f35a372ca7c7926d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "short"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.value",
      "title": "Choose a value to work with",
      "text": "What matters to you about how you live or relate? Choose one personally important direction to give attention to now. It might concern connection, learning, care or something else you name.\n\nUse Rowan’s example if that helps. You do not have to select the most important value in your whole life, or a value someone else expects you to have.",
      "textSha256": "5a80c6159b3fc347d97284e1e413a6d1796fd89bda3576d0f4a1f681cc46cd1d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.value.help",
      "title": "If values compete",
      "text": "Choose a manageable focus for now while respecting other responsibilities. This is not a ranking of your worth or a requirement to neglect another value.",
      "textSha256": "076797a95a5e39bfb03233457afa11a64c13ef9d9b5c961fb78d69edf6cb0419",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.goals",
      "title": "Consider goals that express the value",
      "text": "Think of a few specific changes or goals that could make this value more present in your life. Then choose one that is feasible enough to work toward now.\n\nFor connection, Rowan considered keeping in touch with a friend and joining a group. Neither guarantees closeness. Goals can involve your own actions without controlling someone else.",
      "textSha256": "e5844e55e2066fd189e7f41170bd5ad42d0890c58030da1c601791ddc3cdbcc9",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.goals.help",
      "title": "If I only have a large goal",
      "text": "Make one part more concrete and within your influence. “Build a social life” might begin with deciding what sort of contact you want, not forcing a friendship.",
      "textSha256": "4e4952fe9cf0a35cdcccc1d78df2f817319e25d2b1889379eaf08fc95aa4cc3d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.steps",
      "title": "Find small actions and choose one",
      "text": "What steps could move toward this goal? Identify the first workable action, what it needs, and an opportunity that fits. Include support or a boundary if needed.\n\nChoose a suitable step now if one is available. Otherwise name a realistic later opportunity. A step can be preparation, but it must be something you can actually do, not only a hope for an outcome.",
      "textSha256": "8dda6923aa1e8dfb223a4a251817977fb0b49dd36fd37536244b496d65aa6b2b",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.steps.help",
      "title": "If resources are the obstacle",
      "text": "Make room for the real limit. Seeking information or support may fit; spending money, increasing activity or pushing past a limit is not required.",
      "textSha256": "35d9a46db25a5f474c208adcc9c53c34d8101d04b482d44cf204bfd059b46baa",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.act",
      "title": "Take a suitable step in your life",
      "text": "If the step is appropriate now, you can leave this page and do it. If not, use the opportunity you chose later or decide not to proceed. You do not have to send a message or involve anyone to finish here.\n\nReturn to review what actually happened. Notes are not saved after you leave; remember the step, use your own paper, or explicitly select a copy if you want one.",
      "textSha256": "ed03af38085c083780092ba40693a4502a62e53c0e0664e142373dbc6911d06a",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.act.help",
      "title": "If I only planned it",
      "text": "Planning can be useful preparation, but this page will not call it the action you intended to take. You can return to the steps or stop.",
      "textSha256": "3fe8ab0b764dd5c0ae9eb352fff4fd2b0695648cc8d299c87b5969833206be0e",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.review",
      "title": "Review and choose whether to continue",
      "text": "What action did you actually take, if any? What happened, and what did it show about the goal, opportunity or support? Keep your action separate from outcomes you could not control.\n\nWould another small step, a different goal, more support or a pause fit? You can make no decision now. Building future opportunities takes time and does not require positive feelings after each action.",
      "textSha256": "9d138fb16641521038f854b3762dec317a7005bb049b273f0e902cfc80540c89",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.practice.long.review.help",
      "title": "If the outcome was disappointing",
      "text": "Acknowledge it without making a verdict about your worth or abandoning the value automatically. Review the practical fit, consent and available support. No repeated contact or forced persistence is required.",
      "textSha256": "9ff182bc3335463e30b5143bae128634e35def1f983361ebad5695f487a4430b",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded.",
      "branch": "long"
    },
    {
      "id": "accumulating-positive-emotions.close",
      "title": "Leave the practice here",
      "text": "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.\n\nReturn to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here.",
      "textSha256": "c9171e9f0e25d189db3f09fbfa5ba8707d92ece31276d5ba3baa1b8bcbdbf102",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "capabilityGate": "Unavailable until all relevant actual renderer capability tests pass."
    }
  ],
  "staticTextCopyContract": {
    "scope": "An explicitly requested copy/download of authored teaching or narration transcript is separate from selected personal notes. No clipboard/export on navigation, Finish, Listen, mode selection or source visit.",
    "permissions": "No source PDF copying or redistribution. Cite sources; offer only original authored static content. Personal notes never appended by default."
  }
}
;
