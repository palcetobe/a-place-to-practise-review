window.EmotionSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "opposite.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "decisionGate": {
      "placement": "opposite.practice.decision before rehearse/try; full fit remains accessible before practice.",
      "default": "No real-world action route selected.",
      "context": "Keep the person’s optional situation/emotionUrge/effectiveness entries available adjacent to decision/rehearse/review when writing is shown; hiding writing hides every echo. No inferred clearance from those entries.",
      "choices": [
        {
          "id": "agreed",
          "label": "Use my therapist-agreed practice",
          "meaning": "User chooses to follow their existing agreed plan; never label safe, approved or clinically cleared."
        },
        {
          "id": "fiction",
          "label": "Rehearse Devon’s example",
          "meaning": "Only fictional rehearsal; do not show real-world action as required."
        },
        {
          "id": "pause",
          "label": "Pause and keep a question",
          "meaning": "Skip action route; review/finish/support remain available."
        }
      ],
      "requirements": [
        "Show check fields and decision prompt in order; no automatic recommendation from an emotion, rating or entered text.",
        "Real-world try text only after agreed route; fictional route substitutes exact fictional text in practice.try; pause route suppresses real-world try.",
        "Gate BOTH rehearse and try on every entry path: focused Next, Show all, direct jump, Example-to-Practice, Back/Forward and reset. With no route selected, display decision choices instead of personal rehearsal/action instructions. On reset restore no selection.",
        "Fiction route shows only Devon-specific rehearsal/try text, never instructions to enact a personal action. Pause route suppresses personal rehearsal and action; learning, reflection, Finish and Support remain freely accessible.",
        "Changing route retains optional notes but removes any implied action status; no completion badges."
      ],
      "fictionalRehearseText": "Using only Devon’s fictional story, try wording for a brief neutral reply instead of sarcasm. Consider how the delivery would avoid the original attack urge. Do not contact anyone or substitute a personal situation here.",
      "pauseRehearseText": "Personal rehearsal and action are paused. You can read the example, keep a question for your therapist, review or finish.",
      "fictionalTryText": "Rehearse Devon’s neutral response privately if useful. Do not contact anyone for this fictional exercise. Review only the rehearsal, or finish.",
      "pauseTryText": "Real-world practice is paused. You can keep a question for your therapist, review what you noticed, or finish.",
      "transitionMatrix": [
        {
          "event": "Initial entry or clear/restart/reload",
          "result": "No route selected; show decision choices before either rehearsal or try."
        },
        {
          "event": "Choose agreed",
          "result": "Allow authored agreed-plan rehearsal/try wording; no safe/approved/completed badge."
        },
        {
          "event": "Choose fiction from any route",
          "result": "Immediately replace rehearsal and try with Devon-only text and branch audio IDs; personal instructions removed, any playing old-branch narration stopped."
        },
        {
          "event": "Choose pause from any route",
          "result": "Immediately remove personal rehearsal/action instructions and stop old-branch audio; show pause text and freely accessible review/finish/support."
        },
        {
          "event": "Back/Forward or internal Example/Learn navigation",
          "result": "Retain explicit route within this session but recheck it before rendering either action prompt; never infer or upgrade a route from history."
        },
        {
          "event": "Show all/direct jump with no route or paused route",
          "result": "No personal instructions or personal branch audio; choices or pause text only."
        },
        {
          "event": "Leave tool",
          "result": "Clear route and all notes/echoes; reentry requires a new explicit choice."
        }
      ]
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/opposite",
  "title": "Opposite Action",
  "subtitle": "Practise an agreed response rather than follow an urge",
  "scope": "Therapist-co-designed, bounded follow-through for one ordinary action. Not an automatic emotion-to-action menu, generic Behavioural Activation, unsupervised exposure or a complete DBT protocol.",
  "version": "2026-11-02-emotion-batch-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Explain that opposite action depends on checking facts and action effectiveness, not automatically doing the reverse of a feeling.",
    "practiceObjective": "For an appropriate therapist-agreed situation, identify emotion and urge, review fit/effectiveness, rehearse or try the agreed opposite response and review what occurred; a rehearsal or plan is not marked as real-world action.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.guilford.com/books/DBT-Skills-Training-Manual/Marsha-Linehan/9781462556359/contents",
      "reviewed": "2026-11-02",
      "supports": "Current 2025 revised edition and module scope confirmed from publisher.",
      "limits": "Public contents are not exact procedure text; no assertion of equivalence to unavailable revised teaching notes."
    },
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-02",
      "supports": "Emotion Regulation handouts 9–11: facts/effectiveness decision, specified opposite action, wholehearted performance and repeated practice in the full method.",
      "limits": "Original app language only. Restricted reproduction licence; no copied handouts or complete DBT/effectiveness claim."
    }
  ],
  "resourceId": "tool/opposite-action",
  "routeProposal": "tool/opposite-action",
  "intro": {
    "id": "opposite.intro",
    "title": "Check the fit before choosing the action",
    "paragraphs": [
      "Opposite action means acting against an emotion-led urge when the emotion does not fit the facts, or following the urge would not be effective. It is not “always do the opposite.”",
      "Use this for an ordinary situation and response already worked out with your therapist. If you do not have an agreed practice, use the fictional rehearsal or learn about the method instead."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "opposite.fit",
    "title": "Keep the agreed limits",
    "paragraphs": [
      "A therapist should introduce and co-design the situation, response and review with you. This page cannot decide that an action is safe or appropriate.",
      "Do not use it to approach danger, accept abuse, make unwanted contact, disclose private information, push through pain or exhaustion, or carry out a self-designed exposure. Changed circumstances can change what fits.",
      "If you are unsure whether the facts or action still fit, pause the real-world practice and review with your therapist. You can use a fictional rehearsal or finish without being cleared by a checkbox."
    ]
  },
  "learn": {
    "id": "opposite.learn",
    "title": "Why the decision comes first",
    "paragraphs": [
      "An urge can keep a pattern going. A carefully selected opposite response offers a different way of acting, but the appropriate response depends on the emotion, the situation and its likely consequences.",
      "First distinguish the feeling from its action urge. Check the information and whether following that urge would help or cause problems. If the facts need a practical response, or the opposite action would be unsafe or unhelpful, do not force it.",
      "When an opposite response is agreed, practise it with a manner that supports it rather than covertly carrying out the original urge. This does not require a smile, eye contact, a posture that hurts, or pretending to feel differently. The full method may involve repeated agreed practice; this page supports one attempt and review, not repetition until you feel better."
    ]
  },
  "example": {
    "id": "opposite.example",
    "title": "Example — answering without a cutting remark",
    "paragraphs": [
      "In an ordinary, safe group project, Devon feels irritated after a teammate asks a question already answered in the shared note. Devon’s urge is to reply sarcastically. With a therapist, Devon has identified that attacking would not help; a brief neutral reply is the agreed opposite response, not agreeing to take on extra work.",
      "Devon checks that there is no threat or ongoing mistreatment in this example, then rehearses “The details are in the shared note; I can point you to the section.” Devon chooses a neutral tone rather than hiding the attack in a sarcastic delivery.",
      "Later, in the agreed situation, Devon sends the brief reply without the cutting remark. Irritation remains. On review Devon notes what was actually done and that the exchange did not escalate. Devon does not infer that this response fits every conflict; a new pattern of mistreatment would need a different review."
    ]
  },
  "practiceScenario": {
    "id": "opposite.scenario",
    "title": "Optional fictional rehearsal — Devon",
    "paragraphs": [
      "Use Devon’s ordinary group-project situation. The agreed aim is to answer briefly and neutrally instead of attacking, while keeping a limit on extra work.",
      "Rehearse a response in your own words and consider how its delivery would support that aim. This is fictional rehearsal, not a direction to contact anyone or proof of a real-world outcome."
    ]
  },
  "practice": [
    {
      "id": "opposite.practice.check",
      "title": "Check the situation, emotion and urge",
      "paragraphs": [
        "Name the situation, emotion and action urge separately. What facts support the emotion, and what is uncertain? Does its strength or duration fit what is happening?",
        "Would following the urge help with what matters here, or make the situation harder? Check whether the therapist-agreed opposite response still fits. An understandable emotion does not make every action effective."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "Situation and what is known",
          "optional": true
        },
        {
          "key": "emotionUrge",
          "label": "Emotion and action urge",
          "optional": true
        },
        {
          "key": "effectiveness",
          "label": "Fit and likely consequences",
          "optional": true
        }
      ],
      "help": {
        "title": "If the answer is unclear",
        "text": "Choose to pause real-world practice. You do not need to conclude that an emotion is unjustified to ask for help."
      }
    },
    {
      "id": "opposite.practice.decision",
      "title": "Choose the route that fits",
      "paragraphs": [
        "Use a real-world attempt only when this is the situation and response agreed with your therapist, the facts still support that choice, and you do not have unresolved safety or effectiveness concerns.",
        "Otherwise use Devon’s fictional rehearsal, keep a question for your therapist, or finish. No answer here is a clinical clearance."
      ],
      "help": {
        "title": "If the facts call for action",
        "text": "A boundary, practical response or support may be more appropriate. This page does not require you to do an opposite action."
      }
    },
    {
      "id": "opposite.practice.rehearse",
      "title": "Specify and rehearse the agreed response",
      "paragraphs": [
        "What exactly is the opposite of the identified urge in this agreed situation? State the action and how you will carry it out without slipping the original urge into its delivery.",
        "Try the words or action privately if appropriate. For Devon, the change is a neutral brief response instead of sarcasm—not forced friendliness, extra work or submission."
      ],
      "fields": [
        {
          "key": "response",
          "label": "Agreed response and how I would carry it out",
          "optional": true
        }
      ],
      "help": {
        "title": "If rehearsal feels awkward",
        "text": "Awkward does not prove it is wrong, but pain, safety concerns or a mismatch are reasons to stop and review. You can adapt communication to your abilities; no forced eye contact or posture."
      }
    },
    {
      "id": "opposite.practice.try",
      "title": "Try only within the agreed plan",
      "paragraphs": [
        "If you are on the agreed real-world route, carry out the response in the suitable situation, within the limits set with your therapist. It may happen away from this page; you can come back later without saved notes.",
        "If the situation changes or concerns arise, stop and seek review. If using fiction, rehearse only. You do not need to arrange an interaction to complete this page."
      ],
      "help": {
        "title": "A plan is not an attempt",
        "text": "Continue to review only what actually happened. It is fine to record that you rehearsed, planned, paused, or did not try."
      }
    },
    {
      "id": "opposite.practice.review",
      "title": "Review the attempt, not a success score",
      "paragraphs": [
        "What did you actually do: read, rehearse, try, pause or something else? If you acted, how closely did the response match the agreed action and manner, and what happened?",
        "The emotion may have changed or stayed the same. Note fit, consequences or barriers to discuss with your therapist. Do not automatically repeat, intensify or broaden the practice."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What happened and what needs review",
          "optional": true
        }
      ],
      "help": {
        "title": "If the urge remained",
        "text": "A remaining urge does not mean you must keep practising now. Follow the agreed review plan; this page does not prescribe repeat-until-relief."
      }
    }
  ],
  "close": {
    "id": "opposite.close",
    "title": "Leave the next decision open",
    "paragraphs": [
      "You can finish after learning, rehearsal, an attempt or a pause. Keep any question for your therapist; this page does not assign another action or require a feeling change."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "One co-designed ordinary action and review only, not full method or prescribed repetition until emotion changes. No emotion-to-action lookup, exposure, disclosure or approach prescription.",
    "Fictional rehearsal and pause are first-class routes. Self-selection never constitutes clinical or safety clearance. Original Devon example separates understandable irritation, attack urge and effective neutral reply."
  ],
  "narrationSegments": [
    {
      "id": "opposite.intro",
      "title": "Check the fit before choosing the action",
      "text": "Opposite action means acting against an emotion-led urge when the emotion does not fit the facts, or following the urge would not be effective. It is not “always do the opposite.”\n\nUse this for an ordinary situation and response already worked out with your therapist. If you do not have an agreed practice, use the fictional rehearsal or learn about the method instead.",
      "status": "Script only"
    },
    {
      "id": "opposite.fit",
      "title": "Keep the agreed limits",
      "text": "A therapist should introduce and co-design the situation, response and review with you. This page cannot decide that an action is safe or appropriate.\n\nDo not use it to approach danger, accept abuse, make unwanted contact, disclose private information, push through pain or exhaustion, or carry out a self-designed exposure. Changed circumstances can change what fits.\n\nIf you are unsure whether the facts or action still fit, pause the real-world practice and review with your therapist. You can use a fictional rehearsal or finish without being cleared by a checkbox.",
      "status": "Script only"
    },
    {
      "id": "opposite.learn",
      "title": "Why the decision comes first",
      "text": "An urge can keep a pattern going. A carefully selected opposite response offers a different way of acting, but the appropriate response depends on the emotion, the situation and its likely consequences.\n\nFirst distinguish the feeling from its action urge. Check the information and whether following that urge would help or cause problems. If the facts need a practical response, or the opposite action would be unsafe or unhelpful, do not force it.\n\nWhen an opposite response is agreed, practise it with a manner that supports it rather than covertly carrying out the original urge. This does not require a smile, eye contact, a posture that hurts, or pretending to feel differently. The full method may involve repeated agreed practice; this page supports one attempt and review, not repetition until you feel better.",
      "status": "Script only"
    },
    {
      "id": "opposite.example",
      "title": "Example — answering without a cutting remark",
      "text": "In an ordinary, safe group project, Devon feels irritated after a teammate asks a question already answered in the shared note. Devon’s urge is to reply sarcastically. With a therapist, Devon has identified that attacking would not help; a brief neutral reply is the agreed opposite response, not agreeing to take on extra work.\n\nDevon checks that there is no threat or ongoing mistreatment in this example, then rehearses “The details are in the shared note; I can point you to the section.” Devon chooses a neutral tone rather than hiding the attack in a sarcastic delivery.\n\nLater, in the agreed situation, Devon sends the brief reply without the cutting remark. Irritation remains. On review Devon notes what was actually done and that the exchange did not escalate. Devon does not infer that this response fits every conflict; a new pattern of mistreatment would need a different review.",
      "status": "Script only"
    },
    {
      "id": "opposite.scenario",
      "title": "Optional fictional rehearsal — Devon",
      "text": "Use Devon’s ordinary group-project situation. The agreed aim is to answer briefly and neutrally instead of attacking, while keeping a limit on extra work.\n\nRehearse a response in your own words and consider how its delivery would support that aim. This is fictional rehearsal, not a direction to contact anyone or proof of a real-world outcome.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.check",
      "title": "Check the situation, emotion and urge",
      "text": "Name the situation, emotion and action urge separately. What facts support the emotion, and what is uncertain? Does its strength or duration fit what is happening?\n\nWould following the urge help with what matters here, or make the situation harder? Check whether the therapist-agreed opposite response still fits. An understandable emotion does not make every action effective.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.check.help",
      "title": "If the answer is unclear",
      "text": "Choose to pause real-world practice. You do not need to conclude that an emotion is unjustified to ask for help.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.decision",
      "title": "Choose the route that fits",
      "text": "Use a real-world attempt only when this is the situation and response agreed with your therapist, the facts still support that choice, and you do not have unresolved safety or effectiveness concerns.\n\nOtherwise use Devon’s fictional rehearsal, keep a question for your therapist, or finish. No answer here is a clinical clearance.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.decision.help",
      "title": "If the facts call for action",
      "text": "A boundary, practical response or support may be more appropriate. This page does not require you to do an opposite action.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.rehearse",
      "title": "Specify and rehearse the agreed response",
      "text": "What exactly is the opposite of the identified urge in this agreed situation? State the action and how you will carry it out without slipping the original urge into its delivery.\n\nTry the words or action privately if appropriate. For Devon, the change is a neutral brief response instead of sarcasm—not forced friendliness, extra work or submission.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.rehearse.help",
      "title": "If rehearsal feels awkward",
      "text": "Awkward does not prove it is wrong, but pain, safety concerns or a mismatch are reasons to stop and review. You can adapt communication to your abilities; no forced eye contact or posture.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.try",
      "title": "Try only within the agreed plan",
      "text": "If you are on the agreed real-world route, carry out the response in the suitable situation, within the limits set with your therapist. It may happen away from this page; you can come back later without saved notes.\n\nIf the situation changes or concerns arise, stop and seek review. If using fiction, rehearse only. You do not need to arrange an interaction to complete this page.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.try.help",
      "title": "A plan is not an attempt",
      "text": "Continue to review only what actually happened. It is fine to record that you rehearsed, planned, paused, or did not try.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.review",
      "title": "Review the attempt, not a success score",
      "text": "What did you actually do: read, rehearse, try, pause or something else? If you acted, how closely did the response match the agreed action and manner, and what happened?\n\nThe emotion may have changed or stayed the same. Note fit, consequences or barriers to discuss with your therapist. Do not automatically repeat, intensify or broaden the practice.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.review.help",
      "title": "If the urge remained",
      "text": "A remaining urge does not mean you must keep practising now. Follow the agreed review plan; this page does not prescribe repeat-until-relief.",
      "status": "Script only"
    },
    {
      "id": "opposite.close",
      "title": "Leave the next decision open",
      "text": "You can finish after learning, rehearsal, an attempt or a pause. Keep any question for your therapist; this page does not assign another action or require a feeling change.",
      "status": "Script only"
    },
    {
      "id": "opposite.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    },
    {
      "id": "opposite.practice.rehearse.fictional",
      "title": "Fictional rehearsal",
      "text": "Using only Devon’s fictional story, try wording for a brief neutral reply instead of sarcasm. Consider how the delivery would avoid the original attack urge. Do not contact anyone or substitute a personal situation here.",
      "status": "Conditional static script only; never imply personal action"
    },
    {
      "id": "opposite.practice.rehearse.pause",
      "title": "Practice paused",
      "text": "Personal rehearsal and action are paused. You can read the example, keep a question for your therapist, review or finish.",
      "status": "Conditional static script only; never imply personal action"
    },
    {
      "id": "opposite.practice.try.fictional",
      "title": "Fictional rehearsal",
      "text": "Rehearse Devon’s neutral response privately if useful. Do not contact anyone for this fictional exercise. Review only the rehearsal, or finish.",
      "status": "Conditional static script only; never imply personal action"
    },
    {
      "id": "opposite.practice.try.pause",
      "title": "Practice paused",
      "text": "Real-world practice is paused. You can keep a question for your therapist, review what you noticed, or finish.",
      "status": "Conditional static script only; never imply personal action"
    }
  ]
}
;
