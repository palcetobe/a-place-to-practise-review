window.BoundedSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/graded",
  "version": "2026-11-02-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "title": "Graded Task Assignment",
  "subtitle": "Make one task more manageable",
  "scope": "One task-breakdown, attempt and review practice; not an exposure hierarchy or a full treatment programme.",
  "clinicalContract": {
    "learningObjective": "Explain how breaking an agreed task into workable parts differs from simply setting a goal.",
    "practiceObjective": "Identify one suitable task; arrange its component steps; choose a feasible starting step; try when appropriate; review whether to resize, repeat or move on.",
    "observedPractice": "Private consideration or optional writing demonstrates rehearsal only. An attempt and a later review are distinct from planning. No symptom change, rating, typed response or additional task is required to finish.",
    "sourcePopulationContext": "CCI sources describe broader clinical methods, not validation of this digital adaptation or suitability across ages. Therapist selection and adaptation should account for development, communication, context, consent, privacy and safeguarding. Method-specific source populations and suitability limits still apply."
  },
  "privacy": {
    "id": "graded.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "plan",
      "review"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Matched authored scripts only. Established voice; do not imply generated, listened or live audio. Private inputs never sent to narration.",
    "timer": "No timer required or proposed.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "sources": [
    {
      "id": "cci-mood-course",
      "url": "https://www.cci.health.wa.gov.au/Treatment/Mood-Management-Course",
      "reviewed": "2026-11-02",
      "supports": "Graded tasks as breaking overwhelming tasks into manageable steps; distinct teaching component."
    },
    {
      "id": "cci-graded-sheet",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Treatment-worksheets/Mood-Management-Course/MMC---Graded-tasks-and-Graded-exposure-Worksheet.pdf",
      "reviewed": "2026-11-02",
      "supports": "Goal and manageable component steps over time; title also mentions exposure, which this product deliberately excludes."
    },
    {
      "id": "cci-procrastination-5",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Put-Off-Procrastinating/Putting-Off-Procrastinating---05---Practical-Techniques-to-stop-Procrastination.pdf",
      "reviewed": "2026-11-02",
      "supports": "Task clarification, logical component order, further subdivision and practical timing."
    },
    {
      "id": "cci-procrastination-7",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Put-Off-Procrastinating/Putting-Off-Procrastinating--07--Putting-It-Altogether-Doing-It--Keeping-Going.pdf",
      "reviewed": "2026-11-02",
      "supports": "Reflecting and revising a practical action plan."
    }
  ],
  "productAdaptations": [
    "One agreed task, not a general to-do list.",
    "Separate plan and return-review modes; no exposure hierarchy or SMART-tool replacement.",
    "Original Jordan example and explicit fatigue/access boundaries.",
    "Optional entry and session-only storage rather than reproducing a worksheet."
  ],
  "routeProposal": "tool/graded-task-assignment",
  "intro": {
    "id": "graded.intro",
    "title": "A place to begin",
    "paragraphs": [
      "A task can feel too large to start. This practice helps you divide one task into smaller parts and choose a step that fits today.",
      "You do not need to finish the whole task, push through exhaustion or become more productive."
    ],
    "actions": [
      {
        "id": "plan",
        "label": "Break down a task"
      },
      {
        "id": "review",
        "label": "Review a step I tried or planned"
      }
    ]
  },
  "fit": {
    "id": "graded.fit",
    "title": "Choose a suitable task",
    "paragraphs": [
      "Use a task you and your therapist agree is appropriate.",
      "Respect health advice, disability, fatigue, access and competing demands. This is not a ladder for confronting feared situations or a reason to delay urgent responsibilities. If the task is unsafe or needs specialist support, pause and get help."
    ]
  },
  "learn": {
    "id": "graded.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "A large task hides many smaller actions. Naming those parts can make the starting point clearer and show where help or a smaller step is needed.",
      "A goal describes what you want to do. Grading a task adds the workable steps between here and there. Their order follows the task; it is not a ranking of how much fear you should endure.",
      "Review tells you whether the step fits. Needing a different size, more support or more rest is information, not failure."
    ]
  },
  "example": {
    "id": "graded.example",
    "title": "Example — preparing a library return",
    "paragraphs": [
      "Jordan wants to return three library books on a suitable day. “Sort it all out” feels too big. Jordan separates it into finding the books, putting them in a bag, checking the opening time, and planning a suitable visit.",
      "Today Jordan chooses only to find the books. Two are easy to find; looking for the third becomes tiring. Jordan stops rather than pushing through.",
      "In review, the first step was still too broad. Jordan decides to look in one drawer with help next time. Returning the books remains a separate later step; the whole task has not been marked done."
    ]
  },
  "plan": [
    {
      "id": "graded.plan.task",
      "title": "Choose one task",
      "paragraphs": [
        "Bring to mind one agreed, practical task. What would doing it involve? Keep the focus on this task, not everything you need to do."
      ],
      "fields": [
        {
          "key": "task",
          "label": "The task I am considering",
          "optional": true
        }
      ],
      "help": {
        "title": "If choosing is hard",
        "text": "Use a task already discussed with your therapist. You can leave this open rather than create a new obligation."
      }
    },
    {
      "id": "graded.plan.parts",
      "title": "Find the smaller parts",
      "paragraphs": [
        "What separate actions make up the task? Put them in a useful order. If one part is still too large, divide that part again.",
        "You can consider the steps privately. You do not need a long list or an exact number of steps."
      ],
      "fields": [
        {
          "key": "steps",
          "label": "Smaller steps in a workable order",
          "optional": true
        }
      ],
      "help": {
        "title": "What counts as a smaller step?",
        "text": "For a return, locating the item and packing it are separate actions. Use parts of your own task, not this example as a requirement."
      }
    },
    {
      "id": "graded.plan.choose",
      "title": "Choose a workable starting step",
      "paragraphs": [
        "Which step is possible with your current time, energy, access and support? What would count as doing just that step?",
        "Choose when or after what event it might fit. You can shrink the step, ask for help, or leave the plan open."
      ],
      "fields": [
        {
          "key": "step",
          "label": "The step I might try",
          "optional": true
        },
        {
          "key": "opportunity",
          "label": "When and what support would help",
          "optional": true
        }
      ],
      "help": {
        "title": "If even the first step is too much",
        "text": "Make it smaller or pause. Practical barriers and health limits are not a lack of effort. You do not need to earn rest."
      }
    },
    {
      "id": "graded.plan.try",
      "title": "Try only the chosen step",
      "paragraphs": [
        "If it is safe and practical, try the step now or at the opportunity you chose. Stop or adjust when needed; there is no requirement to continue up the list.",
        "Return to review afterwards, including if you could not start. Clicking through this page does not mean the step happened."
      ],
      "help": {
        "title": "Remembering your step",
        "text": "Keep it in mind or use a record you choose off this tool. Notes here are not saved after you leave this tool or reload."
      }
    }
  ],
  "review": [
    {
      "id": "graded.review.happened",
      "title": "What happened with the step?",
      "paragraphs": [
        "Which step did you plan, and what actually happened? Include partial attempts or not starting."
      ],
      "fields": [
        {
          "key": "reviewStep",
          "label": "The step and what happened",
          "optional": true
        }
      ],
      "help": {
        "title": "If it did not happen",
        "text": "Notice the size, timing, support and circumstances rather than blaming yourself."
      }
    },
    {
      "id": "graded.review.fit",
      "title": "What did this show about the size?",
      "paragraphs": [
        "Was the step workable, too much, or unclear? Would support or a different order help?"
      ],
      "fields": [
        {
          "key": "fit",
          "label": "What I learned about the step",
          "optional": true
        }
      ],
      "help": {
        "title": "If it was easy",
        "text": "That does not make it pointless. A workable starting step is useful information; you do not have to increase it."
      }
    },
    {
      "id": "graded.review.choice",
      "title": "Decide only if useful",
      "paragraphs": [
        "You could repeat it, make it smaller, move to another part, or pause. There is no automatic next level and no new plan required."
      ],
      "fields": [
        {
          "key": "adjustment",
          "label": "Something to keep or change, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If the task keeps growing",
        "text": "Return to the one task you chose. You can discuss whether it is still the right task with your therapist."
      }
    }
  ],
  "close": {
    "id": "graded.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "You can finish after planning or reviewing one step. The whole task does not need to be complete. Notice what you learned, or simply stop here."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "narrationSegments": [
    {
      "id": "graded.intro",
      "title": "A place to begin",
      "text": "A task can feel too large to start. This practice helps you divide one task into smaller parts and choose a step that fits today.\n\nYou do not need to finish the whole task, push through exhaustion or become more productive.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.fit",
      "title": "Choose a suitable task",
      "text": "Use a task you and your therapist agree is appropriate.\n\nRespect health advice, disability, fatigue, access and competing demands. This is not a ladder for confronting feared situations or a reason to delay urgent responsibilities. If the task is unsafe or needs specialist support, pause and get help.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.learn",
      "title": "Why this skill may help",
      "text": "A large task hides many smaller actions. Naming those parts can make the starting point clearer and show where help or a smaller step is needed.\n\nA goal describes what you want to do. Grading a task adds the workable steps between here and there. Their order follows the task; it is not a ranking of how much fear you should endure.\n\nReview tells you whether the step fits. Needing a different size, more support or more rest is information, not failure.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.example",
      "title": "Example — preparing a library return",
      "text": "Jordan wants to return three library books on a suitable day. “Sort it all out” feels too big. Jordan separates it into finding the books, putting them in a bag, checking the opening time, and planning a suitable visit.\n\nToday Jordan chooses only to find the books. Two are easy to find; looking for the third becomes tiring. Jordan stops rather than pushing through.\n\nIn review, the first step was still too broad. Jordan decides to look in one drawer with help next time. Returning the books remains a separate later step; the whole task has not been marked done.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.plan.task",
      "title": "Choose one task",
      "text": "Bring to mind one agreed, practical task. What would doing it involve? Keep the focus on this task, not everything you need to do.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.plan.task.help",
      "title": "If choosing is hard",
      "text": "Use a task already discussed with your therapist. You can leave this open rather than create a new obligation.",
      "status": "Script only"
    },
    {
      "id": "graded.plan.parts",
      "title": "Find the smaller parts",
      "text": "What separate actions make up the task? Put them in a useful order. If one part is still too large, divide that part again.\n\nYou can consider the steps privately. You do not need a long list or an exact number of steps.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.plan.parts.help",
      "title": "What counts as a smaller step?",
      "text": "For a return, locating the item and packing it are separate actions. Use parts of your own task, not this example as a requirement.",
      "status": "Script only"
    },
    {
      "id": "graded.plan.choose",
      "title": "Choose a workable starting step",
      "text": "Which step is possible with your current time, energy, access and support? What would count as doing just that step?\n\nChoose when or after what event it might fit. You can shrink the step, ask for help, or leave the plan open.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.plan.choose.help",
      "title": "If even the first step is too much",
      "text": "Make it smaller or pause. Practical barriers and health limits are not a lack of effort. You do not need to earn rest.",
      "status": "Script only"
    },
    {
      "id": "graded.plan.try",
      "title": "Try only the chosen step",
      "text": "If it is safe and practical, try the step now or at the opportunity you chose. Stop or adjust when needed; there is no requirement to continue up the list.\n\nReturn to review afterwards, including if you could not start. Clicking through this page does not mean the step happened.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.plan.try.help",
      "title": "Remembering your step",
      "text": "Keep it in mind or use a record you choose off this tool. Notes here are not saved after you leave this tool or reload.",
      "status": "Script only"
    },
    {
      "id": "graded.review.happened",
      "title": "What happened with the step?",
      "text": "Which step did you plan, and what actually happened? Include partial attempts or not starting.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.review.happened.help",
      "title": "If it did not happen",
      "text": "Notice the size, timing, support and circumstances rather than blaming yourself.",
      "status": "Script only"
    },
    {
      "id": "graded.review.fit",
      "title": "What did this show about the size?",
      "text": "Was the step workable, too much, or unclear? Would support or a different order help?",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.review.fit.help",
      "title": "If it was easy",
      "text": "That does not make it pointless. A workable starting step is useful information; you do not have to increase it.",
      "status": "Script only"
    },
    {
      "id": "graded.review.choice",
      "title": "Decide only if useful",
      "text": "You could repeat it, make it smaller, move to another part, or pause. There is no automatic next level and no new plan required.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.review.choice.help",
      "title": "If the task keeps growing",
      "text": "Return to the one task you chose. You can discuss whether it is still the right task with your therapist.",
      "status": "Script only"
    },
    {
      "id": "graded.close",
      "title": "Leave it here for now",
      "text": "You can finish after planning or reviewing one step. The whole task does not need to be complete. Notice what you learned, or simply stop here.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "graded.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    }
  ]
}
;
