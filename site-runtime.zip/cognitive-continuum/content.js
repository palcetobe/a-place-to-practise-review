window.PerspectiveSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "cognitive-continuum.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "contextReview": {
      "fields": [
        "criterion",
        "low",
        "high",
        "comparison",
        "evidence",
        "placement"
      ],
      "placement": "place and review",
      "behavior": "Literal entered context shown only when writing is shown; no synthesis or rating inference; hidden/cleared with notes."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/cognitive-continuum",
  "title": "Cognitive Continuum",
  "subtitle": "Replace an all-or-nothing task judgment with defined criteria",
  "scope": "A therapist-introduced, ordinary task-criterion continuum. Not a rating of human worth, normality or lovability, and not the full schema-change method.",
  "version": "2026-11-02-cbt-perspective-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Explain how concrete endpoints and evidence-based comparisons differ from picking a reassuring midpoint.",
    "practiceObjective": "Define one ordinary task dimension and its endpoints, locate comparison examples and the current case using evidence, then review the original extreme judgment without requiring movement.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.padesky.com/wp-content/uploads/2012/11/schema_change_article_permissions.pdf",
      "reviewed": "2026-11-02",
      "supports": "Author-hosted clinical paper: concrete criteria continua, defined endpoints, comparison and reconsideration of extreme evaluations.",
      "limits": "Original paper concerns clinician-led schema change and includes global self-ratings. This ordinary task-only adaptation deliberately excludes human-worth/normality/lovability scales; no full schema protocol or digital youth validation claim."
    }
  ],
  "resourceId": "tool/cognitive-continuum",
  "routeProposal": "tool/cognitive-continuum",
  "intro": {
    "id": "continuum.intro",
    "title": "Define the scale before placing the example",
    "paragraphs": [
      "“It was completely useless” can hide differences between parts of a task. A cognitive continuum makes the criterion clear and compares examples along it.",
      "Choose an ordinary task dimension with your therapist, such as how fully a note explains a plan. Do not put yourself or another person’s worth on the line. You can use the fictional example, think privately or use the optional visual."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "continuum.fit",
    "title": "Keep the criterion specific",
    "paragraphs": [
      "Use this after your therapist has introduced it and helped choose a suitable ordinary task.",
      "Do not rate human value, attractiveness, deservingness, normality or safety. Health, trauma, legal or interpersonal responsibility judgments need appropriate support, not a scale on this page.",
      "If placing a point turns into repeated reassurance checking, or you feel pushed toward a more positive answer, pause. You can leave a range or uncertainty, keep the original placement, or finish."
    ]
  },
  "learn": {
    "id": "continuum.learn",
    "title": "Why use a continuum?",
    "paragraphs": [
      "An extreme label can combine several different judgments. Defining one criterion makes it possible to compare the same thing across cases instead of judging a whole person or experience.",
      "Describe what complete absence and full presence of that task criterion would look like. Add a concrete comparison between them, then consider where the current case fits and why. The middle is not automatically correct.",
      "The line is a thinking aid, not a measurement instrument. A revised description may be more useful than a number; a missing fact can remain missing. This is different from simply replacing a negative statement with a positive one."
    ]
  },
  "example": {
    "id": "continuum.example",
    "title": "Example — a note about a meeting",
    "paragraphs": [
      "Sami calls a meeting note “completely useless” because one detail was missed. Sami chooses the criterion “How fully does the note explain the meeting plan?” The lower anchor has no usable date, time, place or purpose. The upper anchor clearly gives all four.",
      "Sami places a fictional note with only a date toward the lower end, and a note with date, time and place but no purpose nearer the upper end. These are rough comparisons, not a scoring rule. Sami’s own note includes date, time and purpose but omits the place.",
      "Sami places the note nearer the upper anchor, not at complete absence. The evidence supports “The note gives several essentials and needs the place added,” not “completely useless.” Annoyance remains. Sami can correct the place if useful; this review has not already made that correction."
    ]
  },
  "practiceScenario": {
    "id": "continuum.scenario",
    "title": "Optional fictional practice — Alex",
    "paragraphs": [
      "Alex calls a short set of instructions “a total failure.” It states the materials and first step clearly, but leaves out the final step. Use the criterion “How fully do these instructions explain this small task?”",
      "Define absence and full presence of that criterion. Compare another simple example before placing Alex’s instructions. You do not need to assign Alex a personal rating."
    ]
  },
  "practice": [
    {
      "id": "continuum.practice.criterion",
      "title": "Choose one task criterion",
      "paragraphs": [
        "What specific feature are you evaluating? Keep it about an ordinary task, not your value as a person. Note the original all-or-nothing judgment if useful.",
        "If there are several criteria, choose one for now rather than combine them into an overall person score."
      ],
      "fields": [
        {
          "key": "criterion",
          "label": "One task criterion",
          "optional": true
        },
        {
          "key": "judgment",
          "label": "Original judgment, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If the label describes a person",
        "text": "Move to a concrete task feature agreed with your therapist, use Alex’s example, or stop. Do not translate “I’m worthless” into a worth scale."
      }
    },
    {
      "id": "continuum.practice.anchors",
      "title": "Define the endpoints and a comparison",
      "paragraphs": [
        "What would complete absence of this criterion look like? What would full presence look like for this particular task? Describe both concretely.",
        "Add one or two fictional comparison cases with different amounts of the same feature. Place them in words, on paper or on the optional line. Avoid making an ordinary imperfection equal to complete absence."
      ],
      "fields": [
        {
          "key": "low",
          "label": "Complete absence of the task criterion",
          "optional": true
        },
        {
          "key": "high",
          "label": "Full presence of the task criterion",
          "optional": true
        },
        {
          "key": "comparison",
          "label": "Comparison cases and their positions",
          "optional": true
        }
      ],
      "help": {
        "title": "If the anchors do not match",
        "text": "Check that both ends describe the same feature. “No usable meeting details” and “all essential meeting details clear” match; “bad person” and “good worker” do not."
      }
    },
    {
      "id": "continuum.practice.place",
      "title": "Locate the case using evidence",
      "paragraphs": [
        "Where does your task example fit compared with those anchors and cases? Describe the information that supports the placement and anything you do not know.",
        "A point, range or uncertain position is acceptable. You do not need to move toward the middle or higher end. The optional line does not decide the answer."
      ],
      "fields": [
        {
          "key": "evidence",
          "label": "Relevant information and uncertainty",
          "optional": true
        },
        {
          "key": "placement",
          "label": "Where the case fits and why",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot place it",
        "text": "Keep the uncertainty or revise unclear anchors. Do not invent a number just to complete a chart."
      }
    },
    {
      "id": "continuum.practice.review",
      "title": "Review the original judgment",
      "paragraphs": [
        "Does the original judgment still describe the evidence accurately? Keep it, qualify it or use a more specific description.",
        "A missing piece can still need attention. The purpose is an accurate account, not excusing a problem or requiring a new task."
      ],
      "fields": [
        {
          "key": "review",
          "label": "An account I would keep or revise",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing changes",
        "text": "You may have clarified the criterion or learned what information is missing. No shift, positive feeling or repeat rating is required."
      }
    }
  ],
  "close": {
    "id": "continuum.close",
    "title": "Keep the useful distinction",
    "paragraphs": [
      "You can finish with a point, range, description or unresolved question. This is not a score of you, and no correction or improved feeling is required."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "visualAid": {
    "id": "continuum.visual",
    "kind": "optional-anchored-line",
    "default": "Off; no user position or midpoint selected.",
    "placement": "anchors/place/review prompts",
    "purpose": "Keep the two authored anchors, comparison cases and current case visible on the same criterion.",
    "inputs": {
      "anchors": [
        "low",
        "high"
      ],
      "comparisonMarkers": "Optional labeled comparison positions; add one at a time.",
      "caseMarker": "Optional labeled position or range for current case.",
      "numericOption": "Optional position from 0 to 100 as a visual coordinate only, never percent worth, accuracy or completion. Blank until explicitly entered; range needs two user values.",
      "textOption": "Equivalent ordinary-language positions and evidence beside the same anchors; no numerical input needed."
    },
    "behavior": [
      "Render only explicitly entered positions; no guessed defaults, averaging, suggested midpoint or automatic positive movement.",
      "If anchors are blank, display a blank labeled line prompt, not invented labels. Invalid or reversed range values show a nearby neutral correction notice, not an auto-corrected placement.",
      "Keyboard-operable labeled number/range fields with direct values; dragging is optional, never the only way.",
      "Comparison points and current point have text labels and a legend, not color alone. Text-only view conveys all entered content.",
      "Hide all private anchors, labels, positions and echoes when writing/visual entries are hidden; clear on tool exit/reload/clear/restart. Never narrate private entries."
    ],
    "visibleNote": "This line displays your rough comparisons, not a measurement or a score of a person."
  },
  "productAdaptations": [
    "New Sami/Alex examples; one task criterion, optional line/range/text equivalent, no forced midpoint or improved appraisal.",
    "Retired Practice Room continuum-thinking0.2.1 is not imported or revived."
  ],
  "narrationSegments": [
    {
      "id": "continuum.intro",
      "title": "Define the scale before placing the example",
      "text": "“It was completely useless” can hide differences between parts of a task. A cognitive continuum makes the criterion clear and compares examples along it.\n\nChoose an ordinary task dimension with your therapist, such as how fully a note explains a plan. Do not put yourself or another person’s worth on the line. You can use the fictional example, think privately or use the optional visual.",
      "status": "Script only"
    },
    {
      "id": "continuum.fit",
      "title": "Keep the criterion specific",
      "text": "Use this after your therapist has introduced it and helped choose a suitable ordinary task.\n\nDo not rate human value, attractiveness, deservingness, normality or safety. Health, trauma, legal or interpersonal responsibility judgments need appropriate support, not a scale on this page.\n\nIf placing a point turns into repeated reassurance checking, or you feel pushed toward a more positive answer, pause. You can leave a range or uncertainty, keep the original placement, or finish.",
      "status": "Script only"
    },
    {
      "id": "continuum.learn",
      "title": "Why use a continuum?",
      "text": "An extreme label can combine several different judgments. Defining one criterion makes it possible to compare the same thing across cases instead of judging a whole person or experience.\n\nDescribe what complete absence and full presence of that task criterion would look like. Add a concrete comparison between them, then consider where the current case fits and why. The middle is not automatically correct.\n\nThe line is a thinking aid, not a measurement instrument. A revised description may be more useful than a number; a missing fact can remain missing. This is different from simply replacing a negative statement with a positive one.",
      "status": "Script only"
    },
    {
      "id": "continuum.example",
      "title": "Example — a note about a meeting",
      "text": "Sami calls a meeting note “completely useless” because one detail was missed. Sami chooses the criterion “How fully does the note explain the meeting plan?” The lower anchor has no usable date, time, place or purpose. The upper anchor clearly gives all four.\n\nSami places a fictional note with only a date toward the lower end, and a note with date, time and place but no purpose nearer the upper end. These are rough comparisons, not a scoring rule. Sami’s own note includes date, time and purpose but omits the place.\n\nSami places the note nearer the upper anchor, not at complete absence. The evidence supports “The note gives several essentials and needs the place added,” not “completely useless.” Annoyance remains. Sami can correct the place if useful; this review has not already made that correction.",
      "status": "Script only"
    },
    {
      "id": "continuum.scenario",
      "title": "Optional fictional practice — Alex",
      "text": "Alex calls a short set of instructions “a total failure.” It states the materials and first step clearly, but leaves out the final step. Use the criterion “How fully do these instructions explain this small task?”\n\nDefine absence and full presence of that criterion. Compare another simple example before placing Alex’s instructions. You do not need to assign Alex a personal rating.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.criterion",
      "title": "Choose one task criterion",
      "text": "What specific feature are you evaluating? Keep it about an ordinary task, not your value as a person. Note the original all-or-nothing judgment if useful.\n\nIf there are several criteria, choose one for now rather than combine them into an overall person score.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.criterion.help",
      "title": "If the label describes a person",
      "text": "Move to a concrete task feature agreed with your therapist, use Alex’s example, or stop. Do not translate “I’m worthless” into a worth scale.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.anchors",
      "title": "Define the endpoints and a comparison",
      "text": "What would complete absence of this criterion look like? What would full presence look like for this particular task? Describe both concretely.\n\nAdd one or two fictional comparison cases with different amounts of the same feature. Place them in words, on paper or on the optional line. Avoid making an ordinary imperfection equal to complete absence.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.anchors.help",
      "title": "If the anchors do not match",
      "text": "Check that both ends describe the same feature. “No usable meeting details” and “all essential meeting details clear” match; “bad person” and “good worker” do not.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.place",
      "title": "Locate the case using evidence",
      "text": "Where does your task example fit compared with those anchors and cases? Describe the information that supports the placement and anything you do not know.\n\nA point, range or uncertain position is acceptable. You do not need to move toward the middle or higher end. The optional line does not decide the answer.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.place.help",
      "title": "If you cannot place it",
      "text": "Keep the uncertainty or revise unclear anchors. Do not invent a number just to complete a chart.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.review",
      "title": "Review the original judgment",
      "text": "Does the original judgment still describe the evidence accurately? Keep it, qualify it or use a more specific description.\n\nA missing piece can still need attention. The purpose is an accurate account, not excusing a problem or requiring a new task.",
      "status": "Script only"
    },
    {
      "id": "continuum.practice.review.help",
      "title": "If nothing changes",
      "text": "You may have clarified the criterion or learned what information is missing. No shift, positive feeling or repeat rating is required.",
      "status": "Script only"
    },
    {
      "id": "continuum.close",
      "title": "Keep the useful distinction",
      "text": "You can finish with a point, range, description or unresolved question. This is not a score of you, and no correction or improved feeling is required.",
      "status": "Script only"
    },
    {
      "id": "cognitive-continuum.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    },
    {
      "id": "continuum.visual.note",
      "title": "About the optional visual",
      "text": "This line displays your rough comparisons, not a measurement or a score of a person.",
      "status": "Static script only; never user labels or values"
    }
  ]
}
;
