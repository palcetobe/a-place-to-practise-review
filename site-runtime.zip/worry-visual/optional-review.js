
(()=>{const w=window.PracticeWorkspacesReviewData.tools.worry;
w.responses.act.text=['If there is a practical part you could act on, you can consider one part you could work on and realistic options. If useful, you can consider one realistic step and when it might fit. You do not need to make a plan to finish this practice. If you want more help with a practical concern, the separate problem-solving practice is available.'];
w.responses.mixed.text=['There may be a practical part and an uncertain outcome. You do not need to separate them perfectly. If useful, notice a realistic step; if nothing is clear, you can leave that question open or discuss it with your therapist. Urgent action or support still comes first.'];
w.responses.mixed.optionalFields=['A thought, possible step or open question (optional)'];
w.responses.none.text=['You do not have to sort this worry or decide on a next step. You can finish the period with some uncertainty still here.'];w.responses.none.optionalFields=[];
for(const key of ['act','mixed','none'])w.responses[key].narration=w.responses[key].text.join('\n\n');
w.finishReview.title='Close this worry period';w.finishReview.paragraphs[0]='You can finish this period without sorting every worry or making an action plan. Worry or uncertainty may still be here; neither has to disappear before you return to your day. You might return to an ordinary activity, rest, or support.';
})();
