
(()=>{'use strict';const data=structuredClone(window.PracticeWorkspacesReviewData);
const paragraphs=data.tools.worry.optional.example.paragraphs;
if(!paragraphs[1].includes('Noor has chosen 15 minutes'))throw new Error('Unexpected Worry example source');
paragraphs[1]+=' Noor’s 15-minute choice is one option within the 10–20-minute range; you can choose a different length and finish earlier.';
window.PracticeWorkspacesReviewData=data;
})();
