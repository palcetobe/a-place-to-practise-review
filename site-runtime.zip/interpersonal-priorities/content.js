window.InterpersonalPrioritiesContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/dear",
  "componentId": "component/dear/priorities",
  "resourceId": "tool/dearman",
  "routeProposal": null,
  "reviewHarnessRoute": "/interpersonal-priorities/",
  "title": "Clarifying Interpersonal Priorities",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Decide how the result you want, the relationship and self-respect matter in one conversation, before choosing how to respond.",
  "groupedSetStatus": "Existing uncounted component under classic/dear, shared preparation for DEAR MAN, GIVE and FAST. Deepens their retained brief priority prompt. No new resource identity, complete communication method or canonical count. Review harness only; no proposed public route.",
  "integrationContract": {
    "placement": "Shared optional preparation within existing communication resources, not a competing standalone tool.",
    "existingResourceIds": [
      "tool/dearman",
      "tool/give",
      "tool/fast"
    ],
    "canonicalCountDelta": 0,
    "publicRouteProposed": false,
    "linkedPracticeBehavior": "No automatic selection, navigation to another method, note transfer or completion inference."
  },
  "clinicalContract": {
    "learningObjective": "Distinguish three situational aims, their desired outcomes and helpful actions; choose relative importance without equating priority with force, moral worth, certain approval or a fixed lifelong rule.",
    "practiceObjective": "Describe one event, define objective/relationship/self-respect aims, explicitly order their relative importance, examine conflicts and limits, choose a combination of existing skills, check the choice and review actual preparation/use/non-use.",
    "sourcePopulationContext": "2015 author/publisher DBT teaching establishes the component, not efficacy of this digital adaptation or latest-edition equivalence. No age floor. Therapist checks clinical, developmental, cultural, communication, safeguarding and access fit.",
    "exclusions": [
      "No universal forcefulness score, Dime Game, automatic skill prescription or required confrontation",
      "No unsafe disclosure, contact, consent override, pressure after refusal or preserving harmful relationships as a duty",
      "No treating distress, tears, disability or communication support as loss of self-respect",
      "No promise of agreement, approval, relationship improvement or positive feelings",
      "No substitute for urgent support, safety planning, legal advice or specialist care",
      "No copied source worksheet, mandatory ranking field, automated assessment, persistent notes or therapist report"
    ],
    "adaptations": [
      "Original plain-language teaching, fictional conversation and optional fields, not reproduced worksheet or source examples",
      "Relative order remains an explicit client task in words; no numeric scoring or forced answer",
      "Accessible private thought, speech, signing, writing or support rather than required written worksheet",
      "Review distinguishes preparation, rehearsal, actual conversation and unknown outcomes; neutral/adverse/no-use reports allowed",
      "No forced confidence, emotional control, eye contact or moral verdict; behaviour, needs, accountability and boundaries remain visible"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of full bounded priorities component and shared placement; source-use rights",
      "Individual clinical, developmental, cultural, communication, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not a validated reading level",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration generation and listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose preparation or review",
      "options": [
        {
          "value": "prepare",
          "label": "Prepare my priorities",
          "startSectionId": "interpersonal-priorities.practice.situation"
        },
        {
          "value": "review",
          "label": "Review preparation or a conversation",
          "startSectionId": "interpersonal-priorities.practice.review"
        }
      ]
    },
    "entryGate": "Scope and safety visible before selection. No situation or contact approved by this page.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence or writing.",
    "reviewAccess": "Direct blank review without a plan, inferred conversation, choice or result. Both modes expose all groups.",
    "writing": "Optional and hidden initially. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private goals or notes. No audio, TTS, recording upload or autoplay.",
    "timer": "None. No required deadline, exposure, contact or number of repetitions.",
    "completion": "No inferred priority decision, rehearsal, contact, agreement, safety, self-respect or improvement."
  },
  "intro": {
    "id": "interpersonal-priorities.intro",
    "title": "Decide what matters in this conversation",
    "paragraphs": [
      "Before a conversation, you may want several things at once. You might want a change, care about the relationship, and want to act in a way you respect. A priority is what matters more in this situation when those aims pull apart.",
      "This practice helps you name all three aims and decide how much weight to give each. It prepares you to use DEAR MAN, GIVE and FAST. It does not replace those skills or decide how strongly you should ask or say no.",
      "Use it after learning with your therapist. You can think it through, use the example, review what happened or finish without choosing or contacting anyone."
    ]
  },
  "fit": {
    "id": "interpersonal-priorities.fit",
    "title": "Keep safety, choice and support in view",
    "paragraphs": [
      "Choose an ordinary, manageable situation with your therapist. Consider power, culture, support and any real duties or limits. If you are unsure whether speaking up could lead to threats, punishment, control or harm, start with suitable support and a safety plan rather than this exercise.",
      "The page cannot decide whether a conversation is safe. You do not have to confront anyone, keep an unsafe relationship, reveal private facts or accept harm to protect a relationship. Respect the other person’s consent and limits too.",
      "If this brings more distress, pressure or repeated checking, pause and discuss what would help. You can use fiction or stop. You do not have to feel calm, certain or confident first, but you do need enough support to choose what fits.",
      "Think, speak, sign, use an aid or write in a way that works for you. No set eye contact, tone, posture or fluent speech is required. This is not urgent help, a legal decision tool or a test of your worth."
    ]
  },
  "privacy": {
    "id": "interpersonal-priorities.privacy",
    "title": "Writing and sharing are your choice",
    "paragraphs": [
      "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.",
      "Notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep notes, choose only the parts you want, check the preview, then copy or download. Those copies remain wherever you save them.",
      "Hiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return to this practice while the page stays open. It does not keep your answers or add a saved item to your usual Toolbox."
    ]
  },
  "close": {
    "id": "interpersonal-priorities.close",
    "title": "You can leave the decision here",
    "paragraphs": [
      "You can finish after reading, preparing, practising, reviewing or choosing not to continue. No agreement, priority order or good feeling is required to leave.",
      "If useful, keep selected notes or bring a question to your therapist. This page has not contacted anyone, chosen another skill for you or created a reminder. Leaving clears the notes here."
    ]
  },
  "example": {
    "id": "interpersonal-priorities.example",
    "title": "Example: Sam needs a borrowed puzzle back",
    "paragraphs": [
      "Sam lent Jo a puzzle and said it could stay for the week. It is now due back. Sam wants it for a planned game evening. Jo asks to keep it through the weekend. This is an ordinary disagreement, with no threat or earlier promise of extra time.",
      "Sam separates the facts from the thought \"Jo does not care.\" The objective is to have the puzzle back by Friday. For the relationship, Sam hopes Jo will still see them as a fair friend who can lend things again. For self-respect, Sam wants to be clear and truthful, without a made-up reason or an insult.",
      "Sam chooses this order for this occasion: getting the puzzle back first, acting truthfully and fairly next, and looking after the friendship third. Sam still wants Jo to see them as a fair friend. Sam can accept some disappointment, but not lie, threaten or ignore Jo’s limits to get the puzzle.",
      "There is a real conflict: agreeing to the weekend would give Jo the extra time requested but leave Sam without the puzzle. Sam decides to make a clear request with DEAR MAN, use GIVE to hear Jo’s view, and use FAST to keep the explanation honest. This is a mix of skills, not a score that chooses one.",
      "Sam privately rehearses: \"We agreed on this week. I need the puzzle for Friday. Can you bring it back then?\" Later, Sam actually asks. Jo says, \"I wanted to finish it, but I can bring it Friday.\" Sam acknowledges that and thanks Jo. The puzzle has not yet been returned.",
      "In review, Sam notes a clear request and an agreed return date, not a completed return or proof of how Jo feels. Sam still feels awkward but thinks the honest wording fit. Sam plans to check what happens on Friday. No reminder is set by this page."
    ]
  },
  "learn": {
    "id": "interpersonal-priorities.learn",
    "title": "Three aims can matter together",
    "paragraphs": [
      "The objective is the result you want from this exchange. The relationship aim concerns how you hope to relate over time, including how you hope the other person will see you. Self-respect concerns how you hope to see yourself and the way you choose to act. None of these is fully controlled by a script.",
      "Sometimes the main result you want is to repair a relationship or speak up for yourself. That can be your objective. You still consider how you go about it, what it may mean for the relationship, and whether your actions fit your values.",
      "Look at all three aims each time. Their order can change with the situation. Putting one first does not erase the others or give permission to cause harm. Always giving up your needs for approval, or always having to win, can work against what matters over time.",
      "DEAR MAN supports a clear request or refusal. GIVE supports care in the relationship. FAST supports fairness, truth and self-respect. They can be used together. This preparation does not teach the separate Dime Game or choose how forceful to be."
    ]
  },
  "practice": [
    {
      "id": "interpersonal-priorities.practice.situation",
      "title": "Choose one situation and describe the facts",
      "paragraphs": [
        "Choose a suitable conversation, past or planned, or use Sam’s puzzle example. Briefly describe what was said or done and what makes a response matter. Separate what you know from guesses about the person’s reasons.",
        "Keep the event small enough to consider here. Check any real time limit, support need or safety concern. You can prepare without arranging a conversation, or leave it undecided."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The situation, without identifying details",
          "optional": true
        },
        {
          "key": "facts-and-unknowns",
          "label": "Facts, guesses or questions to keep separate",
          "optional": true
        }
      ],
      "help": {
        "title": "If the whole relationship fills the page",
        "text": "Choose one event if that is useful and safe. A wider pattern of harm may need support beyond a communication exercise. You do not need to describe it here."
      }
    },
    {
      "id": "interpersonal-priorities.practice.objective",
      "title": "Name the result you want",
      "paragraphs": [
        "What would you like to be different by the end of this exchange? Name a clear request, refusal, agreement or point you want understood. For Sam, it is a return by Friday, not making Jo feel guilty.",
        "Think about what the person can actually do and what is within your own control. What words or actions could help you seek that result? Asking does not guarantee an answer, and a refusal is not permission to keep pressing."
      ],
      "fields": [
        {
          "key": "objective",
          "label": "The specific result I want",
          "optional": true
        },
        {
          "key": "objective-action",
          "label": "A possible way to seek it, and what I cannot control",
          "optional": true
        }
      ],
      "help": {
        "title": "If I only know that I want things to be better",
        "text": "Try one change you could describe to another person. If it is still unclear, keep the question open and discuss it rather than inventing an objective."
      }
    },
    {
      "id": "interpersonal-priorities.practice.relationship",
      "title": "Name what matters for the relationship",
      "paragraphs": [
        "After this exchange, how do you hope the person will see you, and what kind of connection do you want? You may hope to be seen as fair, caring or clear. Include what matters over time, not just avoiding discomfort today.",
        "What could you do to support that aim while keeping your needs and limits? Listening or acknowledging a concern may help. You cannot make someone like you, and keeping contact is not always the right aim."
      ],
      "fields": [
        {
          "key": "relationship",
          "label": "What I hope for in the relationship and how I am seen",
          "optional": true
        },
        {
          "key": "relationship-action",
          "label": "How I could support that aim without giving up needed limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If keeping them happy seems like the only goal",
        "text": "Notice that pressure without blaming yourself. Your needs matter too. If there is fear of retaliation or harm, pause for support rather than using this to stay agreeable."
      }
    },
    {
      "id": "interpersonal-priorities.practice.self-respect",
      "title": "Name how you want to act and see yourself",
      "paragraphs": [
        "When you look back, what actions would help you respect your choice? You might want to be truthful, fair, keep an important limit or own a real mistake. Name what that would look like in this situation.",
        "How do you hope to feel about how you acted, even if the answer is no? A feeling may not change at once. Self-respect is not being perfect, never apologising, winning, hiding tears or proving you can manage without help."
      ],
      "fields": [
        {
          "key": "self-respect",
          "label": "How I want to act and see myself afterward",
          "optional": true
        },
        {
          "key": "self-respect-action",
          "label": "A value, duty, limit or real responsibility to keep in view",
          "optional": true
        }
      ],
      "help": {
        "title": "If values seem to clash",
        "text": "Name both, such as care for someone and care for your own needs. Seek help with the real conflict. Choosing a value is not a verdict that you or the other person is good or bad."
      }
    },
    {
      "id": "interpersonal-priorities.practice.order",
      "title": "Choose what matters most here",
      "paragraphs": [
        "Look at the result, the relationship and self-respect together. If you cannot meet every aim fully, which matters most for this exchange, which comes next, and which can take less weight? Choose in your own words, not by adding points.",
        "Say why this order fits these facts. All three still count. A lower place does not mean no care, no rights or permission to lie or harm. Do not use the same order by habit for every conversation.",
        "If you cannot choose yet, note what makes it unclear and discuss it with your therapist. The page will not rank the aims for you. Reading this step is not evidence you chose an order."
      ],
      "fields": [
        {
          "key": "priority-order",
          "label": "Most important, next and less important here, or still undecided",
          "optional": true
        },
        {
          "key": "priority-reason",
          "label": "Why that order fits this situation, or what I need to clarify",
          "optional": true
        }
      ],
      "help": {
        "title": "If all three feel equally important",
        "text": "Look for a specific moment where protecting one might cost another. What would you most regret losing here, and what could you accept? If no clear order fits yet, keep the question open rather than force a ranking."
      }
    },
    {
      "id": "interpersonal-priorities.practice.conflict",
      "title": "Check conflicts, costs and limits",
      "paragraphs": [
        "Would one aim get in the way of another? For example, saying yes may avoid disappointment now but break a promise you already made. Name a real conflict if there is one; do not create one to fill the page.",
        "Compare the likely effects now and later. What can you accept changing, and what needs to stay protected? You may revise an aim or its place after this check. Include needed support, consent and real responsibilities."
      ],
      "fields": [
        {
          "key": "conflict",
          "label": "Any conflict between aims, including effects now and later",
          "optional": true
        },
        {
          "key": "limits",
          "label": "What could change, what needs protecting or what remains unknown",
          "optional": true
        }
      ],
      "help": {
        "title": "If the choice seems to require harm",
        "text": "Stop and seek suitable advice or support. This exercise does not turn danger, coercion or violating someone’s consent into an acceptable trade-off."
      }
    },
    {
      "id": "interpersonal-priorities.practice.skill",
      "title": "Choose how to use the existing skills",
      "paragraphs": [
        "With the skills you have learned, decide what to focus on. DEAR MAN can help state the request or refusal. GIVE can help you listen and respond with care. FAST can help you stay fair and truthful while keeping your values in view.",
        "You may need a mix. Name how the mix supports your chosen order and what you want to avoid. This page does not teach the full skills, decide how strongly to ask, or open another tool for you."
      ],
      "fields": [
        {
          "key": "skill-mix",
          "label": "The skills I want to use and why",
          "optional": true
        },
        {
          "key": "skill-focus",
          "label": "A part to practise or a question for my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If I have not learned one of these skills",
        "text": "Use this as preparation for teaching with your therapist. You do not have to improvise a method or contact someone just because a goal is clear."
      }
    },
    {
      "id": "interpersonal-priorities.practice.check",
      "title": "Try explaining your choice",
      "paragraphs": [
        "Privately say, sign, think or write a short explanation of your choice: the result you seek, the relationship you want, how you want to act, their order, and why. You can use Sam’s example instead of personal details.",
        "Check whether your proposed response fits that explanation. If you have learned the related skill, you may rehearse it separately. Rehearsal is not a real conversation. You can change the plan, seek help or stop without trying it with anyone."
      ],
      "fields": [
        {
          "key": "choice-attempt",
          "label": "My explanation or what I actually tried in preparation",
          "optional": true
        },
        {
          "key": "check-change",
          "label": "What fits, what to change or what I have not tried",
          "optional": true
        }
      ],
      "help": {
        "title": "If I keep checking for the perfect answer",
        "text": "Pause. The aim is a careful choice, not certainty. Bring the unresolved part to your therapist instead of repeating until doubt disappears."
      }
    },
    {
      "id": "interpersonal-priorities.practice.review",
      "title": "Review preparation or what actually happened",
      "paragraphs": [
        "What did you actually do: read, name goals, choose an order, rehearse, have a conversation or decide not to continue? Keep these separate. You can review without any earlier notes.",
        "If there was a conversation, what happened to the result you wanted, the relationship and your view of how you acted? Separate facts, impressions and what is not yet known. A promise is not proof of follow-through, and someone else’s feelings may remain unclear.",
        "Did your actions fit the priorities you chose? Did an aim or limit get lost, or did the situation change? Include discomfort, no change or an unwanted effect. Not getting agreement is not proof that your choice or skill failed."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What I actually did or did not do",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What happened for each aim, and what I do not know",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What fitted, changed or needs discussion",
          "optional": true
        }
      ],
      "help": {
        "title": "If I chose not to speak",
        "text": "There is no conversation result to invent. You can review the preparation, what stopped you, and whether support or a different approach would fit."
      }
    },
    {
      "id": "interpersonal-priorities.practice.next",
      "title": "Keep, revise or leave the plan open",
      "paragraphs": [
        "Decide with your therapist whether to keep these priorities, revise them with new facts, practise a related skill, seek support or stop. A new situation may call for a different order.",
        "If there is a next step, keep it within your choice and limits. It remains a plan until it happens. No contact, reminder or report is created here; keep only selected notes if useful."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, revise, pause or stop",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any support or future step to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing needs doing now",
        "text": "You can finish. Clarifying what matters does not create a duty to have a conversation or make another plan."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 interpersonal Handouts 3–4",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Overview and three interpersonal aims; shared preparation for DEAR MAN, GIVE and FAST.",
      "limits": "Historical Second Edition, not the 2025 Revised Edition. Original app prose only; no source form or examples reproduced."
    },
    {
      "id": "Linehan/Guilford: 2015 interpersonal teaching notes, section IV",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Printed pp242–247: concrete goals, all three aims, situational relative importance, and distinctions when relationship or self-respect is itself the main objective.",
      "limits": "Clinical teaching is not evidence that this app is effective or suitable for everyone. Accessible communication and non-shaming safeguards are explicit adaptations."
    },
    {
      "id": "Linehan/Guilford: 2015 interpersonal Worksheets 3 and 5",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Worksheet3 clarifies event, aims, ranking and conflict; Worksheet5 supports review of actions and effects.",
      "limits": "No worksheet reproduced. Relative order is client-chosen in words, not a computed score. Worksheet6 Dime Game is separate and not implemented."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal, meaningful communication and access to needed support.",
      "limits": "Rights guidance, not validation of this clinical component."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from the individual purchaser licence.",
      "limits": "Accessible sources do not grant publication rights. No release-rights approval requested or received."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Event and three concrete goals",
      "sections": [
        "practice.situation",
        "practice.objective",
        "practice.relationship",
        "practice.self-respect"
      ],
      "source": "Handout4; Manual section IV; Worksheet3"
    },
    {
      "operation": "Explicit relative importance and conflicts",
      "sections": [
        "practice.order",
        "practice.conflict"
      ],
      "source": "Manual section IV C and Worksheet3; no default or computed ranking"
    },
    {
      "operation": "Use priorities to select a skill focus or mix",
      "sections": [
        "practice.skill",
        "practice.check"
      ],
      "source": "Handout3; Manual sections III–IV; complete DEAR MAN/GIVE/FAST retained separately"
    },
    {
      "operation": "Review actual preparation/use and each aim",
      "sections": [
        "practice.review",
        "practice.next"
      ],
      "source": "Worksheet5 and product safeguards; no inferred conversation or agreement"
    }
  ],
  "narrationSegments": [
    {
      "id": "interpersonal-priorities.intro",
      "title": "Decide what matters in this conversation",
      "text": "Before a conversation, you may want several things at once. You might want a change, care about the relationship, and want to act in a way you respect. A priority is what matters more in this situation when those aims pull apart.\n\nThis practice helps you name all three aims and decide how much weight to give each. It prepares you to use DEAR MAN, GIVE and FAST. It does not replace those skills or decide how strongly you should ask or say no.\n\nUse it after learning with your therapist. You can think it through, use the example, review what happened or finish without choosing or contacting anyone.",
      "sha256": "1d01eca0c196716d5ecb391350bcc2c38b0f594facf4875c8da56354ee514c4f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.fit",
      "title": "Keep safety, choice and support in view",
      "text": "Choose an ordinary, manageable situation with your therapist. Consider power, culture, support and any real duties or limits. If you are unsure whether speaking up could lead to threats, punishment, control or harm, start with suitable support and a safety plan rather than this exercise.\n\nThe page cannot decide whether a conversation is safe. You do not have to confront anyone, keep an unsafe relationship, reveal private facts or accept harm to protect a relationship. Respect the other person’s consent and limits too.\n\nIf this brings more distress, pressure or repeated checking, pause and discuss what would help. You can use fiction or stop. You do not have to feel calm, certain or confident first, but you do need enough support to choose what fits.\n\nThink, speak, sign, use an aid or write in a way that works for you. No set eye contact, tone, posture or fluent speech is required. This is not urgent help, a legal decision tool or a test of your worth.",
      "sha256": "926c6ff99dc8e483b905f26eb75970f2bd5eab77c9c560ca16ae5782d1b3ab09",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.privacy",
      "title": "Writing and sharing are your choice",
      "text": "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.\n\nNotes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep notes, choose only the parts you want, check the preview, then copy or download. Those copies remain wherever you save them.\n\nHiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return to this practice while the page stays open. It does not keep your answers or add a saved item to your usual Toolbox.",
      "sha256": "c159b3141e49f9cb13dde8096b9b9c41ee7f33bbb7eda953438e780fcc192ca6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.close",
      "title": "You can leave the decision here",
      "text": "You can finish after reading, preparing, practising, reviewing or choosing not to continue. No agreement, priority order or good feeling is required to leave.\n\nIf useful, keep selected notes or bring a question to your therapist. This page has not contacted anyone, chosen another skill for you or created a reminder. Leaving clears the notes here.",
      "sha256": "17bf77e94413a757c59c5de8d284cd931adb8f5317b9de843b353afc9b88614c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.example",
      "title": "Example: Sam needs a borrowed puzzle back",
      "text": "Sam lent Jo a puzzle and said it could stay for the week. It is now due back. Sam wants it for a planned game evening. Jo asks to keep it through the weekend. This is an ordinary disagreement, with no threat or earlier promise of extra time.\n\nSam separates the facts from the thought \"Jo does not care.\" The objective is to have the puzzle back by Friday. For the relationship, Sam hopes Jo will still see them as a fair friend who can lend things again. For self-respect, Sam wants to be clear and truthful, without a made-up reason or an insult.\n\nSam chooses this order for this occasion: getting the puzzle back first, acting truthfully and fairly next, and looking after the friendship third. Sam still wants Jo to see them as a fair friend. Sam can accept some disappointment, but not lie, threaten or ignore Jo’s limits to get the puzzle.\n\nThere is a real conflict: agreeing to the weekend would give Jo the extra time requested but leave Sam without the puzzle. Sam decides to make a clear request with DEAR MAN, use GIVE to hear Jo’s view, and use FAST to keep the explanation honest. This is a mix of skills, not a score that chooses one.\n\nSam privately rehearses: \"We agreed on this week. I need the puzzle for Friday. Can you bring it back then?\" Later, Sam actually asks. Jo says, \"I wanted to finish it, but I can bring it Friday.\" Sam acknowledges that and thanks Jo. The puzzle has not yet been returned.\n\nIn review, Sam notes a clear request and an agreed return date, not a completed return or proof of how Jo feels. Sam still feels awkward but thinks the honest wording fit. Sam plans to check what happens on Friday. No reminder is set by this page.",
      "sha256": "9c8cb2cc4c98601270e58b9e1df62aa34ae127827f4f29aa91a70039ba43f0a4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.learn",
      "title": "Three aims can matter together",
      "text": "The objective is the result you want from this exchange. The relationship aim concerns how you hope to relate over time, including how you hope the other person will see you. Self-respect concerns how you hope to see yourself and the way you choose to act. None of these is fully controlled by a script.\n\nSometimes the main result you want is to repair a relationship or speak up for yourself. That can be your objective. You still consider how you go about it, what it may mean for the relationship, and whether your actions fit your values.\n\nLook at all three aims each time. Their order can change with the situation. Putting one first does not erase the others or give permission to cause harm. Always giving up your needs for approval, or always having to win, can work against what matters over time.\n\nDEAR MAN supports a clear request or refusal. GIVE supports care in the relationship. FAST supports fairness, truth and self-respect. They can be used together. This preparation does not teach the separate Dime Game or choose how forceful to be.",
      "sha256": "04ea06b67dfbdd9ad873a87f462fe22c3ed6137b2f360e44de64939830cb4cdc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.situation",
      "title": "Choose one situation and describe the facts",
      "text": "Choose a suitable conversation, past or planned, or use Sam’s puzzle example. Briefly describe what was said or done and what makes a response matter. Separate what you know from guesses about the person’s reasons.\n\nKeep the event small enough to consider here. Check any real time limit, support need or safety concern. You can prepare without arranging a conversation, or leave it undecided.",
      "sha256": "cb96c04e586041bb92b3d26db5cf192f563d5bfcb48ad09aeddde30ddae9706d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.situation.help",
      "title": "If the whole relationship fills the page",
      "text": "Choose one event if that is useful and safe. A wider pattern of harm may need support beyond a communication exercise. You do not need to describe it here.",
      "sha256": "cd7b76b485f2b01f7ff20feb084887023d3a0f882cb3e90f697d1f20dc2b4b4b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.objective",
      "title": "Name the result you want",
      "text": "What would you like to be different by the end of this exchange? Name a clear request, refusal, agreement or point you want understood. For Sam, it is a return by Friday, not making Jo feel guilty.\n\nThink about what the person can actually do and what is within your own control. What words or actions could help you seek that result? Asking does not guarantee an answer, and a refusal is not permission to keep pressing.",
      "sha256": "df12a2efb0f982c8b629c045d24f36570c6a1adfb116078c0c6bdac678aa4a04",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.objective.help",
      "title": "If I only know that I want things to be better",
      "text": "Try one change you could describe to another person. If it is still unclear, keep the question open and discuss it rather than inventing an objective.",
      "sha256": "6a51c2217df6e080e7fbc174347c9789523164ee9bf7905e70c72ea727f892e9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.relationship",
      "title": "Name what matters for the relationship",
      "text": "After this exchange, how do you hope the person will see you, and what kind of connection do you want? You may hope to be seen as fair, caring or clear. Include what matters over time, not just avoiding discomfort today.\n\nWhat could you do to support that aim while keeping your needs and limits? Listening or acknowledging a concern may help. You cannot make someone like you, and keeping contact is not always the right aim.",
      "sha256": "aff853b4e298fda3a7c5fd0571284838852fa874f5faae05e0ff17dcd2b78717",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.relationship.help",
      "title": "If keeping them happy seems like the only goal",
      "text": "Notice that pressure without blaming yourself. Your needs matter too. If there is fear of retaliation or harm, pause for support rather than using this to stay agreeable.",
      "sha256": "06863b5d0818fc3da7a3807af26606a5223497da5830d9ee5810e7a5114ffb83",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.self-respect",
      "title": "Name how you want to act and see yourself",
      "text": "When you look back, what actions would help you respect your choice? You might want to be truthful, fair, keep an important limit or own a real mistake. Name what that would look like in this situation.\n\nHow do you hope to feel about how you acted, even if the answer is no? A feeling may not change at once. Self-respect is not being perfect, never apologising, winning, hiding tears or proving you can manage without help.",
      "sha256": "e0993f650263f3156aadee4fa10dc32a5be1686596b1c97bcae48576c01f6c9a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.self-respect.help",
      "title": "If values seem to clash",
      "text": "Name both, such as care for someone and care for your own needs. Seek help with the real conflict. Choosing a value is not a verdict that you or the other person is good or bad.",
      "sha256": "bb2d1c28ee92db65aa6613def649d661486d2a0ebd353e73363534590e82c339",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.order",
      "title": "Choose what matters most here",
      "text": "Look at the result, the relationship and self-respect together. If you cannot meet every aim fully, which matters most for this exchange, which comes next, and which can take less weight? Choose in your own words, not by adding points.\n\nSay why this order fits these facts. All three still count. A lower place does not mean no care, no rights or permission to lie or harm. Do not use the same order by habit for every conversation.\n\nIf you cannot choose yet, note what makes it unclear and discuss it with your therapist. The page will not rank the aims for you. Reading this step is not evidence you chose an order.",
      "sha256": "064de5afb9473c2e6b376b346ce438ae594a9774516a9789c37795969985c9d3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.order.help",
      "title": "If all three feel equally important",
      "text": "Look for a specific moment where protecting one might cost another. What would you most regret losing here, and what could you accept? If no clear order fits yet, keep the question open rather than force a ranking.",
      "sha256": "11c1b5c9e29608df00b54f9ec537825ef37b4787213dfd3d9bdae1f26a892455",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.conflict",
      "title": "Check conflicts, costs and limits",
      "text": "Would one aim get in the way of another? For example, saying yes may avoid disappointment now but break a promise you already made. Name a real conflict if there is one; do not create one to fill the page.\n\nCompare the likely effects now and later. What can you accept changing, and what needs to stay protected? You may revise an aim or its place after this check. Include needed support, consent and real responsibilities.",
      "sha256": "024b33de06ff6d56e373f300edac89aaa5a60b9ebf6c0c9872c2e75c9bdf6f72",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.conflict.help",
      "title": "If the choice seems to require harm",
      "text": "Stop and seek suitable advice or support. This exercise does not turn danger, coercion or violating someone’s consent into an acceptable trade-off.",
      "sha256": "d0d7cd71b0071771734bca39bae6a14ad211a89dedbc3c919baf774fbef37d8b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.skill",
      "title": "Choose how to use the existing skills",
      "text": "With the skills you have learned, decide what to focus on. DEAR MAN can help state the request or refusal. GIVE can help you listen and respond with care. FAST can help you stay fair and truthful while keeping your values in view.\n\nYou may need a mix. Name how the mix supports your chosen order and what you want to avoid. This page does not teach the full skills, decide how strongly to ask, or open another tool for you.",
      "sha256": "03c44a28359ed2dd69772134646e3a71a0d2831fb960bf5bd1e10eb0468209ca",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.skill.help",
      "title": "If I have not learned one of these skills",
      "text": "Use this as preparation for teaching with your therapist. You do not have to improvise a method or contact someone just because a goal is clear.",
      "sha256": "e664beab558bb03466e58d4ed40e9c888b1f5c64e08de3328fdadfd0edac739e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.check",
      "title": "Try explaining your choice",
      "text": "Privately say, sign, think or write a short explanation of your choice: the result you seek, the relationship you want, how you want to act, their order, and why. You can use Sam’s example instead of personal details.\n\nCheck whether your proposed response fits that explanation. If you have learned the related skill, you may rehearse it separately. Rehearsal is not a real conversation. You can change the plan, seek help or stop without trying it with anyone.",
      "sha256": "30894293b276fd2e2dbd725ea38575d9a81921c90858acd063495de3a45bb4b2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.check.help",
      "title": "If I keep checking for the perfect answer",
      "text": "Pause. The aim is a careful choice, not certainty. Bring the unresolved part to your therapist instead of repeating until doubt disappears.",
      "sha256": "d1fd60b5393dd49d31e2c5cf956f2d2486c9267c44fb006c5bfa1351c8f4cdda",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.review",
      "title": "Review preparation or what actually happened",
      "text": "What did you actually do: read, name goals, choose an order, rehearse, have a conversation or decide not to continue? Keep these separate. You can review without any earlier notes.\n\nIf there was a conversation, what happened to the result you wanted, the relationship and your view of how you acted? Separate facts, impressions and what is not yet known. A promise is not proof of follow-through, and someone else’s feelings may remain unclear.\n\nDid your actions fit the priorities you chose? Did an aim or limit get lost, or did the situation change? Include discomfort, no change or an unwanted effect. Not getting agreement is not proof that your choice or skill failed.",
      "sha256": "3906332aca7afa142329a90fc71fb5ca2d9d897b6e03c80f1d1fe8b6df2544a9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.review.help",
      "title": "If I chose not to speak",
      "text": "There is no conversation result to invent. You can review the preparation, what stopped you, and whether support or a different approach would fit.",
      "sha256": "e91d3918c1bbd7428d95921ad6d9bb77301ec2dd36417eb0a47fd12c6a566017",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-priorities.practice.next",
      "title": "Keep, revise or leave the plan open",
      "text": "Decide with your therapist whether to keep these priorities, revise them with new facts, practise a related skill, seek support or stop. A new situation may call for a different order.\n\nIf there is a next step, keep it within your choice and limits. It remains a plan until it happens. No contact, reminder or report is created here; keep only selected notes if useful.",
      "sha256": "ae805b540fb18899366b8efcfec40b5c1a8392062548e3e75b3842090d18b017",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-priorities.practice.next.help",
      "title": "If nothing needs doing now",
      "text": "You can finish. Clarifying what matters does not create a duty to have a conversation or make another plan.",
      "sha256": "96f7bb8f13cfc3583023b128b32d3d9e7a2b6f880f2f4c698c1828b21d2709ac",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
