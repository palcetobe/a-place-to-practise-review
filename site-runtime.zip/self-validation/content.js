window.ContinuedSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/validation",
  "version": "2026-11-02-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "title": "Self-Validation",
  "subtitle": "Acknowledge your experience without a put-down",
  "scope": "Self-Validation component within Validation and Self-Validation; DBT-informed educational practice, not the whole grouped set or a full DBT programme.",
  "clinicalContract": {
    "learningObjective": "Distinguish acknowledging experience from endorsing a factual interpretation, praising yourself or excusing harmful behaviour.",
    "practiceObjective": "Try a believable acknowledgment of an ordinary experience without dismissing it; use known context only if helpful and review whether the wording adds a put-down or unsupported claim.",
    "observedPractice": "A private or optional written acknowledgment, or a fictional rehearsal, and self-review. A brief feeling statement can be sufficient; context, warmth, explanation and relief are not required.",
    "sourcePopulationContext": "Primary sources describe broader clinical methods, not validation of this digital adaptation or suitability across ages. Therapist selection and adaptation should account for development, communication, context, consent, privacy and safeguarding. Method-specific source populations and suitability limits still apply."
  },
  "privacy": {
    "id": "validation.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Exact scripts below await generation, listening and integration. Audio repair is a separate workstream; no old asset is presumed to match changed text.",
    "timer": "No timer required or proposed.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "sources": [
    {
      "id": "linehan-selfvalidation",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-02",
      "supports": "Interpersonal Effectiveness handouts17,19,19a: validation without endorsing invalid claims; matter-of-fact self-description instead of self-attack. Conceptual grounding only; publisher worksheets are not reproduced or redistributed."
    },
    {
      "id": "behavioraltech-validation",
      "url": "https://behavioraltech.org/teaching-give-skills-part-2/",
      "reviewed": "2026-11-02",
      "supports": "Validation distinguished from praise and merely saying pleasant things; source discusses interpersonal GIVE, not proof of this self-guided procedure."
    },
    {
      "id": "nhs-validation",
      "url": "https://www.rightdecisions.scot.nhs.uk/personality-disorder-integrated-care-pathway/general-principles-in-treating-personality-disorder/general-treatment-strategies/validation/",
      "reviewed": "2026-11-02",
      "supports": "Historical teaching-brief source only; direct re-open returned403 on2026-11-02. Not relied on for fresh claims; publisher and BehavioralTech sources verified."
    }
  ],
  "productAdaptations": [
    "Retains historical Sasha/Ash scenarios and optional context; removes none of their key distinctions.",
    "Three original prompts, not official numbered DBT steps. Not all validation skills or full DBT.",
    "Optional wording and fictional model; no automated text assessment, forced body focus, cause, warmth, relief or action.",
    "No legacy downloaded records or audio imported; current session-only privacy and script status control."
  ],
  "resourceId": "tool/self-validation",
  "routeProposal": "tool/self-validation",
  "componentId": "component/validation/self-validation",
  "groupedSetStatus": "Self-validation component only; validation of others remains not built by this contract. No new catalogue count.",
  "intro": {
    "id": "validation.intro",
    "title": "Take your experience seriously",
    "paragraphs": [
      "Self-validation means acknowledging what you are experiencing without putting yourself down for having it. You can name a feeling, recognise that something is hard, or say you are unsure.",
      "You do not need to prove why you feel this way or feel better afterwards. This page practises self-validation, not the separate skill of validating another person."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "validation.fit",
    "title": "Use an ordinary or fictional moment",
    "paragraphs": [
      "Practise with your therapist’s guidance between sessions. You can use fiction and leave personal details out.",
      "Acknowledging hurt does not require accepting mistreatment, assuming someone’s motives, excusing harm or handling everything alone. If a situation needs safety support, use that support rather than trying to validate your way through it. Pause if the practice feels overwhelming."
    ]
  },
  "learn": {
    "id": "validation.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "A dismissive response adds a second struggle: having a feeling and then attacking yourself for having it. An honest acknowledgment is a different response, even if the feeling stays.",
      "Understanding is not the same as agreement with every thought. “I feel hurt” acknowledges an experience; it does not prove “they intended to hurt me.” You can take the experience seriously while leaving that interpretation uncertain.",
      "You may add context you already know, but you do not need to search your past, invent a cause or use a warm tone. “I feel uneasy and I don’t know why” can be enough."
    ]
  },
  "example": {
    "id": "validation.example",
    "title": "Example — Sasha meets a change",
    "paragraphs": [
      "Sasha arrives for a craft workshop and finds it has moved rooms. The printed timetable did not show the change. Sasha feels frustrated and unsure where to go. The reasons for the change are unknown.",
      "Sasha first thinks, “It is only a room change, so I should not feel this.” Sasha notices the put-down and tries, “I feel frustrated and uncertain.” If useful, Sasha can add, “I was relying on that timetable.”",
      "In review, Sasha notices that the revised words acknowledge the experience without guessing staff motives. Frustration remains. The acknowledgment is still complete; finding the room or requesting access support is a separate practical need."
    ]
  },
  "practiceScenario": {
    "id": "validation.scenario",
    "title": "Optional fictional practice — Ash",
    "paragraphs": [
      "Ash notices uneasiness during an ordinary afternoon but does not know why. Ash thinks, “I cannot acknowledge this until I can explain it.”",
      "Use Ash, invent a manageable moment or use your own. No personal disclosure or explanation is needed."
    ]
  },
  "practice": [
    {
      "id": "validation.practice.notice",
      "title": "Notice what is here",
      "paragraphs": [
        "What experience could you acknowledge? A feeling, a difficulty, or “I’m not sure what I feel” is enough to begin. There is no need to focus inside your body."
      ],
      "fields": [
        {
          "key": "experience",
          "label": "What I notice, if I want to write",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot find an emotion word",
        "text": "Use plain words such as “This is hard” or leave the description open. The aim is acknowledgment, not a perfect label."
      }
    },
    {
      "id": "validation.practice.acknowledge",
      "title": "Try an honest acknowledgment",
      "paragraphs": [
        "Try words that take the experience seriously without criticising yourself for having it. A brief statement may be enough.",
        "If helpful, add something you already know about the circumstances. Context is optional; it is not permission you must earn to acknowledge a feeling."
      ],
      "fields": [
        {
          "key": "acknowledgment",
          "label": "Words I might try",
          "optional": true
        }
      ],
      "help": {
        "title": "If words feel forced",
        "text": "Make them simpler rather than more positive. You do not need an affirmation, a cause, praise or a promise to change."
      }
    },
    {
      "id": "validation.practice.review",
      "title": "Check what the words do",
      "paragraphs": [
        "Do the words acknowledge the experience, or finish by dismissing it? Do they treat an uncertain explanation as fact? You can remove a put-down or leave an explanation open.",
        "Notice whether the wording feels honest, not whether the feeling has gone away. You can stop without another sentence or action."
      ],
      "fields": [
        {
          "key": "review",
          "label": "A revision or observation, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "A possible Ash response",
        "text": "“I feel uneasy. I don’t know why.” This acknowledges the experience without making a cause a condition. “I should not feel this until I know why” would add a condition. The example is a model, not a grade for your words."
      }
    }
  ],
  "close": {
    "id": "validation.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "A brief acknowledgment can stand on its own. You do not have to justify the experience, feel calmer or make an action plan before finishing."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "narrationSegments": [
    {
      "id": "validation.intro",
      "title": "Take your experience seriously",
      "text": "Self-validation means acknowledging what you are experiencing without putting yourself down for having it. You can name a feeling, recognise that something is hard, or say you are unsure.\n\nYou do not need to prove why you feel this way or feel better afterwards. This page practises self-validation, not the separate skill of validating another person.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.fit",
      "title": "Use an ordinary or fictional moment",
      "text": "Practise with your therapist’s guidance between sessions. You can use fiction and leave personal details out.\n\nAcknowledging hurt does not require accepting mistreatment, assuming someone’s motives, excusing harm or handling everything alone. If a situation needs safety support, use that support rather than trying to validate your way through it. Pause if the practice feels overwhelming.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.learn",
      "title": "Why this skill may help",
      "text": "A dismissive response adds a second struggle: having a feeling and then attacking yourself for having it. An honest acknowledgment is a different response, even if the feeling stays.\n\nUnderstanding is not the same as agreement with every thought. “I feel hurt” acknowledges an experience; it does not prove “they intended to hurt me.” You can take the experience seriously while leaving that interpretation uncertain.\n\nYou may add context you already know, but you do not need to search your past, invent a cause or use a warm tone. “I feel uneasy and I don’t know why” can be enough.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.example",
      "title": "Example — Sasha meets a change",
      "text": "Sasha arrives for a craft workshop and finds it has moved rooms. The printed timetable did not show the change. Sasha feels frustrated and unsure where to go. The reasons for the change are unknown.\n\nSasha first thinks, “It is only a room change, so I should not feel this.” Sasha notices the put-down and tries, “I feel frustrated and uncertain.” If useful, Sasha can add, “I was relying on that timetable.”\n\nIn review, Sasha notices that the revised words acknowledge the experience without guessing staff motives. Frustration remains. The acknowledgment is still complete; finding the room or requesting access support is a separate practical need.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.scenario",
      "title": "Optional fictional practice — Ash",
      "text": "Ash notices uneasiness during an ordinary afternoon but does not know why. Ash thinks, “I cannot acknowledge this until I can explain it.”\n\nUse Ash, invent a manageable moment or use your own. No personal disclosure or explanation is needed.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.practice.notice",
      "title": "Notice what is here",
      "text": "What experience could you acknowledge? A feeling, a difficulty, or “I’m not sure what I feel” is enough to begin. There is no need to focus inside your body.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.practice.notice.help",
      "title": "If you cannot find an emotion word",
      "text": "Use plain words such as “This is hard” or leave the description open. The aim is acknowledgment, not a perfect label.",
      "status": "Script only"
    },
    {
      "id": "validation.practice.acknowledge",
      "title": "Try an honest acknowledgment",
      "text": "Try words that take the experience seriously without criticising yourself for having it. A brief statement may be enough.\n\nIf helpful, add something you already know about the circumstances. Context is optional; it is not permission you must earn to acknowledge a feeling.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.practice.acknowledge.help",
      "title": "If words feel forced",
      "text": "Make them simpler rather than more positive. You do not need an affirmation, a cause, praise or a promise to change.",
      "status": "Script only"
    },
    {
      "id": "validation.practice.review",
      "title": "Check what the words do",
      "text": "Do the words acknowledge the experience, or finish by dismissing it? Do they treat an uncertain explanation as fact? You can remove a put-down or leave an explanation open.\n\nNotice whether the wording feels honest, not whether the feeling has gone away. You can stop without another sentence or action.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.practice.review.help",
      "title": "A possible Ash response",
      "text": "“I feel uneasy. I don’t know why.” This acknowledges the experience without making a cause a condition. “I should not feel this until I know why” would add a condition. The example is a model, not a grade for your words.",
      "status": "Script only"
    },
    {
      "id": "validation.close",
      "title": "Leave it here for now",
      "text": "A brief acknowledgment can stand on its own. You do not have to justify the experience, feel calmer or make an action plan before finishing.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "validation.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    }
  ]
}
;
