window.MindfulnessOfOthersContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/relationships",
  "componentId": "component/relationships/mindfulness-of-others",
  "resourceId": "tool/mindfulness-of-others",
  "routeProposal": "/mindfulness-of-others/",
  "title": "Mindfulness of Others",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Practise observing, describing and taking part with another person while staying open to new information and keeping choices and limits.",
  "groupedSetStatus": "Existing uncounted named component under Building Relationships and Ending Destructive Ones. Complete bounded original adaptation, not the whole grouped set, full GIVE, active listening, validation, friendship-building or relationship-ending work. No new canonical count.",
  "clinicalContract": {
    "learningObjective": "Distinguish present observations from labels, assumptions and intended effects; be genuinely open to correction without blind trust, compulsory agreement or loss of protective judgement.",
    "practiceObjective": "Choose a suitable shared interaction, attend with curiosity, update views, loosen evaluative labels, describe facts and own experience, check uncertain meaning, calibrate trust from actual behavior, participate flexibly, rehearse and review actual use/non-use.",
    "sourcePopulationContext": "2015 author/publisher DBT teaching establishes the named component, not efficacy of this app or latest-edition equivalence. No age floor. Therapist checks clinical, developmental, cultural, communication, safeguarding and access fit.",
    "exclusions": [
      "No compelled relationship, contact, forgiveness, disclosure, trust or abandonment of boundaries",
      "No forced eye contact, speech style, masking, withdrawal of communication aids or quiet-body demand",
      "No assumption that a gesture or facial expression proves a thought, motive, feeling or danger level",
      "No harmful-intent inference from impact alone, and no dismissing evidence of harm to give benefit of doubt",
      "No exposure protocol, deliberate induction of self-criticism, rating comparison, perfection or anxiety-reduction goal",
      "No real surveillance, recording, analysis of another person, social scoring or automatic messages",
      "No replacement for urgent support, safety planning, safeguarding, care duties or specialist help"
    ],
    "adaptations": [
      "Original prose, ordinary fictional exchange and optional notes, not reproduced Handout12/12a or Worksheet9",
      "All Observe/Describe/Participate domains and relevant How qualities retained; no compulsory sequence in live conversation",
      "Nonessential distraction can be reduced without removing AAC, assistive technology, regulation movement or necessary attention to care/safety",
      "Participation means active involvement in the present exchange, not literal fusion, lost self-awareness or commitment to an ongoing relationship",
      "Trust teaching retains genuine openness plus evidence, boundaries and freedom to decline; no prescribed disclosure or risky trust experiment",
      "Optional private rehearsal adapts the suggested group roleplay; no deliberately induced performance-anxiety comparison or copied checklist/score"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of the complete bounded adaptation and component placement; source-use rights",
      "Individual clinical, developmental, cultural, communication, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not a validated reading level",
      "Integrated desktop/mobile/keyboard/screen-reader, selected-export and lifecycle acceptance",
      "Authorized exact-script narration generation and listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose practice or review",
      "options": [
        {
          "value": "prepare",
          "label": "Prepare and practise with others",
          "startSectionId": "mindfulness-of-others.practice.situation"
        },
        {
          "value": "review",
          "label": "Review a practice or interaction",
          "startSectionId": "mindfulness-of-others.practice.review"
        }
      ]
    },
    "entryGate": "Scope and safety visible before selection. No contact or relationship approved by the page.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence or writing.",
    "reviewAccess": "Direct blank review without a stored plan, inferred contact or outcome. Both modes expose all groups.",
    "writing": "Optional and hidden initially. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording upload or autoplay.",
    "timer": "None. No contact deadline, required duration, exposure ladder or repetition count.",
    "completion": "No inferred attention, understanding, trust, participation, relationship, safety, agreement or improvement."
  },
  "intro": {
    "id": "mindfulness-of-others.intro",
    "title": "Be present with another person",
    "paragraphs": [
      "Mindfulness of others means paying attention to the person and the exchange you are in. You notice what happens, use clear words for what you know, and take part rather than only watching or planning your next move.",
      "You can stay open to learning something new about a person without agreeing with everything or ignoring harm. The practice builds on GIVE and the mindfulness skills Observe, Describe and Participate. It is more than finding the right words to say.",
      "Use this after teaching with your therapist, in a suitable ordinary setting or a private rehearsal. You can read the example, practise one part, review an interaction or finish without making contact."
    ]
  },
  "fit": {
    "id": "mindfulness-of-others.fit",
    "title": "Choose a setting where you have room to choose",
    "paragraphs": [
      "With your therapist, choose a manageable exchange where participation is welcome. Check power, culture, privacy, access and needed support. If there are threats, pressure, control or fear of punishment, begin with suitable support rather than trying to be more open to that person.",
      "Being mindful does not mean staying in an unsafe exchange, trusting someone who has shown harm, giving up a limit or making contact after a refusal. The tool cannot judge safety or tell you whether a person is trustworthy.",
      "Keep communication aids, needed movement, quiet space and support. Eye contact, a still body, fluent speech or a particular facial expression are not required. Reading, signing, communication devices and pictures count too. You do not need to hide a disability or distress.",
      "If attention to others becomes upsetting, exhausting or a search for hidden danger or approval, pause and discuss what fits. This page is not treatment for every social fear, a test of closeness or urgent support. You may stop without asking permission."
    ]
  },
  "privacy": {
    "id": "mindfulness-of-others.privacy",
    "title": "Keep only the details you want",
    "paragraphs": [
      "Writing is optional. You may think privately, use your own paper or practise with your therapist. A general label is enough; names, private messages and personal history are not needed. This page records no voice and sends nothing to anyone.",
      "Notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. Choose notes, check the preview, then copy or download only if you want a separate copy. That copy stays wherever you save it.",
      "Hiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return while this page stays open; it does not keep answers or add a saved item to your usual Toolbox."
    ]
  },
  "close": {
    "id": "mindfulness-of-others.close",
    "title": "Let this practice end",
    "paragraphs": [
      "You can finish after reading, rehearsing, trying a part, reviewing or choosing not to continue. You do not need to feel closer, less anxious or sure about another person.",
      "Keep selected notes only if useful. You can bring a question to your therapist or return to an ordinary activity. This page has not contacted anyone, saved a relationship record or set a reminder. Leaving clears the notes here."
    ]
  },
  "example": {
    "id": "mindfulness-of-others.example",
    "title": "Example: Mina and Dev choose some music",
    "paragraphs": [
      "Mina and Dev are choosing music together for a small gathering. Dev liked lively music last month. Today Dev says, \"Could we start with something quiet?\" Mina thinks, \"Dev is impossible to please,\" then notices that this is a label, not something Dev said.",
      "Mina puts an unrelated shopping list aside but keeps a device used to read the song choices. Mina returns attention from \"Am I choosing badly?\" to Dev’s request. Mina notices the changed preference without deciding Dev is rejecting them.",
      "Mina says, \"You liked the lively songs last time. Today you asked for a quiet start. What would fit?\" Dev replies, \"I still like those songs. I want people to be able to talk first.\" Mina updates their view: the request concerns the start of this gathering, not a permanent dislike of lively music.",
      "Mina had hoped to start with a favourite lively song. They say that plainly, then choose to let Dev pick the first quiet song and suggest their favourite for later. Dev picks a song, and Mina adds another that fits the shared plan. Mina takes part instead of monitoring every choice or needing to win the point.",
      "This was a small choice Mina wanted to share, not proof that Dev can be trusted with everything or a promise to agree next time. No private disclosure or ongoing commitment was required. Both could still change their minds or set a limit.",
      "Afterward, Mina records what actually happened: one judgement noticed, a question asked, new information taken in and two song choices made. Some awkwardness remained. Mina cannot know from this whether Dev felt closer, and does not use the outcome to rate the friendship."
    ]
  },
  "learn": {
    "id": "mindfulness-of-others.learn",
    "title": "Observe, describe and participate",
    "paragraphs": [
      "Observe means noticing the person’s actual words and actions with interest. Describe means saying what you observed, and keeping your own thoughts and feelings separate from guesses about theirs. Participate means joining in the current exchange, not watching yourself perform every moment.",
      "The mindfulness How skills apply too: keep attention with the present exchange, leave out unhelpful labels, and choose what serves the situation and your values. You can move between the What skills as needed. You do not have to do all three at once or run a checklist while someone talks.",
      "Giving the benefit of the doubt means really allowing that your first explanation may be wrong. It does not mean deciding everyone has good intent. Trust can grow through what people actually do, and evidence of harm still matters. A clear limit or a pause can be a mindful response.",
      "This is an extension of GIVE, not a replacement for it. Listening and checking understanding, validation and friendship-building are related skills with their own purposes. Joining one conversation does not commit you to a lasting relationship."
    ]
  },
  "practice": [
    {
      "id": "mindfulness-of-others.practice.situation",
      "title": "Choose a suitable exchange",
      "paragraphs": [
        "Choose an ordinary conversation or shared activity that you want to take part in, or use Mina and Dev’s example. Name the setting and what you hope to practise, such as attention, clearer description or joining in.",
        "Check whether the other person is willing and what support or limits matter. You can practise privately without involving them. These groups explain the parts; a real interaction does not need to follow them in order."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The situation, without identifying details",
          "optional": true
        },
        {
          "key": "practice-aim",
          "label": "What I want to practise and any needed limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If no suitable person or setting comes to mind",
        "text": "Use the fictional exchange or talk through a choice with your therapist. You do not need to make a new contact to finish this practice."
      }
    },
    {
      "id": "mindfulness-of-others.practice.attend",
      "title": "Observe: give the exchange your attention",
      "paragraphs": [
        "If you choose to practise, notice what the person is saying, signing, writing or doing now. Be curious about their meaning. Put aside an unrelated task if you can, while keeping aids, movement and support that help you take part.",
        "If you notice yourself rehearsing a reply or checking how you appear, gently return to the current message. You can still notice your own needs, surroundings and safety. This is not a demand to stop every thought or give attention you do not have."
      ],
      "fields": [
        {
          "key": "attention",
          "label": "What I actually noticed in the exchange or example",
          "optional": true
        },
        {
          "key": "attention-return",
          "label": "What helped me return, or why I paused",
          "optional": true
        }
      ],
      "help": {
        "title": "If a pause or more time would help",
        "text": "Ask for time or for the message in a form you can use. Using a communication aid, reading a cue or taking a needed break is not the same as ignoring the person."
      }
    },
    {
      "id": "mindfulness-of-others.practice.update",
      "title": "Stay open to new information",
      "paragraphs": [
        "What is the person telling or showing you now? Let it add to what you knew before. A preference or view can change. Check the new information rather than deciding the person must still want what they wanted last time.",
        "You do not need to erase earlier events or accept every claim. Hold both what is new and what remains known. If they correct a misunderstanding, try updating your view without treating the correction as a contest."
      ],
      "fields": [
        {
          "key": "new-information",
          "label": "New or changed information I noticed",
          "optional": true
        },
        {
          "key": "updated-view",
          "label": "What I would update, keep or leave uncertain",
          "optional": true
        }
      ],
      "help": {
        "title": "If the new account does not fit earlier facts",
        "text": "Name the mismatch as a question, not proof of deceit or proof that earlier harm did not happen. Important concerns may need support outside this exercise."
      }
    },
    {
      "id": "mindfulness-of-others.practice.judgements",
      "title": "Notice labels and the need to be right",
      "paragraphs": [
        "Notice any broad label, such as \"They are impossible,\" or a push to prove your view is the only right one. A thought can be present without guiding your next reply. Return to the event you are trying to understand.",
        "Try leaving out an insult or ranking of the person. You can still name an action as harmful, disagree, keep a value or correct an important fact. Letting go of a contest does not mean saying you agree when you do not."
      ],
      "fields": [
        {
          "key": "judgement",
          "label": "A label or urge to win that I noticed, if any",
          "optional": true
        },
        {
          "key": "description-shift",
          "label": "How I could return to the event without giving up a needed point",
          "optional": true
        }
      ],
      "help": {
        "title": "If I judge myself for having a judgement",
        "text": "Notice that too, without turning it into another task to get right. You can continue, change the wording or stop. A perfect mind is not required."
      }
    },
    {
      "id": "mindfulness-of-others.practice.describe",
      "title": "Describe what you know",
      "paragraphs": [
        "Put the relevant words or actions into a brief description. Keep a fact such as \"They asked for a quiet song\" separate from \"They dislike my choices.\" Name your own reaction as yours, if useful.",
        "Mina could say, \"You asked for a quiet start. I had hoped to play this lively song first.\" That states a request and a personal wish without claiming to know Dev’s motive. Try a description for your own example."
      ],
      "fields": [
        {
          "key": "observed-facts",
          "label": "The words or actions I observed",
          "optional": true
        },
        {
          "key": "own-response",
          "label": "My own thought, feeling or preference, separate from their mind",
          "optional": true
        }
      ],
      "help": {
        "title": "If I can only remember a general impression",
        "text": "Keep it as an impression. You do not have to invent exact words or collect evidence about the person. Leave the detail unknown if that is all you know."
      }
    },
    {
      "id": "mindfulness-of-others.practice.check",
      "title": "Check meaning without assuming a motive",
      "paragraphs": [
        "If clarification would help and is welcome, ask a plain question or check a brief summary. Leave room for an answer you did not expect. For Mina, \"What would fit for the start?\" is more useful than \"Why are you trying to spoil my choice?\"",
        "Notice the answer and adjust if it changes your understanding. Words and nonverbal cues can be useful clues, but no expression or gesture proves what someone thinks. A lack of reply remains a lack of reply, not a hidden answer.",
        "An effect on you does not by itself prove that effect was intended. Where it fits, genuinely consider another possible reason. You can remain unsure and still respond to harm or keep a boundary; you do not need to prove a motive first."
      ],
      "fields": [
        {
          "key": "clarifying-question",
          "label": "A useful question or summary to check",
          "optional": true
        },
        {
          "key": "reply-and-uncertainty",
          "label": "What was actually said, or what remains unknown",
          "optional": true
        }
      ],
      "help": {
        "title": "If checking becomes repeated reassurance-seeking",
        "text": "Pause instead of asking until you feel certain. Discuss the pattern with your therapist. The other person can decline to explain, and this page cannot decide what they meant."
      }
    },
    {
      "id": "mindfulness-of-others.practice.trust",
      "title": "Let trust depend on actions and limits",
      "paragraphs": [
        "Being open does not require trusting everything. If it fits, you may choose a small, low-stakes way to share an activity and see whether the person follows through. In the example, Mina freely lets Dev choose a first song. No private information or important possession is at stake.",
        "Notice what actually happens, not just how long you have known them or what you hope. Trust in one area does not prove trust in all areas. You can decline the opportunity, keep the current limit or change your view when what happened gives you reason to.",
        "Do not dismiss warning signs, harmful patterns or your need for support in order to give someone a chance. You do not owe another test to someone who has harmed you. You do not need to set up a test of trust. This page cannot assess safety."
      ],
      "fields": [
        {
          "key": "trust-choice",
          "label": "A suitable small shared choice, current limit or decision not to try",
          "optional": true
        },
        {
          "key": "trust-evidence",
          "label": "What their actions show in this area, and what they do not show",
          "optional": true
        }
      ],
      "help": {
        "title": "If a small choice does not feel small for me",
        "text": "Do not use it just because it appears in an example. Keep the boundary and choose another part of the skill with support."
      }
    },
    {
      "id": "mindfulness-of-others.practice.participate",
      "title": "Participate without controlling every turn",
      "paragraphs": [
        "When joining is suitable and wanted, take part in what is happening now. Offer a relevant thought, answer, question or action in the shared activity. Let yourself be involved rather than only watching for a mistake.",
        "Allow room for the other person’s contribution and for an ordinary change of direction. Try responding to their actual turn instead of forcing the exchange back to a fixed script. You may disagree, ask for structure or keep a clear limit.",
        "Being involved does not mean losing yourself, pleasing everyone or joining every activity. Keep consent, values, care duties and safety. One conversation does not commit you to an ongoing relationship. You can pause or leave."
      ],
      "fields": [
        {
          "key": "participation",
          "label": "A contribution or shared action I could try",
          "optional": true
        },
        {
          "key": "flexibility-and-limits",
          "label": "Where I can be flexible, and what needs to stay protected",
          "optional": true
        }
      ],
      "help": {
        "title": "If taking part needs structure",
        "text": "A clear turn, written choices or an agreed activity can help. Flexibility does not require guessing social rules, dropping support or hiding how you communicate."
      }
    },
    {
      "id": "mindfulness-of-others.practice.rehearse",
      "title": "Try a short exchange privately",
      "paragraphs": [
        "Choose a part to rehearse in your usual way of communicating, alone or with your therapist. Use your situation or this fictional line: \"I want something quiet at the start.\" Notice the words, describe what you know and try a useful question or reply.",
        "Then consider this possible clarification: \"I still like lively music. I want people to talk first.\" Try taking in that information. To practise Participate, try your own next turn now: offer a quiet song choice, a way to take turns or another shared action that fits. You can keep your own preference, allow a suitable change or pause.",
        "Notice what you actually tried. You may revise it once if useful or finish. You do not have to repeat until you feel confident. Real use is a separate choice in a suitable setting, not something this page has arranged."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I actually tried or left untried",
          "optional": true
        },
        {
          "key": "rehearsal-learning",
          "label": "What I noticed or would change",
          "optional": true
        }
      ],
      "help": {
        "title": "If the fictional reply does not fit my situation",
        "text": "Treat it only as one made-up reply. Do not assume someone will respond this way. You can use another ordinary example agreed with your therapist or stop."
      }
    },
    {
      "id": "mindfulness-of-others.practice.review",
      "title": "Review the actual practice or interaction",
      "paragraphs": [
        "Was this reading, rehearsal, a real exchange or no use? Which parts did you actually try? You can start here without earlier notes. Moving through the page is not proof of attention, understanding or contact.",
        "What did you observe? What did you say or do? Did new information change your view? Where did you describe rather than assume, and where did you join in or choose a limit? Keep guesses about the other person separate from known facts.",
        "What fitted your needs, and what was hard, unchanged or unwanted? Was your choice and the other person’s choice respected? No closeness, approval or drop in anxiety is required. Take any important concern to your therapist or suitable support."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What actually happened or did not happen",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What I observed, tried, changed or still do not know",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What fitted, what did not, or a question to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If I stopped or did not join in",
        "text": "There is no outcome to invent. You can review why that choice fitted, what made it difficult or what support might help. Stopping for a limit is not proof of failure."
      }
    },
    {
      "id": "mindfulness-of-others.practice.next",
      "title": "Keep a useful part or choose something else",
      "paragraphs": [
        "Decide whether to keep the same practice, change the setting or support, focus on a different part, pause or stop. You can discuss the choice with your therapist. Every new interaction still needs to be suitable and wanted.",
        "A future plan is not a record of doing it. No message, reminder or relationship score is created here. Keep selected notes only if useful, and let the practice end."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, change, pause or stop",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any support or future practice to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If another skill fits better",
        "text": "You can use the already-taught listening, GIVE, validation or boundary skills for their own purposes. This is not a test you must pass before choosing them."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 interpersonal Handouts 12–12a",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Handout12, printed p143/PDF index72: Observe, Describe and Participate in interactions. Handout12a is an optional recognition exercise.",
      "limits": "Historical Second Edition, not the 2025 Revised Edition. Original prose and rehearsal; no source checklist, paired quiz or examples reproduced."
    },
    {
      "id": "Linehan/Guilford: 2015 interpersonal teaching notes, section XII",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Printed pp276–280/PDF indices47–51: GIVE and What/How extension, updating views, descriptive rather than assumed motives, earned trust and participation with explicit protective limits.",
      "limits": "No promise of friendship or anxiety reduction. The manual’s performance-comparison teaching exercise and ratings are not imported. Accessibility and bounded practice are explicit adaptations."
    },
    {
      "id": "Linehan/Guilford: 2015 interpersonal Worksheet 9",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed p184: describe an actual situation and attempted mindfulness-of-others skills; source teaching values attempts rather than perfection.",
      "limits": "No copied checklist, score or required successful outcome. The candidate permits no use, neutral effects and unwanted effects."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Meaningful communication, choice/refusal and access to AAC and support across the lifespan.",
      "limits": "Rights guidance, not clinical validation or all-age suitability of this component."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from the individual purchaser licence.",
      "limits": "Source access does not grant publication rights. No rights approval requested or received."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Observe with present curiosity and openness to change",
      "sections": [
        "practice.attend",
        "practice.update",
        "practice.judgements"
      ],
      "source": "Handout12 Observe; Manual section XII B; relevant How skills retained"
    },
    {
      "operation": "Describe observations and own experience, check assumptions without blind trust",
      "sections": [
        "practice.describe",
        "practice.check",
        "practice.trust"
      ],
      "source": "Handout12 Describe; Manual section XII C, especially pp279–280 protective limits"
    },
    {
      "operation": "Participate flexibly in the current exchange",
      "sections": [
        "practice.participate",
        "practice.rehearse"
      ],
      "source": "Handout12 Participate; Manual section XII D; no duty to ongoing relationship or unsafe conformity"
    },
    {
      "operation": "Choose fit and review attempts honestly",
      "sections": [
        "practice.situation",
        "practice.review",
        "practice.next"
      ],
      "source": "Worksheet9 and product safeguards; no required outcome or checklist score"
    }
  ],
  "narrationSegments": [
    {
      "id": "mindfulness-of-others.intro",
      "title": "Be present with another person",
      "text": "Mindfulness of others means paying attention to the person and the exchange you are in. You notice what happens, use clear words for what you know, and take part rather than only watching or planning your next move.\n\nYou can stay open to learning something new about a person without agreeing with everything or ignoring harm. The practice builds on GIVE and the mindfulness skills Observe, Describe and Participate. It is more than finding the right words to say.\n\nUse this after teaching with your therapist, in a suitable ordinary setting or a private rehearsal. You can read the example, practise one part, review an interaction or finish without making contact.",
      "sha256": "9d375d35c03f119669745413f8c3f635ce15ce1963fbd8326f74cba21479dfe3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.fit",
      "title": "Choose a setting where you have room to choose",
      "text": "With your therapist, choose a manageable exchange where participation is welcome. Check power, culture, privacy, access and needed support. If there are threats, pressure, control or fear of punishment, begin with suitable support rather than trying to be more open to that person.\n\nBeing mindful does not mean staying in an unsafe exchange, trusting someone who has shown harm, giving up a limit or making contact after a refusal. The tool cannot judge safety or tell you whether a person is trustworthy.\n\nKeep communication aids, needed movement, quiet space and support. Eye contact, a still body, fluent speech or a particular facial expression are not required. Reading, signing, communication devices and pictures count too. You do not need to hide a disability or distress.\n\nIf attention to others becomes upsetting, exhausting or a search for hidden danger or approval, pause and discuss what fits. This page is not treatment for every social fear, a test of closeness or urgent support. You may stop without asking permission.",
      "sha256": "6c077961749b68ebc91ec553034e573fe22a5a240b2f7164f66328495020a2b1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.privacy",
      "title": "Keep only the details you want",
      "text": "Writing is optional. You may think privately, use your own paper or practise with your therapist. A general label is enough; names, private messages and personal history are not needed. This page records no voice and sends nothing to anyone.\n\nNotes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. Choose notes, check the preview, then copy or download only if you want a separate copy. That copy stays wherever you save it.\n\nHiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return while this page stays open; it does not keep answers or add a saved item to your usual Toolbox.",
      "sha256": "ff6045070bf11d4a00cd7a4e0e928017b21babd53e34efe8a65f532d85062ffd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.close",
      "title": "Let this practice end",
      "text": "You can finish after reading, rehearsing, trying a part, reviewing or choosing not to continue. You do not need to feel closer, less anxious or sure about another person.\n\nKeep selected notes only if useful. You can bring a question to your therapist or return to an ordinary activity. This page has not contacted anyone, saved a relationship record or set a reminder. Leaving clears the notes here.",
      "sha256": "e2fcb6265c4685380a873029042269c9a2feacc299d304891f0b3f35cef7d507",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.example",
      "title": "Example: Mina and Dev choose some music",
      "text": "Mina and Dev are choosing music together for a small gathering. Dev liked lively music last month. Today Dev says, \"Could we start with something quiet?\" Mina thinks, \"Dev is impossible to please,\" then notices that this is a label, not something Dev said.\n\nMina puts an unrelated shopping list aside but keeps a device used to read the song choices. Mina returns attention from \"Am I choosing badly?\" to Dev’s request. Mina notices the changed preference without deciding Dev is rejecting them.\n\nMina says, \"You liked the lively songs last time. Today you asked for a quiet start. What would fit?\" Dev replies, \"I still like those songs. I want people to be able to talk first.\" Mina updates their view: the request concerns the start of this gathering, not a permanent dislike of lively music.\n\nMina had hoped to start with a favourite lively song. They say that plainly, then choose to let Dev pick the first quiet song and suggest their favourite for later. Dev picks a song, and Mina adds another that fits the shared plan. Mina takes part instead of monitoring every choice or needing to win the point.\n\nThis was a small choice Mina wanted to share, not proof that Dev can be trusted with everything or a promise to agree next time. No private disclosure or ongoing commitment was required. Both could still change their minds or set a limit.\n\nAfterward, Mina records what actually happened: one judgement noticed, a question asked, new information taken in and two song choices made. Some awkwardness remained. Mina cannot know from this whether Dev felt closer, and does not use the outcome to rate the friendship.",
      "sha256": "43feddf1538c94cbfaf44b8e956a0f244a2c8a1cd9616b26ff4fa369da26613e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.learn",
      "title": "Observe, describe and participate",
      "text": "Observe means noticing the person’s actual words and actions with interest. Describe means saying what you observed, and keeping your own thoughts and feelings separate from guesses about theirs. Participate means joining in the current exchange, not watching yourself perform every moment.\n\nThe mindfulness How skills apply too: keep attention with the present exchange, leave out unhelpful labels, and choose what serves the situation and your values. You can move between the What skills as needed. You do not have to do all three at once or run a checklist while someone talks.\n\nGiving the benefit of the doubt means really allowing that your first explanation may be wrong. It does not mean deciding everyone has good intent. Trust can grow through what people actually do, and evidence of harm still matters. A clear limit or a pause can be a mindful response.\n\nThis is an extension of GIVE, not a replacement for it. Listening and checking understanding, validation and friendship-building are related skills with their own purposes. Joining one conversation does not commit you to a lasting relationship.",
      "sha256": "1b97a878022dd4b35542a4e917f839567017f6cc34ba83cc316a0a4c84423f48",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.situation",
      "title": "Choose a suitable exchange",
      "text": "Choose an ordinary conversation or shared activity that you want to take part in, or use Mina and Dev’s example. Name the setting and what you hope to practise, such as attention, clearer description or joining in.\n\nCheck whether the other person is willing and what support or limits matter. You can practise privately without involving them. These groups explain the parts; a real interaction does not need to follow them in order.",
      "sha256": "1f35f2e4b370586e0c928d8844c2ef1369493fb34395b030474f1a6f264e6555",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.situation.help",
      "title": "If no suitable person or setting comes to mind",
      "text": "Use the fictional exchange or talk through a choice with your therapist. You do not need to make a new contact to finish this practice.",
      "sha256": "ee5295803a9a2e1e3eba5451218b058e08f0c47f1e3389ec72750a2de4496b3e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.attend",
      "title": "Observe: give the exchange your attention",
      "text": "If you choose to practise, notice what the person is saying, signing, writing or doing now. Be curious about their meaning. Put aside an unrelated task if you can, while keeping aids, movement and support that help you take part.\n\nIf you notice yourself rehearsing a reply or checking how you appear, gently return to the current message. You can still notice your own needs, surroundings and safety. This is not a demand to stop every thought or give attention you do not have.",
      "sha256": "32d144e5a7f9f85981f2d4514cafd437f8d6130607126318124dec60c20725ed",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.attend.help",
      "title": "If a pause or more time would help",
      "text": "Ask for time or for the message in a form you can use. Using a communication aid, reading a cue or taking a needed break is not the same as ignoring the person.",
      "sha256": "47b2189ef4e34501a3a4fdbd943e4828bf9579f7f3dec44d4bb715e3855be0de",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.update",
      "title": "Stay open to new information",
      "text": "What is the person telling or showing you now? Let it add to what you knew before. A preference or view can change. Check the new information rather than deciding the person must still want what they wanted last time.\n\nYou do not need to erase earlier events or accept every claim. Hold both what is new and what remains known. If they correct a misunderstanding, try updating your view without treating the correction as a contest.",
      "sha256": "d9977021d85477876072fcd23a14dac40db7f0f149c407cf5ba77f43af9101da",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.update.help",
      "title": "If the new account does not fit earlier facts",
      "text": "Name the mismatch as a question, not proof of deceit or proof that earlier harm did not happen. Important concerns may need support outside this exercise.",
      "sha256": "2bbfcfcb9401ff56cb44da895235145c1ac2416aa63b24aec686d551190b2551",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.judgements",
      "title": "Notice labels and the need to be right",
      "text": "Notice any broad label, such as \"They are impossible,\" or a push to prove your view is the only right one. A thought can be present without guiding your next reply. Return to the event you are trying to understand.\n\nTry leaving out an insult or ranking of the person. You can still name an action as harmful, disagree, keep a value or correct an important fact. Letting go of a contest does not mean saying you agree when you do not.",
      "sha256": "90a14635eebdc332a31d84cc07ff1b32e75b23306f8c387653be5922e9b986d1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.judgements.help",
      "title": "If I judge myself for having a judgement",
      "text": "Notice that too, without turning it into another task to get right. You can continue, change the wording or stop. A perfect mind is not required.",
      "sha256": "de10ae0f96b21895f93700bec002feb3d5e792c1da777641e89058f63082ca8c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.describe",
      "title": "Describe what you know",
      "text": "Put the relevant words or actions into a brief description. Keep a fact such as \"They asked for a quiet song\" separate from \"They dislike my choices.\" Name your own reaction as yours, if useful.\n\nMina could say, \"You asked for a quiet start. I had hoped to play this lively song first.\" That states a request and a personal wish without claiming to know Dev’s motive. Try a description for your own example.",
      "sha256": "dbb8043c6029a219ad01578444d78700e818f754391bda1f38bbc51b16c9c56d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.describe.help",
      "title": "If I can only remember a general impression",
      "text": "Keep it as an impression. You do not have to invent exact words or collect evidence about the person. Leave the detail unknown if that is all you know.",
      "sha256": "f0598bf0c8e4c7f8558a6fb0d6bfb7b2f0b4e2cdf2206a5b364cef4300c5b64d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.check",
      "title": "Check meaning without assuming a motive",
      "text": "If clarification would help and is welcome, ask a plain question or check a brief summary. Leave room for an answer you did not expect. For Mina, \"What would fit for the start?\" is more useful than \"Why are you trying to spoil my choice?\"\n\nNotice the answer and adjust if it changes your understanding. Words and nonverbal cues can be useful clues, but no expression or gesture proves what someone thinks. A lack of reply remains a lack of reply, not a hidden answer.\n\nAn effect on you does not by itself prove that effect was intended. Where it fits, genuinely consider another possible reason. You can remain unsure and still respond to harm or keep a boundary; you do not need to prove a motive first.",
      "sha256": "b1e6d96a6e226d9e7465a25dfb818ba939542557b00980878556d155e338c0e2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.check.help",
      "title": "If checking becomes repeated reassurance-seeking",
      "text": "Pause instead of asking until you feel certain. Discuss the pattern with your therapist. The other person can decline to explain, and this page cannot decide what they meant.",
      "sha256": "2fceb0559705dda7595b38fa5eaa6c9b03bec22c15cc95e316139fb78819ad5d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.trust",
      "title": "Let trust depend on actions and limits",
      "text": "Being open does not require trusting everything. If it fits, you may choose a small, low-stakes way to share an activity and see whether the person follows through. In the example, Mina freely lets Dev choose a first song. No private information or important possession is at stake.\n\nNotice what actually happens, not just how long you have known them or what you hope. Trust in one area does not prove trust in all areas. You can decline the opportunity, keep the current limit or change your view when what happened gives you reason to.\n\nDo not dismiss warning signs, harmful patterns or your need for support in order to give someone a chance. You do not owe another test to someone who has harmed you. You do not need to set up a test of trust. This page cannot assess safety.",
      "sha256": "debfba694fa9833060b16067c2e01859ddfe7310c067276f590ec33ca56aea2c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.trust.help",
      "title": "If a small choice does not feel small for me",
      "text": "Do not use it just because it appears in an example. Keep the boundary and choose another part of the skill with support.",
      "sha256": "ff3973de788ef1af683a397db45b3126a69627deadf61883274a755420582b5e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.participate",
      "title": "Participate without controlling every turn",
      "text": "When joining is suitable and wanted, take part in what is happening now. Offer a relevant thought, answer, question or action in the shared activity. Let yourself be involved rather than only watching for a mistake.\n\nAllow room for the other person’s contribution and for an ordinary change of direction. Try responding to their actual turn instead of forcing the exchange back to a fixed script. You may disagree, ask for structure or keep a clear limit.\n\nBeing involved does not mean losing yourself, pleasing everyone or joining every activity. Keep consent, values, care duties and safety. One conversation does not commit you to an ongoing relationship. You can pause or leave.",
      "sha256": "88d00a8e340cc7c6e50624ea1ea14906559d0d3b2b4702a06713d5f7893b2160",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.participate.help",
      "title": "If taking part needs structure",
      "text": "A clear turn, written choices or an agreed activity can help. Flexibility does not require guessing social rules, dropping support or hiding how you communicate.",
      "sha256": "cfddd4db3fbe2c699941836eadc0690bbaa15a4aabec27a4df8396403f3eaeef",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.rehearse",
      "title": "Try a short exchange privately",
      "text": "Choose a part to rehearse in your usual way of communicating, alone or with your therapist. Use your situation or this fictional line: \"I want something quiet at the start.\" Notice the words, describe what you know and try a useful question or reply.\n\nThen consider this possible clarification: \"I still like lively music. I want people to talk first.\" Try taking in that information. To practise Participate, try your own next turn now: offer a quiet song choice, a way to take turns or another shared action that fits. You can keep your own preference, allow a suitable change or pause.\n\nNotice what you actually tried. You may revise it once if useful or finish. You do not have to repeat until you feel confident. Real use is a separate choice in a suitable setting, not something this page has arranged.",
      "sha256": "75d335051cf40ef0b7ff8fff9f4b571645e0df7c6c8341e7954827be0ac40963",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.rehearse.help",
      "title": "If the fictional reply does not fit my situation",
      "text": "Treat it only as one made-up reply. Do not assume someone will respond this way. You can use another ordinary example agreed with your therapist or stop.",
      "sha256": "20461efbd45f22585403c59522cef134735f5a0510bfcf7ff66a6b58ce414b02",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.review",
      "title": "Review the actual practice or interaction",
      "text": "Was this reading, rehearsal, a real exchange or no use? Which parts did you actually try? You can start here without earlier notes. Moving through the page is not proof of attention, understanding or contact.\n\nWhat did you observe? What did you say or do? Did new information change your view? Where did you describe rather than assume, and where did you join in or choose a limit? Keep guesses about the other person separate from known facts.\n\nWhat fitted your needs, and what was hard, unchanged or unwanted? Was your choice and the other person’s choice respected? No closeness, approval or drop in anxiety is required. Take any important concern to your therapist or suitable support.",
      "sha256": "8f86d5fe069babbf98e5e5d827791bf5e82b96f3c6019a3077816f4aa1692187",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.review.help",
      "title": "If I stopped or did not join in",
      "text": "There is no outcome to invent. You can review why that choice fitted, what made it difficult or what support might help. Stopping for a limit is not proof of failure.",
      "sha256": "a452569fd07a5c24318aa36f9ae187a5edadf8a770f11ae406b353d74e7896b6",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "mindfulness-of-others.practice.next",
      "title": "Keep a useful part or choose something else",
      "text": "Decide whether to keep the same practice, change the setting or support, focus on a different part, pause or stop. You can discuss the choice with your therapist. Every new interaction still needs to be suitable and wanted.\n\nA future plan is not a record of doing it. No message, reminder or relationship score is created here. Keep selected notes only if useful, and let the practice end.",
      "sha256": "699eee7f7a6ffba7c9df4584b0c49f7b85b9118e2d78e6d6306cf5bcb5dede46",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "mindfulness-of-others.practice.next.help",
      "title": "If another skill fits better",
      "text": "You can use the already-taught listening, GIVE, validation or boundary skills for their own purposes. This is not a test you must pass before choosing them.",
      "sha256": "8dd68b54383b8b4b8f07053175e366563ee56c0d3b9586be5c1b6458110e13f2",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
