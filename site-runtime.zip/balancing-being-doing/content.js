window.BalancingBeingDoingContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/mindful",
  "componentId": "component/mindful/balancing-being-mind-with-doing-mind",
  "resourceId": "tool/balancing-being-doing",
  "routeProposal": "/balancing-being-doing/",
  "title": "Balancing Being Mind with Doing Mind",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "A therapist-introduced everyday skillful-means practice: act on what matters while experiencing the present and loosening a rigid demand for the result.",
  "groupedSetStatus": "Existing uncounted component under classic/mindful. Complete bounded everyday adaptation, not every optional Handout 9a exercise, the Three-minute Wise Mind breath/body procedure, a calendar programme or the whole mindfulness set. Candidate route only; no new canonical count.",
  "clinicalContract": {
    "learningObjective": "Distinguish useful goal-directed doing and curious present-experiencing being; recognize context-specific costs of imbalance without moralizing rest, disability or productivity; integrate awareness with purposeful action rather than merely alternate work and breaks.",
    "practiceObjective": "Choose one manageable ordinary activity, identify relevant goals and present experience, notice a goal-related thought as a mental event without discarding evidence, choose the missing contribution, actually engage in a small action with present awareness and flexible outcome expectations, then review what occurred and what still matters.",
    "sourcePopulationContext": "2015 author/publisher DBT optional teaching establishes the component, not efficacy of this digital adaptation or latest-edition equivalence. Source teaching assumes prior mindfulness learning. No age floor. Therapist checks clinical, developmental, cultural, communication, safeguarding and access fit.",
    "exclusions": [
      "No universal work/rest ratio, productivity target, compliance score, diagnostic classification or all-age suitability claim",
      "No forced body/breath focus, altered breathing, closed eyes, loss-of-awareness exercise, trauma recall or exposure",
      "No treating rest, fatigue, disability, care needs or limited resources as laziness or an excess of being mind",
      "No instruction to abandon real goals, safety checks, care plans, deadlines, rights or other people’s consent",
      "No claim that thoughts are false, inner certainty is truth, calm proves wise mind or an outcome is guaranteed",
      "No complete MBCT/MBSR protocol, Three-minute Wise Mind recreation, pleasant/unpleasant events calendar or full middle-path curriculum"
    ],
    "adaptations": [
      "Original plain-language explanation, fictional examples and optional notes, not reproduced source worksheet or example",
      "Both directions retained: bring awareness into driven action, or bring fitting purposeful action into present experience; synthesis can happen within one activity",
      "Use a chosen ordinary activity and accessible attention; no prescription of sensory/motor task, posture, breath anchor, timing or repeated meditation",
      "Omit separate optional Three-minute Wise Mind sequence and calendar schedule, rather than silently claiming an external-focus variant is identical",
      "Review actual doing and awareness, context, costs and uncertainties without symptom-reduction ratings or mandatory daily logging"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of complete bounded everyday component scope and source-use rights",
      "Individual prior learning, clinical, developmental, cultural, communication, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not a validated reading level",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration generation and listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose practice or review",
      "options": [
        {
          "value": "prepare",
          "label": "Try an everyday practice",
          "startSectionId": "balancing-being-doing.practice.situation"
        },
        {
          "value": "review",
          "label": "Review an everyday practice",
          "startSectionId": "balancing-being-doing.practice.review"
        }
      ]
    },
    "entryGate": "Scope and safety visible before selection. No activity or clinical fit approved by this page.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence or writing.",
    "reviewAccess": "Direct blank review without a stored plan, inferred practice or result. Both modes expose all groups.",
    "writing": "Optional and hidden initially. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording upload or autoplay.",
    "timer": "None. No required duration, work/rest ratio, exposure ladder or repetition count.",
    "completion": "No inferred mindfulness, wise mind, balanced state, practice, task completion, safety or improvement."
  },
  "intro": {
    "id": "balancing-being-doing.intro",
    "title": "Be here while doing what matters",
    "paragraphs": [
      "Doing mind helps you plan, solve problems and work toward a goal. Being mind is curious about this moment without trying to make it reach a target. Both can help. These are ways the mind can work, not types of people.",
      "This DBT practice brings them together: take a useful action while noticing the experience, without demanding that the result must go one way. You can care about a goal and still leave room for what actually happens.",
      "Use this everyday practice after learning mindfulness with your therapist. It is not a work-and-rest schedule or the separate three-minute breath exercise. You can use the example, review a past attempt or stop."
    ]
  },
  "fit": {
    "id": "balancing-being-doing.fit",
    "title": "Choose a manageable and supported practice",
    "paragraphs": [
      "Choose a familiar, low-risk activity with your therapist. Check health, energy, access, care needs and real responsibilities. Rest or asking for help may be what is needed. This is not a reason to increase tasks, push through pain or ignore a care plan.",
      "Do not practise while driving, using tools that could hurt you, supervising a situation that needs full attention, or handling an urgent problem. Keep needed alerts and support. Use a different time or activity if attention needs to stay on safety.",
      "No closed eyes, special breathing or body focus is required. If you feel less connected to your surroundings, more distressed or caught in checking whether you are mindful enough, stop and discuss the practice with your therapist. Use your agreed support if needed.",
      "You can think, speak, sign or use a communication aid. You do not have to produce a calm feeling or a clear inner answer. This page does not provide urgent help or decide what is safe."
    ]
  },
  "privacy": {
    "id": "balancing-being-doing.privacy",
    "title": "Writing and sharing are your choice",
    "paragraphs": [
      "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.",
      "Notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep notes, choose only the parts you want, check the preview, then copy or download. Those copies remain wherever you save them.",
      "Hiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return while the page stays open. It does not keep your answers or add a saved item to your usual Toolbox."
    ]
  },
  "close": {
    "id": "balancing-being-doing.close",
    "title": "Finish without making this another target",
    "paragraphs": [
      "You can finish after reading, trying, reviewing or deciding not to practise. You do not need a balanced feeling, a finished task or proof that you did it right.",
      "If useful, keep selected notes or bring a question to your therapist. No reminder, report or next task is created. Leaving clears the notes here."
    ]
  },
  "example": {
    "id": "balancing-being-doing.example",
    "title": "Made-up examples: a card and an envelope",
    "paragraphs": [
      "Ren wants to make a card for a friend. The aim is to express care, but Ren keeps planning how every letter should look. The thought is, \"It has to look perfect to count.\" Ren notices that this is a demand in the mind, not a fact about the friend.",
      "With the practice learned in therapy, Ren keeps the aim and adds attention to the present activity. Ren writes a short greeting, notices the pen moving and the paper under it, and lets an uneven letter remain. A worry about the result returns. Ren notices it and goes back to writing rather than checking every letter.",
      "Ren stops at the chosen point. The card has a greeting, and Ren still feels unsure. It has not been sent, and the friend’s reaction is unknown. In review, Ren notes both a real action and a return to the experience. No calm or perfect card is claimed.",
      "In another made-up scene, Ren enjoys looking at paper colours while a finished card still needs an envelope before a planned trip. Ren is aware of the colours but has lost track of that small task. This is not a needed rest break or an energy problem.",
      "Ren adds a clear action without dropping awareness: chooses a fitting envelope, notices its edge while placing the card inside, and checks that it closes. The colours are still there to notice. Ren has prepared the card, not posted it. This shows adding doing to being, rather than treating the two as separate blocks of time."
    ]
  },
  "learn": {
    "id": "balancing-being-doing.learn",
    "title": "Both modes have something to offer",
    "paragraphs": [
      "Doing mind compares what is happening with what you want to happen. It helps with planning and useful changes. When it takes over, you may miss the present or treat each thought as a fact or an order you must follow.",
      "Being mind notices what this moment is like with interest. A thought can be noticed as something happening in the mind. That does not make all thoughts false or mean ignoring facts. Being is not blankness, sleep or feeling cut off from the world.",
      "You may need more present awareness during a task, or more purposeful action while absorbed in experience. A useful mix can happen at the same time: do what fits and notice how the moment is unfolding. Balance does not mean equal minutes or constant checking.",
      "Letting go of a rigid demand for success is not giving up your goals. You can plan carefully, keep safety checks and work toward what matters while accepting that some outcomes are not in your control. This is one form of Wise Mind practice, not a way to discover a guaranteed right answer."
    ]
  },
  "practice": [
    {
      "id": "balancing-being-doing.practice.situation",
      "title": "Choose one ordinary moment",
      "paragraphs": [
        "Choose a manageable activity already available, or explore Ren’s example without making a personal plan. It might be part of a quiet hobby or another familiar task that fits you. The example is not an instruction to use pens or paper.",
        "What is the situation, and why might this practice fit? Include any real limit or support need. If you are reviewing a past moment, use what you remember and leave gaps unknown."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The ordinary activity or example I am considering",
          "optional": true
        },
        {
          "key": "fit-and-support",
          "label": "Why it fits, and any limits or support",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing seems suitable now",
        "text": "You can read the example or leave the choice for therapy. Do not turn a risky or overwhelming situation into practice just because it is available."
      }
    },
    {
      "id": "balancing-being-doing.practice.doing",
      "title": "Notice what doing mind brings",
      "paragraphs": [
        "What are you trying to achieve, plan, solve or finish? Name a real purpose, not only a demand to be productive. It could be care, learning, a practical need or something else that matters to you.",
        "How is goal-focused thinking useful here? Is it also crowding out what you notice, or making the result feel like a test of your worth? You can value the goal without accepting that extra pressure."
      ],
      "fields": [
        {
          "key": "doing-purpose",
          "label": "The goal or useful purpose of doing",
          "optional": true
        },
        {
          "key": "doing-cost",
          "label": "What it helps with and any pressure or missed experience",
          "optional": true
        }
      ],
      "help": {
        "title": "If I think I should always be doing more",
        "text": "Check the actual need and your limits. Rest, help or reducing a demand may be useful choices. Your worth is not a measure of output."
      }
    },
    {
      "id": "balancing-being-doing.practice.being",
      "title": "Notice what being mind brings",
      "paragraphs": [
        "What is happening in the moment that you can notice with curiosity? Choose an accessible part of the activity, such as a sound, a shape, a movement or the way something changes. You do not have to use every sense or focus inside your body.",
        "Can you let this experience be here without trying to make it pleasant or useful? Also notice if something important needs action. Enjoying a moment is not wrong, and neither is responding to a real need."
      ],
      "fields": [
        {
          "key": "being-experience",
          "label": "A present detail or experience I can notice",
          "optional": true
        },
        {
          "key": "being-and-needs",
          "label": "What being offers and anything else needing attention",
          "optional": true
        }
      ],
      "help": {
        "title": "If rest is what I need",
        "text": "Rest is not proof of too much being mind. Keep health, energy and support in view. This exercise does not decide that you should work instead."
      }
    },
    {
      "id": "balancing-being-doing.practice.thoughts",
      "title": "Hold a thought without treating it as an order",
      "paragraphs": [
        "If a thought about the goal is present, notice it as a thought. For example, a demand that everything be perfect is something the mind is saying, not a command you must obey. No thought needs to be created for this step.",
        "Keep relevant facts alongside it. A real deadline or safety instruction still matters. What part is known, what is a prediction, and what is a rigid demand? You do not need to debate the thought until it goes away."
      ],
      "fields": [
        {
          "key": "goal-thought",
          "label": "A thought or demand, if one is present",
          "optional": true
        },
        {
          "key": "facts-and-demand",
          "label": "Relevant facts and what I can hold more lightly",
          "optional": true
        }
      ],
      "help": {
        "title": "If the thought returns",
        "text": "You can notice it again and return to the activity. Repeating a phrase until the thought disappears is not the aim. If this becomes another checking loop, pause."
      }
    },
    {
      "id": "balancing-being-doing.practice.needs",
      "title": "Check what this moment calls for",
      "paragraphs": [
        "What would fit the actual situation now? You may need to act, rest, ask for help, make a plan, protect a limit or finish. Consider your needs and any real responsibility to others, not only the strongest urge.",
        "Can you make room for present experience while doing that? Or, if you are absorbed in experience, is there a small needed action to add? The page does not choose for you. Uncertainty can be a reason to check with your therapist."
      ],
      "fields": [
        {
          "key": "current-need",
          "label": "What may be needed in this moment",
          "optional": true
        },
        {
          "key": "missing-part",
          "label": "More awareness, a purposeful action, support or still unclear",
          "optional": true
        }
      ],
      "help": {
        "title": "If someone else says I must do it",
        "text": "A demand is not automatically a valid duty. Keep consent, safety, power and your limits in view. Willing action is not obedience to an unsafe or unfair request."
      }
    },
    {
      "id": "balancing-being-doing.practice.choose",
      "title": "Choose one way to bring the two together",
      "paragraphs": [
        "Name a small, fitting action and one part of it to notice as it happens. If you are driven to finish, keep the purpose and soften the demand for a perfect result. If you are missing a real task while enjoying the moment, bring that task into your awareness and choose a first action.",
        "Choose an ordinary point to stop or check what is needed next. There is no set length or number of repetitions. Keep useful checks and access aids; do not remove them to make the task harder."
      ],
      "fields": [
        {
          "key": "chosen-action",
          "label": "The fitting action I choose, or why I am not choosing one",
          "optional": true
        },
        {
          "key": "awareness-and-end",
          "label": "What I can notice while acting, and a suitable ending",
          "optional": true
        }
      ],
      "help": {
        "title": "If it sounds like work now and rest later",
        "text": "Breaks can help, but this practice asks a different question: can awareness and purposeful action be present in the same moment? You need not earn a rest by finishing work."
      }
    },
    {
      "id": "balancing-being-doing.practice.try",
      "title": "Actually try the small action with awareness",
      "paragraphs": [
        "If it fits now, set this page aside and begin the action you chose. While doing it, let yourself notice the accessible part you selected. Be curious about what is here rather than measuring whether you are doing mindfulness well.",
        "Keep the useful purpose, but see if the result can remain uncertain. If attention goes into planning or judging, notice that and return to the activity when it fits. No distraction, special feeling or perfect focus is required.",
        "If you are only planning or exploring fiction, that is not a real attempt. You can instead rehearse how you would begin, or leave the practice for a supported time. Do not act beyond your limits to fill this step."
      ],
      "fields": [
        {
          "key": "actual-try",
          "label": "What I actually tried, rehearsed or did not try",
          "optional": true
        },
        {
          "key": "noticed-during",
          "label": "What I noticed while acting, if anything",
          "optional": true
        }
      ],
      "help": {
        "title": "If I keep watching myself rather than taking part",
        "text": "Let the activity have your attention, rather than checking yourself at every instant. You can review later. If this keeps increasing strain, stop and discuss it."
      }
    },
    {
      "id": "balancing-being-doing.practice.respond",
      "title": "Respond when the moment changes",
      "paragraphs": [
        "If the task or your needs changed, notice that too. You can return attention, adjust the task, take a needed break, get help or stop. Awareness includes noticing that the old plan no longer fits.",
        "For a goal-related worry, let it be a thought while keeping track of real information. For a real problem, respond to the problem. This is not a rule to keep bringing attention back when something needs care or action."
      ],
      "fields": [
        {
          "key": "change-noticed",
          "label": "Any change, distraction, worry or need I noticed",
          "optional": true
        },
        {
          "key": "response",
          "label": "What I actually did in response, or might discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If discomfort did not fade",
        "text": "That does not settle whether the practice fitted. Look at access, choice, awareness and the action. You can stop without waiting for the discomfort to change."
      }
    },
    {
      "id": "balancing-being-doing.practice.close",
      "title": "End the attempt and notice the wider situation",
      "paragraphs": [
        "At a suitable point, stop this attempt or return to your ordinary activity. Notice the setting and any next responsibility. No body scan, deep breath or special closing feeling is needed.",
        "What is done, what remains, and what is outside your control? An unfinished task can stay unfinished. Choose whether anything now needs attention, including rest or help, without turning this into another demand to achieve."
      ],
      "fields": [
        {
          "key": "ending",
          "label": "Where I stopped or returned to ordinary activity",
          "optional": true
        },
        {
          "key": "remaining",
          "label": "What is done, remains or needs support",
          "optional": true
        }
      ],
      "help": {
        "title": "If I did not finish the task",
        "text": "This practice does not require task completion. A useful stopping point, an access limit or a changed need may matter more than finishing."
      }
    },
    {
      "id": "balancing-being-doing.practice.review",
      "title": "Review the action and the awareness separately",
      "paragraphs": [
        "What did you actually do: read, plan, rehearse, try the activity, stop or not practise? You can review without earlier notes. If there was no suitable opportunity, keep that separate from choosing not to try.",
        "If you tried, what happened to the purpose, your attention and the demand for a certain result? Was there a moment of acting with awareness? Include not noticing, difficulty, discomfort or an unchanged result. Do not fill gaps with what you hoped happened.",
        "What fitted this context, and what did not? A calmer feeling, a finished task or praise from someone else is not proof of balance. Bring uncertainty or unwanted effects to your therapist rather than scoring yourself."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What I actually did or did not do",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What I noticed about action, awareness and outcome pressure",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What fitted, did not fit or needs discussion",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot tell whether it worked",
        "text": "You can leave that open. One account cannot prove a balanced state or a cause. A concrete observation or question is enough for review."
      }
    },
    {
      "id": "balancing-being-doing.practice.next",
      "title": "Keep, change or leave the practice",
      "paragraphs": [
        "With your therapist, decide whether a similar practice fits again, needs a different activity or support, or should be left for now. There is no daily quota or missed-practice debt.",
        "If useful, choose a natural cue, such as the start of a suitable activity. A cue here does not set an alarm or reminder. A future plan is not a record of doing it; you can finish without one."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, change, pause or leave",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any support or suitable opportunity to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If this becomes another performance target",
        "text": "Pause and bring that pattern to your therapist. You do not have to master balance before you are allowed to stop, rest or get help."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Handouts 9 and 9a",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed pp. 71–73: doing/being synthesis and optional ways to bring it into ordinary activity.",
      "limits": "Historical Second Edition. This original bounded practice is not every optional exercise or the Three-minute Wise Mind breath/body sequence; source forms, examples and diagrams are not reproduced."
    },
    {
      "id": "Linehan/Guilford: 2015 mindfulness teaching notes, section XV",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Printed pp. 222–225: retain meaningful action while loosening attachment to achievement; both directions matter; prior mindfulness teaching and non-symptom-based review.",
      "limits": "Source teaching does not validate this app. Accessible choices, non-shaming language and individual safety/support are explicit adaptations. No claim of exact 2025 Revised fidelity."
    },
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Worksheets 7 and 7a",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed pp. 98–100: review actual everyday practice and experience during and after it.",
      "limits": "Original optional single-episode review, not copied forms, rating anchors, daily calendar or persistent log. Separate pleasant/unpleasant event exercises remain outside this candidate."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal, meaningful communication and access to needed support.",
      "limits": "Rights guidance, not clinical validation of this component."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from the individual purchaser licence.",
      "limits": "Accessible sources do not grant publication rights. No release-rights approval requested or received."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Context and useful contributions of both modes",
      "sections": [
        "practice.situation",
        "practice.doing",
        "practice.being"
      ],
      "source": "Handout 9; Manual section XV B–E; original individual-fit framing"
    },
    {
      "operation": "Mental events, real needs and chosen synthesis",
      "sections": [
        "practice.thoughts",
        "practice.needs",
        "practice.choose"
      ],
      "source": "Handout 9 and selected everyday ideas from 9a; no replacement of optional Three-minute Wise Mind"
    },
    {
      "operation": "Actual aware action, flexible adjustment and ending",
      "sections": [
        "practice.try",
        "practice.respond",
        "practice.close"
      ],
      "source": "Handout 9a everyday practice and willingness; original accessible action and safety limits"
    },
    {
      "operation": "Honest episode review and optional future use",
      "sections": [
        "practice.review",
        "practice.next"
      ],
      "source": "Worksheets 7/7a; Manual review not rated by calm; original no-log/no-quota adaptation"
    }
  ],
  "narrationSegments": [
    {
      "id": "balancing-being-doing.intro",
      "title": "Be here while doing what matters",
      "text": "Doing mind helps you plan, solve problems and work toward a goal. Being mind is curious about this moment without trying to make it reach a target. Both can help. These are ways the mind can work, not types of people.\n\nThis DBT practice brings them together: take a useful action while noticing the experience, without demanding that the result must go one way. You can care about a goal and still leave room for what actually happens.\n\nUse this everyday practice after learning mindfulness with your therapist. It is not a work-and-rest schedule or the separate three-minute breath exercise. You can use the example, review a past attempt or stop.",
      "sha256": "2469aaac23c0ca23e5c98107c19742ffc25766abbf483117c96a9ebe3b4dd461",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.fit",
      "title": "Choose a manageable and supported practice",
      "text": "Choose a familiar, low-risk activity with your therapist. Check health, energy, access, care needs and real responsibilities. Rest or asking for help may be what is needed. This is not a reason to increase tasks, push through pain or ignore a care plan.\n\nDo not practise while driving, using tools that could hurt you, supervising a situation that needs full attention, or handling an urgent problem. Keep needed alerts and support. Use a different time or activity if attention needs to stay on safety.\n\nNo closed eyes, special breathing or body focus is required. If you feel less connected to your surroundings, more distressed or caught in checking whether you are mindful enough, stop and discuss the practice with your therapist. Use your agreed support if needed.\n\nYou can think, speak, sign or use a communication aid. You do not have to produce a calm feeling or a clear inner answer. This page does not provide urgent help or decide what is safe.",
      "sha256": "933dee1ea9c8c69bb0bbe14d362cd2ad57e18dc0cd4b9abde0f251cf71ff057c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.privacy",
      "title": "Writing and sharing are your choice",
      "text": "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.\n\nNotes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep notes, choose only the parts you want, check the preview, then copy or download. Those copies remain wherever you save them.\n\nHiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return while the page stays open. It does not keep your answers or add a saved item to your usual Toolbox.",
      "sha256": "ea7c2a2aefc5a68a961d8b05ce5ee5d550e8018b0f20dfa1ab56b32821f5c885",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.close",
      "title": "Finish without making this another target",
      "text": "You can finish after reading, trying, reviewing or deciding not to practise. You do not need a balanced feeling, a finished task or proof that you did it right.\n\nIf useful, keep selected notes or bring a question to your therapist. No reminder, report or next task is created. Leaving clears the notes here.",
      "sha256": "8a936de1c871ddd5660d00a1beb3d42251bd9d15ebfa665d5dc5318095f0f0b5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.example",
      "title": "Made-up examples: a card and an envelope",
      "text": "Ren wants to make a card for a friend. The aim is to express care, but Ren keeps planning how every letter should look. The thought is, \"It has to look perfect to count.\" Ren notices that this is a demand in the mind, not a fact about the friend.\n\nWith the practice learned in therapy, Ren keeps the aim and adds attention to the present activity. Ren writes a short greeting, notices the pen moving and the paper under it, and lets an uneven letter remain. A worry about the result returns. Ren notices it and goes back to writing rather than checking every letter.\n\nRen stops at the chosen point. The card has a greeting, and Ren still feels unsure. It has not been sent, and the friend’s reaction is unknown. In review, Ren notes both a real action and a return to the experience. No calm or perfect card is claimed.\n\nIn another made-up scene, Ren enjoys looking at paper colours while a finished card still needs an envelope before a planned trip. Ren is aware of the colours but has lost track of that small task. This is not a needed rest break or an energy problem.\n\nRen adds a clear action without dropping awareness: chooses a fitting envelope, notices its edge while placing the card inside, and checks that it closes. The colours are still there to notice. Ren has prepared the card, not posted it. This shows adding doing to being, rather than treating the two as separate blocks of time.",
      "sha256": "b754b8f8519a1c85f4fd7fce710b08dc4a871af057969afd96b4234142c81f53",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.learn",
      "title": "Both modes have something to offer",
      "text": "Doing mind compares what is happening with what you want to happen. It helps with planning and useful changes. When it takes over, you may miss the present or treat each thought as a fact or an order you must follow.\n\nBeing mind notices what this moment is like with interest. A thought can be noticed as something happening in the mind. That does not make all thoughts false or mean ignoring facts. Being is not blankness, sleep or feeling cut off from the world.\n\nYou may need more present awareness during a task, or more purposeful action while absorbed in experience. A useful mix can happen at the same time: do what fits and notice how the moment is unfolding. Balance does not mean equal minutes or constant checking.\n\nLetting go of a rigid demand for success is not giving up your goals. You can plan carefully, keep safety checks and work toward what matters while accepting that some outcomes are not in your control. This is one form of Wise Mind practice, not a way to discover a guaranteed right answer.",
      "sha256": "8758b40c12cd322b8ef6be99daea055b9cabc4247562e569f5b0657738640225",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.situation",
      "title": "Choose one ordinary moment",
      "text": "Choose a manageable activity already available, or explore Ren’s example without making a personal plan. It might be part of a quiet hobby or another familiar task that fits you. The example is not an instruction to use pens or paper.\n\nWhat is the situation, and why might this practice fit? Include any real limit or support need. If you are reviewing a past moment, use what you remember and leave gaps unknown.",
      "sha256": "c41e2bc6643f41b4056c70bca373933baa9a63523663ff7b63149762b5410c16",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.situation.help",
      "title": "If nothing seems suitable now",
      "text": "You can read the example or leave the choice for therapy. Do not turn a risky or overwhelming situation into practice just because it is available.",
      "sha256": "a73e4e6bb18888ba1225e66321bb3e97e4fb2e412c01cb5957d5aea2327ab7df",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.doing",
      "title": "Notice what doing mind brings",
      "text": "What are you trying to achieve, plan, solve or finish? Name a real purpose, not only a demand to be productive. It could be care, learning, a practical need or something else that matters to you.\n\nHow is goal-focused thinking useful here? Is it also crowding out what you notice, or making the result feel like a test of your worth? You can value the goal without accepting that extra pressure.",
      "sha256": "4f826f1fc0fdac10bdce4fde50d2f0a5f0e097273928db87e068066a80a9bc76",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.doing.help",
      "title": "If I think I should always be doing more",
      "text": "Check the actual need and your limits. Rest, help or reducing a demand may be useful choices. Your worth is not a measure of output.",
      "sha256": "0db70e9281ed4dd5fe2c2c26f4b51bcf4cf7575b5d22bcb599a64c3b79c37f72",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.being",
      "title": "Notice what being mind brings",
      "text": "What is happening in the moment that you can notice with curiosity? Choose an accessible part of the activity, such as a sound, a shape, a movement or the way something changes. You do not have to use every sense or focus inside your body.\n\nCan you let this experience be here without trying to make it pleasant or useful? Also notice if something important needs action. Enjoying a moment is not wrong, and neither is responding to a real need.",
      "sha256": "8a36ccabb429aaf0428f40062c0bdaebf857aad2e3cf5a7c246c5f700536c1c6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.being.help",
      "title": "If rest is what I need",
      "text": "Rest is not proof of too much being mind. Keep health, energy and support in view. This exercise does not decide that you should work instead.",
      "sha256": "4060f8ad3b6a5238b6219c88fe89a7eadc5038f56a5c01eb017938a04f15f0d8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.thoughts",
      "title": "Hold a thought without treating it as an order",
      "text": "If a thought about the goal is present, notice it as a thought. For example, a demand that everything be perfect is something the mind is saying, not a command you must obey. No thought needs to be created for this step.\n\nKeep relevant facts alongside it. A real deadline or safety instruction still matters. What part is known, what is a prediction, and what is a rigid demand? You do not need to debate the thought until it goes away.",
      "sha256": "f9b2eb7a085e6754a26fc663ed3e65d62c58e49cf2f64647e909452fc7da993a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.thoughts.help",
      "title": "If the thought returns",
      "text": "You can notice it again and return to the activity. Repeating a phrase until the thought disappears is not the aim. If this becomes another checking loop, pause.",
      "sha256": "3829f97f0234c6d39765dede514c1ac936da1ec039834fef7cb5d1a38aa994bb",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.needs",
      "title": "Check what this moment calls for",
      "text": "What would fit the actual situation now? You may need to act, rest, ask for help, make a plan, protect a limit or finish. Consider your needs and any real responsibility to others, not only the strongest urge.\n\nCan you make room for present experience while doing that? Or, if you are absorbed in experience, is there a small needed action to add? The page does not choose for you. Uncertainty can be a reason to check with your therapist.",
      "sha256": "0fc5003d01d084cabbc9fed292435cf0927ec06611b5e5ea41abece0dffa9416",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.needs.help",
      "title": "If someone else says I must do it",
      "text": "A demand is not automatically a valid duty. Keep consent, safety, power and your limits in view. Willing action is not obedience to an unsafe or unfair request.",
      "sha256": "44d0bcf707c86ccd83ada683e6086c2835ae8e9e1f107d477ef51c89ebd613a3",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.choose",
      "title": "Choose one way to bring the two together",
      "text": "Name a small, fitting action and one part of it to notice as it happens. If you are driven to finish, keep the purpose and soften the demand for a perfect result. If you are missing a real task while enjoying the moment, bring that task into your awareness and choose a first action.\n\nChoose an ordinary point to stop or check what is needed next. There is no set length or number of repetitions. Keep useful checks and access aids; do not remove them to make the task harder.",
      "sha256": "d2a2bdec215ea0e3bd7cd5db75dd2cdd864412278118a4082f1d6431f76f452e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.choose.help",
      "title": "If it sounds like work now and rest later",
      "text": "Breaks can help, but this practice asks a different question: can awareness and purposeful action be present in the same moment? You need not earn a rest by finishing work.",
      "sha256": "f6fe5ed4ea97aa37ebca6d9fb9fc6f7746963eb2bdbe9476edb9ec5c66734c8b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.try",
      "title": "Actually try the small action with awareness",
      "text": "If it fits now, set this page aside and begin the action you chose. While doing it, let yourself notice the accessible part you selected. Be curious about what is here rather than measuring whether you are doing mindfulness well.\n\nKeep the useful purpose, but see if the result can remain uncertain. If attention goes into planning or judging, notice that and return to the activity when it fits. No distraction, special feeling or perfect focus is required.\n\nIf you are only planning or exploring fiction, that is not a real attempt. You can instead rehearse how you would begin, or leave the practice for a supported time. Do not act beyond your limits to fill this step.",
      "sha256": "15a9114c661bee2bae2addabb5d633faf9bc782da25848efa3e7be35ebb06901",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.try.help",
      "title": "If I keep watching myself rather than taking part",
      "text": "Let the activity have your attention, rather than checking yourself at every instant. You can review later. If this keeps increasing strain, stop and discuss it.",
      "sha256": "95836dbed64eeca55bbfc64608ec11bc536de1ff1ae3811592c8b7c57c8b1a17",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.respond",
      "title": "Respond when the moment changes",
      "text": "If the task or your needs changed, notice that too. You can return attention, adjust the task, take a needed break, get help or stop. Awareness includes noticing that the old plan no longer fits.\n\nFor a goal-related worry, let it be a thought while keeping track of real information. For a real problem, respond to the problem. This is not a rule to keep bringing attention back when something needs care or action.",
      "sha256": "b844b6fcddfac002617432f03e0a40da78e690948adc53d8d88b951b88c089d6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.respond.help",
      "title": "If discomfort did not fade",
      "text": "That does not settle whether the practice fitted. Look at access, choice, awareness and the action. You can stop without waiting for the discomfort to change.",
      "sha256": "863487aeb07b978f344f36e3e95f06f0170900a3f14692969cecc3a665bd90c9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.close",
      "title": "End the attempt and notice the wider situation",
      "text": "At a suitable point, stop this attempt or return to your ordinary activity. Notice the setting and any next responsibility. No body scan, deep breath or special closing feeling is needed.\n\nWhat is done, what remains, and what is outside your control? An unfinished task can stay unfinished. Choose whether anything now needs attention, including rest or help, without turning this into another demand to achieve.",
      "sha256": "1dbda0b37435d92800ec1f644f0aa36dd9d531f09f7484193e3a0e3d128b0744",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.close.help",
      "title": "If I did not finish the task",
      "text": "This practice does not require task completion. A useful stopping point, an access limit or a changed need may matter more than finishing.",
      "sha256": "01ec5de4d85c5a2ccea5b8b19ff93ee62912457090b622fcfdd3579854c095d2",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.review",
      "title": "Review the action and the awareness separately",
      "text": "What did you actually do: read, plan, rehearse, try the activity, stop or not practise? You can review without earlier notes. If there was no suitable opportunity, keep that separate from choosing not to try.\n\nIf you tried, what happened to the purpose, your attention and the demand for a certain result? Was there a moment of acting with awareness? Include not noticing, difficulty, discomfort or an unchanged result. Do not fill gaps with what you hoped happened.\n\nWhat fitted this context, and what did not? A calmer feeling, a finished task or praise from someone else is not proof of balance. Bring uncertainty or unwanted effects to your therapist rather than scoring yourself.",
      "sha256": "b1d1b1a583ab75f86ec324f3f259c833a9fd54481daa607519b7313214292103",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.review.help",
      "title": "If I cannot tell whether it worked",
      "text": "You can leave that open. One account cannot prove a balanced state or a cause. A concrete observation or question is enough for review.",
      "sha256": "ceacf626fdd380e28d8f574249c494adf2d397438c412061b8b05c07283d9649",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "balancing-being-doing.practice.next",
      "title": "Keep, change or leave the practice",
      "text": "With your therapist, decide whether a similar practice fits again, needs a different activity or support, or should be left for now. There is no daily quota or missed-practice debt.\n\nIf useful, choose a natural cue, such as the start of a suitable activity. A cue here does not set an alarm or reminder. A future plan is not a record of doing it; you can finish without one.",
      "sha256": "e79802fcc4b2531553e817fe2e35a0d5f28125110fa897484ed9bd733d6f23ae",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "balancing-being-doing.practice.next.help",
      "title": "If this becomes another performance target",
      "text": "Pause and bring that pattern to your therapist. You do not have to master balance before you are allowed to stop, rest or get help.",
      "sha256": "99911b6b42ff2cbb58571185f0f4862ea95faf6fa6b2bce861128a8e5a545b71",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
