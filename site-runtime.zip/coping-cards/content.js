window.CopingCardsContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/thought",
  "componentId": "component/cbt/coping-cards",
  "resourceId": "tool/coping-cards",
  "routeProposal": "/coping-cards/",
  "title": "Coping Cards",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Make and try one accessible reminder of a response or skill you have already worked on with your therapist, then review its fit.",
  "groupedSetStatus": "Existing Coping Cards component under classic/thought. A cue and rehearsal format for previously agreed learning, not a new therapeutic mechanism, another Thought Record or a safety plan. No new canonical count.",
  "clinicalContract": {
    "learningObjective": "Distinguish a short credible reminder of agreed learning from an untested positive statement, repeated reassurance, a full worksheet or an emergency plan.",
    "practiceObjective": "Choose an ordinary use cue and previously agreed response/skill, draft concise words, check credibility/access, keep an explicit private copy if wanted, rehearse and use as agreed, then review actual use/non-use and revise or stop.",
    "sourcePopulationContext": "Primary CBT teaching establishes coping cards as reminders and rehearsal aids, not evidence of efficacy or all-age suitability for this adaptation. No age floor. Individual clinical, developmental, communication, safeguarding and access fit requires review.",
    "exclusions": [
      "No self-generated health/medication, exposure, trauma or crisis instructions",
      "No guarantee of safety, certainty, approval, success or relief",
      "No requirement to repeat until a thought feels false, an emotion settles or certainty appears",
      "No substitution for practical help, protection, a care plan or clinician teaching",
      "No obligation to disclose sensitive history, copy a harsh thought or store personal text in the tool",
      "No automatic therapist message, reminder, saved card, calendar event or inferred action"
    ],
    "adaptations": [
      "Original text and example; no source card template or wording reproduced",
      "One ordinary therapist-agreed cue/response or familiar skill; no automatic interpretation or positive replacement",
      "Planning, actual keeping of a copy, rehearsal, real-world use/non-use and review remain distinct",
      "Paper/private speech/access support permitted; no stored card or uploaded recording",
      "Selected-only literal notes export is not an automatic finished card; user chooses and checks what to keep",
      "Neutral, adverse and no-use outcomes permitted, with no mandatory reading dose"
    ],
    "reviewGates": [
      "Owner/clinician and rights review of bounded card format and safeguards",
      "Individual clinical, developmental, safeguarding, communication and access fit",
      "Human comprehension review; grade-five wording is a target, not a validated reading level",
      "Real integrated desktop/mobile/keyboard/screen-reader and clipboard/download/lifecycle acceptance",
      "Authorized narration generation, exact-script listening, binding and controls review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Use the learning you have agreed with your therapist",
      "options": [
        {
          "value": "prepare",
          "label": "Prepare and try a card",
          "startSectionId": "coping-cards.practice.cue"
        },
        {
          "value": "review",
          "label": "Review a card I tried or planned",
          "startSectionId": "coping-cards.practice.review"
        }
      ]
    },
    "entryGate": "Therapist-introduced scope visible before mode choice; no card or action approval. Example, Learn, Finish and support remain available.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No writing or completion requirement.",
    "reviewAccess": "Direct blank review without stored card, prior draft or inferred attempt. Both modes expose all groups.",
    "writing": "Optional and hidden initially; fiction never fills notes. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only. Internal reading/navigation retains; clear, restart, leaving/reloading, history and BFCache clear notes. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. No assembled or saved card inferred; editing/hiding/mode/stage changes invalidate export.",
    "narration": "Hashed static public text/help only, never card text or other notes. No audio, TTS, recording upload or autoplay.",
    "timer": "None. No reminders, repeated-reading quota or certainty check.",
    "completion": "No inferred finished card, saved copy, rehearsal, real use, skill action, success or emotional change."
  },
  "intro": {
    "id": "coping-cards.intro",
    "title": "Keep useful learning within reach",
    "paragraphs": [
      "A coping card is a short reminder you can use when it is hard to recall something useful from therapy. It may hold a realistic response, a familiar skill step or a reason for a choice you have already discussed.",
      "The card does not make the thought true or the situation safe. It helps you remember and try agreed learning. Here you can prepare one card, think about how to find it, try using it, and review whether it fits."
    ]
  },
  "fit": {
    "id": "coping-cards.fit",
    "title": "Use an ordinary situation and agreed learning",
    "paragraphs": [
      "Use this after your therapist has introduced coping cards and checked the response or skill with you. Do not use the page to approve a new belief, treatment step or major decision. You can keep an idea as a question for your session.",
      "Choose an ordinary situation where a reminder may help. This is not a crisis or safety plan, an exposure task, trauma work, health advice or a substitute for urgent help. Keep needed care, aids, safety steps and boundaries.",
      "The message needs to be credible to you, not bright or certain. It must not tell you to ignore danger, pain, unfair treatment or a real problem. A card can remind you to seek help or pause, not just to do more.",
      "If reading feels threatening, brings painful memories or becomes something you repeat until you feel safe or certain, pause and discuss the pattern with your therapist. Do not force belief, calm or more reading to prove the card works."
    ]
  },
  "privacy": {
    "id": "coping-cards.privacy",
    "title": "You choose whether to make and keep a copy",
    "paragraphs": [
      "You can think through a card without writing, speak privately, use your own paper or add optional notes here. A plan for a card is not a saved card. This page does not record your voice or keep a card after you leave.",
      "Notes stay in this open tool through its examples and help. Leaving, reloading, clearing or starting again removes them. To keep a copy, select the notes you want, check the preview, then copy or download. Check the copy yourself before relying on it later.",
      "A card may be seen by other people. Leave out names or private history you do not need, and choose where to keep it. Device tools or a screen reader may read your words. Skill narration never reads your notes. Nothing is sent to your therapist; no reminder or alert is set. Copies you keep outside this tool remain until you remove them. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "coping-cards.close",
    "title": "Keep the status clear",
    "paragraphs": [
      "A draft, a copy, a rehearsal and real use are different. You can finish at any of these points, or without making a card. No change in feeling or belief is required.",
      "Choose any notes you want to keep, or leave them here to clear. Finish and clear removes notes in this tool, not copies you kept elsewhere. You decide whether to bring a copy or describe the experience to your therapist."
    ]
  },
  "example": {
    "id": "coping-cards.example",
    "title": "Leni makes a reminder for a first draft",
    "paragraphs": [
      "This is made up, not a card to copy. Leni wants to write a short note about a favourite book. Starting feels hard when Leni thinks the first sentence must sound polished. In therapy, Leni has checked a more realistic view: a first draft can be rough, and a small start leaves room to revise.",
      "Leni chooses the cue \"Starting my book note.\" The card message is \"Rough words can be a start.\" The familiar action is \"Write one sentence, then choose whether to continue, change it or pause.\" These words remind Leni of work already done; the card does not promise a good review.",
      "Leni checks that the words make sense and the action fits the agreed plan. The paper card goes inside the notebook with a plain title and no therapy history. Leni looks at it there to check it can be found and read. Merely planning that place would not have put the card there.",
      "For rehearsal, Leni reads the card and quietly says the familiar step. Leni notices that \"rough words\" fits better than \"great writing.\" Rehearsal is not recorded as writing the book note.",
      "At the next agreed writing time, Leni finds the card, reads it and writes \"The funny parts surprised me.\" Leni still dislikes the sentence and chooses to pause. Reading the card did not make Leni certain or remove the wish to polish it.",
      "In review, Leni reports what actually happened and that the action line was hard to find quickly. Leni and the therapist consider putting that line first. That is a proposed revision, not evidence it has been used. If the card had stayed in another room, the review would note no use and address access instead of inventing a result."
    ]
  },
  "learn": {
    "id": "coping-cards.learn",
    "title": "A reminder, not a new rule",
    "paragraphs": [
      "A Thought Record helps examine a thought and form a balanced response. Coping cards help you recall learning when you need it. The useful work comes first; making a short card does not replace checking the response or learning the skill.",
      "Keep the words brief enough to use, but do not remove an important limit or turn uncertainty into a promise. A message can be fair and useful while a difficult feeling remains.",
      "A card may cue thinking, a skill you know, or an agreed choice. Reading and doing are different. If it reminds you of an action, check whether that action still fits the real setting and your needs.",
      "Learning may involve revisiting a card in a way agreed with your therapist. That is different from feeling forced to repeat it until you are certain or calm. Access needs may also mean reading or hearing it more than once; there is no universal reading dose here.",
      "A card may need a different place, shorter wording, another format or no further use. Review what happened rather than treating use or non-use as proof of effort, worth or success. This component is not a full CBT programme or emergency plan."
    ]
  },
  "practice": [
    {
      "id": "coping-cards.practice.cue",
      "title": "Choose when a reminder might help",
      "paragraphs": [
        "Choose one ordinary situation you have discussed with your therapist. What makes it hard to recall a useful response or skill at that point? A brief cue is enough; no painful history or exact harsh thought is required.",
        "When would it make sense to notice the card: before a familiar task, at a chosen pause, or another agreed moment? Do not make noticing every thought or feeling a new job."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The ordinary situation we discussed",
          "optional": true
        },
        {
          "key": "use-cue",
          "label": "When a reminder may be useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If the situation needs practical help",
        "text": "A reminder cannot remove a real barrier or make a harmful setting safe. Keep the need for help, access or protection visible. Your therapist may suggest a different tool or no card for this situation."
      }
    },
    {
      "id": "coping-cards.practice.learning",
      "title": "Choose learning you already have",
      "paragraphs": [
        "What response, reminder or skill have you and your therapist already found credible and suitable? Use your own words. If it is a thinking response, keep the evidence and uncertainty that make it fair.",
        "If it is an action or a skill, use one you have been taught and agreed to use. A new treatment step belongs in your session, not on a card that this page has supposedly approved."
      ],
      "fields": [
        {
          "key": "agreed-learning",
          "label": "The response or skill we have already worked on",
          "optional": true
        },
        {
          "key": "why-credible",
          "label": "Why it fits, and any important limit",
          "optional": true
        }
      ],
      "help": {
        "title": "If no useful response is ready",
        "text": "Leave the card as an idea. You can return to the relevant skill with your therapist. You do not have to invent a positive sentence or copy the example to fill the space."
      }
    },
    {
      "id": "coping-cards.practice.card",
      "title": "Draft a short card in your own words",
      "paragraphs": [
        "Choose the few words you want to find at the cue. The card can hold a realistic message, a familiar skill step, or both. It does not need a full worksheet or a list of every coping skill.",
        "A short cue can help you know when it applies. Keep any limit that matters. You can leave out a harsh thought or personal details, and you do not have to use a special card layout."
      ],
      "fields": [
        {
          "key": "card-cue",
          "label": "Card: when this may help",
          "optional": true
        },
        {
          "key": "card-message",
          "label": "Card: the message I want to remember",
          "optional": true
        },
        {
          "key": "card-step",
          "label": "Card: a familiar step, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If the card is getting long",
        "text": "Ask which part you need in that moment. Keep the rest for your session or other notes. Shorter is useful only if the message stays accurate, understandable and accessible."
      }
    },
    {
      "id": "coping-cards.practice.fit",
      "title": "Check the card before relying on it",
      "paragraphs": [
        "Read or hear the words at a manageable time. Do they sound believable, respectful and clear to you? Check for hidden rules such as \"I must feel better,\" promises of safety, or instructions that do not fit your limits.",
        "Does any action still match what you agreed with your therapist? A card cannot decide whether a new setting is safe or whether treatment advice should change. Keep unclear wording as a question before using it."
      ],
      "fields": [
        {
          "key": "wording-check",
          "label": "Words that fit, or need checking",
          "optional": true
        },
        {
          "key": "action-check",
          "label": "Any action, limit or uncertainty to review",
          "optional": true
        }
      ],
      "help": {
        "title": "If the words feel false or pressuring",
        "text": "Do not repeat them harder. Use a more credible response already agreed, leave the card unfinished, or bring the problem to your therapist. A useful reminder does not have to promise an outcome."
      }
    },
    {
      "id": "coping-cards.practice.access",
      "title": "Choose how to keep and find it",
      "paragraphs": [
        "What format and place would let you find the card at the agreed moment? Your own paper, a private device note or another accessible format may fit. Consider reading, language, vision, memory, movement and any support you want.",
        "If you use notes here, choose the card parts you want to keep, check the preview, then copy or download. Other planning notes are not added unless you select them. Check your copy and its location; this tool does not save the card for you.",
        "Keep only what you are comfortable having there. A device or cloud service may store or sync a copy you make outside this page. You can use a plain cue, choose a more private place or decide not to keep a card."
      ],
      "fields": [
        {
          "key": "access-plan",
          "label": "The format, place and access support I choose",
          "optional": true
        },
        {
          "key": "copy-status",
          "label": "What I actually kept and checked, or have not done yet",
          "optional": true
        }
      ],
      "help": {
        "title": "If making a copy is not useful or possible",
        "text": "You can finish without a saved card and discuss another format with your therapist. Thinking through words may help prepare, but it is not proof that a reminder will be available later."
      }
    },
    {
      "id": "coping-cards.practice.rehearse",
      "title": "Rehearse the agreed way to use it",
      "paragraphs": [
        "At a suitable ordinary time, try finding the card and reading, hearing or saying the chosen words in a way that fits you. If it cues a skill, briefly check how you would begin the familiar step. You do not need to create distress to rehearse.",
        "Notice whether you can find, understand and use it. Adjust with your therapist if the words are too long, unclear or pressuring. This is a rehearsal, not evidence that you used the card in the later situation or carried out its action."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I actually rehearsed, or did not try",
          "optional": true
        },
        {
          "key": "rehearsal-learning",
          "label": "What I learned about access, words or use",
          "optional": true
        }
      ],
      "help": {
        "title": "If rehearsal starts to feel compulsory",
        "text": "You do not need to keep going until the words feel right or you are sure nothing bad can happen. Pause and discuss it. The aim is access to useful learning, not a test of certainty."
      }
    },
    {
      "id": "coping-cards.practice.use",
      "title": "Use it only as agreed and still suitable",
      "paragraphs": [
        "At the real cue, check whether the situation and your needs still fit. Use the agreed brief reminder if you choose. You can then decide whether a familiar action fits; reading does not require you to act.",
        "Keep safety, consent, access and needed care. You may change the plan with support, pause or not use the card. A feeling can remain. Do not keep repeating it just to force relief or cancel a thought.",
        "A real use happens outside these buttons. Return to review when it is useful. If you leave or reload, notes here clear; keep selected notes first if wanted."
      ],
      "fields": [
        {
          "key": "use-plan",
          "label": "The agreed occasion and way to use it",
          "optional": true
        },
        {
          "key": "changed-needs",
          "label": "Any changed need, limit or support to check",
          "optional": true
        }
      ],
      "help": {
        "title": "If help is needed now",
        "text": "Do not delay practical or urgent help to find, finish or read a card. Use your existing care plan or appropriate support. This page does not monitor you or alert anyone."
      }
    },
    {
      "id": "coping-cards.practice.review",
      "title": "Review actual use or non-use",
      "paragraphs": [
        "Was this a draft, a kept copy, a rehearsal or real use? What actually happened? If you did not find or use the card, say that; there is no effect to invent. You can still explore access, timing or why it did not fit.",
        "If you used it, what did you understand and what did you do, if anything? Keep reading the card separate from carrying out the skill. Include helpful, neutral, awkward or unwanted effects, and what you still do not know.",
        "Did the words stay credible and relevant in the real situation? Did use help recall a choice, or become pressure or repeated checking? A better mood or completed action is not the test."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "Draft, copy, rehearsal or real use: what actually happened",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What I noticed or did, and what remains unknown",
          "optional": true
        },
        {
          "key": "fit-review",
          "label": "How the words and use fitted, including any pressure",
          "optional": true
        }
      ],
      "help": {
        "title": "If the card was not used",
        "text": "Check practical reasons without blame. It may have been unavailable, hard to read, irrelevant or not wanted. Your therapist can help decide whether to change access, revise the content or stop using it."
      }
    },
    {
      "id": "coping-cards.practice.revise",
      "title": "Keep, revise or put the card aside",
      "paragraphs": [
        "With your therapist, decide whether to keep the card, change its words or format, choose a different cue, or stop using it. New evidence or a changed situation may mean the response needs fresh work, not just shorter wording.",
        "If you make a revised copy, check that you can tell it from an old one. You choose what to replace or remove outside this page. Agree any next use or review; this tool sets no reminder or reading schedule."
      ],
      "fields": [
        {
          "key": "revision",
          "label": "What to keep, change or stop after review",
          "optional": true
        },
        {
          "key": "therapy-review",
          "label": "Questions and any next use we agree",
          "optional": true
        }
      ],
      "help": {
        "title": "If you choose not to keep a card",
        "text": "That is a valid outcome. You can still bring useful learning or questions to therapy in your own way. No card, score, streak or finished worksheet is required."
      }
    }
  ],
  "sources": [
    {
      "id": "VA: Cognitive Behavioral Therapy for Depression, Therapist Manual (2011)",
      "url": "https://mirecc.va.gov/MIRECC/docs/CBT-D_Manual_Depression.pdf",
      "supports": "Printed pp120–123: coping cards hold cognitive responses or learned strategies, support recall/application, and require planning where to keep them and when to consult them.",
      "limits": "Adult Veteran/military clinician manual, not validation of this adaptation or all-age suitability. Original wording and example only; no source dialogue/card reproduced. Condition-specific, medical and crisis procedures are not imported."
    },
    {
      "id": "VA: Cognitive Behavioral Therapy Strategies Guide",
      "url": "https://www.mirecc.va.gov/visn16/docs/cbt-strategies-guide.pdf",
      "supports": "Printed p100: cards cue learned interventions in relevant situations and are reviewed and revised.",
      "limits": "CBT-D clinician resource for Veterans, not a standalone treatment or efficacy trial of this app. Its card template, examples and breathing/action instructions are not copied. Rights review remains open."
    },
    {
      "id": "Beck Institute: Note taking in Session",
      "url": "https://beckinstitute.org/blog/note-taking-in-session/",
      "supports": "Collaborative summaries of learning, checking wording, choice about who records it, and discussion of barriers to later reading.",
      "limits": "Author-origin clinical guidance, not this app or a universal reading schedule. This version sets no daily dose. No article passage, transcript or therapy-note template is reproduced."
    },
    {
      "id": "Beck Institute: Value-Focused Treatment in CBT for Depression",
      "url": "https://beckinstitute.org/blog/value-focused-treatment-in-cbt-for-depression/",
      "supports": "A coping card may recall previously discussed reasons for an agreed activity, as well as a realistic response or learned strategy.",
      "limits": "Clinical teaching example, not permission to prescribe a new activity or add a values exercise. No source story or card wording reproduced; no efficacy claim for this adaptation."
    },
    {
      "id": "Beck Institute: Permission to Use Beck Institute Materials",
      "url": "https://beckinstitute.org/permission-to-use-beck-institute-materials/",
      "supports": "Source-use permission process; public access does not authorize copying, reprinting, adapting or translating source material for distribution.",
      "limits": "No permission has been requested or granted. This is original explanatory text and an original example; attribution does not itself settle release rights."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Identify an ordinary cue and select previously agreed learning",
      "sections": [
        "practice.cue",
        "practice.learning"
      ],
      "source": "VA CBT-D pp120–123; new thought restructuring or treatment planning is not supplied by the card"
    },
    {
      "operation": "Create a concise credible personal reminder",
      "sections": [
        "practice.card",
        "practice.fit"
      ],
      "source": "VA CBT-D pp120–123 and Beck note-taking; original cue/message/step labels, no source form copied"
    },
    {
      "operation": "Plan accessible location and actual copy",
      "sections": [
        "practice.access"
      ],
      "source": "VA CBT-D p123 for place/circumstances; privacy and exact selected-copy verification are product safeguards"
    },
    {
      "operation": "Rehearse recall and use in agreed situations",
      "sections": [
        "practice.rehearse",
        "practice.use"
      ],
      "source": "VA CBT-D recall/application and Beck review/barrier guidance; explicit rehearsal-versus-real-use distinction is adaptation"
    },
    {
      "operation": "Review actual use/non-use and revise",
      "sections": [
        "practice.review",
        "practice.revise"
      ],
      "source": "VA Strategies Guide p100 review/revise; literal status, adverse/neutral outcomes and no automatic reminder are product safeguards"
    },
    {
      "operation": "Prevent forced certainty and preserve real-world help",
      "sections": [
        "fit",
        "learn",
        "practice.rehearse",
        "practice.use"
      ],
      "source": "Conservative clinical-product safeguards, not a validated checking screen or a claim that the cited card sources prescribe these exact limits"
    }
  ],
  "narrationSegments": [
    {
      "id": "coping-cards.intro",
      "title": "Keep useful learning within reach",
      "text": "A coping card is a short reminder you can use when it is hard to recall something useful from therapy. It may hold a realistic response, a familiar skill step or a reason for a choice you have already discussed.\n\nThe card does not make the thought true or the situation safe. It helps you remember and try agreed learning. Here you can prepare one card, think about how to find it, try using it, and review whether it fits.",
      "sha256": "f3b6322cf4f058d8647318e44456ace407eef6d8950e5287dcd67295a8694bbc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.fit",
      "title": "Use an ordinary situation and agreed learning",
      "text": "Use this after your therapist has introduced coping cards and checked the response or skill with you. Do not use the page to approve a new belief, treatment step or major decision. You can keep an idea as a question for your session.\n\nChoose an ordinary situation where a reminder may help. This is not a crisis or safety plan, an exposure task, trauma work, health advice or a substitute for urgent help. Keep needed care, aids, safety steps and boundaries.\n\nThe message needs to be credible to you, not bright or certain. It must not tell you to ignore danger, pain, unfair treatment or a real problem. A card can remind you to seek help or pause, not just to do more.\n\nIf reading feels threatening, brings painful memories or becomes something you repeat until you feel safe or certain, pause and discuss the pattern with your therapist. Do not force belief, calm or more reading to prove the card works.",
      "sha256": "84a25a367758168e468ceae0094e2621ba91fdc59de0cdff9d114054909249c6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.privacy",
      "title": "You choose whether to make and keep a copy",
      "text": "You can think through a card without writing, speak privately, use your own paper or add optional notes here. A plan for a card is not a saved card. This page does not record your voice or keep a card after you leave.\n\nNotes stay in this open tool through its examples and help. Leaving, reloading, clearing or starting again removes them. To keep a copy, select the notes you want, check the preview, then copy or download. Check the copy yourself before relying on it later.\n\nA card may be seen by other people. Leave out names or private history you do not need, and choose where to keep it. Device tools or a screen reader may read your words. Skill narration never reads your notes. Nothing is sent to your therapist; no reminder or alert is set. Copies you keep outside this tool remain until you remove them. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "f276e81fae8f42b1efda921dc489c8167ab0b198255cc8c17af6055674eace85",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.close",
      "title": "Keep the status clear",
      "text": "A draft, a copy, a rehearsal and real use are different. You can finish at any of these points, or without making a card. No change in feeling or belief is required.\n\nChoose any notes you want to keep, or leave them here to clear. Finish and clear removes notes in this tool, not copies you kept elsewhere. You decide whether to bring a copy or describe the experience to your therapist.",
      "sha256": "a076a5b4b3646f9f6b5c28a658b15b950925733176b0fd54ad5d7739e5c1588c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.example",
      "title": "Leni makes a reminder for a first draft",
      "text": "This is made up, not a card to copy. Leni wants to write a short note about a favourite book. Starting feels hard when Leni thinks the first sentence must sound polished. In therapy, Leni has checked a more realistic view: a first draft can be rough, and a small start leaves room to revise.\n\nLeni chooses the cue \"Starting my book note.\" The card message is \"Rough words can be a start.\" The familiar action is \"Write one sentence, then choose whether to continue, change it or pause.\" These words remind Leni of work already done; the card does not promise a good review.\n\nLeni checks that the words make sense and the action fits the agreed plan. The paper card goes inside the notebook with a plain title and no therapy history. Leni looks at it there to check it can be found and read. Merely planning that place would not have put the card there.\n\nFor rehearsal, Leni reads the card and quietly says the familiar step. Leni notices that \"rough words\" fits better than \"great writing.\" Rehearsal is not recorded as writing the book note.\n\nAt the next agreed writing time, Leni finds the card, reads it and writes \"The funny parts surprised me.\" Leni still dislikes the sentence and chooses to pause. Reading the card did not make Leni certain or remove the wish to polish it.\n\nIn review, Leni reports what actually happened and that the action line was hard to find quickly. Leni and the therapist consider putting that line first. That is a proposed revision, not evidence it has been used. If the card had stayed in another room, the review would note no use and address access instead of inventing a result.",
      "sha256": "fa86878f55ac0534fdf522da42ca550d51d2638b78e747fe0ffaa9e70414e9c8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.learn",
      "title": "A reminder, not a new rule",
      "text": "A Thought Record helps examine a thought and form a balanced response. Coping cards help you recall learning when you need it. The useful work comes first; making a short card does not replace checking the response or learning the skill.\n\nKeep the words brief enough to use, but do not remove an important limit or turn uncertainty into a promise. A message can be fair and useful while a difficult feeling remains.\n\nA card may cue thinking, a skill you know, or an agreed choice. Reading and doing are different. If it reminds you of an action, check whether that action still fits the real setting and your needs.\n\nLearning may involve revisiting a card in a way agreed with your therapist. That is different from feeling forced to repeat it until you are certain or calm. Access needs may also mean reading or hearing it more than once; there is no universal reading dose here.\n\nA card may need a different place, shorter wording, another format or no further use. Review what happened rather than treating use or non-use as proof of effort, worth or success. This component is not a full CBT programme or emergency plan.",
      "sha256": "cd7ad0f026480c6e7b12dfaec2ea42d7faebc6bda75baac5eadfca3879628b18",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.cue",
      "title": "Choose when a reminder might help",
      "text": "Choose one ordinary situation you have discussed with your therapist. What makes it hard to recall a useful response or skill at that point? A brief cue is enough; no painful history or exact harsh thought is required.\n\nWhen would it make sense to notice the card: before a familiar task, at a chosen pause, or another agreed moment? Do not make noticing every thought or feeling a new job.",
      "sha256": "6da4c576c8705952c5f34362a6aa4e7ded14af18754c9730381b74cd3cb2c6fb",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.cue.help",
      "title": "If the situation needs practical help",
      "text": "A reminder cannot remove a real barrier or make a harmful setting safe. Keep the need for help, access or protection visible. Your therapist may suggest a different tool or no card for this situation.",
      "sha256": "6f79f6eff11cc485e11cc1a96720f5fb4d9eccf27282d5e2b68d7b763e8abebf",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.learning",
      "title": "Choose learning you already have",
      "text": "What response, reminder or skill have you and your therapist already found credible and suitable? Use your own words. If it is a thinking response, keep the evidence and uncertainty that make it fair.\n\nIf it is an action or a skill, use one you have been taught and agreed to use. A new treatment step belongs in your session, not on a card that this page has supposedly approved.",
      "sha256": "af6ff629c69aebd2392850adc3e87e2540d95d3d6c1025ea3679425c0a021716",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.learning.help",
      "title": "If no useful response is ready",
      "text": "Leave the card as an idea. You can return to the relevant skill with your therapist. You do not have to invent a positive sentence or copy the example to fill the space.",
      "sha256": "3e3a4de4575de666d936155d4ad3c61a347d9437bf6427305b1f148d9529a0fa",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.card",
      "title": "Draft a short card in your own words",
      "text": "Choose the few words you want to find at the cue. The card can hold a realistic message, a familiar skill step, or both. It does not need a full worksheet or a list of every coping skill.\n\nA short cue can help you know when it applies. Keep any limit that matters. You can leave out a harsh thought or personal details, and you do not have to use a special card layout.",
      "sha256": "cfaa647db5152240b7c87d6cb39062c63884716ba7a01370500e27a2df1ac7c2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.card.help",
      "title": "If the card is getting long",
      "text": "Ask which part you need in that moment. Keep the rest for your session or other notes. Shorter is useful only if the message stays accurate, understandable and accessible.",
      "sha256": "03cf7a2b4b7414966c1713d1411e4071dbb4aff38316084a6ef1f4770277b195",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.fit",
      "title": "Check the card before relying on it",
      "text": "Read or hear the words at a manageable time. Do they sound believable, respectful and clear to you? Check for hidden rules such as \"I must feel better,\" promises of safety, or instructions that do not fit your limits.\n\nDoes any action still match what you agreed with your therapist? A card cannot decide whether a new setting is safe or whether treatment advice should change. Keep unclear wording as a question before using it.",
      "sha256": "3f5c1951c9e9c4090dc31a56be4914f25a059692ff38f38843210bb4631d4078",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.fit.help",
      "title": "If the words feel false or pressuring",
      "text": "Do not repeat them harder. Use a more credible response already agreed, leave the card unfinished, or bring the problem to your therapist. A useful reminder does not have to promise an outcome.",
      "sha256": "c120cea589f5ac833f67edc6bef316860911a4c1a9b4b37654a936641beb3747",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.access",
      "title": "Choose how to keep and find it",
      "text": "What format and place would let you find the card at the agreed moment? Your own paper, a private device note or another accessible format may fit. Consider reading, language, vision, memory, movement and any support you want.\n\nIf you use notes here, choose the card parts you want to keep, check the preview, then copy or download. Other planning notes are not added unless you select them. Check your copy and its location; this tool does not save the card for you.\n\nKeep only what you are comfortable having there. A device or cloud service may store or sync a copy you make outside this page. You can use a plain cue, choose a more private place or decide not to keep a card.",
      "sha256": "2683e2296b2d749a696737953236f265aa65f0199956064344d871f2ebae6fdc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.access.help",
      "title": "If making a copy is not useful or possible",
      "text": "You can finish without a saved card and discuss another format with your therapist. Thinking through words may help prepare, but it is not proof that a reminder will be available later.",
      "sha256": "a48469e66350c8a708b54b6d96af049b99f5a59afff6c8d242057ebb00bb4265",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.rehearse",
      "title": "Rehearse the agreed way to use it",
      "text": "At a suitable ordinary time, try finding the card and reading, hearing or saying the chosen words in a way that fits you. If it cues a skill, briefly check how you would begin the familiar step. You do not need to create distress to rehearse.\n\nNotice whether you can find, understand and use it. Adjust with your therapist if the words are too long, unclear or pressuring. This is a rehearsal, not evidence that you used the card in the later situation or carried out its action.",
      "sha256": "2e58a6a236d59b156221d005591db0b1cc199c9654a86e35b70a8bb7460a1a20",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.rehearse.help",
      "title": "If rehearsal starts to feel compulsory",
      "text": "You do not need to keep going until the words feel right or you are sure nothing bad can happen. Pause and discuss it. The aim is access to useful learning, not a test of certainty.",
      "sha256": "ee53a5d7dd2c302e82a3658e829aaffd04e1d886e793e15263f38ba376cb6ee8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.use",
      "title": "Use it only as agreed and still suitable",
      "text": "At the real cue, check whether the situation and your needs still fit. Use the agreed brief reminder if you choose. You can then decide whether a familiar action fits; reading does not require you to act.\n\nKeep safety, consent, access and needed care. You may change the plan with support, pause or not use the card. A feeling can remain. Do not keep repeating it just to force relief or cancel a thought.\n\nA real use happens outside these buttons. Return to review when it is useful. If you leave or reload, notes here clear; keep selected notes first if wanted.",
      "sha256": "3fcd36df0148b283dcc585969e30085dd5af1a01f90d589c505c434f96df0756",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.use.help",
      "title": "If help is needed now",
      "text": "Do not delay practical or urgent help to find, finish or read a card. Use your existing care plan or appropriate support. This page does not monitor you or alert anyone.",
      "sha256": "d5b6e5cf5e32fd709c91b13f1e4366533c95d436d53caee1e7b70e30d7b5f412",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.review",
      "title": "Review actual use or non-use",
      "text": "Was this a draft, a kept copy, a rehearsal or real use? What actually happened? If you did not find or use the card, say that; there is no effect to invent. You can still explore access, timing or why it did not fit.\n\nIf you used it, what did you understand and what did you do, if anything? Keep reading the card separate from carrying out the skill. Include helpful, neutral, awkward or unwanted effects, and what you still do not know.\n\nDid the words stay credible and relevant in the real situation? Did use help recall a choice, or become pressure or repeated checking? A better mood or completed action is not the test.",
      "sha256": "7fcdb495e42049c2aabf2449d30c9f58a5618f9d4f6fad2bf79c3b6bea3b807b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.review.help",
      "title": "If the card was not used",
      "text": "Check practical reasons without blame. It may have been unavailable, hard to read, irrelevant or not wanted. Your therapist can help decide whether to change access, revise the content or stop using it.",
      "sha256": "a85f5aacecf668d57272ab81e51624eebfe016e427f94ea283c44d8c4794a034",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "coping-cards.practice.revise",
      "title": "Keep, revise or put the card aside",
      "text": "With your therapist, decide whether to keep the card, change its words or format, choose a different cue, or stop using it. New evidence or a changed situation may mean the response needs fresh work, not just shorter wording.\n\nIf you make a revised copy, check that you can tell it from an old one. You choose what to replace or remove outside this page. Agree any next use or review; this tool sets no reminder or reading schedule.",
      "sha256": "2bd8071f08e59bae9cbe3f7bf2566e537568ff22ea6a76e54a53684b092bdc3f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "coping-cards.practice.revise.help",
      "title": "If you choose not to keep a card",
      "text": "That is a valid outcome. You can still bring useful learning or questions to therapy in your own way. No card, score, streak or finished worksheet is required.",
      "sha256": "a700078c479e3ba16c296d899bac65fa7d043e4fd29a33f82aea9f4abbd03f5a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
