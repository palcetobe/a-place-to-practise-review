window.ChainSolutionContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/chain",
  "resourceId": "tool/chain-solution-analysis",
  "routeProposal": "/chain-solution-analysis/",
  "title": "Chain Analysis and Solution Analysis",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "With your therapist, understand one ordinary action and practise a different response at a useful point.",
  "groupedSetStatus": "One existing grouped canonical entry, classic/chain, containing Chain Analysis and Solution Analysis. Both named written procedures are represented within the bounded ordinary-case scope. This is not complete DBT treatment, CBT functional assessment or Missing-Links Analysis. No new component count.",
  "implementedComponentIds": [
    "component/chain/chain-analysis",
    "component/chain/solution-analysis"
  ],
  "clinicalContract": {
    "learningObjective": "Distinguish earlier context, prompt, sequential links, target action and immediate/later consequences; treat possible functions as hypotheses and link a feasible solution to a point in the sequence.",
    "practiceObjective": "Review one clinician-selected ordinary occurrence, leave uncertain details visible, consider link-specific alternatives, rehearse an agreed replacement, plan prevention/repair/support and review actual later use.",
    "sourcePopulationContext": "Primary sources teach clinicians to conduct DBT chain and solution analysis, including high-risk examples excluded here. They do not validate this isolated adaptation or universal age suitability. No blanket adult-only or 16+ rule; clinician-led introduction/rehearsal and individual developmental, safeguarding, health, cultural, power, communication and access review remain necessary.",
    "exclusions": [
      "No solo analysis of self-harm, suicidal actions, violence, trauma, substance-use episodes or other high-risk behaviour",
      "No exhaustive or compulsive reconstruction, forced recall, causal verdict, hidden-motive inference or character judgment",
      "No chain about blaming another person for harm or proving a victim caused it",
      "No prescription for food, medication, sleep, health changes or removal of needed protections/aids",
      "No coerced apology, punishment, dangerous contact or repair outside the person's actual responsibility"
    ],
    "adaptations": [
      "Original sequence, prompts and fictional example; no publisher forms, scales, transcript or source pages reproduced",
      "Clinician-led first example and response rehearsal before bounded between-session use",
      "Uncertain links/consequence function remain open and revisable",
      "Optional multiline sequence allows relevant detail without fixed link count or inferred causal arrows",
      "No attempt, changed plan, no opportunity, difficult outcome and no improvement remain valid review states",
      "All writing optional, in-memory only, selected exact-preview export; no automatic reporting or media"
    ],
    "reviewGates": [
      "Owner/clinician and rights review of original adaptation and two-component fidelity",
      "Clinician-led introduction, rehearsal, exact target and individually appropriate between-session scope",
      "Human comprehension and developmental/safeguarding/communication/access fit",
      "Integrated desktop/mobile/browser lifecycle/keyboard/screen-reader/support/privacy acceptance",
      "Authorized audio generation, exact-script listening and controls before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use the ordinary target and approach agreed with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Map my agreed episode",
          "startSectionId": "chain-solution-analysis.practice.target"
        },
        {
          "value": "review",
          "label": "Review my agreed response",
          "startSectionId": "chain-solution-analysis.practice.review"
        }
      ]
    },
    "entryGate": "Visible scope before explicit choice. No entry choice certifies clinician contact, safety, completed analysis or practice. Example/Learn/Finish/support always available.",
    "focus": "One meaningful prompt group, free jump/Show all/Previous/Finish, no required notes or completion locks.",
    "reviewAccess": "Direct blank review without prior stored chain or attempt; no inference from clicking through.",
    "writing": "Hidden and optional initially; fiction never populates notes. Hide removes private display and invalidates export.",
    "persistence": "Open-page memory only. Internal readers/navigation retain notes; leaving/reload/clear/restart/history/BFCache clear them. Visibility change alone retains them.",
    "export": "Explicit note selection, exact preview, then selected-only copy/download. Nothing preselected. Edit/hide/mode change invalidates selection.",
    "narration": "Exact fixed public paragraph/help scripts only, never notes. No audio, TTS, autoplay or activation.",
    "timer": "None. Pause or stop without a minimum duration or detail count.",
    "completion": "No completed-chain, attempted, success, causal, mood, score or streak verdict."
  },
  "intro": {
    "id": "chain-solution-analysis.intro",
    "title": "Understand a sequence, then practise a change",
    "paragraphs": [
      "A chain analysis looks closely at one action that happened. It maps what was going on before it, the steps leading to it and what followed. A sequence can help you ask useful questions. It does not prove why everything happened.",
      "Solution analysis is the next part. With your therapist, you find places where another response or more support could help. You practise a response, plan for hard parts and later review what really happened. The aim is learning, not blame."
    ]
  },
  "fit": {
    "id": "chain-solution-analysis.fit",
    "title": "Start with your therapist and an ordinary episode",
    "paragraphs": [
      "Your therapist first helps you map an example and rehearse a possible response. Between sessions, use only an ordinary, non-dangerous action and type of change you have agreed to work on. This page cannot choose a safe target for you.",
      "Do not use this page to go over self-harm, suicide, violence, trauma, alcohol or other drug use, or other high-risk acts on your own. If safety needs attention now, leave the exercise and seek help. You do not need to finish first.",
      "Choose one action you actually did, not a judgment like \"I was bad\". If the main question is why a helpful action did not happen, ask your therapist about a different method called Missing-Links Analysis. Do not invent an event to fill this page.",
      "Keep the account small enough to manage. You can leave gaps, skip writing, stop or ask for help. If the review becomes self-attack, repeated checking or distressing recall, pause and bring it to your therapist."
    ]
  },
  "privacy": {
    "id": "chain-solution-analysis.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, contact details and private health or history details are not needed. Notes stay while you use this open tool, including its example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes to your therapist. Optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "chain-solution-analysis.close",
    "title": "Leave the account and plan here",
    "paragraphs": [
      "You can stop with a partial account, a question, a plan or a review. Missing detail is not a failure. A plan or rehearsal is not the same as trying the response in life.",
      "Return to a prompt if you wish, or choose notes to keep for your session. Finish and clear removes these notes, not any copies you have kept elsewhere. Nothing is sent to your therapist."
    ]
  },
  "example": {
    "id": "chain-solution-analysis.example",
    "title": "Lee speaks over a friend while choosing a film",
    "paragraphs": [
      "This is made up. Lee and their therapist choose one ordinary episode, not a dangerous conflict. Target action: Lee spoke over a friend twice while they were choosing a film. Lee wants to understand that action, not label themselves a bad friend.",
      "Before: Lee was tired after a busy day and had little quiet time. That may have made the chat harder. It does not prove tiredness caused the interruption. The friend had no duty to guess what Lee needed.",
      "Prompt: The friend started describing a film they wanted to watch. Lee had not yet shared a choice. That event is different from Lee's thought, \"My ideas will not get a turn.\"",
      "Links: Lee heard the first suggestion, thought \"I need to get in now\", felt tense and leaned forward. Lee started speaking before the friend finished. The friend paused. Lee added another suggestion over the next sentence. Some details of the timing are unclear.",
      "After: Lee got to name a film and felt brief relief. The friend said, \"Please let me finish.\" Later, they took longer to decide and Lee felt regret. Getting a turn may help explain why interrupting was tempting, but one episode cannot prove its purpose.",
      "Solutions: Lee and the therapist consider asking for a short quiet break before the chat; noticing the urge to jump in and pausing for a moment; or waiting for the sentence to end and asking, \"Can I suggest one too?\" They choose the last response to practise. This does not require the friend to agree with Lee's film choice.",
      "Rehearsal: In the session, the therapist plays the friend and starts a suggestion. Lee practises waiting and asking for a turn. The first try feels awkward. They practise again with fewer words. If Lee loses the words, they can ask for a moment and try the short question.",
      "Prevention and repair: Lee can say when they need a short break before a chat. For the interruption, Lee plans to acknowledge speaking over the friend and offer to hear the idea when the friend is ready. That plan is not an apology already made or a promise that the friend will respond warmly.",
      "Later review: At another ordinary film chat, Lee waits for a sentence to end and asks for a turn. Lee is still tense. The friend says yes, but they still disagree about the film. Lee did use the planned response; agreement was not the goal. At the next session, Lee and the therapist review the attempt. Lee says waiting through a long sentence was hard. They rehearse a short silent cue, \"Let this sentence finish\", then the question. They keep the request for a turn and agree to try the cue next time. That revised plan has not been tried outside the session yet."
    ]
  },
  "learn": {
    "id": "chain-solution-analysis.learn",
    "title": "Different parts of the chain have different jobs",
    "paragraphs": [
      "The target is the specific action you want to understand. Earlier conditions can make a moment harder, such as tiredness, pain, noise, pressure or missing support. These are sometimes called vulnerability factors. They are not personal faults.",
      "The prompting event is what happened just before this sequence began. Links are the thoughts, feelings, body signals, outside events and actions along the way. What came first is not always what caused the next part.",
      "Consequences are what followed the action, right away or later. An action may meet a need or bring quick relief and still create a problem later. Check what actually happened. Do not assume what the action achieved or what another person intended.",
      "A possible explanation is a guess to check with your therapist. More information may change it. You do not need to find one hidden reason or remember every detail perfectly.",
      "Solution analysis uses the map. You consider other responses at specific points, practise a useful one, plan for barriers, and consider support or changes that could prevent the pattern. If your action caused harm, you can consider a fair repair. Repair is not punishment.",
      "This differs from a short situation map or comparing two patterns. It works through one episode and connects a response to a point in that sequence. It also differs from Missing-Links Analysis, which asks why an agreed helpful action did not occur.",
      "Your skills are only part of the picture. Access, power, unfair treatment, health and other people's actions matter. Changing your response does not make you responsible for someone else's harm. A plan may need more support or a change in the setting."
    ]
  },
  "practice": [
    {
      "id": "chain-solution-analysis.practice.target",
      "title": "Choose one action that actually happened",
      "paragraphs": [
        "Use the ordinary target agreed with your therapist. What did you do that someone could have seen or heard? Describe the action rather than calling yourself a name. Include enough detail to know which action you mean.",
        "Choose one occasion. Note the general setting and when the action began or ended, if useful. You do not need names, an exact date or private details. Keep the focus on your action, not a judgment of the whole relationship or day."
      ],
      "fields": [
        {
          "key": "target",
          "label": "The specific action I want to understand",
          "optional": true
        },
        {
          "key": "occasion",
          "label": "The one occasion and useful limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If the only target is something you did not do",
        "text": "Do not turn a missing action into an invented chain. Ask your therapist whether Missing-Links Analysis fits better. You can still read this example or review a response you had already agreed to try."
      }
    },
    {
      "id": "chain-solution-analysis.practice.before",
      "title": "Notice conditions that were already there",
      "paragraphs": [
        "Before the sequence began, what may have made this moment harder? Consider energy, pain, stress, noise, time pressure, support or other demands. Mention only what seems relevant. You do not need health details.",
        "What help, care or access did you need? What was available? These conditions can matter without being the whole cause. Needing support is not a failure to use a skill."
      ],
      "fields": [
        {
          "key": "before",
          "label": "Earlier conditions that may matter",
          "optional": true
        },
        {
          "key": "needs-support",
          "label": "Needs, support or access to keep in view",
          "optional": true
        }
      ],
      "help": {
        "title": "If you start blaming yourself for being tired or upset",
        "text": "Describe the condition without judging it. The question is what support or change could help, not whether you should have had fewer needs. Do not change food, medicine or health care on this page's advice."
      }
    },
    {
      "id": "chain-solution-analysis.practice.prompt",
      "title": "Locate the event that started this sequence",
      "paragraphs": [
        "What happened just before the links leading to the target action? Find one outside event you could describe in time: what you saw, heard or what happened around you. Your therapist can help choose the useful starting point.",
        "Keep the event apart from what you thought it meant. \"They began to speak\" differs from \"They wanted to ignore me.\" If the starting point is unclear, say so. You do not have to force an answer."
      ],
      "fields": [
        {
          "key": "prompting-event",
          "label": "The event just before the sequence",
          "optional": true
        },
        {
          "key": "event-meaning",
          "label": "What I thought it meant, or what is unclear",
          "optional": true
        }
      ],
      "help": {
        "title": "If there seem to be several starting points",
        "text": "Pick the one you and your therapist agreed to review, or leave a question. Earlier strain belongs in the context; a later thought can be a link. This is a useful map, not proof of the one true cause."
      }
    },
    {
      "id": "chain-solution-analysis.practice.links",
      "title": "Trace the steps toward the action",
      "paragraphs": [
        "From that event, describe what happened next, then next, up to the target action. Include the thoughts, feelings, body signals, outside events and actions that seem relevant. A brief numbered list can help; there is no required number of links.",
        "Be specific enough to see a possible place for change. Keep what you remember apart from what you guess. Include a response that helped if there was one. Leave unknown gaps visible instead of filling them with a story.",
        "Read the order once if useful. Does it fit what you remember? If recalling more feels overwhelming or turns into repeated checking, stop and review the gap with your therapist."
      ],
      "fields": [
        {
          "key": "sequence",
          "label": "The sequence from prompt to target action",
          "optional": true
        },
        {
          "key": "gaps",
          "label": "Gaps, guesses or details I want help checking",
          "optional": true
        }
      ],
      "help": {
        "title": "If feelings or body details are hard to name",
        "text": "Use what you do know. You may remember an action or thought more clearly. You do not have to scan your body, recreate distress or produce an emotion label to make a useful account."
      }
    },
    {
      "id": "chain-solution-analysis.practice.after",
      "title": "Look at what followed, now and later",
      "paragraphs": [
        "What happened right after the action, inside you and around you? What happened later? Include any relief, useful effect or cost you actually noticed. Do not assume how someone else felt unless they told you.",
        "With your therapist, ask what the action may have helped you get, avoid or delay at that moment. That is a possible explanation, not a fact proved by one episode. A real need may remain even if you want to change how you met it."
      ],
      "fields": [
        {
          "key": "immediate",
          "label": "What happened right afterward",
          "optional": true
        },
        {
          "key": "later",
          "label": "What happened later",
          "optional": true
        },
        {
          "key": "possible-function",
          "label": "What the action may have achieved, or what is unknown",
          "optional": true
        }
      ],
      "help": {
        "title": "If the action helped for a moment",
        "text": "You can name that honestly. Quick relief or getting a need met does not make you bad, and it does not erase later costs. Look for another response that respects the need and the situation."
      }
    },
    {
      "id": "chain-solution-analysis.practice.check",
      "title": "Check the map before choosing a change",
      "paragraphs": [
        "Look at the target, earlier conditions, prompt, links and consequences together. Is something important missing or in the wrong place? Which parts are facts, memories, guesses or unknowns?",
        "Bring important gaps and possible explanations to your therapist. A chain is a working account that can change. Do not choose a solution based on a guess about another person's hidden motive."
      ],
      "fields": [
        {
          "key": "map-questions",
          "label": "Corrections, questions or possible explanations to check",
          "optional": true
        }
      ],
      "help": {
        "title": "If the account feels like a case against you",
        "text": "Pause. This work should help find a response or support, not prove that you caused every part of the event. Harm by someone else remains their responsibility. You can ask to review this together."
      }
    },
    {
      "id": "chain-solution-analysis.practice.solutions",
      "title": "Find alternatives at specific points",
      "paragraphs": [
        "Look for points where a different action, a familiar skill or more support could have helped. Consider more than one point if useful: before the prompt, at an early link, or just before the target action. You do not have to change every link.",
        "For each option, say which point it fits and what you would actually do. \"Use a skill\" is less clear than \"Ask for a moment, then use the short question I practised.\" Keep choices within your control and current ability.",
        "With your therapist, choose one feasible response to practise first. If a new response has not been discussed or taught, keep it as a question for your session. A needed aid or boundary is not something to remove to make practice harder."
      ],
      "fields": [
        {
          "key": "change-points",
          "label": "Points where a change or support might fit",
          "optional": true
        },
        {
          "key": "alternatives",
          "label": "Possible responses matched to those points",
          "optional": true
        },
        {
          "key": "selected-response",
          "label": "The first response agreed with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If none of the options seems possible",
        "text": "You may need more teaching, a smaller step, better access or help changing the setting. That is not unwillingness. Do not force a response that puts you at risk or asks for more than you can do."
      }
    },
    {
      "id": "chain-solution-analysis.practice.rehearse",
      "title": "Rehearse the response and a backup",
      "paragraphs": [
        "Use the response your therapist has helped you practise. If comfortable, say the first words quietly, describe the action, or picture a short ordinary scene. You can skip imagery and writing. Practise the response rather than just naming a skill.",
        "Notice where you get stuck. Could shorter words, a smaller step or a different support help? Try the adjusted version if it fits, or leave it for practice with your therapist. Rehearsal is not proof the real situation will go that way.",
        "What could get in the way outside the session? Plan a feasible backup or way to pause and get help. No one else has to cooperate for you to learn that the plan needs changing."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I rehearsed, changed or want help practising",
          "optional": true
        },
        {
          "key": "barrier-backup",
          "label": "A likely obstacle and backup or support",
          "optional": true
        }
      ],
      "help": {
        "title": "If rehearsal starts to feel like reliving the episode",
        "text": "Stop. You do not need to replay upsetting details to practise a simple response. Use a neutral scene, describe the words without imagery, or wait to practise with your therapist."
      }
    },
    {
      "id": "chain-solution-analysis.practice.prevent-repair",
      "title": "Plan support before, and fair repair after",
      "paragraphs": [
        "What could make a similar moment easier before it starts? Consider a practical change, needed care, access or support. Do not treat every hard condition as something you alone must fix.",
        "Did your own action cause a problem that needs repair? With your therapist, consider a small fair step, such as acknowledging an interruption and offering to listen. No repair may be needed, or you may need advice first.",
        "Repair is not punishment or taking all the blame. Do not contact an unsafe person, make a costly promise or give up a boundary just to finish this exercise. A planned request is not sent, agreed or completed."
      ],
      "fields": [
        {
          "key": "prevention",
          "label": "Support or a practical change before next time",
          "optional": true
        },
        {
          "key": "repair",
          "label": "Any fair repair to consider, or why none is needed yet",
          "optional": true
        }
      ],
      "help": {
        "title": "If another person wants more than you can offer",
        "text": "Keep the difference between your part and their demands. You can ask your therapist for help deciding what is fair and safe. An apology does not require agreeing with an unfair claim or giving up protection."
      }
    },
    {
      "id": "chain-solution-analysis.practice.plan",
      "title": "Set the agreed use and review plan",
      "paragraphs": [
        "What ordinary cue or situation will remind you to try the response? Note the first action, needed support and limits you agreed. If the situation or risk has changed, pause and check the plan.",
        "A real attempt happens in life, not by pressing Next. You can stop, use only part, find no chance to try, or decide the plan no longer fits. Review what happened rather than forcing a result.",
        "Agree how you will review with your therapist. To come back later, choose Review my agreed response. These notes do not stay when you leave or reload; choose notes to keep first if you want a copy."
      ],
      "fields": [
        {
          "key": "action-plan",
          "label": "The cue, first action, support and limits we agreed",
          "optional": true
        },
        {
          "key": "review-plan",
          "label": "How I will review this with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If the target action happens again",
        "text": "That does not erase what you learned. Take care of any immediate needs, then review where the plan did or did not fit. Do not punish yourself or repeat the analysis until you feel certain."
      }
    },
    {
      "id": "chain-solution-analysis.practice.review",
      "title": "Review actual use, not the hoped-for result",
      "paragraphs": [
        "Recall or check the response you agreed to try. If you cannot remember, leave it open and ask your therapist. What opportunity arose, if any? What did you actually try, change, stop or not try?",
        "What happened next? What helped, made things harder or remains unclear? Keep an action you tried separate from whether someone agreed, a feeling changed or the problem ended. No chance to practise is not a failed test.",
        "Bring the result and questions to your therapist. You may revise the map, choose a different point, practise more together or change the support. Do not assume one outcome proves a cause. A new plan is not required before you finish."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "The opportunity and what I actually tried or did not try",
          "optional": true
        },
        {
          "key": "learning",
          "label": "What happened and what I learned or still do not know",
          "optional": true
        },
        {
          "key": "therapy-review",
          "label": "What I want to review or change with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If you need help now",
        "text": "Use Support and urgent help to find help options. You do not have to complete a chain first. This page is not monitored and does not send an alert to your therapist or anyone else."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan: official general skills orientation reference",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-orientation.pdf?t=1",
      "supports": "Distinguishes chain from missing-links analysis; links sequence, consequences, alternatives, prevention and repair.",
      "limits": "Professional source; not permission to reproduce handouts or electronically display worksheets. This candidate uses original words and a new ordinary example. No isolated digital or universal age validation."
    },
    {
      "id": "Rizvi and Ritschel: Mastering the Art of Chain Analysis",
      "url": "https://doi.org/10.1016/j.cbpra.2013.09.002",
      "supports": "Collaborative hypotheses, careful consequence assessment, link-specific solutions, rehearsal, outside-session planning and barrier review.",
      "limits": "Clinician paper, not a validated solo exercise. High-risk examples/transcript/figures are not reproduced or used as learner targets."
    },
    {
      "id": "Rizvi: Chain Analysis in DBT, official chapter excerpt",
      "url": "https://www.guilford.com/excerpts/rizvi_ch1.pdf?t=1",
      "supports": "Concrete target, one occurrence, chronology and distinction among core chain parts.",
      "limits": "Clinician training text with high-risk content excluded here. Original sources remain copyrighted; adaptation rights, clinical and accessibility acceptance are separate."
    },
    {
      "id": "Behavioral Tech: targeting, assessing and solving behaviours",
      "url": "https://behavioraltech.org/event/5142-getting-to-the-heart-of-the-problem-targeting-assessing-and-solving-problem-behaviors/",
      "supports": "Practitioner competence and distinction between behavioural assessment and solution analysis.",
      "limits": "Training overview is not enough by itself to author a full exercise or certify individual suitability."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Concrete target and one actual occasion",
      "componentId": "component/chain/chain-analysis",
      "sections": [
        "practice.target"
      ],
      "source": "Rizvi official chapter; Linehan orientation"
    },
    {
      "operation": "Prior vulnerability/context versus prompting event and sequential links",
      "componentId": "component/chain/chain-analysis",
      "sections": [
        "practice.before",
        "practice.prompt",
        "practice.links"
      ],
      "source": "Linehan orientation Handout7a; Rizvi and Ritschel2014"
    },
    {
      "operation": "Immediate/later consequences and revisable function hypotheses",
      "componentId": "component/chain/chain-analysis",
      "sections": [
        "practice.after",
        "practice.check"
      ],
      "source": "Rizvi and Ritschel2014 pp337,339–340"
    },
    {
      "operation": "Alternatives at specific links, first selected response, actual rehearsal and obstacles",
      "componentId": "component/chain/solution-analysis",
      "sections": [
        "practice.solutions",
        "practice.rehearse"
      ],
      "source": "Rizvi and Ritschel2014 pp340–342"
    },
    {
      "operation": "Prevention/support, proportionate repair, outside-session plan and actual review",
      "componentId": "component/chain/solution-analysis",
      "sections": [
        "practice.prevent-repair",
        "practice.plan",
        "practice.review"
      ],
      "source": "Linehan orientation Handout7a; Rizvi and Ritschel2014"
    }
  ],
  "narrationSegments": [
    {
      "id": "chain-solution-analysis.intro",
      "title": "Understand a sequence, then practise a change",
      "text": "A chain analysis looks closely at one action that happened. It maps what was going on before it, the steps leading to it and what followed. A sequence can help you ask useful questions. It does not prove why everything happened.\n\nSolution analysis is the next part. With your therapist, you find places where another response or more support could help. You practise a response, plan for hard parts and later review what really happened. The aim is learning, not blame.",
      "sha256": "5391a80285fc663c2ae2e879d719e4866da7f3bac43d756b873f50bc4d14306f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.fit",
      "title": "Start with your therapist and an ordinary episode",
      "text": "Your therapist first helps you map an example and rehearse a possible response. Between sessions, use only an ordinary, non-dangerous action and type of change you have agreed to work on. This page cannot choose a safe target for you.\n\nDo not use this page to go over self-harm, suicide, violence, trauma, alcohol or other drug use, or other high-risk acts on your own. If safety needs attention now, leave the exercise and seek help. You do not need to finish first.\n\nChoose one action you actually did, not a judgment like \"I was bad\". If the main question is why a helpful action did not happen, ask your therapist about a different method called Missing-Links Analysis. Do not invent an event to fill this page.\n\nKeep the account small enough to manage. You can leave gaps, skip writing, stop or ask for help. If the review becomes self-attack, repeated checking or distressing recall, pause and bring it to your therapist.",
      "sha256": "f13835b699e7dd2f1dfc671242febb6959f7408549c51024d5d68467d62a0343",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, contact details and private health or history details are not needed. Notes stay while you use this open tool, including its example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes to your therapist. Optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "6e70bfecb3bcbd7836482becd98270953edec7b5d688ff2d76e6267a54523bf7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.close",
      "title": "Leave the account and plan here",
      "text": "You can stop with a partial account, a question, a plan or a review. Missing detail is not a failure. A plan or rehearsal is not the same as trying the response in life.\n\nReturn to a prompt if you wish, or choose notes to keep for your session. Finish and clear removes these notes, not any copies you have kept elsewhere. Nothing is sent to your therapist.",
      "sha256": "6772c941fd95ff00861f0da69c1b9a7a1d66771837616ed1715fc75b4f308b95",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.example",
      "title": "Lee speaks over a friend while choosing a film",
      "text": "This is made up. Lee and their therapist choose one ordinary episode, not a dangerous conflict. Target action: Lee spoke over a friend twice while they were choosing a film. Lee wants to understand that action, not label themselves a bad friend.\n\nBefore: Lee was tired after a busy day and had little quiet time. That may have made the chat harder. It does not prove tiredness caused the interruption. The friend had no duty to guess what Lee needed.\n\nPrompt: The friend started describing a film they wanted to watch. Lee had not yet shared a choice. That event is different from Lee's thought, \"My ideas will not get a turn.\"\n\nLinks: Lee heard the first suggestion, thought \"I need to get in now\", felt tense and leaned forward. Lee started speaking before the friend finished. The friend paused. Lee added another suggestion over the next sentence. Some details of the timing are unclear.\n\nAfter: Lee got to name a film and felt brief relief. The friend said, \"Please let me finish.\" Later, they took longer to decide and Lee felt regret. Getting a turn may help explain why interrupting was tempting, but one episode cannot prove its purpose.\n\nSolutions: Lee and the therapist consider asking for a short quiet break before the chat; noticing the urge to jump in and pausing for a moment; or waiting for the sentence to end and asking, \"Can I suggest one too?\" They choose the last response to practise. This does not require the friend to agree with Lee's film choice.\n\nRehearsal: In the session, the therapist plays the friend and starts a suggestion. Lee practises waiting and asking for a turn. The first try feels awkward. They practise again with fewer words. If Lee loses the words, they can ask for a moment and try the short question.\n\nPrevention and repair: Lee can say when they need a short break before a chat. For the interruption, Lee plans to acknowledge speaking over the friend and offer to hear the idea when the friend is ready. That plan is not an apology already made or a promise that the friend will respond warmly.\n\nLater review: At another ordinary film chat, Lee waits for a sentence to end and asks for a turn. Lee is still tense. The friend says yes, but they still disagree about the film. Lee did use the planned response; agreement was not the goal. At the next session, Lee and the therapist review the attempt. Lee says waiting through a long sentence was hard. They rehearse a short silent cue, \"Let this sentence finish\", then the question. They keep the request for a turn and agree to try the cue next time. That revised plan has not been tried outside the session yet.",
      "sha256": "44a858db5bbcc270c9073e04a55f3f8a230576920618cc100385d8f615a9d775",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.learn",
      "title": "Different parts of the chain have different jobs",
      "text": "The target is the specific action you want to understand. Earlier conditions can make a moment harder, such as tiredness, pain, noise, pressure or missing support. These are sometimes called vulnerability factors. They are not personal faults.\n\nThe prompting event is what happened just before this sequence began. Links are the thoughts, feelings, body signals, outside events and actions along the way. What came first is not always what caused the next part.\n\nConsequences are what followed the action, right away or later. An action may meet a need or bring quick relief and still create a problem later. Check what actually happened. Do not assume what the action achieved or what another person intended.\n\nA possible explanation is a guess to check with your therapist. More information may change it. You do not need to find one hidden reason or remember every detail perfectly.\n\nSolution analysis uses the map. You consider other responses at specific points, practise a useful one, plan for barriers, and consider support or changes that could prevent the pattern. If your action caused harm, you can consider a fair repair. Repair is not punishment.\n\nThis differs from a short situation map or comparing two patterns. It works through one episode and connects a response to a point in that sequence. It also differs from Missing-Links Analysis, which asks why an agreed helpful action did not occur.\n\nYour skills are only part of the picture. Access, power, unfair treatment, health and other people's actions matter. Changing your response does not make you responsible for someone else's harm. A plan may need more support or a change in the setting.",
      "sha256": "32a14baec25d0bfdac925c701770ceaae392ba8a2c2aae9c18ea96b3607f1c81",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.target",
      "title": "Choose one action that actually happened",
      "text": "Use the ordinary target agreed with your therapist. What did you do that someone could have seen or heard? Describe the action rather than calling yourself a name. Include enough detail to know which action you mean.\n\nChoose one occasion. Note the general setting and when the action began or ended, if useful. You do not need names, an exact date or private details. Keep the focus on your action, not a judgment of the whole relationship or day.",
      "sha256": "29777138f1b097c34898ff594130d6a854fb569183c08d999cf8f9a855589f2f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.target.help",
      "title": "If the only target is something you did not do",
      "text": "Do not turn a missing action into an invented chain. Ask your therapist whether Missing-Links Analysis fits better. You can still read this example or review a response you had already agreed to try.",
      "sha256": "59b0228962aa8ceb49f79658630872ea946f12872586ae4e4e2ac282a142c055",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.before",
      "title": "Notice conditions that were already there",
      "text": "Before the sequence began, what may have made this moment harder? Consider energy, pain, stress, noise, time pressure, support or other demands. Mention only what seems relevant. You do not need health details.\n\nWhat help, care or access did you need? What was available? These conditions can matter without being the whole cause. Needing support is not a failure to use a skill.",
      "sha256": "98cc7d7ec1ed5fe46d2c026e52894a7599fefb68afc2430eee713cca4f997891",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.before.help",
      "title": "If you start blaming yourself for being tired or upset",
      "text": "Describe the condition without judging it. The question is what support or change could help, not whether you should have had fewer needs. Do not change food, medicine or health care on this page's advice.",
      "sha256": "c872725bab723d63b912df55ee92020c6d93d7812d3b1022f6dd4703354ce122",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.prompt",
      "title": "Locate the event that started this sequence",
      "text": "What happened just before the links leading to the target action? Find one outside event you could describe in time: what you saw, heard or what happened around you. Your therapist can help choose the useful starting point.\n\nKeep the event apart from what you thought it meant. \"They began to speak\" differs from \"They wanted to ignore me.\" If the starting point is unclear, say so. You do not have to force an answer.",
      "sha256": "082f2da11c7c094845fcb0d77abe267b6916117fb19227377a195e46c8b33902",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.prompt.help",
      "title": "If there seem to be several starting points",
      "text": "Pick the one you and your therapist agreed to review, or leave a question. Earlier strain belongs in the context; a later thought can be a link. This is a useful map, not proof of the one true cause.",
      "sha256": "e1476327ed104d32e485de98f9bc468d1106ee9edbbf55ea1efa92d265e9e0d7",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.links",
      "title": "Trace the steps toward the action",
      "text": "From that event, describe what happened next, then next, up to the target action. Include the thoughts, feelings, body signals, outside events and actions that seem relevant. A brief numbered list can help; there is no required number of links.\n\nBe specific enough to see a possible place for change. Keep what you remember apart from what you guess. Include a response that helped if there was one. Leave unknown gaps visible instead of filling them with a story.\n\nRead the order once if useful. Does it fit what you remember? If recalling more feels overwhelming or turns into repeated checking, stop and review the gap with your therapist.",
      "sha256": "74c9fae828baae95aa71ea86cf528ef31d9246a08e68eb1d568467e8d63f0c9f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.links.help",
      "title": "If feelings or body details are hard to name",
      "text": "Use what you do know. You may remember an action or thought more clearly. You do not have to scan your body, recreate distress or produce an emotion label to make a useful account.",
      "sha256": "5910102495469f2f54c96fa18e43be522692a93e05271e6bb0aa761e5102e7cf",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.after",
      "title": "Look at what followed, now and later",
      "text": "What happened right after the action, inside you and around you? What happened later? Include any relief, useful effect or cost you actually noticed. Do not assume how someone else felt unless they told you.\n\nWith your therapist, ask what the action may have helped you get, avoid or delay at that moment. That is a possible explanation, not a fact proved by one episode. A real need may remain even if you want to change how you met it.",
      "sha256": "7db723dd0722dffc7d4659bf07645f91d19ea5d716799665c0ab44e652ef9ba4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.after.help",
      "title": "If the action helped for a moment",
      "text": "You can name that honestly. Quick relief or getting a need met does not make you bad, and it does not erase later costs. Look for another response that respects the need and the situation.",
      "sha256": "7907db4c735a84ac156429169452b3fbf08b28a2bc2b07fd83ad011f04479723",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.check",
      "title": "Check the map before choosing a change",
      "text": "Look at the target, earlier conditions, prompt, links and consequences together. Is something important missing or in the wrong place? Which parts are facts, memories, guesses or unknowns?\n\nBring important gaps and possible explanations to your therapist. A chain is a working account that can change. Do not choose a solution based on a guess about another person's hidden motive.",
      "sha256": "c3e91cfc29542c93a8db7f3dbd1a8583b44ad34ef381f960f25f5d450912df6f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.check.help",
      "title": "If the account feels like a case against you",
      "text": "Pause. This work should help find a response or support, not prove that you caused every part of the event. Harm by someone else remains their responsibility. You can ask to review this together.",
      "sha256": "3d219ad75c19923a7e682a2ca4f5949e2e5a732a60a9c51689ac87b595c2ac60",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.solutions",
      "title": "Find alternatives at specific points",
      "text": "Look for points where a different action, a familiar skill or more support could have helped. Consider more than one point if useful: before the prompt, at an early link, or just before the target action. You do not have to change every link.\n\nFor each option, say which point it fits and what you would actually do. \"Use a skill\" is less clear than \"Ask for a moment, then use the short question I practised.\" Keep choices within your control and current ability.\n\nWith your therapist, choose one feasible response to practise first. If a new response has not been discussed or taught, keep it as a question for your session. A needed aid or boundary is not something to remove to make practice harder.",
      "sha256": "7124eb990ed99bc3d6b5cf095b9375cf526dc483a1017c28d69a1ed5ebf56a8e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.solutions.help",
      "title": "If none of the options seems possible",
      "text": "You may need more teaching, a smaller step, better access or help changing the setting. That is not unwillingness. Do not force a response that puts you at risk or asks for more than you can do.",
      "sha256": "7df3d206f51fe735d7d757fae79d696b3b6e470add95f0d6f667a4555e517300",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.rehearse",
      "title": "Rehearse the response and a backup",
      "text": "Use the response your therapist has helped you practise. If comfortable, say the first words quietly, describe the action, or picture a short ordinary scene. You can skip imagery and writing. Practise the response rather than just naming a skill.\n\nNotice where you get stuck. Could shorter words, a smaller step or a different support help? Try the adjusted version if it fits, or leave it for practice with your therapist. Rehearsal is not proof the real situation will go that way.\n\nWhat could get in the way outside the session? Plan a feasible backup or way to pause and get help. No one else has to cooperate for you to learn that the plan needs changing.",
      "sha256": "425bd301d4bc1d2c423ed0f3513816eac15e37dc33473a0ca37e4b6171892aba",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.rehearse.help",
      "title": "If rehearsal starts to feel like reliving the episode",
      "text": "Stop. You do not need to replay upsetting details to practise a simple response. Use a neutral scene, describe the words without imagery, or wait to practise with your therapist.",
      "sha256": "caf211aa1aaf75200f5610e148875ebbb42f5f2d3d43c71738dcd2c30d2ee414",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.prevent-repair",
      "title": "Plan support before, and fair repair after",
      "text": "What could make a similar moment easier before it starts? Consider a practical change, needed care, access or support. Do not treat every hard condition as something you alone must fix.\n\nDid your own action cause a problem that needs repair? With your therapist, consider a small fair step, such as acknowledging an interruption and offering to listen. No repair may be needed, or you may need advice first.\n\nRepair is not punishment or taking all the blame. Do not contact an unsafe person, make a costly promise or give up a boundary just to finish this exercise. A planned request is not sent, agreed or completed.",
      "sha256": "1fb54ea3752d5d16659f5079dffc688b9625e64fe6a985252368ad5cb1d15d30",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.prevent-repair.help",
      "title": "If another person wants more than you can offer",
      "text": "Keep the difference between your part and their demands. You can ask your therapist for help deciding what is fair and safe. An apology does not require agreeing with an unfair claim or giving up protection.",
      "sha256": "ccc93e5c413b81e873f6e0371ab8281060294bedae65c60fc40874234ee634b5",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.plan",
      "title": "Set the agreed use and review plan",
      "text": "What ordinary cue or situation will remind you to try the response? Note the first action, needed support and limits you agreed. If the situation or risk has changed, pause and check the plan.\n\nA real attempt happens in life, not by pressing Next. You can stop, use only part, find no chance to try, or decide the plan no longer fits. Review what happened rather than forcing a result.\n\nAgree how you will review with your therapist. To come back later, choose Review my agreed response. These notes do not stay when you leave or reload; choose notes to keep first if you want a copy.",
      "sha256": "649cddeec3c409a81a590deab6d300a1a172fd365a374948c063c4628ed9d8d6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.plan.help",
      "title": "If the target action happens again",
      "text": "That does not erase what you learned. Take care of any immediate needs, then review where the plan did or did not fit. Do not punish yourself or repeat the analysis until you feel certain.",
      "sha256": "2a2899691fa5dfbdbe92851f5a4e59fd460f47c19c59060e7659fe8dda89b0d2",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "chain-solution-analysis.practice.review",
      "title": "Review actual use, not the hoped-for result",
      "text": "Recall or check the response you agreed to try. If you cannot remember, leave it open and ask your therapist. What opportunity arose, if any? What did you actually try, change, stop or not try?\n\nWhat happened next? What helped, made things harder or remains unclear? Keep an action you tried separate from whether someone agreed, a feeling changed or the problem ended. No chance to practise is not a failed test.\n\nBring the result and questions to your therapist. You may revise the map, choose a different point, practise more together or change the support. Do not assume one outcome proves a cause. A new plan is not required before you finish.",
      "sha256": "7ee9b07224915e8620a038f0a9c8c73c38dfed46bce380843c2e6d07bcb77cde",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "chain-solution-analysis.practice.review.help",
      "title": "If you need help now",
      "text": "Use Support and urgent help to find help options. You do not have to complete a chain first. This page is not monitored and does not send an alert to your therapist or anyone else.",
      "sha256": "f35e1fe659f2657dc4d2865c09667ec3e09362eb6aea38dd87a86389ceeb0e36",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
