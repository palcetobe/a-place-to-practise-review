window.ContinuedSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/problem",
  "version": "2026-11-02-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "title": "Problem-Solving",
  "subtitle": "Work through a practical problem",
  "scope": "A bounded plan, try and review practice for an ordinary practical difficulty; not specialist advice, crisis management or a complete treatment programme.",
  "clinicalContract": {
    "learningObjective": "Distinguish generating alternatives from evaluating them, and a proposed action from its actual outcome.",
    "practiceObjective": "Describe a workable problem and aim; consider alternatives before choosing; compare feasibility and unknowns; plan a first action; try when appropriate; return to review what happened.",
    "observedPractice": "Private consideration or optional writing demonstrates rehearsal only. An attempt and a later review are distinct from planning. No symptom change, rating, typed response or additional task is required to finish.",
    "sourcePopulationContext": "Primary sources describe broader clinical methods, not validation of this digital adaptation or suitability across ages. Therapist selection and adaptation should account for development, communication, context, consent, privacy and safeguarding. Method-specific source populations and suitability limits still apply."
  },
  "privacy": {
    "id": "problem.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "plan",
      "review"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Exact scripts below await generation, listening and integration. Audio repair is a separate workstream; no old asset is presumed to match changed text.",
    "timer": "No timer required or proposed.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "sources": [
    {
      "id": "healthywa-problem",
      "url": "https://www.healthywa.wa.gov.au/Articles/N_R/Problem-solving",
      "reviewed": "2026-11-02",
      "supports": "Six-step sequence separates defining, generating, evaluating, deciding, implementing and evaluating outcome. Source quota15ideas is not retained; this is a bounded adaptation, not equivalent dosage."
    },
    {
      "id": "cci-problem",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Depression/Depression---Information-Sheets/Depression-Information-Sheet---13---Problem-Solving.pdf",
      "reviewed": "2026-11-02",
      "supports": "Specific problem and realistic goal, possibilities before evaluation, practical implementation and revision. Source worksheets not reproduced."
    }
  ],
  "productAdaptations": [
    "Preserves historical Alex/Jamie mixed outcome and Jo unavailable-printer review; short textual versions, not full original branch set or illustrated runtime.",
    "Adds aim explicitly and combines decision/action planning; actual implementation remains outside the tool.",
    "No15idea or3–4option quota; alternatives still taught and prompted before comparison.",
    "Plan/review modes, optional writing and no personal export; not an exact desktop port."
  ],
  "resourceId": "tool/work-through-a-practical-problem",
  "routeProposal": "tool/work-through-a-practical-problem",
  "intro": {
    "id": "problem.intro",
    "title": "Work with one practical difficulty",
    "paragraphs": [
      "Choose an ordinary difficulty with some room for action. This practice helps you make options, compare them and plan a first step, then review what actually happens.",
      "You can use a fictional problem or keep your own private. A plan does not guarantee a solution, another person’s agreement or relief."
    ],
    "actions": [
      {
        "id": "plan",
        "label": "Explore a problem and plan"
      },
      {
        "id": "review",
        "label": "Review an action I tried or planned"
      }
    ]
  },
  "fit": {
    "id": "problem.fit",
    "title": "Choose a suitable problem",
    "paragraphs": [
      "Use this with your therapist between sessions. Choose a manageable, non-urgent practical situation.",
      "For danger, coercion, safeguarding concerns, urgent needs or specialist medical, legal or financial decisions, seek appropriate help rather than relying on this exercise. Some problems need resources or cooperation you do not control. A blocked option is not personal failure."
    ]
  },
  "learn": {
    "id": "problem.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "Going over a difficulty repeatedly can feel like working on it without creating a decision to test. Problem-solving separates understanding the obstacle, making options, choosing and learning from an attempt.",
      "Give possibilities a little room before judging them. Then compare their benefits, costs, access needs and unknowns. An information question or request for support can be a first action.",
      "Review uses what actually happened. If one route is blocked, that does not prove every route is blocked. Keeping, changing, seeking help or pausing can each be a reasonable result of review."
    ]
  },
  "example": {
    "id": "problem.example",
    "title": "Example — Alex and Jamie share a task",
    "paragraphs": [
      "Alex and Jamie share a home. With no agreed dinner and cleanup arrangement, Alex did both on three evenings this week. Alex wants a workable arrangement, not a guarantee that Jamie will agree or that frustration will disappear.",
      "Alex considers alternating both tasks, dividing cooking and cleanup, or agreeing separate meals on busy days. Alternating could share the work, but requires agreement and a fallback for late work nights.",
      "Alex chooses to discuss alternating and a fallback at a suitable time. Jamie agrees to try alternating. Several evenings work; on a late work night, cleanup is missed because the fallback was not settled.",
      "In review, Alex notices what worked and what remains unclear. Alex can ask to discuss a realistic late-night fallback, reconsider the arrangement or seek support. The mixed result is not treated as total success or failure."
    ]
  },
  "practiceScenario": {
    "id": "problem.scenario",
    "title": "Optional fictional practice — Jo",
    "paragraphs": [
      "Jo agreed to bring a printed poem to a club on Friday, but the home printer broke. Jo has a digital copy and can reach the library on Thursday; its printing service and cost are unknown. Jo can ask the organiser, using an accessible method, whether another way of sharing would fit. No answer is known.",
      "Use Jo while planning, invent a manageable difficulty, or use your own. Your answer does not send a message, book a service or make anything happen in the story."
    ]
  },
  "plan": [
    {
      "id": "problem.plan.define",
      "title": "Describe the practical difficulty",
      "paragraphs": [
        "What is happening, when, and what makes it difficult? Describe the situation rather than deciding what it says about a person. What part might change?"
      ],
      "fields": [
        {
          "key": "problem",
          "label": "The practical difficulty",
          "optional": true
        }
      ],
      "help": {
        "title": "If the question has no workable action",
        "text": "A demand to know the future or control another person may not be a solvable problem. You can leave it open and discuss the fit with your therapist rather than force a solution."
      }
    },
    {
      "id": "problem.plan.aim",
      "title": "Choose a useful aim",
      "paragraphs": [
        "What realistic change would help? Keep another person’s agreement and any missing resources separate from what you can choose."
      ],
      "fields": [
        {
          "key": "aim",
          "label": "A useful change to work towards",
          "optional": true
        }
      ],
      "help": {
        "title": "If the whole problem is beyond your control",
        "text": "Choose a part, a question or a source of help if useful. You do not have to solve a structural or shared problem on your own."
      }
    },
    {
      "id": "problem.plan.options",
      "title": "Make room for different options",
      "paragraphs": [
        "Before deciding, consider different ways forward. Could you change the approach, get information or ask for support? You can note possibilities before comparing them.",
        "Try to make room for an alternative rather than treating the first idea as settled. There is no required number to type."
      ],
      "fields": [
        {
          "key": "options",
          "label": "Possible ways forward",
          "optional": true
        }
      ],
      "help": {
        "title": "If only one idea comes to mind",
        "text": "Keep it as a possibility, not a guaranteed solution. A question about access, availability or cooperation can help you discover other options."
      }
    },
    {
      "id": "problem.plan.compare",
      "title": "Compare what each option needs",
      "paragraphs": [
        "For the options worth considering, what are the possible benefits, drawbacks and requirements? What is known and what still needs checking?",
        "Choose a feasible first action or information question, or leave the choice open. Do not assume a service is available or another person has agreed."
      ],
      "fields": [
        {
          "key": "comparison",
          "label": "Benefits, limits and unknowns",
          "optional": true
        },
        {
          "key": "choice",
          "label": "An option or question to take forward",
          "optional": true
        }
      ],
      "help": {
        "title": "If every option has a drawback",
        "text": "You do not need a perfect answer. Consider what is acceptable and possible, or seek support rather than choosing something unsafe or unworkable."
      }
    },
    {
      "id": "problem.plan.action",
      "title": "Plan a first action and a review",
      "paragraphs": [
        "What would you do, when might it fit, and what preparation or support is needed? When would it make sense to review what happened?",
        "Try it away from this page when appropriate, or pause. Returning here does not mean the action occurred; use review whether you tried, partly tried or could not begin."
      ],
      "fields": [
        {
          "key": "action",
          "label": "A first action and what it needs",
          "optional": true
        },
        {
          "key": "reviewPoint",
          "label": "When I might review, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "Keeping the plan",
        "text": "Remember it or note it privately off this tool. Nothing here is scheduled, saved across visits or sent to your therapist."
      }
    }
  ],
  "review": [
    {
      "id": "problem.review.happened",
      "title": "What actually happened?",
      "paragraphs": [
        "Bring the planned action to mind. Did you try it, partly try, or not get to it? What changed and what remains unknown?"
      ],
      "fields": [
        {
          "key": "happened",
          "label": "The action and actual result",
          "optional": true
        }
      ],
      "help": {
        "title": "A fictional review if using Jo",
        "text": "Suppose Jo checks and staff confirm the library cannot print before Friday. The organiser has not replied. These are supplied story facts, not an action you took. Review the affected option without inventing an answer from the organiser."
      }
    },
    {
      "id": "problem.review.revise",
      "title": "What would you keep or change?",
      "paragraphs": [
        "Which part of the plan does the result affect? Consider keeping a workable part, revising an option, asking for help or leaving the decision open.",
        "If the original problem still needs attention, you can revisit the options later. You do not need a new plan to finish today."
      ],
      "fields": [
        {
          "key": "revision",
          "label": "Something to keep, change or ask",
          "optional": true
        }
      ],
      "help": {
        "title": "If one route is blocked",
        "text": "For Jo, library printing is unavailable in time. A different way of sharing still needs an answer; silence is not permission. You can retain an unaffected possibility with its unknowns rather than declaring every option failed."
      }
    }
  ],
  "close": {
    "id": "problem.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "A plan, an attempt and a review are different. You may leave with an action, a question, a reason to seek support, or nothing decided. No solution or new task is required to finish."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "narrationSegments": [
    {
      "id": "problem.intro",
      "title": "Work with one practical difficulty",
      "text": "Choose an ordinary difficulty with some room for action. This practice helps you make options, compare them and plan a first step, then review what actually happens.\n\nYou can use a fictional problem or keep your own private. A plan does not guarantee a solution, another person’s agreement or relief.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.fit",
      "title": "Choose a suitable problem",
      "text": "Use this with your therapist between sessions. Choose a manageable, non-urgent practical situation.\n\nFor danger, coercion, safeguarding concerns, urgent needs or specialist medical, legal or financial decisions, seek appropriate help rather than relying on this exercise. Some problems need resources or cooperation you do not control. A blocked option is not personal failure.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.learn",
      "title": "Why this skill may help",
      "text": "Going over a difficulty repeatedly can feel like working on it without creating a decision to test. Problem-solving separates understanding the obstacle, making options, choosing and learning from an attempt.\n\nGive possibilities a little room before judging them. Then compare their benefits, costs, access needs and unknowns. An information question or request for support can be a first action.\n\nReview uses what actually happened. If one route is blocked, that does not prove every route is blocked. Keeping, changing, seeking help or pausing can each be a reasonable result of review.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.example",
      "title": "Example — Alex and Jamie share a task",
      "text": "Alex and Jamie share a home. With no agreed dinner and cleanup arrangement, Alex did both on three evenings this week. Alex wants a workable arrangement, not a guarantee that Jamie will agree or that frustration will disappear.\n\nAlex considers alternating both tasks, dividing cooking and cleanup, or agreeing separate meals on busy days. Alternating could share the work, but requires agreement and a fallback for late work nights.\n\nAlex chooses to discuss alternating and a fallback at a suitable time. Jamie agrees to try alternating. Several evenings work; on a late work night, cleanup is missed because the fallback was not settled.\n\nIn review, Alex notices what worked and what remains unclear. Alex can ask to discuss a realistic late-night fallback, reconsider the arrangement or seek support. The mixed result is not treated as total success or failure.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.scenario",
      "title": "Optional fictional practice — Jo",
      "text": "Jo agreed to bring a printed poem to a club on Friday, but the home printer broke. Jo has a digital copy and can reach the library on Thursday; its printing service and cost are unknown. Jo can ask the organiser, using an accessible method, whether another way of sharing would fit. No answer is known.\n\nUse Jo while planning, invent a manageable difficulty, or use your own. Your answer does not send a message, book a service or make anything happen in the story.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.plan.define",
      "title": "Describe the practical difficulty",
      "text": "What is happening, when, and what makes it difficult? Describe the situation rather than deciding what it says about a person. What part might change?",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.plan.define.help",
      "title": "If the question has no workable action",
      "text": "A demand to know the future or control another person may not be a solvable problem. You can leave it open and discuss the fit with your therapist rather than force a solution.",
      "status": "Script only"
    },
    {
      "id": "problem.plan.aim",
      "title": "Choose a useful aim",
      "text": "What realistic change would help? Keep another person’s agreement and any missing resources separate from what you can choose.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.plan.aim.help",
      "title": "If the whole problem is beyond your control",
      "text": "Choose a part, a question or a source of help if useful. You do not have to solve a structural or shared problem on your own.",
      "status": "Script only"
    },
    {
      "id": "problem.plan.options",
      "title": "Make room for different options",
      "text": "Before deciding, consider different ways forward. Could you change the approach, get information or ask for support? You can note possibilities before comparing them.\n\nTry to make room for an alternative rather than treating the first idea as settled. There is no required number to type.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.plan.options.help",
      "title": "If only one idea comes to mind",
      "text": "Keep it as a possibility, not a guaranteed solution. A question about access, availability or cooperation can help you discover other options.",
      "status": "Script only"
    },
    {
      "id": "problem.plan.compare",
      "title": "Compare what each option needs",
      "text": "For the options worth considering, what are the possible benefits, drawbacks and requirements? What is known and what still needs checking?\n\nChoose a feasible first action or information question, or leave the choice open. Do not assume a service is available or another person has agreed.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.plan.compare.help",
      "title": "If every option has a drawback",
      "text": "You do not need a perfect answer. Consider what is acceptable and possible, or seek support rather than choosing something unsafe or unworkable.",
      "status": "Script only"
    },
    {
      "id": "problem.plan.action",
      "title": "Plan a first action and a review",
      "text": "What would you do, when might it fit, and what preparation or support is needed? When would it make sense to review what happened?\n\nTry it away from this page when appropriate, or pause. Returning here does not mean the action occurred; use review whether you tried, partly tried or could not begin.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.plan.action.help",
      "title": "Keeping the plan",
      "text": "Remember it or note it privately off this tool. Nothing here is scheduled, saved across visits or sent to your therapist.",
      "status": "Script only"
    },
    {
      "id": "problem.review.happened",
      "title": "What actually happened?",
      "text": "Bring the planned action to mind. Did you try it, partly try, or not get to it? What changed and what remains unknown?",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.review.happened.help",
      "title": "A fictional review if using Jo",
      "text": "Suppose Jo checks and staff confirm the library cannot print before Friday. The organiser has not replied. These are supplied story facts, not an action you took. Review the affected option without inventing an answer from the organiser.",
      "status": "Script only"
    },
    {
      "id": "problem.review.revise",
      "title": "What would you keep or change?",
      "text": "Which part of the plan does the result affect? Consider keeping a workable part, revising an option, asking for help or leaving the decision open.\n\nIf the original problem still needs attention, you can revisit the options later. You do not need a new plan to finish today.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.review.revise.help",
      "title": "If one route is blocked",
      "text": "For Jo, library printing is unavailable in time. A different way of sharing still needs an answer; silence is not permission. You can retain an unaffected possibility with its unknowns rather than declaring every option failed.",
      "status": "Script only"
    },
    {
      "id": "problem.close",
      "title": "Leave it here for now",
      "text": "A plan, an attempt and a review are different. You may leave with an action, a question, a reason to seek support, or nothing decided. No solution or new task is required to finish.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "problem.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    }
  ]
}
;
