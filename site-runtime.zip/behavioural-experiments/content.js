window.BehaviouralExperimentContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/experiment",
  "resourceId": "tool/behavioural-experiments",
  "routeProposal": "/behavioural-experiments/",
  "title": "Behavioural Experiments",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Test one prediction with a small plan you and your therapist have agreed.",
  "groupedSetStatus": "One existing canonical entry, classic/experiment. This general procedure does not complete condition-specific experiments, exposure treatment, metacognitive experiments or appearance-checking variants. No new catalogue count.",
  "clinicalContract": {
    "sourcePopulationContext": "Therapist-introduced and individually adapted. These sources establish no universal age cutoff or all-age validation. Development, safeguarding, communication, health and access needs require individual review.",
    "learningObjective": "Distinguish a prediction from an observable outcome, and learn from a bounded real-world test without requiring a favourable result.",
    "practiceObjective": "Specify the belief and evidence, preserve a co-designed test and protections, record the actual attempt or non-attempt, compare evidence and review learning with the therapist.",
    "exclusions": [
      "Actual danger, coercion or intentional humiliation",
      "Violating health advice or removing needed protections or disability supports",
      "Self-directed trauma, interoceptive exposure or response prevention",
      "Experiments involving eating, medication, substances, abusive relationships or crisis management"
    ],
    "reviewGates": [
      "Clinician review of client language, source fidelity, ordinary example and bounded fit",
      "Individual developmental, medical, safeguarding and access fit",
      "Review adverse-result handling and stopping/support wording",
      "Exact-script listening and runtime/media binding acceptance before narration",
      "Desktop/mobile/keyboard/screen-reader and release integration checks"
    ],
    "adaptations": [
      "Original wording and example; no publisher handout reproduced",
      "Belief ratings optional with words or numbers; not claimed as source wording",
      "No distress rating or required reduction",
      "Explicit no-attempt, changed-plan, ambiguous and adverse results",
      "No automated safety assessment or outcome verdict",
      "Session-only notes and explicit selected-note export"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use a test agreed with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Plan my agreed test",
          "startSectionId": "behavioural-experiments.practice.prediction"
        },
        {
          "value": "review",
          "label": "Review my agreed test",
          "startSectionId": "behavioural-experiments.practice.observation"
        }
      ]
    },
    "entryGate": "Both entries require an explicit choice from visible therapist-agreed fit text. Neither choice certifies safety. Example/Learn/Finish/support remain available with no entry choice.",
    "focus": "One meaningful prompt group; free jump, Show all, Previous and Finish. No forced writing or completion locks.",
    "reviewAccess": "Review is available from the outset, including no attempt, stopped attempt or changed plan. No attempt checkbox or result inference.",
    "writing": "Hidden and optional by default. Never prefill fiction. Hide removes every private display and invalidates export preview.",
    "persistence": "Memory in this open tool only. Internal reading/navigation retain notes. Leaving, reloading, clear, restart, history navigation or BFCache return clears them. Offscreen visibility alone retains them.",
    "export": "Separate explicit note selection, exact preview, then copy or download. Editing, hiding or mode changes invalidate selection. No default selection.",
    "narration": "Exact authored static paragraph/help scopes only. Scripts are prepared, no recordings present, no Audio/TTS and no automatic speech.",
    "timer": "None. Real-world timing comes from the therapist-agreed plan, not the app.",
    "completion": "No success, completed, attempted, mood-improvement, score or streak state."
  },
  "intro": {
    "id": "behavioural-experiments.intro",
    "title": "Test one prediction",
    "paragraphs": [
      "A prediction is a guess about what will happen. It can feel like a fact. A behavioural experiment checks one guess by trying a small, planned test.",
      "You and your therapist choose the test and its limits first. Here you can plan it, read an example, or review what happened. The aim is to learn. You do not have to prove your guess wrong or feel less worried."
    ]
  },
  "fit": {
    "id": "behavioural-experiments.fit",
    "title": "Before using your own test",
    "paragraphs": [
      "Use a small test that you and your therapist have agreed. Check what to do, what to watch for, and when to stop or seek help. This page cannot decide whether a test fits you.",
      "Do not use this page for danger, abuse, harm, or a test that breaks health advice. Do not change food, medicine or substance use, or bring back a traumatic event as a test here.",
      "Keep the care, aids and support you need. Do not drop real safeguards to make a test harder. If the plan no longer fits, pause and check with your therapist.",
      "No agreed test yet? You can read the example or learn about the skill. You do not need to try a test today."
    ]
  },
  "privacy": {
    "id": "behavioural-experiments.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Notes stay while you use this open tool, including its example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes to your therapist or read them aloud. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "behavioural-experiments.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can stop after reading, planning, reviewing, or choosing not to do a test. A plan is not an attempt. An unclear result is not a failure.",
      "You can return to the prompts or choose notes to keep for your next session. Finish and clear removes the notes in this tool. It does not remove a copy you kept elsewhere."
    ]
  },
  "example": {
    "id": "behavioural-experiments.example",
    "title": "Robin asks where to find a book",
    "paragraphs": [
      "This is a made-up example, not a test you need to copy. Robin and their therapist agree on one small test during a usual library visit.",
      "Prediction: \"If I ask where the travel books are, the staff member will say I should know and refuse to help.\" Robin feels very sure. Another possible result is that the staff member will point out the shelf.",
      "Plan: Robin will ask one staff member at the help desk when they are free. Robin and their therapist agree that Robin can read the question from a note. This page does not ask Robin to give up that support.",
      "Evidence: Robin will notice the words and actions they can hear and see. They cannot know what the staff member thinks. If the desk is closed or staff cannot talk, the test may not give an answer.",
      "Attempt: Robin asks once. The staff member says, \"It is on the next floor,\" and points to the lift. Robin still feels nervous.",
      "Review: The person gave directions and did not say Robin should know. That does not fit the refusal Robin predicted. Feeling nervous does not change those facts.",
      "Learning: \"In this visit, I asked a question and got help. I cannot know how every person will respond.\" Robin feels less sure of the first prediction and will discuss the result in therapy.",
      "If the reply had been rude, Robin would not need to call it a good result. They could note the words, get support if needed, and review the test. One reply would not prove anything about Robin's worth."
    ]
  },
  "learn": {
    "id": "behavioural-experiments.learn",
    "title": "Why test a prediction?",
    "paragraphs": [
      "A strong guess can shape what we do. We may avoid a step and never get to see what happens. A small, agreed test can add new facts to the picture.",
      "First name the guess. Then agree what you will do and what you could notice. Afterward, compare the real result with the guess. Notice what the test still cannot tell you.",
      "This differs from just doing more activities. The test asks a clear question and looks for facts that help answer it. It is not a demand to push through fear or prove that nothing bad can happen.",
      "People sometimes do things to prevent a feared result. The reason for an action matters. An aid, a support person or a health step may be needed. This page cannot judge that. Only change your plan or supports with the right clinical advice.",
      "A result may fit the guess, not fit it, fit only part, or leave the question open. You do not need a positive answer. If something hurtful or unsafe happened, take it seriously and seek the help you need.",
      "You can rate how sure you feel before and after, with words or a number. That is not a test score. The rating can stay the same. Talk with your therapist before changing the plan or trying another test."
    ]
  },
  "practice": [
    {
      "id": "behavioural-experiments.practice.prediction",
      "title": "Name one prediction",
      "paragraphs": [
        "Bring to mind the small test you agreed with your therapist. What do you think will happen? Try: \"If I do this, then this will happen.\" Keep to one guess.",
        "If useful, note how sure you feel: a little, fairly or very sure. Or use 0 to 100, where 0 means not at all sure and 100 means fully sure. You can skip this."
      ],
      "fields": [
        {
          "key": "prediction",
          "label": "My prediction",
          "optional": true
        },
        {
          "key": "belief-before",
          "label": "How sure I feel before",
          "optional": true
        }
      ],
      "help": {
        "title": "If the guess is too broad",
        "text": "\"It will go badly\" is hard to check. Name what you expect to see or hear. Ask your therapist to help make a broad fear into one clear test."
      }
    },
    {
      "id": "behavioural-experiments.practice.evidence",
      "title": "Choose what you could notice",
      "paragraphs": [
        "What would you see or hear if your guess happened? What might you notice if it did not? Think of another possible result too. Do this before the test.",
        "Keep facts apart from guesses about other people's thoughts. A look or a pause can have more than one meaning. Some results will not give a clear answer."
      ],
      "fields": [
        {
          "key": "evidence-for",
          "label": "What would fit my prediction",
          "optional": true
        },
        {
          "key": "evidence-against",
          "label": "What would not fit it",
          "optional": true
        },
        {
          "key": "other-result",
          "label": "Another possible result",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot read the result",
        "text": "You may not be able to test \"They will think I am foolish\". You could discuss a clear action or spoken response to notice instead. Do not treat silence or a facial expression as proof of a private thought."
      }
    },
    {
      "id": "behavioural-experiments.practice.plan",
      "title": "Set out the agreed test",
      "paragraphs": [
        "What small action did you agree to try? Note where, when, and for how long or how often, as set out in your plan. What will you watch for?",
        "Keep the support, aids and safeguards you need. Do not remove them on this page's advice. If a change is part of your test, check that exact change with your therapist first."
      ],
      "fields": [
        {
          "key": "test-plan",
          "label": "The action, place and time we agreed",
          "optional": true
        },
        {
          "key": "observe-plan",
          "label": "What I will watch for",
          "optional": true
        },
        {
          "key": "supports",
          "label": "Supports and safeguards to keep",
          "optional": true
        }
      ],
      "help": {
        "title": "If the plan feels too big",
        "text": "You can pause. Discuss a smaller test, more support or a different plan with your therapist. This page does not ask you to test danger, ignore health advice or let someone mistreat you."
      }
    },
    {
      "id": "behavioural-experiments.practice.limits",
      "title": "Plan for a change or a hard moment",
      "paragraphs": [
        "What could get in the way of the agreed test? Decide how to handle that with your therapist. Check when to stop, who to ask for help, and how you will review the result.",
        "If the setting, your needs or the risks have changed, do not press on just to finish. Pause and check the plan. You do not need to stay in an unsafe situation to finish a test."
      ],
      "fields": [
        {
          "key": "obstacles",
          "label": "What could get in the way",
          "optional": true
        },
        {
          "key": "stop-support",
          "label": "When to stop and how to get support",
          "optional": true
        },
        {
          "key": "review-plan",
          "label": "How I will review this with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If you need help now",
        "text": "You can leave the test. Use the Support and urgent help link at any time. No one monitors these notes, and they are not sent to your therapist."
      }
    },
    {
      "id": "behavioural-experiments.practice.try",
      "title": "Try it only when the plan fits",
      "paragraphs": [
        "The real test happens in your life, not by pressing Next. Use the plan you agreed. Notice what happens without trying to force one answer.",
        "You can stop or change course when needed. Do not repeat a test just to make your fear or rating go down. Note any change to the plan when you review.",
        "You can leave this page and return later to Review my agreed test. Notes are not saved when you leave or reload. If you want a copy, use Choose notes to keep first."
      ],
      "help": {
        "title": "If you did not try it",
        "text": "You can still go to the review prompts. Not trying a test is not evidence that your prediction came true. A barrier, a change of plan or a choice to stop can be worth discussing."
      }
    },
    {
      "id": "behavioural-experiments.practice.observation",
      "title": "Describe what really happened",
      "paragraphs": [
        "Did you try the agreed test, try part, change it, or not try it? You can review any of these. There is no completion check to pass.",
        "If you tried it, what did you actually do? What did you see or hear? Note useful facts and any change to the plan. You can note how you felt too. Keep that apart from guesses about what other people thought.",
        "If you did not try it, leave the result open. You can note what got in the way or why the plan did not fit. Do not invent an outcome."
      ],
      "fields": [
        {
          "key": "attempt-account",
          "label": "What I did, changed or did not try",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What I actually saw or heard",
          "optional": true
        },
        {
          "key": "feelings",
          "label": "What I felt",
          "optional": true
        }
      ],
      "help": {
        "title": "If the result was hurtful or unsafe",
        "text": "Name what happened without forcing a positive meaning. Stop the test and seek the support you need. Review it with your therapist before another test. This page is not a crisis plan."
      }
    },
    {
      "id": "behavioural-experiments.practice.compare",
      "title": "Compare the result with the prediction",
      "paragraphs": [
        "Look back at your first guess and the facts you planned to notice. Does the result fit the guess, not fit it, fit part of it, or leave you unsure?",
        "What supports your view? What points another way? What can this one test not tell you? If the plan changed, that may change what you can learn from it.",
        "No attempt, no clear chance to observe, or too little information can mean there is no answer yet. You do not need to turn that into a good or bad result."
      ],
      "fields": [
        {
          "key": "comparison",
          "label": "How the facts compare with my prediction",
          "optional": true
        },
        {
          "key": "limits",
          "label": "What this test cannot tell me",
          "optional": true
        }
      ],
      "help": {
        "title": "If the feared result happened",
        "text": "Take the facts seriously. Check how much of the prediction they support, what they do not show, and what help you need. You do not have to explain away harm or blame yourself."
      }
    },
    {
      "id": "behavioural-experiments.practice.learning",
      "title": "Keep the learning and review the next step",
      "paragraphs": [
        "What have you learned, if anything, from this one test? Try a fair statement that fits the facts. \"I do not know yet\" is a valid answer.",
        "If useful, note how sure you feel about the first prediction now. Use the same words or scale as before. You do not have to feel less sure.",
        "Bring the result, any barriers and any questions to your therapist. Review whether to keep, change or stop the plan before a new test. A repeat is not required."
      ],
      "fields": [
        {
          "key": "learning",
          "label": "What I learned or still do not know",
          "optional": true
        },
        {
          "key": "belief-after",
          "label": "How sure I feel now",
          "optional": true
        },
        {
          "key": "therapy-review",
          "label": "What I want to review with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want notes for your next session",
        "text": "Choose notes to keep lets you select and check just the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy."
      }
    }
  ],
  "sources": [
    {
      "id": "CCI Behavioural Experiment Monitoring",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Anxiety/Anxiety---Worksheets/Anxiety-Worksheet---10---Behavioural-experiment.pdf",
      "supports": "Prediction, belief rating, planned test, observable evidence, actual outcome and learning.",
      "limits": "Procedure evidence, not app validation or permission to reproduce the worksheet. Ratings are optional in this adaptation."
    },
    {
      "id": "CCI Behavioural Experiments Negative Predictions",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Anxiety/Anxiety---Information-Sheets/Anxiety-Information-Sheet---05---Behavioural-Experiments-Negative-Predictions.pdf",
      "supports": "Alternative predictions, specific logistics, manageable tests, obstacles and review.",
      "limits": "Generic clinical information does not establish individual fit or an all-age digital programme."
    },
    {
      "id": "CCI What are Safety Behaviours",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Anxiety/Anxiety---Information-Sheets/Anxiety-Information-Sheet---07-What-are-Safety-Behaviours.pdf",
      "supports": "The purpose and context of an action matter in identifying safety behaviours.",
      "limits": "The explicit protection/disability-support safeguard here is a conservative adaptation, not a validated source checklist."
    },
    {
      "id": "Beck Institute The New Homework in Cognitive Behavior Therapy",
      "url": "https://beckinstitute.org/blog/the-new-homework-in-cognitive-behavior-therapy/",
      "supports": "Collaborative action plans, specific practical planning and non-punitive review of barriers.",
      "limits": "Source-informed teaching; no guarantee of outcomes, clinical acceptance or digital efficacy."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Prediction and optional confidence",
      "sections": [
        "practice.prediction"
      ],
      "source": "Original book p117; CCI worksheet"
    },
    {
      "operation": "Observable evidence and alternative",
      "sections": [
        "practice.evidence"
      ],
      "source": "Original book p117; CCI worksheet and information sheet"
    },
    {
      "operation": "Bounded agreed test, logistics and obstacles",
      "sections": [
        "practice.plan",
        "practice.limits"
      ],
      "source": "Original book p117; CCI information sheet; Beck action plans"
    },
    {
      "operation": "Actual attempt distinguished from planning",
      "sections": [
        "practice.try",
        "practice.observation"
      ],
      "source": "Original book p118; CCI actual outcome; Beck review"
    },
    {
      "operation": "Compare evidence and preserve limits/adverse results",
      "sections": [
        "practice.compare"
      ],
      "source": "CCI evidence comparison; explicit conservative product safeguards"
    },
    {
      "operation": "Learning and optional rating/review",
      "sections": [
        "practice.learning"
      ],
      "source": "Original book p118; CCI learning/rerating; Beck review"
    }
  ],
  "narrationSegments": [
    {
      "id": "behavioural-experiments.intro",
      "title": "Test one prediction",
      "text": "A prediction is a guess about what will happen. It can feel like a fact. A behavioural experiment checks one guess by trying a small, planned test.\n\nYou and your therapist choose the test and its limits first. Here you can plan it, read an example, or review what happened. The aim is to learn. You do not have to prove your guess wrong or feel less worried.",
      "sha256": "90213258a0dc85af9b180712bf8f1733d229199259f8b4cd13eed63634cfb0f6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.fit",
      "title": "Before using your own test",
      "text": "Use a small test that you and your therapist have agreed. Check what to do, what to watch for, and when to stop or seek help. This page cannot decide whether a test fits you.\n\nDo not use this page for danger, abuse, harm, or a test that breaks health advice. Do not change food, medicine or substance use, or bring back a traumatic event as a test here.\n\nKeep the care, aids and support you need. Do not drop real safeguards to make a test harder. If the plan no longer fits, pause and check with your therapist.\n\nNo agreed test yet? You can read the example or learn about the skill. You do not need to try a test today.",
      "sha256": "8743bec30171a4a46ace02c3aab607d5f772707be2391ac01659ea84fd53934f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Notes stay while you use this open tool, including its example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes to your therapist or read them aloud. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "1e88da270c07f8e69e9f6fd5173370fd884c51ca8ab2ab675b9841fbd1331445",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.close",
      "title": "Leave the practice here",
      "text": "You can stop after reading, planning, reviewing, or choosing not to do a test. A plan is not an attempt. An unclear result is not a failure.\n\nYou can return to the prompts or choose notes to keep for your next session. Finish and clear removes the notes in this tool. It does not remove a copy you kept elsewhere.",
      "sha256": "73b905e5627a8c7a67d39a30708514bd4307f3bc06b0c177f78023f86780519e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.example",
      "title": "Robin asks where to find a book",
      "text": "This is a made-up example, not a test you need to copy. Robin and their therapist agree on one small test during a usual library visit.\n\nPrediction: \"If I ask where the travel books are, the staff member will say I should know and refuse to help.\" Robin feels very sure. Another possible result is that the staff member will point out the shelf.\n\nPlan: Robin will ask one staff member at the help desk when they are free. Robin and their therapist agree that Robin can read the question from a note. This page does not ask Robin to give up that support.\n\nEvidence: Robin will notice the words and actions they can hear and see. They cannot know what the staff member thinks. If the desk is closed or staff cannot talk, the test may not give an answer.\n\nAttempt: Robin asks once. The staff member says, \"It is on the next floor,\" and points to the lift. Robin still feels nervous.\n\nReview: The person gave directions and did not say Robin should know. That does not fit the refusal Robin predicted. Feeling nervous does not change those facts.\n\nLearning: \"In this visit, I asked a question and got help. I cannot know how every person will respond.\" Robin feels less sure of the first prediction and will discuss the result in therapy.\n\nIf the reply had been rude, Robin would not need to call it a good result. They could note the words, get support if needed, and review the test. One reply would not prove anything about Robin's worth.",
      "sha256": "f2e260ee0b087d3d7826328a47e69f87c2415373c26666d733dd92c0bbaf94dd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.learn",
      "title": "Why test a prediction?",
      "text": "A strong guess can shape what we do. We may avoid a step and never get to see what happens. A small, agreed test can add new facts to the picture.\n\nFirst name the guess. Then agree what you will do and what you could notice. Afterward, compare the real result with the guess. Notice what the test still cannot tell you.\n\nThis differs from just doing more activities. The test asks a clear question and looks for facts that help answer it. It is not a demand to push through fear or prove that nothing bad can happen.\n\nPeople sometimes do things to prevent a feared result. The reason for an action matters. An aid, a support person or a health step may be needed. This page cannot judge that. Only change your plan or supports with the right clinical advice.\n\nA result may fit the guess, not fit it, fit only part, or leave the question open. You do not need a positive answer. If something hurtful or unsafe happened, take it seriously and seek the help you need.\n\nYou can rate how sure you feel before and after, with words or a number. That is not a test score. The rating can stay the same. Talk with your therapist before changing the plan or trying another test.",
      "sha256": "fa1ddef6f83964f989285a7a5a95a6b26335fd3bf0999f52e8e0ece7202c369c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.prediction",
      "title": "Name one prediction",
      "text": "Bring to mind the small test you agreed with your therapist. What do you think will happen? Try: \"If I do this, then this will happen.\" Keep to one guess.\n\nIf useful, note how sure you feel: a little, fairly or very sure. Or use 0 to 100, where 0 means not at all sure and 100 means fully sure. You can skip this.",
      "sha256": "ccbd76f8219f0352da6f3f1c85fb6fed245799aa0ec182baf9144d3577be2034",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.prediction.help",
      "title": "If the guess is too broad",
      "text": "\"It will go badly\" is hard to check. Name what you expect to see or hear. Ask your therapist to help make a broad fear into one clear test.",
      "sha256": "7af794c437c9a7c513819d77f9ccecc6379493ff8dbf690dd673da34dedc8c6f",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "behavioural-experiments.practice.evidence",
      "title": "Choose what you could notice",
      "text": "What would you see or hear if your guess happened? What might you notice if it did not? Think of another possible result too. Do this before the test.\n\nKeep facts apart from guesses about other people's thoughts. A look or a pause can have more than one meaning. Some results will not give a clear answer.",
      "sha256": "24d556cccbf70267b554c70445da73766792513951c5d237188ee40fb289de06",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.evidence.help",
      "title": "If you cannot read the result",
      "text": "You may not be able to test \"They will think I am foolish\". You could discuss a clear action or spoken response to notice instead. Do not treat silence or a facial expression as proof of a private thought.",
      "sha256": "d4270686e4190e12bdb968d0d80489e9500603d1b676a911aa4f4df5ee96dac2",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "behavioural-experiments.practice.plan",
      "title": "Set out the agreed test",
      "text": "What small action did you agree to try? Note where, when, and for how long or how often, as set out in your plan. What will you watch for?\n\nKeep the support, aids and safeguards you need. Do not remove them on this page's advice. If a change is part of your test, check that exact change with your therapist first.",
      "sha256": "ad3a68f36e33e9d3371282b71a51d77839d82f579ee8fcda43128f2ea2334929",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.plan.help",
      "title": "If the plan feels too big",
      "text": "You can pause. Discuss a smaller test, more support or a different plan with your therapist. This page does not ask you to test danger, ignore health advice or let someone mistreat you.",
      "sha256": "cf43811a407b398d413e798a17b3111956648ee9a6f954d32f9a16cc9bcb72ef",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "behavioural-experiments.practice.limits",
      "title": "Plan for a change or a hard moment",
      "text": "What could get in the way of the agreed test? Decide how to handle that with your therapist. Check when to stop, who to ask for help, and how you will review the result.\n\nIf the setting, your needs or the risks have changed, do not press on just to finish. Pause and check the plan. You do not need to stay in an unsafe situation to finish a test.",
      "sha256": "27da30655e5bcb700abd630b8bdffaae2418e308e9d91723820e28d301c574bc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.limits.help",
      "title": "If you need help now",
      "text": "You can leave the test. Use the Support and urgent help link at any time. No one monitors these notes, and they are not sent to your therapist.",
      "sha256": "642a4b6d7dffe4805804854a01d80e3752c674af76cb6f4c270afcfcbc72167c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "behavioural-experiments.practice.try",
      "title": "Try it only when the plan fits",
      "text": "The real test happens in your life, not by pressing Next. Use the plan you agreed. Notice what happens without trying to force one answer.\n\nYou can stop or change course when needed. Do not repeat a test just to make your fear or rating go down. Note any change to the plan when you review.\n\nYou can leave this page and return later to Review my agreed test. Notes are not saved when you leave or reload. If you want a copy, use Choose notes to keep first.",
      "sha256": "249d0398a252e94574a17ba6b991668f6a483254111023444c2d2464d4104f64",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.try.help",
      "title": "If you did not try it",
      "text": "You can still go to the review prompts. Not trying a test is not evidence that your prediction came true. A barrier, a change of plan or a choice to stop can be worth discussing.",
      "sha256": "ed8e811394dd364741a5cb4e888a67b33ad5171ceb17bf980e9bebc8cdce1ea3",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "behavioural-experiments.practice.observation",
      "title": "Describe what really happened",
      "text": "Did you try the agreed test, try part, change it, or not try it? You can review any of these. There is no completion check to pass.\n\nIf you tried it, what did you actually do? What did you see or hear? Note useful facts and any change to the plan. You can note how you felt too. Keep that apart from guesses about what other people thought.\n\nIf you did not try it, leave the result open. You can note what got in the way or why the plan did not fit. Do not invent an outcome.",
      "sha256": "aeaf77569e84957321aafa519b6f2c64b7689ea0d0b7244c2d5cca6b6d0c270e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.observation.help",
      "title": "If the result was hurtful or unsafe",
      "text": "Name what happened without forcing a positive meaning. Stop the test and seek the support you need. Review it with your therapist before another test. This page is not a crisis plan.",
      "sha256": "01f579acc724608cda08f90197be3262c568365227fd801bba21ba0051bfed00",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "behavioural-experiments.practice.compare",
      "title": "Compare the result with the prediction",
      "text": "Look back at your first guess and the facts you planned to notice. Does the result fit the guess, not fit it, fit part of it, or leave you unsure?\n\nWhat supports your view? What points another way? What can this one test not tell you? If the plan changed, that may change what you can learn from it.\n\nNo attempt, no clear chance to observe, or too little information can mean there is no answer yet. You do not need to turn that into a good or bad result.",
      "sha256": "7b50ab4b7367d41e718b154670f378aaac6a689e458a76cc4bfebd397aaf49ce",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.compare.help",
      "title": "If the feared result happened",
      "text": "Take the facts seriously. Check how much of the prediction they support, what they do not show, and what help you need. You do not have to explain away harm or blame yourself.",
      "sha256": "2eb0f0ecc1260653eaa326eed454d90d5b64b9f80e0e7ad9ea5989c11f18668e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "behavioural-experiments.practice.learning",
      "title": "Keep the learning and review the next step",
      "text": "What have you learned, if anything, from this one test? Try a fair statement that fits the facts. \"I do not know yet\" is a valid answer.\n\nIf useful, note how sure you feel about the first prediction now. Use the same words or scale as before. You do not have to feel less sure.\n\nBring the result, any barriers and any questions to your therapist. Review whether to keep, change or stop the plan before a new test. A repeat is not required.",
      "sha256": "bb5053ee8b1eaa104b35da83977e495863874559798da6474bcfd7e15ddf586f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "behavioural-experiments.practice.learning.help",
      "title": "If you want notes for your next session",
      "text": "Choose notes to keep lets you select and check just the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy.",
      "sha256": "5f5185f938bd20a0cf9ad8970d3ad795dcdde6bacbc457be45012fed8a8ea886",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
