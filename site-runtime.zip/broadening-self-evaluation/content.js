window.PerspectiveSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "self-worth-pie.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "contextReview": {
      "fields": [
        "areas",
        "pattern",
        "area",
        "plan"
      ],
      "placement": "review and adjacent comparison prompts",
      "behavior": "Literal entered context only when writing shown. Never infer a percentage, worth, blame, diagnosis or completion; hide/clear every echo with notes."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/self-worth-pie",
  "title": "Self-Worth Pie Chart / Broadening Self-Evaluation",
  "subtitle": "Notice what dominates self-judgment and make room for more of life",
  "scope": "A bounded map of current self-evaluation emphasis and one optional broadening practice. Not a measure of inherent worth, an ideal life-balance test or specialist eating-disorder treatment.",
  "version": "2026-11-02-cbt-perspective-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish current influences on self-judgment from personal worth, time spent, chosen values and achievement requirements.",
    "practiceObjective": "Map what currently carries weight in self-evaluation, notice a narrow dependency if present, then consider and optionally try a realistic way of reconnecting with a neglected life area and review it without scoring worth.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Perfectionism-in-Perspective/Perfectionism-in-Perspective---08---Re-evaluating-the-importance-of-achieving.pdf",
      "reviewed": "2026-11-02",
      "supports": "Module8: current self-evaluation emphasis and broadening neglected life areas through activity.",
      "limits": "Perfectionism workbook context; no copied chart/example, motivation/contentment guarantee or specialist eating-disorder application. Optional nonnumerical map and one try/review are bounded adaptations, not the full course."
    }
  ],
  "resourceId": "tool/broadening-self-evaluation",
  "routeProposal": "tool/broadening-self-evaluation",
  "intro": {
    "id": "self-evaluation.intro",
    "title": "Map the judgment, not your value",
    "paragraphs": [
      "Sometimes one area—such as getting work exactly right—dominates how we judge ourselves. This practice makes that pattern visible and considers whether more of life could have room.",
      "The chart is not a division of your human worth. You do not need more achievements, equal slices, or a perfectly balanced life. Use words, your own paper, or an optional rough chart."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "self-evaluation.fit",
    "title": "Use a suitable focus",
    "paragraphs": [
      "Use this with your therapist after discussing what the map means.",
      "Do not use this page to score bodies, weight, food, attractiveness or personal value. If eating, body image or another health condition is part of the concern, use a specialist-agreed approach instead.",
      "Care, disability, money, culture and other circumstances affect the room available in life. A narrow range of activities is not a personal failure. If the chart becomes another standard to meet, stop or use a simple discussion with your therapist."
    ]
  },
  "learn": {
    "id": "self-evaluation.learn",
    "title": "Why look at the pattern?",
    "paragraphs": [
      "When one demanding standard carries most of self-evaluation, a setback there can feel like a verdict on the whole person. Seeing that dependency may help separate the setback from the person’s value.",
      "Map what currently influences your self-judgment—not what ought to matter, how much time each area takes, or how well you perform. Then consider whether an important part of life has been crowded out.",
      "Broadening means making realistic room for experience, connection or interest without turning it into another test. A chosen activity can support that exploration; it does not earn worth or have to improve mood."
    ]
  },
  "example": {
    "id": "self-evaluation.example",
    "title": "Example — beyond getting work right",
    "paragraphs": [
      "Avery notices that work performance dominates self-judgment. For a rough illustration Avery gives it 80 parts of 100, with friendship 15 and creative interest 5. These are estimates of current influence, not facts about Avery’s worth or time use.",
      "A work error tends to erase everything else in Avery’s self-appraisal. Avery wants a little more room for creative interest, not a new achievement target. Avery chooses ten minutes of informal sketching with no quality goal.",
      "Avery tries it and leaves the sketch unfinished. The work concern remains, but Avery notices some curiosity alongside it. On review Avery decides to keep sketching as an option rather than assign a new ideal percentage or prove that the chart has changed."
    ]
  },
  "practiceScenario": {
    "id": "self-evaluation.scenario",
    "title": "Optional fictional practice — Fin",
    "paragraphs": [
      "Fin judges the whole week by whether every study task was completed perfectly. Fin also enjoys talking with a cousin, but treats that as unimportant whenever a task goes wrong.",
      "Consider the current self-judgment pattern and a realistic way to give that relationship room without making “being a perfect cousin” another standard. You can use Fin, your own agreed example, or just read."
    ]
  },
  "practice": [
    {
      "id": "self-evaluation.practice.map",
      "title": "Map current influences",
      "paragraphs": [
        "What areas currently affect how you judge yourself when things go well or badly? Describe their relative influence in words or use the optional rough chart.",
        "This is a snapshot of a pattern, not a list of things you must value. You can leave areas unclear; do not score yourself in each one."
      ],
      "fields": [
        {
          "key": "areas",
          "label": "Areas and their current influence",
          "optional": true
        }
      ],
      "help": {
        "title": "If everything points to one area",
        "text": "Notice that without treating it as a failure. The question is whether that pattern fits how you want to relate to your life, not whether your chart looks balanced."
      }
    },
    {
      "id": "self-evaluation.practice.notice",
      "title": "Notice the effect of the pattern",
      "paragraphs": [
        "Does a setback in one area become a global judgment? Is something important being overlooked or squeezed out? You may find no change is needed.",
        "Keep your circumstances in view. Do not count the number of interests as a measure of how well you are doing."
      ],
      "fields": [
        {
          "key": "pattern",
          "label": "What the map helps me notice",
          "optional": true
        }
      ],
      "help": {
        "title": "If this feels like a values list",
        "text": "Values ask how you want to live. This map asks what currently controls self-evaluation. They can inform each other, but they are not the same task."
      }
    },
    {
      "id": "self-evaluation.practice.plan",
      "title": "Make room without a new performance rule",
      "paragraphs": [
        "If useful, choose one neglected area you want to reconnect with. What small, accessible experience would give it room without requiring success or approval?",
        "Decide what is realistic given energy, access and responsibilities. A possible activity is optional; rest, support or no new plan may fit better."
      ],
      "fields": [
        {
          "key": "area",
          "label": "An area I might give room to",
          "optional": true
        },
        {
          "key": "plan",
          "label": "A realistic experience, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "For Fin’s example",
        "text": "A brief optional conversation with the cousin could make room for connection. It should not become a requirement to be entertaining, helpful or perfectly reliable."
      }
    },
    {
      "id": "self-evaluation.practice.try",
      "title": "Try it when it fits, or leave it planned",
      "paragraphs": [
        "If you choose to try your activity, do it at a suitable time away from the page. There is no timer, reminder or completion requirement here.",
        "You can return to review, but this page does not save your plan. If you only read or planned, say that rather than treating the activity as done."
      ],
      "help": {
        "title": "If the plan turns into pressure",
        "text": "Reduce or abandon it. Broadening is not adding another way to fail; discuss the pattern with your therapist if useful."
      }
    },
    {
      "id": "self-evaluation.practice.review",
      "title": "Review the experience, not your worth",
      "paragraphs": [
        "If you tried something, what happened? Did you notice another experience or a new performance rule? What would you keep, change or leave?",
        "If you have not tried it, leave the review open. No mood improvement, chart redistribution or repeat activity is required."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What happened or remains to be tried",
          "optional": true
        }
      ],
      "help": {
        "title": "If it was not enjoyable",
        "text": "That is information, not failure. You can adapt the choice, explore a barrier, stop or seek support."
      }
    }
  ],
  "close": {
    "id": "self-evaluation.close",
    "title": "No ideal pie to achieve",
    "paragraphs": [
      "You can finish with a noticed pattern, an optional plan, an experience or no change. Your worth is not determined by the chart or by carrying out the activity."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "Original Avery/Fin examples; mapping influence explicitly separated from inherent worth and time allocation. No ideal equal-slice target or required area count.",
    "Optional private/text map is an adapted conceptual rehearsal, not a claim that a numerical pie was completed. Try/review separates activity from planning."
  ],
  "visualAid": {
    "id": "self-evaluation.visual",
    "kind": "optional-tentative-pie",
    "default": "Off; empty user chart, no initial categories or equal slices. Fictional example chart may be viewed separately with clear Example label.",
    "placement": "map/notice/review",
    "purpose": "Relative influence on current self-judgment, never amount of worth.",
    "inputs": {
      "rows": "Start with blank optional label/share rows; add/remove a row by keyboard button; no required category count.",
      "share": "Optional rough user-entered number 0–100, labeled estimated share of current influence",
      "unknown": "Explicit optional unallocated/uncertain remainder; never assigned to the person, another category or equal slices.",
      "textEquivalent": "The ordinary-language areas/factors and comparison fields are complete alternatives. Label them adapted nonnumerical practice, not a completed percentage pie."
    },
    "behavior": [
      "Render only user-entered finite nonnegative values; never normalize, average, recommend shares or force a total of 100.",
      "If sum is below 100, mark remainder Unallocated/uncertain—not a personal share. If sum exceeds 100, show a gentle total notice and no misleading full pie; keep labels/text and allow revision or leaving it incomplete.",
      "For a labeled row with a blank share, show the literal label with “share not entered” in the text table. Do not infer its size from the unallocated remainder; the remainder is not evidence about any factor.",
      "Blank is not zero. With all entries blank, show an empty-chart placeholder, not a full uncertain slice. Zero entered explicitly may be listed in the textual legend without a visible wedge.",
      "A row missing its label or with invalid/nonfinite/out-of-range share is shown as incomplete with a nearby notice; do not silently discard it or invent a label. Keep text review available without rendering a misleading completed pie.",
      "No equal-slice goal, red/green score or change-success animation. Display total and all labels/shares in a keyboard-readable text table; chart never color-only.",
      "No dragging required; direct labeled inputs and Add/remove buttons suffice. User controls chart visibility independently, but hiding writing hides all private chart data/labels/echoes too.",
      "Clear labels/shares/visibility on exit/reload/clear/restart; internal Back/Learn/Example retains them. No private entries in narration or backend storage."
    ],
    "visibleNote": "These are rough estimates of current self-judgment influence, not human worth or an ideal balance."
  },
  "narrationSegments": [
    {
      "id": "self-evaluation.intro",
      "title": "Map the judgment, not your value",
      "text": "Sometimes one area—such as getting work exactly right—dominates how we judge ourselves. This practice makes that pattern visible and considers whether more of life could have room.\n\nThe chart is not a division of your human worth. You do not need more achievements, equal slices, or a perfectly balanced life. Use words, your own paper, or an optional rough chart.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.fit",
      "title": "Use a suitable focus",
      "text": "Use this with your therapist after discussing what the map means.\n\nDo not use this page to score bodies, weight, food, attractiveness or personal value. If eating, body image or another health condition is part of the concern, use a specialist-agreed approach instead.\n\nCare, disability, money, culture and other circumstances affect the room available in life. A narrow range of activities is not a personal failure. If the chart becomes another standard to meet, stop or use a simple discussion with your therapist.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.learn",
      "title": "Why look at the pattern?",
      "text": "When one demanding standard carries most of self-evaluation, a setback there can feel like a verdict on the whole person. Seeing that dependency may help separate the setback from the person’s value.\n\nMap what currently influences your self-judgment—not what ought to matter, how much time each area takes, or how well you perform. Then consider whether an important part of life has been crowded out.\n\nBroadening means making realistic room for experience, connection or interest without turning it into another test. A chosen activity can support that exploration; it does not earn worth or have to improve mood.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.example",
      "title": "Example — beyond getting work right",
      "text": "Avery notices that work performance dominates self-judgment. For a rough illustration Avery gives it 80 parts of 100, with friendship 15 and creative interest 5. These are estimates of current influence, not facts about Avery’s worth or time use.\n\nA work error tends to erase everything else in Avery’s self-appraisal. Avery wants a little more room for creative interest, not a new achievement target. Avery chooses ten minutes of informal sketching with no quality goal.\n\nAvery tries it and leaves the sketch unfinished. The work concern remains, but Avery notices some curiosity alongside it. On review Avery decides to keep sketching as an option rather than assign a new ideal percentage or prove that the chart has changed.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.scenario",
      "title": "Optional fictional practice — Fin",
      "text": "Fin judges the whole week by whether every study task was completed perfectly. Fin also enjoys talking with a cousin, but treats that as unimportant whenever a task goes wrong.\n\nConsider the current self-judgment pattern and a realistic way to give that relationship room without making “being a perfect cousin” another standard. You can use Fin, your own agreed example, or just read.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.map",
      "title": "Map current influences",
      "text": "What areas currently affect how you judge yourself when things go well or badly? Describe their relative influence in words or use the optional rough chart.\n\nThis is a snapshot of a pattern, not a list of things you must value. You can leave areas unclear; do not score yourself in each one.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.map.help",
      "title": "If everything points to one area",
      "text": "Notice that without treating it as a failure. The question is whether that pattern fits how you want to relate to your life, not whether your chart looks balanced.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.notice",
      "title": "Notice the effect of the pattern",
      "text": "Does a setback in one area become a global judgment? Is something important being overlooked or squeezed out? You may find no change is needed.\n\nKeep your circumstances in view. Do not count the number of interests as a measure of how well you are doing.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.notice.help",
      "title": "If this feels like a values list",
      "text": "Values ask how you want to live. This map asks what currently controls self-evaluation. They can inform each other, but they are not the same task.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.plan",
      "title": "Make room without a new performance rule",
      "text": "If useful, choose one neglected area you want to reconnect with. What small, accessible experience would give it room without requiring success or approval?\n\nDecide what is realistic given energy, access and responsibilities. A possible activity is optional; rest, support or no new plan may fit better.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.plan.help",
      "title": "For Fin’s example",
      "text": "A brief optional conversation with the cousin could make room for connection. It should not become a requirement to be entertaining, helpful or perfectly reliable.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.try",
      "title": "Try it when it fits, or leave it planned",
      "text": "If you choose to try your activity, do it at a suitable time away from the page. There is no timer, reminder or completion requirement here.\n\nYou can return to review, but this page does not save your plan. If you only read or planned, say that rather than treating the activity as done.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.try.help",
      "title": "If the plan turns into pressure",
      "text": "Reduce or abandon it. Broadening is not adding another way to fail; discuss the pattern with your therapist if useful.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.review",
      "title": "Review the experience, not your worth",
      "text": "If you tried something, what happened? Did you notice another experience or a new performance rule? What would you keep, change or leave?\n\nIf you have not tried it, leave the review open. No mood improvement, chart redistribution or repeat activity is required.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.practice.review.help",
      "title": "If it was not enjoyable",
      "text": "That is information, not failure. You can adapt the choice, explore a barrier, stop or seek support.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.close",
      "title": "No ideal pie to achieve",
      "text": "You can finish with a noticed pattern, an optional plan, an experience or no change. Your worth is not determined by the chart or by carrying out the activity.",
      "status": "Script only"
    },
    {
      "id": "self-worth-pie.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    },
    {
      "id": "self-evaluation.visual.note",
      "title": "About the optional visual",
      "text": "These are rough estimates of current self-judgment influence, not human worth or an ideal balance.",
      "status": "Static script only; never user labels or values"
    }
  ]
}
;
