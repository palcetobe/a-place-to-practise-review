window.NightSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "soothe.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact-match assets, listening and integration gates pass. No private text voiced.",
    "timer": "None; practice can be brief or stopped at any point.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/soothe",
  "title": "Self-Soothe",
  "subtitle": "Try a tolerable sensory comfort",
  "scope": "A bounded sensory self-soothing practice, distinct from grounding or a full DBT programme. Optional body-scan component is not included.",
  "resourceId": "tool/self-soothe",
  "routeProposal": "tool/self-soothe",
  "version": "2026-11-02-night-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish intentionally comforting sensory contact from orienting to the surroundings, and recognise that soothing does not solve every practical problem.",
    "practiceObjective": "Choose one safe, accessible sensory comfort, actually try attending to it briefly if suitable, then review its fit and adjust or stop.",
    "observedPractice": "Reading, preparing and actually trying are distinct; no compulsory writing, rating, relief or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Adult source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "intro": {
    "id": "self-soothe.intro",
    "title": "One possible comfort is enough",
    "paragraphs": [
      "Self-soothing means offering yourself a tolerable sensory comfort. You might choose a pleasant view, a gentle sound or a comfortable texture. You do not need to use every sense or feel calm.",
      "This is not a five-senses test. Choose what is available and suits you, or read the example first. Comfort can be ordinary and cost nothing."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "self-soothe.fit",
    "title": "Check what is suitable for you",
    "paragraphs": [
      "Use this with your therapist between sessions. Avoid anything that conflicts with allergies, sensory sensitivities, pain, health advice or personal boundaries. No food, scent, touch, closed eyes or body focus is required.",
      "Use a safe, ordinary situation where you can give a little attention. Do not use this to put off urgent care, leave a danger unattended, or test a suspected allergy. If an experience feels unpleasant, overwhelming or linked to upsetting memories, stop it and choose less stimulation or support.",
      "This tool is not a crisis assessment. Support and practical help remain available before, during and after the exercise."
    ]
  },
  "learn": {
    "id": "self-soothe.learn",
    "title": "Why try sensory comfort?",
    "paragraphs": [
      "When a moment is difficult, gentle sensory contact may offer a way of caring for yourself while it is happening. The purpose here is to try a suitable comfort, not to force the feeling away.",
      "Grounding usually directs attention to what is here now. Self-soothing selects an experience because it may be comforting. The same object can serve either purpose; the intention and how you use it matter.",
      "Sensory preferences differ. A quiet sound might suit one person and irritate another. Trying, noticing and adjusting are part of learning what fits. Soothing does not remove the need for support or a practical response when those are needed."
    ]
  },
  "example": {
    "id": "self-soothe.example",
    "title": "Example — changing the sensory choice",
    "paragraphs": [
      "After a frustrating ordinary day, Mina considers listening to music. The first track feels too busy, so Mina turns it off rather than trying to tolerate it.",
      "Mina chooses the familiar texture of a soft sleeve instead and notices it gently for a brief moment. No squeezing or special movement is needed. The texture is acceptable; frustration remains.",
      "Mina decides the quieter option fits better today and stops after that brief try. Mina has practised choosing and reviewing a comfort, not proved the day is fixed. Asking for help with the practical difficulty remains a separate option."
    ]
  },
  "practiceScenario": {
    "id": "self-soothe.scenario",
    "title": "If you prefer an example first",
    "paragraphs": [
      "Consider Mina’s choice when music feels too busy. What could Mina change without forcing comfort or using another sensory experience that is also unwelcome?",
      "Reading this can teach the procedure. An actual sensory try is optional and separate; you can finish after reading."
    ]
  },
  "practice": [
    {
      "id": "self-soothe.practice.choose",
      "title": "Choose one accessible comfort",
      "paragraphs": [
        "What is already available that might be gentle or pleasant for you? Consider one familiar view, sound or texture, or another sensory choice you already know is safe.",
        "Choose one, not a checklist. You may prefer less stimulation or nothing right now."
      ],
      "fields": [
        {
          "key": "choice",
          "label": "One possible comfort, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing is available",
        "text": "Do not buy or fetch something to complete the page. You can plan to try a familiar choice later, read, or stop. Planning is different from trying."
      }
    },
    {
      "id": "self-soothe.practice.try",
      "title": "Try it gently, if suitable",
      "paragraphs": [
        "If you have chosen something safe and available, give it a little attention. Notice a detail you find tolerable or comforting, without having to scan your whole body or change your breathing.",
        "A brief try is enough to begin checking fit. You can stop immediately or keep going by choice; no duration or calm target is required."
      ],
      "help": {
        "title": "If it is not pleasant",
        "text": "Stop or reduce the stimulation. You do not need to expose yourself to an unpleasant sensation to succeed at self-soothing."
      }
    },
    {
      "id": "self-soothe.practice.review",
      "title": "Notice what fits",
      "paragraphs": [
        "Was the experience comforting, neutral, unpleasant or unclear? You can change it, use less, stop or keep it as an option. You do not need to rate your distress.",
        "If you only planned or read, there is no sensory outcome to report. If there is a practical need or a need for support, comfort is not a substitute for attending to it."
      ],
      "fields": [
        {
          "key": "review",
          "label": "Something I noticed or might change",
          "optional": true
        }
      ],
      "help": {
        "title": "If comfort brings guilt",
        "text": "You do not have to earn a small comfort. If that idea is difficult or the practice increases distress, pause and discuss it with your therapist rather than forcing the experience."
      }
    }
  ],
  "close": {
    "id": "self-soothe.close",
    "title": "Keep only what fits",
    "paragraphs": [
      "You can finish with a useful option, a choice you do not want to repeat, or no conclusion. There is no required feeling or next task."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-4teaching.pdf?t=1",
      "reviewed": "2026-11-02",
      "supports": "Printed pp443–444: sensory self-soothing, individual barriers and limits; distinguish comfort from practical problem solving. Reopened direct publisher source.",
      "limits": "Qualified-professional teaching context and restrictive reproduction license. Original app wording only; no copied handout, full DBT claim or adolescent adaptation validation. Optionality and no forced repetition are bounded product adaptations."
    }
  ],
  "productAdaptations": [
    "Original Mina example and short one-choice practice; no compulsory five-sense survey, body scan, food/scent, positive outcome or repeated exposure to discomfort.",
    "Sensory examples are a small set, not a personalized health recommendation. Preserve ordinary safety/support access."
  ],
  "narrationSegments": [
    {
      "id": "self-soothe.intro",
      "title": "One possible comfort is enough",
      "text": "Self-soothing means offering yourself a tolerable sensory comfort. You might choose a pleasant view, a gentle sound or a comfortable texture. You do not need to use every sense or feel calm.\n\nThis is not a five-senses test. Choose what is available and suits you, or read the example first. Comfort can be ordinary and cost nothing.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.fit",
      "title": "Check what is suitable for you",
      "text": "Use this with your therapist between sessions. Avoid anything that conflicts with allergies, sensory sensitivities, pain, health advice or personal boundaries. No food, scent, touch, closed eyes or body focus is required.\n\nUse a safe, ordinary situation where you can give a little attention. Do not use this to put off urgent care, leave a danger unattended, or test a suspected allergy. If an experience feels unpleasant, overwhelming or linked to upsetting memories, stop it and choose less stimulation or support.\n\nThis tool is not a crisis assessment. Support and practical help remain available before, during and after the exercise.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.learn",
      "title": "Why try sensory comfort?",
      "text": "When a moment is difficult, gentle sensory contact may offer a way of caring for yourself while it is happening. The purpose here is to try a suitable comfort, not to force the feeling away.\n\nGrounding usually directs attention to what is here now. Self-soothing selects an experience because it may be comforting. The same object can serve either purpose; the intention and how you use it matter.\n\nSensory preferences differ. A quiet sound might suit one person and irritate another. Trying, noticing and adjusting are part of learning what fits. Soothing does not remove the need for support or a practical response when those are needed.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.example",
      "title": "Example — changing the sensory choice",
      "text": "After a frustrating ordinary day, Mina considers listening to music. The first track feels too busy, so Mina turns it off rather than trying to tolerate it.\n\nMina chooses the familiar texture of a soft sleeve instead and notices it gently for a brief moment. No squeezing or special movement is needed. The texture is acceptable; frustration remains.\n\nMina decides the quieter option fits better today and stops after that brief try. Mina has practised choosing and reviewing a comfort, not proved the day is fixed. Asking for help with the practical difficulty remains a separate option.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.scenario",
      "title": "If you prefer an example first",
      "text": "Consider Mina’s choice when music feels too busy. What could Mina change without forcing comfort or using another sensory experience that is also unwelcome?\n\nReading this can teach the procedure. An actual sensory try is optional and separate; you can finish after reading.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.practice.choose",
      "title": "Choose one accessible comfort",
      "text": "What is already available that might be gentle or pleasant for you? Consider one familiar view, sound or texture, or another sensory choice you already know is safe.\n\nChoose one, not a checklist. You may prefer less stimulation or nothing right now.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.practice.choose.help",
      "title": "If nothing is available",
      "text": "Do not buy or fetch something to complete the page. You can plan to try a familiar choice later, read, or stop. Planning is different from trying.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.practice.try",
      "title": "Try it gently, if suitable",
      "text": "If you have chosen something safe and available, give it a little attention. Notice a detail you find tolerable or comforting, without having to scan your whole body or change your breathing.\n\nA brief try is enough to begin checking fit. You can stop immediately or keep going by choice; no duration or calm target is required.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.practice.try.help",
      "title": "If it is not pleasant",
      "text": "Stop or reduce the stimulation. You do not need to expose yourself to an unpleasant sensation to succeed at self-soothing.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.practice.review",
      "title": "Notice what fits",
      "text": "Was the experience comforting, neutral, unpleasant or unclear? You can change it, use less, stop or keep it as an option. You do not need to rate your distress.\n\nIf you only planned or read, there is no sensory outcome to report. If there is a practical need or a need for support, comfort is not a substitute for attending to it.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.practice.review.help",
      "title": "If comfort brings guilt",
      "text": "You do not have to earn a small comfort. If that idea is difficult or the practice increases distress, pause and discuss it with your therapist rather than forcing the experience.",
      "status": "Script only"
    },
    {
      "id": "self-soothe.close",
      "title": "Keep only what fits",
      "text": "You can finish with a useful option, a choice you do not want to repeat, or no conclusion. There is no required feeling or next task.",
      "status": "Script only"
    },
    {
      "id": "soothe.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    }
  ]
}
;
