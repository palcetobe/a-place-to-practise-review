window.EveningSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "emotion-awareness.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Frozen authored scripts only until exact asset, perceptual listening and integration gates pass. No personal words in audio. Existing audio assets do not imply these new words are voiced.",
    "timer": "None unless explicitly specified in practiceAid.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show optional fictional practice before prompts and keep available contextually. Do not prefill or evaluate private words. Reading the example is not marked as actual practice."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/emotion-awareness",
  "title": "Understanding and Naming Emotions",
  "subtitle": "Find words that fit, or leave them open",
  "scope": "Observing, describing and naming component only; not the whole DBT emotion-awareness curriculum, a diagnostic test, body-to-emotion map or emotion-regulation treatment.",
  "resourceId": "tool/name-whats-here",
  "routeProposal": "tool/name-whats-here",
  "version": "2026-11-02-evening-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish a tentative emotion description from a fact about the situation, a cause, an action urge or a diagnosis.",
    "practiceObjective": "Consider one ordinary moment or fictional example, try an emotion word or description if useful, and review what fits or remains uncertain without requiring bodily attention or a definite label.",
    "observedPractice": "Private consideration, actual optional practice and review are separate from reading; no typing, rating, symptom reduction or claim of mastery required.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Adult source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "componentId": "component/emotion-awareness/observing-and-describing-emotions",
  "intro": {
    "id": "emotion-awareness.intro",
    "title": "Words can be approximate",
    "paragraphs": [
      "An emotion word can help describe an experience: disappointed, relieved, worried, or words in your own language. Several words may fit, and “not sure” is welcome.",
      "You can start with a word you already have, an ordinary situation, or the fictional example. Body attention is optional. You do not need to find the right label or change how you feel."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "emotion-awareness.fit",
    "title": "Keep the practice manageable",
    "paragraphs": [
      "Use this with your therapist between sessions. Choose an ordinary moment or fiction; no detailed or upsetting memory is needed.",
      "Skip body noticing if it is uncomfortable or not useful. A sensation can have different meanings or physical causes; this tool does not interpret symptoms or replace medical advice.",
      "Naming a feeling does not decide whether mistreatment occurred, prove another person’s motives, or require accepting harm. Pause and get support when needed."
    ]
  },
  "learn": {
    "id": "emotion-awareness.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "Putting an experience into words can help you describe it to yourself or someone supporting you. A tentative word can open a conversation rather than close it with a verdict.",
      "Consider the situation and your own meaning. The same event or bodily description can go with different emotions for different people. A word is not a diagnosis or a prediction from a sensation.",
      "Emotions can draw attention to what matters or bring an urge to act, but the urge is not an instruction and the feeling does not establish every interpretation as fact. This page practises description; further work on emotion functions is separate."
    ]
  },
  "example": {
    "id": "emotion-awareness.example",
    "title": "Example — a cancelled plan",
    "paragraphs": [
      "Sam’s plan with a friend is cancelled. Sam describes a heavy feeling and wonders about disappointment, sadness, or both. Sam tries “disappointed” without deciding it is the only possible word.",
      "Ren also uses “heavy,” while resting after a busy day. Ren wonders about tiredness or relief. The shared description does not tell us which feeling either person has.",
      "In review, Sam keeps “disappointed, perhaps sad too.” Sam’s feeling has not changed, and the reason for the cancellation is still unknown. The words describe Sam’s experience; they do not prove the friend’s motives."
    ]
  },
  "practiceScenario": {
    "id": "emotion-awareness.scenario",
    "title": "Optional fictional practice — Casey",
    "paragraphs": [
      "An ordinary class Casey wanted to attend is cancelled. Casey says, “I was looking forward to it, and part of me is glad to have a free evening.”",
      "Consider possible words or a question you would ask Casey. More than one feeling may fit. Use this example, another manageable situation, or just read."
    ]
  },
  "practice": [
    {
      "id": "emotion-awareness.practice.moment",
      "title": "Choose a starting point",
      "paragraphs": [
        "Bring to mind an ordinary moment, a word you already have, or Casey’s example. What is happening, and how would you describe the experience?",
        "Keep personal details private if you want. You do not need to search inside your body."
      ],
      "fields": [
        {
          "key": "starting",
          "label": "A word, moment or question, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you already have a word",
        "text": "Start there. You do not need a more precise label or an additional bodily description to continue."
      }
    },
    {
      "id": "emotion-awareness.practice.words",
      "title": "Try a word or description",
      "paragraphs": [
        "Could a word fit, partly fit, or not fit? You can use several words, another language, a short description, or “not sure.”",
        "Some possibilities are disappointed, relieved, sad, worried, angry or glad. These are examples, not a full list or a prediction about you."
      ],
      "fields": [
        {
          "key": "words",
          "label": "Words or a description I might try",
          "optional": true
        }
      ],
      "help": {
        "title": "If no word fits",
        "text": "Leave the experience unnamed, or keep a question for your therapist. If you choose to notice a body sensation, treat it as a description, not a code for an emotion."
      }
    },
    {
      "id": "emotion-awareness.practice.meaning",
      "title": "Keep meaning and facts separate",
      "paragraphs": [
        "What makes a word seem useful in this context? You can change it or leave it tentative. If using Casey, work with what Casey actually said rather than guessing hidden motives.",
        "“I feel ignored” may communicate something important about being overlooked. You can keep that meaning and explore how it feels without this page deciding what happened."
      ],
      "fields": [
        {
          "key": "meaning",
          "label": "What fits, partly fits or remains open",
          "optional": true
        }
      ],
      "help": {
        "title": "A possible Casey account",
        "text": "Disappointment could fit looking forward to the class; relief could fit being glad about free time. You could ask Casey whether either word fits. The story does not prove those are the only feelings. This is a model, not a grade for your words."
      }
    },
    {
      "id": "emotion-awareness.practice.review",
      "title": "Review without forcing certainty",
      "paragraphs": [
        "Do the words still fit, or would you change or leave them open? You can notice an urge or possible meaning without having to act on it.",
        "A useful outcome may be a word, a question, or noticing that labeling is not helpful today. Relief or certainty is not required."
      ],
      "fields": [
        {
          "key": "review",
          "label": "Something to keep or discuss, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If naming feels like pressure",
        "text": "Stop searching. An honest “I’m not sure” can communicate where you are. You can ask for help without first naming an emotion."
      }
    }
  ],
  "close": {
    "id": "emotion-awareness.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "You can finish with one word, several words, a question, or no label. Nothing needs to be resolved and no action is required."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "id": "linehan-emotions",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-02",
      "supports": "Emotion Regulation handouts2,3,5,6 distinguish emotion description, prompting events, interpretations, bodily responses and urges; bounded naming subset, not full curriculum. No worksheet reproduction."
    },
    {
      "id": "cci-connection",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Depression/Depression-Worksheets/Depression-Worksheet---05---Making-the-Thought-Feeling-Connection.pdf",
      "reviewed": "2026-11-02",
      "supports": "Conceptual link of context/self-statements and possible feelings, not validation of wheel or body-first mapping."
    },
    {
      "id": "va-emotion-education",
      "url": "https://www.veterantraining.va.gov/apps/veteranparenting/feelings-understanding.html",
      "reviewed": "2026-11-02",
      "supports": "Educational recognition and communication of feelings; parent/family context not exact digital16–17 validation. No taxonomy or relief guarantee transferred."
    }
  ],
  "productAdaptations": [
    "Preserves tool/name-whats-here identity and historical body-optional/tentative naming intent. Finding words for emotions and Emotional check-in historical shared lesson are provenance, not new counts or automatic route redirects.",
    "Sam/Ren case retained in concise form; original Casey rehearsal added. No body-to-emotion inference, wheel score, automatic evaluation, fullfunctions curriculum or diagnosis.",
    "Words can stay uncertain, plural, in another language or absent; no mandatory body focus/rating/action."
  ],
  "narrationSegments": [
    {
      "id": "emotion-awareness.intro",
      "title": "Words can be approximate",
      "text": "An emotion word can help describe an experience: disappointed, relieved, worried, or words in your own language. Several words may fit, and “not sure” is welcome.\n\nYou can start with a word you already have, an ordinary situation, or the fictional example. Body attention is optional. You do not need to find the right label or change how you feel.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.fit",
      "title": "Keep the practice manageable",
      "text": "Use this with your therapist between sessions. Choose an ordinary moment or fiction; no detailed or upsetting memory is needed.\n\nSkip body noticing if it is uncomfortable or not useful. A sensation can have different meanings or physical causes; this tool does not interpret symptoms or replace medical advice.\n\nNaming a feeling does not decide whether mistreatment occurred, prove another person’s motives, or require accepting harm. Pause and get support when needed.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.learn",
      "title": "Why this skill may help",
      "text": "Putting an experience into words can help you describe it to yourself or someone supporting you. A tentative word can open a conversation rather than close it with a verdict.\n\nConsider the situation and your own meaning. The same event or bodily description can go with different emotions for different people. A word is not a diagnosis or a prediction from a sensation.\n\nEmotions can draw attention to what matters or bring an urge to act, but the urge is not an instruction and the feeling does not establish every interpretation as fact. This page practises description; further work on emotion functions is separate.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.example",
      "title": "Example — a cancelled plan",
      "text": "Sam’s plan with a friend is cancelled. Sam describes a heavy feeling and wonders about disappointment, sadness, or both. Sam tries “disappointed” without deciding it is the only possible word.\n\nRen also uses “heavy,” while resting after a busy day. Ren wonders about tiredness or relief. The shared description does not tell us which feeling either person has.\n\nIn review, Sam keeps “disappointed, perhaps sad too.” Sam’s feeling has not changed, and the reason for the cancellation is still unknown. The words describe Sam’s experience; they do not prove the friend’s motives.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.scenario",
      "title": "Optional fictional practice — Casey",
      "text": "An ordinary class Casey wanted to attend is cancelled. Casey says, “I was looking forward to it, and part of me is glad to have a free evening.”\n\nConsider possible words or a question you would ask Casey. More than one feeling may fit. Use this example, another manageable situation, or just read.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.practice.moment",
      "title": "Choose a starting point",
      "text": "Bring to mind an ordinary moment, a word you already have, or Casey’s example. What is happening, and how would you describe the experience?\n\nKeep personal details private if you want. You do not need to search inside your body.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.practice.moment.help",
      "title": "If you already have a word",
      "text": "Start there. You do not need a more precise label or an additional bodily description to continue.",
      "status": "Script only"
    },
    {
      "id": "emotion-awareness.practice.words",
      "title": "Try a word or description",
      "text": "Could a word fit, partly fit, or not fit? You can use several words, another language, a short description, or “not sure.”\n\nSome possibilities are disappointed, relieved, sad, worried, angry or glad. These are examples, not a full list or a prediction about you.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.practice.words.help",
      "title": "If no word fits",
      "text": "Leave the experience unnamed, or keep a question for your therapist. If you choose to notice a body sensation, treat it as a description, not a code for an emotion.",
      "status": "Script only"
    },
    {
      "id": "emotion-awareness.practice.meaning",
      "title": "Keep meaning and facts separate",
      "text": "What makes a word seem useful in this context? You can change it or leave it tentative. If using Casey, work with what Casey actually said rather than guessing hidden motives.\n\n“I feel ignored” may communicate something important about being overlooked. You can keep that meaning and explore how it feels without this page deciding what happened.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.practice.meaning.help",
      "title": "A possible Casey account",
      "text": "Disappointment could fit looking forward to the class; relief could fit being glad about free time. You could ask Casey whether either word fits. The story does not prove those are the only feelings. This is a model, not a grade for your words.",
      "status": "Script only"
    },
    {
      "id": "emotion-awareness.practice.review",
      "title": "Review without forcing certainty",
      "text": "Do the words still fit, or would you change or leave them open? You can notice an urge or possible meaning without having to act on it.\n\nA useful outcome may be a word, a question, or noticing that labeling is not helpful today. Relief or certainty is not required.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.practice.review.help",
      "title": "If naming feels like pressure",
      "text": "Stop searching. An honest “I’m not sure” can communicate where you are. You can ask for help without first naming an emotion.",
      "status": "Script only"
    },
    {
      "id": "emotion-awareness.close",
      "title": "Leave it here for now",
      "text": "You can finish with one word, several words, a question, or no label. Nothing needs to be resolved and no action is required.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "emotion-awareness.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; generation/listening/integration not asserted"
    }
  ]
}
;
