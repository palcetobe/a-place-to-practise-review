window.DBTChoiceContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "proscons.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "quadrantGrid": {
      "placement": "proscons.practice.grid and review",
      "structure": "Two explicitly labeled rows Following the urge / Not following the urge now; two columns Possible benefits / Possible costs.",
      "fields": [
        "actPros",
        "actCons",
        "notPros",
        "notCons"
      ],
      "mobile": "Retain four distinct labeled cells in readable order; do not collapse into a two-column generic pros/cons list.",
      "review": "Show all four entered cells together at review when writing is shown, plus exact urge/alternative context. Blank cells say no entry, not no cost/benefit.",
      "privacy": "All notes and echoes hidden with writing; cleared on leave/reload/clear/restart; never voiced.",
      "interpretation": "No weights, scores, cell counts, winner, recommendation or prefilled personal content. Private thinking/paper/example routes remain complete participation options."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/proscons",
  "title": "Pros and Cons",
  "subtitle": "DBT practice: compare following an urge with not following it",
  "scope": "DBT four-quadrant practice for considering an ordinary urge agreed with your therapist, or the fictional example.",
  "version": "2026-11-03-distress-choice-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Explain the four distinct comparisons and why number of items does not determine the best response.",
    "practiceObjective": "Consider near-term and later consequences in all four quadrants for one agreed ordinary urge, review their importance and uncertainty, and form a provisional response without needing to act on the urge or reach a forced decision.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Official 2015 Distress Tolerance handout 5 provides method identity and procedure.",
      "limits": "Original app wording/examples only; no copied worksheet. Current 2025 edition scope recognised separately; exact revised procedure not asserted identical. Adult framework does not validate this digital 16–17 adaptation."
    },
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-4teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Qualified-professional crisis-survival teaching: temporary tolerating of distress without making things worse; balance with appropriate practical response.",
      "limits": "Not a substitute for assessment, personal safety plan or complete DBT. Restricted reproduction licence; source suggestions narrowed for this ordinary-context adaptation."
    }
  ],
  "resourceId": "tool/dbt-pros-and-cons",
  "routeProposal": "tool/dbt-pros-and-cons",
  "componentId": "component/proscons/dbt-crisis-urge",
  "intro": {
    "id": "proscons.intro",
    "title": "Look beyond the immediate pull",
    "paragraphs": [
      "A strong urge can make the immediate payoff stand out while later consequences fade from view. DBT Pros and Cons considers both following the urge and not following it, including the costs of tolerating discomfort.",
      "Practise before becoming overwhelmed, with an ordinary urge agreed with your therapist or the fictional example. You do not have to act on the urge, write an answer or decide immediately."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "proscons.fit",
    "title": "Use the ordinary practice version",
    "paragraphs": [
      "Use this after your therapist introduces it and chooses a suitable, non-urgent situation with you.",
      "This page is not for weighing suicide, self-harm, violence, dangerous substance use, abuse, medical decisions or other high-stakes actions. If urgent safety or care is needed, use your agreed support plan or appropriate help now rather than completing a comparison.",
      "Choose a specific ordinary urge, not every possible life decision. If the exercise becomes repeated checking for certainty, pause and discuss that pattern. This page is not monitored and does not make a decision for you."
    ]
  },
  "learn": {
    "id": "proscons.learn",
    "title": "Why four boxes rather than two?",
    "paragraphs": [
      "Consider the possible benefits and costs of following the urge, then the benefits and costs of not following it. Not acting can have costs too, such as frustration remaining for a while. Naming that honestly is part of the method.",
      "In each box distinguish what might happen soon from what might matter later. A consequence may be uncertain; do not turn a possibility into a prediction.",
      "Review importance, not the length of the lists. A single important consequence may matter more than several small ones. This practice does not add scores, choose for you, or require enduring a situation that is unsafe."
    ]
  },
  "example": {
    "id": "proscons.example",
    "title": "Example — wanting to give up a hobby",
    "paragraphs": [
      "After one frustrating practice, Jordan wants to give up an otherwise enjoyed hobby immediately. Jordan and a therapist use this ordinary urge to rehearse the four-part method.",
      "Following the urge: a possible near-term benefit is escaping the frustration and freeing time. Possible later costs are losing an enjoyed activity and regretting a decision made in a heated moment.",
      "Not following the urge now: a benefit is keeping the option to decide later; a later benefit might be returning to something Jordan values. Costs are that frustration and uncertainty may remain, and a later decision still needs attention. Not following the urge does not mean forcing continued practice tonight.",
      "Jordan reviews the four boxes and chooses to leave the larger decision open for now. Frustration remains. The comparison helped Jordan notice time horizons; it did not prove that keeping the hobby is always right or that a future activity has been completed."
    ]
  },
  "practiceScenario": {
    "id": "proscons.scenario",
    "title": "Optional fictional practice — Jordan",
    "paragraphs": [
      "Use Jordan’s urge to give up an ordinarily enjoyed hobby after a frustrating attempt. Compare following that urge now with not deciding to give up now.",
      "You do not have to match Jordan’s conclusion. Work with likely or uncertain consequences, not a rule that everyone must persist with every hobby."
    ]
  },
  "practice": [
    {
      "id": "proscons.practice.urge",
      "title": "Define the urge and its alternative",
      "paragraphs": [
        "What specific ordinary urge are you considering? What would following it mean? What would not following it now mean in this situation?",
        "Use the agreed situation or Jordan’s example. Not acting on an urge can include a pause; it does not mean doing the exact opposite or staying in danger."
      ],
      "fields": [
        {
          "key": "urge",
          "label": "The agreed ordinary urge",
          "optional": true
        },
        {
          "key": "acting",
          "label": "Following it would mean",
          "optional": true
        },
        {
          "key": "notActing",
          "label": "Not following it now would mean",
          "optional": true
        }
      ],
      "help": {
        "title": "If the alternatives are unclear",
        "text": "Make them specific enough to compare, or leave the question for your therapist. Do not create an extreme alternative such as “I must keep doing this forever.”"
      }
    },
    {
      "id": "proscons.practice.grid",
      "title": "Consider all four sides",
      "paragraphs": [
        "Consider possible benefits and costs of following the urge, and possible benefits and costs of not following it. In each box, think about soon and later if relevant.",
        "You may leave a box unknown or empty. You do not need equal numbers of items, reassuring answers or certainty."
      ],
      "fields": [
        {
          "key": "actPros",
          "label": "Possible benefits of following the urge — soon or later",
          "optional": true
        },
        {
          "key": "actCons",
          "label": "Possible costs of following the urge — soon or later",
          "optional": true
        },
        {
          "key": "notPros",
          "label": "Possible benefits of not following the urge — soon or later",
          "optional": true
        },
        {
          "key": "notCons",
          "label": "Possible costs of not following the urge — soon or later",
          "optional": true
        }
      ],
      "help": {
        "title": "If you only notice immediate relief",
        "text": "Keep that real short-term possibility and look for possible later effects too. Also acknowledge the discomfort of not following the urge; do not hide it to force a conclusion."
      }
    },
    {
      "id": "proscons.practice.review",
      "title": "Review what matters, without a tally",
      "paragraphs": [
        "Look at the four boxes together. Which consequences matter most in this situation? What is uncertain or missing? A longer list does not win.",
        "What response, pause or support need fits your review? You can leave the decision open. Considering a response is not the same as carrying it out."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What matters or remains uncertain",
          "optional": true
        },
        {
          "key": "response",
          "label": "A provisional response, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If a benefit appears in two boxes",
        "text": "That may be useful information rather than an error. Describe how the alternatives differ; the aim is understanding consequences, not producing a perfectly symmetrical grid."
      }
    }
  ],
  "close": {
    "id": "proscons.close",
    "title": "A provisional review is enough",
    "paragraphs": [
      "You can finish with a response, a pause or an open question. No action or feeling change is required. This page does not save the comparison; an agreed personal record elsewhere is separate."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "Ordinary agreed-urge rehearsal before overwhelm, not unsupervised dangerous-crisis deliberation. All four DBT cells and near/later distinction preserved; no required written carry-card or repeated reading.",
    "Original Jordan example. Retired priorities-choice/tool/weigh-what-matters is not imported or claimed equivalent."
  ],
  "narrationSegments": [
    {
      "id": "proscons.intro",
      "title": "Look beyond the immediate pull",
      "text": "A strong urge can make the immediate payoff stand out while later consequences fade from view. DBT Pros and Cons considers both following the urge and not following it, including the costs of tolerating discomfort.\n\nPractise before becoming overwhelmed, with an ordinary urge agreed with your therapist or the fictional example. You do not have to act on the urge, write an answer or decide immediately.",
      "status": "Script only"
    },
    {
      "id": "proscons.fit",
      "title": "Use the ordinary practice version",
      "text": "Use this after your therapist introduces it and chooses a suitable, non-urgent situation with you.\n\nThis page is not for weighing suicide, self-harm, violence, dangerous substance use, abuse, medical decisions or other high-stakes actions. If urgent safety or care is needed, use your agreed support plan or appropriate help now rather than completing a comparison.\n\nChoose a specific ordinary urge, not every possible life decision. If the exercise becomes repeated checking for certainty, pause and discuss that pattern. This page is not monitored and does not make a decision for you.",
      "status": "Script only"
    },
    {
      "id": "proscons.learn",
      "title": "Why four boxes rather than two?",
      "text": "Consider the possible benefits and costs of following the urge, then the benefits and costs of not following it. Not acting can have costs too, such as frustration remaining for a while. Naming that honestly is part of the method.\n\nIn each box distinguish what might happen soon from what might matter later. A consequence may be uncertain; do not turn a possibility into a prediction.\n\nReview importance, not the length of the lists. A single important consequence may matter more than several small ones. This practice does not add scores, choose for you, or require enduring a situation that is unsafe.",
      "status": "Script only"
    },
    {
      "id": "proscons.example",
      "title": "Example — wanting to give up a hobby",
      "text": "After one frustrating practice, Jordan wants to give up an otherwise enjoyed hobby immediately. Jordan and a therapist use this ordinary urge to rehearse the four-part method.\n\nFollowing the urge: a possible near-term benefit is escaping the frustration and freeing time. Possible later costs are losing an enjoyed activity and regretting a decision made in a heated moment.\n\nNot following the urge now: a benefit is keeping the option to decide later; a later benefit might be returning to something Jordan values. Costs are that frustration and uncertainty may remain, and a later decision still needs attention. Not following the urge does not mean forcing continued practice tonight.\n\nJordan reviews the four boxes and chooses to leave the larger decision open for now. Frustration remains. The comparison helped Jordan notice time horizons; it did not prove that keeping the hobby is always right or that a future activity has been completed.",
      "status": "Script only"
    },
    {
      "id": "proscons.scenario",
      "title": "Optional fictional practice — Jordan",
      "text": "Use Jordan’s urge to give up an ordinarily enjoyed hobby after a frustrating attempt. Compare following that urge now with not deciding to give up now.\n\nYou do not have to match Jordan’s conclusion. Work with likely or uncertain consequences, not a rule that everyone must persist with every hobby.",
      "status": "Script only"
    },
    {
      "id": "proscons.practice.urge",
      "title": "Define the urge and its alternative",
      "text": "What specific ordinary urge are you considering? What would following it mean? What would not following it now mean in this situation?\n\nUse the agreed situation or Jordan’s example. Not acting on an urge can include a pause; it does not mean doing the exact opposite or staying in danger.",
      "status": "Script only"
    },
    {
      "id": "proscons.practice.urge.help",
      "title": "If the alternatives are unclear",
      "text": "Make them specific enough to compare, or leave the question for your therapist. Do not create an extreme alternative such as “I must keep doing this forever.”",
      "status": "Script only"
    },
    {
      "id": "proscons.practice.grid",
      "title": "Consider all four sides",
      "text": "Consider possible benefits and costs of following the urge, and possible benefits and costs of not following it. In each box, think about soon and later if relevant.\n\nYou may leave a box unknown or empty. You do not need equal numbers of items, reassuring answers or certainty.",
      "status": "Script only"
    },
    {
      "id": "proscons.practice.grid.help",
      "title": "If you only notice immediate relief",
      "text": "Keep that real short-term possibility and look for possible later effects too. Also acknowledge the discomfort of not following the urge; do not hide it to force a conclusion.",
      "status": "Script only"
    },
    {
      "id": "proscons.practice.review",
      "title": "Review what matters, without a tally",
      "text": "Look at the four boxes together. Which consequences matter most in this situation? What is uncertain or missing? A longer list does not win.\n\nWhat response, pause or support need fits your review? You can leave the decision open. Considering a response is not the same as carrying it out.",
      "status": "Script only"
    },
    {
      "id": "proscons.practice.review.help",
      "title": "If a benefit appears in two boxes",
      "text": "That may be useful information rather than an error. Describe how the alternatives differ; the aim is understanding consequences, not producing a perfectly symmetrical grid.",
      "status": "Script only"
    },
    {
      "id": "proscons.close",
      "title": "A provisional review is enough",
      "text": "You can finish with a response, a pause or an open question. No action or feeling change is required. This page does not save the comparison; an agreed personal record elsewhere is separate.",
      "status": "Script only"
    },
    {
      "id": "proscons.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    }
  ],
  "reviewerNotes": {
    "historicalCatalogueTitle": "Pros and Cons / Advantages–Disadvantages Analysis",
    "historicalScope": "DBT Pros and Cons component, rehearsed with an ordinary therapist-agreed urge. The separate CBT Advantages–Disadvantages mode is not built here. Not a crisis assessment, generic priorities comparison or decision calculator.",
    "catalogueComponentStatus": "DBT four-quadrant practice only; CBT Advantages/Disadvantages component remains unbuilt. No new catalogue count.",
    "reason": "Separate catalogue bookkeeping from the learner-facing DBT practice. The CBT variant is not implemented by this page."
  }
};
