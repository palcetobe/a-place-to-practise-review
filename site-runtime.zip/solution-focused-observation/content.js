window.SolutionFocusedObservationContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/solution-focused-observation",
  "resourceId": "tool/solution-focused-observation",
  "routeProposal": "/solution-focused-observation/",
  "title": "Solution-Focused Observation",
  "version": "2026-11-05-public-review-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. No recordings are provided for this practice; scripts are prepared and listening approval is not asserted.",
  "scope": "Therapist-co-constructed observation of real events the person would like to continue, followed by concrete, client-defined reflection and a next-session conversation. No required problem exception, positive finding, behavioral assignment or whole SFBT treatment.",
  "groupedSetStatus": "Existing grouped canonical entry classic/solution-focused-observation. Complete written observational follow-through cycle only, including an explicit real-session review boundary. Broader behavioral suggestions and SFBT therapy are not implemented. No component identity is invented and no canonical count is added.",
  "implementedSubset": "therapist-co-constructed-observation-and-session-review",
  "relatedComponentsComplete": false,
  "clinicalContract": {
    "learningObjective": "Distinguish observing personally desired continuations from forced positivity, self-worth evidence, behavioral activation, monitoring a problem pattern or therapist-imposed improvement. The person defines what would be worth continuing and may notice nothing useful.",
    "practiceObjective": "Agree an observational invitation in an actual therapy conversation; choose an accessible observation window and optional way to remember; notice real events without a demand to change them; describe actual or absent observations, their desired significance and possible contributions/context; choose what to bring to the next session and review there before any new suggestion.",
    "sourcePopulationContext": "The directly read SFBTA 2025 professional treatment manual and founder-authored Berg procedures establish clinical conversation and co-construction, not a validated standalone worksheet. No age floor or all-age efficacy claim; developmental understanding, communication, culture, consent, safeguarding, access and clinical fit require individual review.",
    "exclusions": [
      "No whole SFBT treatment, automated therapist, diagnosis, risk assessment, miracle question, scaling protocol or compulsory search for exceptions",
      "No mandatory optimism, gratitude, symptom improvement, finding a positive event, achievement or proof of personal worth",
      "No behavioral assignment, exposure, activity prescription, increase in demands, surveillance, recording or contact initiated by the tool",
      "No ignoring abuse, discrimination, poverty, disability, medical needs or practical risks because an event seemed better",
      "No claim that one event reveals a cause, guarantees recurrence, proves another person changed or makes unsafe contact safe",
      "No replacement for care, safeguarding, real next-session conversation or needed immediate support"
    ],
    "adaptations": [
      "Original explanation, optional record and fictional example, not copied source text or worksheet",
      "Preserve the historical broad FFST invitation and modern individualized observational suggestions as alternative agreed focuses, not a universal assignment at every first session",
      "A person may notice an event outside the presenting problem; an exception, deliberate action, numerical score or changed feeling is not required",
      "Private thought, speech, sign, AAC or optional writing can support recall; this tool does not preserve a longitudinal log or conduct the next clinical conversation",
      "Concrete event, personal meaning and possible contribution/context remain distinct; no forced strengths label or causal certainty",
      "Behavioral suggestions remain separate. A future choice is discussed with the therapist, not automatically generated from an observation"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of observational scope, co-construction fidelity, accessible wording, source adaptations and release rights",
      "Individual agreement in a real therapy conversation, developmental/communication/cultural/safeguarding/access and clinical fit",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration production and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose preparation or review",
      "options": [
        {
          "value": "prepare",
          "label": "Prepare an agreed observation",
          "startSectionId": "solution-focused-observation.practice.situation"
        },
        {
          "value": "review",
          "label": "Review what I noticed",
          "startSectionId": "solution-focused-observation.practice.result"
        }
      ]
    },
    "entryGate": "Purpose, therapist co-construction, choice and practical safety visible before entry. No default mode, agreed assignment, positive event or completed therapy inferred.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing, sequence, event, improvement or result.",
    "reviewAccess": "Direct blank review identifies the real observation window and actual/no/unclear events. No saved plan, personal example, desired outcome or completed session inferred.",
    "writing": "Optional and hidden initially; hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. Optional preparation/review, not ongoing observation or monitoring. No audio, TTS, recording or autoplay.",
    "timer": "None. No daily quota, streak, event count, score, observation timer or automatic reminder.",
    "completion": "No inferred positive finding, exception, deliberate action, improvement, changed relationship, next-session conversation or full treatment completion."
  },
  "intro": {
    "id": "solution-focused-observation.intro",
    "title": "Notice something you would like to continue",
    "paragraphs": [
      "In this practice, you and your therapist agree what you might notice between sessions. You look for real moments you would like to keep in your life. They can be small and ordinary, and need not solve the problem that brought you to therapy.",
      "The task is to notice, not to make a good thing happen. You do not have to find a bright side, feel grateful or turn every hard moment into a lesson. Nothing useful noticed is an honest result.",
      "Use this after you and your therapist have agreed what to notice in a way that fits you. This page can help you prepare or recall what to discuss next. It does not replace that conversation. You can also read the made-up example without taking on a task."
    ]
  },
  "fit": {
    "id": "solution-focused-observation.fit",
    "title": "Keep your own aims and real needs in view",
    "paragraphs": [
      "What counts as worth continuing is yours to decide. A therapist can help make the invitation clear, but you do not need to adopt someone else’s wish for how you should act or feel. You can change the focus, decline the task or pause.",
      "Noticing one useful moment does not cancel harm or make an unsafe situation safe. Do not use this to ignore threats, abuse, discrimination, a health need or a practical problem. Get the support you need rather than waiting to find a better moment.",
      "Choose a way to notice and remember that fits your age, understanding, culture, communication and access. You can think, speak, sign, use an aid or make an optional note. No particular sense, daily record or contact with another person is required.",
      "If the task becomes pressure to please your therapist, watch yourself all day or prove that life is improving, stop and discuss that. You do not have to earn care by finding something good. A different focus or no task may fit better."
    ]
  },
  "privacy": {
    "id": "solution-focused-observation.privacy",
    "title": "Keep only the details you choose",
    "paragraphs": [
      "A few words may help you remember. Leave out names and private details about others when they are not needed. This tool does not watch your day, record an interaction, contact anyone or send your therapist a report.",
      "Writing stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.",
      "Hiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox."
    ]
  },
  "close": {
    "id": "solution-focused-observation.close",
    "title": "Finish with an observation or an open question",
    "paragraphs": [
      "You can finish after reading, preparing or reviewing. No useful event, changed feeling or next action is needed to leave. A plan to notice is not the same as having noticed something.",
      "Choose what, if anything, you want to bring to your therapist. Nothing is sent and no reminder is made. Leaving clears this tool’s notes, not copies you kept elsewhere."
    ]
  },
  "example": {
    "id": "solution-focused-observation.example",
    "title": "A made-up example: a little room to speak",
    "paragraphs": [
      "Kai tells a therapist, “I’d like more room to share my ideas.” Together they agree that before the next session, Kai might notice any ordinary moment they would like to continue. Kai does not agree to start a conversation or make anyone listen.",
      "On one day, Kai notices nothing that fits. Later, during a familiar craft group, a member asks which paper Kai would use and waits. Kai points to the green sheet using a communication board. The group uses another color, but Kai has had time to give an idea.",
      "Kai wants that room to choose and respond to continue, not a promise that everyone will agree. The board was available, the question was clear and someone waited. Kai’s own part was giving a choice. Kai does not know which part made the difference, or whether it will happen next time.",
      "Kai keeps the words “time to give my idea” on a private note. Anxiety has not gone away, and other parts of the week were hard. This one event does not erase those things.",
      "At the next session, Kai chooses to describe the event and the day when nothing stood out. The therapist asks what mattered to Kai and checks whether the invitation was useful. They agree to keep noticing for now. No extra social task follows automatically."
    ]
  },
  "learn": {
    "id": "solution-focused-observation.learn",
    "title": "An observation is not a demand to improve",
    "paragraphs": [
      "Solution-focused work pays close attention to what a person wants in life, including small signs already present. The person and therapist build the next step together through conversation. A page cannot decide the person’s goal or what an event means.",
      "One early task in this approach is called the Formula First Session Task. It invites noticing things a person would like to continue before the next meeting. The broad invitation can reach beyond the main problem. It is not a rule that every first session must end with this task.",
      "Other observation invitations are more specific and come from the conversation, such as noticing when there is room to make a choice. Agree the focus with your therapist. You do not need to find a time when a problem was absent, use a number scale or answer an imagined-future question.",
      "Noticing differs from an action task. This page does not ask you to arrange an event or repeat a behavior to test it. Any later action suggestion needs its own shared discussion. A useful event may involve something you did, other people, support, timing or something you cannot explain.",
      "The aim is not a list of good qualities, gratitude or proof that things are better. Nor do you have to compare several problem episodes to find a pattern. You are noticing what you personally want to keep, then using that detail in the next conversation. Difficult or absent observations belong there too."
    ]
  },
  "practice": [
    {
      "id": "solution-focused-observation.practice.situation",
      "title": "Start with the invitation you agreed",
      "paragraphs": [
        "What did you and your therapist agree would be useful to notice? You can keep the invitation broad: ordinary moments you would like to continue. Or use a specific focus that came from your conversation.",
        "Use your own words. If the invitation is unclear or does not fit, check it with your therapist instead of guessing. You can explore the example or finish without taking on an assignment."
      ],
      "fields": [
        {
          "key": "invitation",
          "label": "The observation invitation I agreed with my therapist",
          "optional": true
        },
        {
          "key": "my-aim",
          "label": "What I want from this, or what is unclear",
          "optional": true
        }
      ],
      "help": {
        "title": "If someone else chose the goal",
        "text": "You can say what you want, do not want or do not understand. Agreement does not mean having to find the result someone hopes for."
      }
    },
    {
      "id": "solution-focused-observation.practice.focus",
      "title": "Make the focus clear enough to notice",
      "paragraphs": [
        "What might an ordinary example look like in your life? A broad focus can stay broad. If you chose something like “more room to choose,” you might notice someone waiting for your answer or time to decide for yourself.",
        "This is a possible example, not a result you must produce. Leave room for a different event to matter. You do not have to tie it to the main problem or label it an exception."
      ],
      "fields": [
        {
          "key": "possible-event",
          "label": "What an example might look like, if helpful",
          "optional": true
        },
        {
          "key": "not-required",
          "label": "A result I do not need to produce",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot picture an example",
        "text": "Keep the agreed broad invitation, ask for help making it clearer, or pause. Do not invent an event to make the page work."
      }
    },
    {
      "id": "solution-focused-observation.practice.plan",
      "title": "Agree a manageable time and way to remember",
      "paragraphs": [
        "When will you and your therapist next talk about what you noticed? Use the time you agreed. This page does not set a daily task, count or new appointment.",
        "You can simply remember, or choose a private way to keep a few words if that helps. Consider time, privacy, access and support. There is no need to check each hour, watch another person or record their behavior."
      ],
      "fields": [
        {
          "key": "window",
          "label": "The agreed time to notice or next conversation",
          "optional": true
        },
        {
          "key": "remember",
          "label": "How I might remember, or no record",
          "optional": true
        },
        {
          "key": "limits",
          "label": "Privacy, access or other needs to keep in view",
          "optional": true
        }
      ],
      "help": {
        "title": "If remembering is difficult",
        "text": "Agree an accessible cue or way to share with your therapist. A missed detail is not failure, and a record is not required to receive support."
      }
    },
    {
      "id": "solution-focused-observation.practice.observe",
      "title": "Notice during ordinary life",
      "paragraphs": [
        "Set the page aside and go on with your day. During the agreed time, if a moment catches your attention, ask whether you would like some part of it to continue. You do not have to search all day or arrange the moment.",
        "If something fits, notice enough detail to recognize it later. Keep the event separate from guesses about why it happened. A hard feeling can still be present. Do not force yourself to enjoy, repeat or stay in the situation."
      ],
      "fields": [
        {
          "key": "memory-cue",
          "label": "A few words about a real moment, if one occurs",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am only preparing now",
        "text": "Leave this part open. You can return to review later without a saved plan. Reading an example or imagining a moment is not an observation from your own life."
      }
    },
    {
      "id": "solution-focused-observation.practice.none",
      "title": "Leave room for nothing, worse or unclear",
      "paragraphs": [
        "You may notice nothing that fits, have no real chance to observe, or find that life became harder. Keep that account as it is. You do not need to hunt for a positive detail to balance it.",
        "Practical help, safety or a different kind of conversation may matter more. If you need support now, use your usual support or care plan rather than waiting for the next session. This tool cannot assess your situation."
      ],
      "fields": [
        {
          "key": "no-event",
          "label": "Nothing noticed, no chance, harder or unclear, if that fits",
          "optional": true
        },
        {
          "key": "need",
          "label": "A need or question I want help with",
          "optional": true
        }
      ],
      "help": {
        "title": "If I feel I let my therapist down",
        "text": "The task is information for a shared conversation, not a test of effort. You can bring the mismatch or pressure itself to the session."
      }
    },
    {
      "id": "solution-focused-observation.practice.result",
      "title": "Review what actually happened",
      "paragraphs": [
        "What time or occasion are you reviewing, and what did you actually notice? You can start here without a saved plan. Say if you only prepared, noticed nothing, stopped or are unsure.",
        "Choose one real event if there is one you want to discuss. Keep a made-up example or future hope separate. If there is no event, you can go straight to the next-session discussion without filling in the event steps."
      ],
      "fields": [
        {
          "key": "actual-window",
          "label": "The time or occasion I am reviewing",
          "optional": true
        },
        {
          "key": "actual-result",
          "label": "What I actually noticed, did not notice or could not try",
          "optional": true
        }
      ],
      "help": {
        "title": "If I remember only part",
        "text": "Keep the part you remember and leave the rest unknown. Do not repeatedly replay an event to get a perfect account."
      }
    },
    {
      "id": "solution-focused-observation.practice.detail",
      "title": "Describe one event in plain detail",
      "paragraphs": [
        "What was happening, and what did you notice or do? Name only the details that help explain the moment. For example, “Someone waited while I chose,” is more specific than “Everyone was kind.”",
        "Use what you can recall, including your own experience. You do not need to guess another person’s thoughts, collect proof or ask them for reassurance. A brief account can be enough for the conversation."
      ],
      "fields": [
        {
          "key": "event",
          "label": "The event and what I actually noticed",
          "optional": true
        },
        {
          "key": "unknown",
          "label": "What I do not know or cannot recall",
          "optional": true
        }
      ],
      "help": {
        "title": "If a private detail is not needed",
        "text": "Leave it out. You can keep names and identifying information off the page and decide later what you want to share."
      }
    },
    {
      "id": "solution-focused-observation.practice.meaning",
      "title": "Name the part you would like to continue",
      "paragraphs": [
        "What, if anything, about this moment would you like to keep in your life? What makes that part matter to you? It may be a choice, some space, support or something else you name.",
        "You do not need to want every part of the event again. You can value being heard without agreeing to more contact, or value rest without calling the whole day good. A later look may show that the event does not fit after all."
      ],
      "fields": [
        {
          "key": "continue",
          "label": "The part I would like to continue, if any",
          "optional": true
        },
        {
          "key": "matters",
          "label": "Why that part matters to me",
          "optional": true
        },
        {
          "key": "not-repeat",
          "label": "A part I do not want to repeat or still question",
          "optional": true
        }
      ],
      "help": {
        "title": "If it no longer feels useful",
        "text": "Keep the change in view. You are allowed to revise the meaning rather than make the event fit the task."
      }
    },
    {
      "id": "solution-focused-observation.practice.supports",
      "title": "Notice your part and the wider setting",
      "paragraphs": [
        "Was there anything you did that helped this wanted part happen? There may be no clear answer. Also consider what other people, tools, timing, access or circumstances made possible.",
        "Describe possible help without claiming a cause. You do not control other people’s choices or every condition. One event does not prove you can make it happen again by trying harder."
      ],
      "fields": [
        {
          "key": "my-part",
          "label": "Anything I did that helped, or none / not sure",
          "optional": true
        },
        {
          "key": "context",
          "label": "Support or circumstances that may have mattered",
          "optional": true
        }
      ],
      "help": {
        "title": "If it seemed to happen by chance",
        "text": "That can stay in the account. You do not have to turn it into a personal success or invent a step you can repeat."
      }
    },
    {
      "id": "solution-focused-observation.practice.session",
      "title": "Bring what you choose to the next conversation",
      "paragraphs": [
        "At the agreed session, share only what you want: an event, why it mattered, nothing noticed, a harder week or a concern about the task. You can say it in your own way without handing over notes.",
        "Explore with your therapist what the observation means to you and whether the invitation helped. There may be more to understand about support, limits or what you want next. Preparing this account is not the same as having that conversation."
      ],
      "fields": [
        {
          "key": "share",
          "label": "What I want to discuss, if anything",
          "optional": true
        },
        {
          "key": "session-status",
          "label": "Conversation still to come, or what we actually discussed",
          "optional": true
        }
      ],
      "help": {
        "title": "If the session has not happened yet",
        "text": "Leave the outcome open. This page does not contact your therapist, schedule a meeting or complete the review for you."
      }
    },
    {
      "id": "solution-focused-observation.practice.next",
      "title": "Let the next step be a shared choice",
      "paragraphs": [
        "After the conversation, you may agree to keep noticing, change the focus, consider a separate action or stop the task. There is no automatic instruction to do more just because one moment mattered.",
        "If you have not discussed it yet, you can keep a question for later. A new action, if wanted, needs its own check of consent, safety, access and practical fit. You can finish with no new plan."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "An agreed next choice, or still undecided",
          "optional": true
        },
        {
          "key": "next-question",
          "label": "A question, support or limit to keep in view",
          "optional": true
        }
      ],
      "help": {
        "title": "If the same moment cannot happen again",
        "text": "That does not erase what it showed you wanted. Discuss whether any part remains useful, whether other support is needed, or whether to leave it here."
      }
    }
  ],
  "sources": [
    {
      "url": "https://www.sfbta.org/Solution%20Focused%20Therapy%20Treatment%20Manual%20for%20Working%20with%20Individuals%20-3rd%20Edition-%20final.pdf",
      "supports": "Printed pp.6–7 historical Formula First Session Task and return to the next meeting; pp.8–9 co-construction; pp.19–22/24–25 client-defined detail and later-session exploration; pp.30–31 observational versus behavioral suggestions; pp.33–34 nothing better or worse.",
      "limits": "Professional treatment manual, not validation of this standalone digital adaptation. Original writing and example; no source scripts reproduced. Broader therapy, scaling, miracle question and behavioral assignments are not implemented.",
      "label": "SFBTA Research Committee: Solution Focused Therapy Treatment Manual, 3rd edition (2025)"
    },
    {
      "url": "https://www.sfbta.org/Solution-building_procedures.pdf",
      "supports": "Inspected first-page text outlines negotiated goals, exceptions, scaling and possible next steps. It provides broader conversational context, not the specific observation protocol.",
      "limits": "Founder-authored clinical outline, not a universal homework prescription or standalone-tool efficacy study. Attribution and availability do not establish public reproduction rights.",
      "label": "Insoo Kim Berg: Solution-Building Procedures (SFBTA legacy material)"
    }
  ],
  "narrationSegments": [
    {
      "id": "solution-focused-observation.intro",
      "title": "Notice something you would like to continue",
      "text": "In this practice, you and your therapist agree what you might notice between sessions. You look for real moments you would like to keep in your life. They can be small and ordinary, and need not solve the problem that brought you to therapy.\n\nThe task is to notice, not to make a good thing happen. You do not have to find a bright side, feel grateful or turn every hard moment into a lesson. Nothing useful noticed is an honest result.\n\nUse this after you and your therapist have agreed what to notice in a way that fits you. This page can help you prepare or recall what to discuss next. It does not replace that conversation. You can also read the made-up example without taking on a task.",
      "sha256": "712524ee98f6512a8d4fa5c76ab85f03c453785c48fab36acdf0d622d78d7fcf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.fit",
      "title": "Keep your own aims and real needs in view",
      "text": "What counts as worth continuing is yours to decide. A therapist can help make the invitation clear, but you do not need to adopt someone else’s wish for how you should act or feel. You can change the focus, decline the task or pause.\n\nNoticing one useful moment does not cancel harm or make an unsafe situation safe. Do not use this to ignore threats, abuse, discrimination, a health need or a practical problem. Get the support you need rather than waiting to find a better moment.\n\nChoose a way to notice and remember that fits your age, understanding, culture, communication and access. You can think, speak, sign, use an aid or make an optional note. No particular sense, daily record or contact with another person is required.\n\nIf the task becomes pressure to please your therapist, watch yourself all day or prove that life is improving, stop and discuss that. You do not have to earn care by finding something good. A different focus or no task may fit better.",
      "sha256": "7e958ef0e50154e3766c0bae763d61b3d5540173d41942078aecb0466308f14f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.privacy",
      "title": "Keep only the details you choose",
      "text": "A few words may help you remember. Leave out names and private details about others when they are not needed. This tool does not watch your day, record an interaction, contact anyone or send your therapist a report.\n\nWriting stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.\n\nHiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox.",
      "sha256": "49db4c62d8f6081254490be63f723a217ea10a839740c9d1fd09ddf030502fc5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.close",
      "title": "Finish with an observation or an open question",
      "text": "You can finish after reading, preparing or reviewing. No useful event, changed feeling or next action is needed to leave. A plan to notice is not the same as having noticed something.\n\nChoose what, if anything, you want to bring to your therapist. Nothing is sent and no reminder is made. Leaving clears this tool’s notes, not copies you kept elsewhere.",
      "sha256": "76ac7ad51d14291d5ce592b4124ee24a37f7d2991a1473b9b3b8ac89b1aa8a12",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.example",
      "title": "A made-up example: a little room to speak",
      "text": "Kai tells a therapist, “I’d like more room to share my ideas.” Together they agree that before the next session, Kai might notice any ordinary moment they would like to continue. Kai does not agree to start a conversation or make anyone listen.\n\nOn one day, Kai notices nothing that fits. Later, during a familiar craft group, a member asks which paper Kai would use and waits. Kai points to the green sheet using a communication board. The group uses another color, but Kai has had time to give an idea.\n\nKai wants that room to choose and respond to continue, not a promise that everyone will agree. The board was available, the question was clear and someone waited. Kai’s own part was giving a choice. Kai does not know which part made the difference, or whether it will happen next time.\n\nKai keeps the words “time to give my idea” on a private note. Anxiety has not gone away, and other parts of the week were hard. This one event does not erase those things.\n\nAt the next session, Kai chooses to describe the event and the day when nothing stood out. The therapist asks what mattered to Kai and checks whether the invitation was useful. They agree to keep noticing for now. No extra social task follows automatically.",
      "sha256": "8a133e38ed0c18a73350c6a0ab7c3841a8be46731f0df91f8ba4e7b98055db86",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.learn",
      "title": "An observation is not a demand to improve",
      "text": "Solution-focused work pays close attention to what a person wants in life, including small signs already present. The person and therapist build the next step together through conversation. A page cannot decide the person’s goal or what an event means.\n\nOne early task in this approach is called the Formula First Session Task. It invites noticing things a person would like to continue before the next meeting. The broad invitation can reach beyond the main problem. It is not a rule that every first session must end with this task.\n\nOther observation invitations are more specific and come from the conversation, such as noticing when there is room to make a choice. Agree the focus with your therapist. You do not need to find a time when a problem was absent, use a number scale or answer an imagined-future question.\n\nNoticing differs from an action task. This page does not ask you to arrange an event or repeat a behavior to test it. Any later action suggestion needs its own shared discussion. A useful event may involve something you did, other people, support, timing or something you cannot explain.\n\nThe aim is not a list of good qualities, gratitude or proof that things are better. Nor do you have to compare several problem episodes to find a pattern. You are noticing what you personally want to keep, then using that detail in the next conversation. Difficult or absent observations belong there too.",
      "sha256": "1615152a26a116317f9f361762514e409e9cde70014443bc5bf5fbf5db96678a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.situation",
      "title": "Start with the invitation you agreed",
      "text": "What did you and your therapist agree would be useful to notice? You can keep the invitation broad: ordinary moments you would like to continue. Or use a specific focus that came from your conversation.\n\nUse your own words. If the invitation is unclear or does not fit, check it with your therapist instead of guessing. You can explore the example or finish without taking on an assignment.",
      "sha256": "236808be7c694edbd207f65c9649df8a97b5bfc6fbf66b681c9dcd845c9b5924",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.situation.help",
      "title": "If someone else chose the goal",
      "text": "You can say what you want, do not want or do not understand. Agreement does not mean having to find the result someone hopes for.",
      "sha256": "99cb3de3049a67a88a8283ec820a2fcd14f6549a3b9dd358be886e06dd541112",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.focus",
      "title": "Make the focus clear enough to notice",
      "text": "What might an ordinary example look like in your life? A broad focus can stay broad. If you chose something like “more room to choose,” you might notice someone waiting for your answer or time to decide for yourself.\n\nThis is a possible example, not a result you must produce. Leave room for a different event to matter. You do not have to tie it to the main problem or label it an exception.",
      "sha256": "2e956c896877546fe792ae42be2c7e87d5ce91e3f5df1b3b5041c7054a0a493f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.focus.help",
      "title": "If I cannot picture an example",
      "text": "Keep the agreed broad invitation, ask for help making it clearer, or pause. Do not invent an event to make the page work.",
      "sha256": "865bd5325f1334cde1207cc513d82e0ed5afe3412285e8069f30856c796a4c1d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.plan",
      "title": "Agree a manageable time and way to remember",
      "text": "When will you and your therapist next talk about what you noticed? Use the time you agreed. This page does not set a daily task, count or new appointment.\n\nYou can simply remember, or choose a private way to keep a few words if that helps. Consider time, privacy, access and support. There is no need to check each hour, watch another person or record their behavior.",
      "sha256": "33c0b0f78b8f3af7c07bf03359e4da2a31d67f5700e69ccaaae92a64160301fb",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.plan.help",
      "title": "If remembering is difficult",
      "text": "Agree an accessible cue or way to share with your therapist. A missed detail is not failure, and a record is not required to receive support.",
      "sha256": "c7c728c475e2d902318d8132f601876ae93fc4e32210b43e777105f989ca2b69",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.observe",
      "title": "Notice during ordinary life",
      "text": "Set the page aside and go on with your day. During the agreed time, if a moment catches your attention, ask whether you would like some part of it to continue. You do not have to search all day or arrange the moment.\n\nIf something fits, notice enough detail to recognize it later. Keep the event separate from guesses about why it happened. A hard feeling can still be present. Do not force yourself to enjoy, repeat or stay in the situation.",
      "sha256": "957df728e27779f39e6ae63e16cae602e0b43abff86f7063755c2b5d0f73d905",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.observe.help",
      "title": "If I am only preparing now",
      "text": "Leave this part open. You can return to review later without a saved plan. Reading an example or imagining a moment is not an observation from your own life.",
      "sha256": "0dd883378bdfe42ab20ce6efd3da8486415fb2090bb8d48bdbe3ac53d1e429cf",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.none",
      "title": "Leave room for nothing, worse or unclear",
      "text": "You may notice nothing that fits, have no real chance to observe, or find that life became harder. Keep that account as it is. You do not need to hunt for a positive detail to balance it.\n\nPractical help, safety or a different kind of conversation may matter more. If you need support now, use your usual support or care plan rather than waiting for the next session. This tool cannot assess your situation.",
      "sha256": "6792d55b9c26fa08e9da39a165f616e1732791b31a106aca1a79570dcb80ded2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.none.help",
      "title": "If I feel I let my therapist down",
      "text": "The task is information for a shared conversation, not a test of effort. You can bring the mismatch or pressure itself to the session.",
      "sha256": "a33caa42bf148c100adfc719b4132aff3e5b094001e50158bc33e9ce41924270",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.result",
      "title": "Review what actually happened",
      "text": "What time or occasion are you reviewing, and what did you actually notice? You can start here without a saved plan. Say if you only prepared, noticed nothing, stopped or are unsure.\n\nChoose one real event if there is one you want to discuss. Keep a made-up example or future hope separate. If there is no event, you can go straight to the next-session discussion without filling in the event steps.",
      "sha256": "26ccb5d9bf16aec7cc0472ec1104d94f5b820e42589d8baa4d6fbcb4e1293176",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.result.help",
      "title": "If I remember only part",
      "text": "Keep the part you remember and leave the rest unknown. Do not repeatedly replay an event to get a perfect account.",
      "sha256": "9e1f7b00b9f7d4c60ba2c7a162291cc6f0ab0f6e4334160786461c31dcba1663",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.detail",
      "title": "Describe one event in plain detail",
      "text": "What was happening, and what did you notice or do? Name only the details that help explain the moment. For example, “Someone waited while I chose,” is more specific than “Everyone was kind.”\n\nUse what you can recall, including your own experience. You do not need to guess another person’s thoughts, collect proof or ask them for reassurance. A brief account can be enough for the conversation.",
      "sha256": "9d1df8e7dfa2b9cd2f2e6f7c547c7ac9ff87765421849cc4375dc8ed7d6ae4f2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.detail.help",
      "title": "If a private detail is not needed",
      "text": "Leave it out. You can keep names and identifying information off the page and decide later what you want to share.",
      "sha256": "01d0088239b3dd0d46ffbe17c705b29d661ab2b0aa8ef197d4ac6d6a9f0cb59b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.meaning",
      "title": "Name the part you would like to continue",
      "text": "What, if anything, about this moment would you like to keep in your life? What makes that part matter to you? It may be a choice, some space, support or something else you name.\n\nYou do not need to want every part of the event again. You can value being heard without agreeing to more contact, or value rest without calling the whole day good. A later look may show that the event does not fit after all.",
      "sha256": "5ffa6f5d6f0ba9cdcc41254fbbd33f888cb760e5d5c54871ed239736518ea98a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.meaning.help",
      "title": "If it no longer feels useful",
      "text": "Keep the change in view. You are allowed to revise the meaning rather than make the event fit the task.",
      "sha256": "765c5459cd2cc262516173689c9bf83ceefcfd4dedef277fb338b838fbfe3729",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.supports",
      "title": "Notice your part and the wider setting",
      "text": "Was there anything you did that helped this wanted part happen? There may be no clear answer. Also consider what other people, tools, timing, access or circumstances made possible.\n\nDescribe possible help without claiming a cause. You do not control other people’s choices or every condition. One event does not prove you can make it happen again by trying harder.",
      "sha256": "e32b85203aa7be76e8daeb02f58ef286a1dd9e022a0a0647daeeb935e05a6997",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.supports.help",
      "title": "If it seemed to happen by chance",
      "text": "That can stay in the account. You do not have to turn it into a personal success or invent a step you can repeat.",
      "sha256": "4151adf4c7f448f12269d84cbf78e6abe860bccb6659e35351524ce5be965c15",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.session",
      "title": "Bring what you choose to the next conversation",
      "text": "At the agreed session, share only what you want: an event, why it mattered, nothing noticed, a harder week or a concern about the task. You can say it in your own way without handing over notes.\n\nExplore with your therapist what the observation means to you and whether the invitation helped. There may be more to understand about support, limits or what you want next. Preparing this account is not the same as having that conversation.",
      "sha256": "c8b57043cdff7e0e9541b763476da6f182284195f112758f58a577e4e0f7b327",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.session.help",
      "title": "If the session has not happened yet",
      "text": "Leave the outcome open. This page does not contact your therapist, schedule a meeting or complete the review for you.",
      "sha256": "f260e0a4a16ad679258b21501176442e3f16e8af1087e7a7880dfdb416ebd62c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "solution-focused-observation.practice.next",
      "title": "Let the next step be a shared choice",
      "text": "After the conversation, you may agree to keep noticing, change the focus, consider a separate action or stop the task. There is no automatic instruction to do more just because one moment mattered.\n\nIf you have not discussed it yet, you can keep a question for later. A new action, if wanted, needs its own check of consent, safety, access and practical fit. You can finish with no new plan.",
      "sha256": "b4786c1cc7e11de546b1577c58a2f02d565f530eb2911801ce0ee7d84ea9c998",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "solution-focused-observation.practice.next.help",
      "title": "If the same moment cannot happen again",
      "text": "That does not erase what it showed you wanted. Discuss whether any part remains useful, whether other support is needed, or whether to leave it here.",
      "sha256": "4700cf857d3de0b6b278aa26b3798915844f271bc74b38de6c7348d373a60792",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
