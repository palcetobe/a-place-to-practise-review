window.InterpersonalLegacy = {
  "preview": [
    [
      "fast-t",
      "What I need to say: "
    ],
    [
      "fast-s",
      "What I'm protecting: "
    ],
    [
      "fast-f",
      "What fair looks like: "
    ]
  ]
};
