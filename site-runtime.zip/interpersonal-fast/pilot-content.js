window.InterpersonalPilotContent = {
  "schema": "a-place-to-practise.optional-fictional-pilot.v1",
  "id": "pilot/fast-phrases",
  "canonicalId": "classic/fast",
  "resourceId": "tool/fast",
  "title": "Keep, change or trim a fictional phrase",
  "version": "2026-11-03-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "integration": {
    "anchorIds": [
      "fast.practice.apologies",
      "fast.practice.review"
    ],
    "placement": "One optional teaching exercise opened from a quiet text action beside the stated prompt or contextual help. Not a new required step, top-level mode, route, tool or catalogue entry.",
    "preserve": "All existing 7/4/4 prompts, original examples, three adjacent Practice this skill / See an example / Learn more actions, note preview/export/guide behavior, saved IDs and safety/support remain unchanged.",
    "entry": "No automatic opening. Keep the precise originating prompt, active context, response choice, scroll/focus and notes; opening this fiction exercise does not select fictional context in the underlying personal practice.",
    "exit": "Close/Back returns to the precise originating prompt and state. Finish/support/leave obey existing tool-wide clear policy. No required choices or completion event.",
    "state": "Only authored fictional selection state inside this optional exercise; no persistence or analytics. Switching unrelated pilot scenarios resets their local edits, never personal practice notes. Closing resets local pilot selections and stops its audio; the main practice is untouched.",
    "privacy": "Do not read, import, infer, copy into, overwrite, score or narrate any private field. This fictional-only pilot has no personal writing input, microphone, recording, timer or automatic export.",
    "narration": "Exact static visible section only, explicit Listen/Pause/Resume; Replay unavailable until that exact clip actually plays. Stop before any panel/choice/scenario/phrase/action change, close, navigation or focus return. No autoplay, composite-script speech, hidden-branch audio, TTS or new provider.",
    "support": "Existing support/finish remain reachable. No safety questionnaire, safety determination or instruction to test a boundary with another person.",
    "entryLabel": "Explore a fictional draft"
  },
  "sources": [
    {
      "id": "linehan-handouts-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical interpersonal handouts 4–7 provide the distinctions between objective, relationship and self-respect skills; this is original fictional teaching, not a reproduced worksheet.",
      "limits": "Not exact 2025 wording, digital efficacy evidence or permission to redistribute publisher materials."
    },
    {
      "id": "linehan-worksheets-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Interpersonal worksheet 4 supports mental/spoken rehearsal.",
      "limits": "Does not test the proposed interaction or establish its superiority."
    }
  ],
  "acceptance": [
    "No required click, rating, score, streak, mastery badge, good/bad response label or controlled-outcome claim.",
    "Every fictional choice and stopping option is reachable without personal input or audio.",
    "Fictional exercise does not change current practice context, notes, selected response or export selections.",
    "No snippet or action can invent a private interpretation, obligation or promise.",
    "All new audio remains unavailable until exact approved assets and integration/listening checks; existing recordings are not reassigned.",
    "Targeted source/content review required before any freeze; separate model, DOM, browser, accessibility, privacy and audio review for implementation."
  ],
  "learningObjective": "Consider what a phrase means before keeping, changing or trimming it; preserve truthful limits, fairness and proportionate accountability without demanding disclosure or banning apologies.",
  "intro": {
    "id": "pilot.fast.intro",
    "title": "Look at what the words are doing",
    "paragraphs": [
      "Explore one of two separate fictional drafts. For any phrase, you can keep it, try the offered change, trim it, or leave the choice open.",
      "There is no best final sentence or required edit. This exercise does not examine your own writing, decide whether you owe an apology or ask you to disclose private information."
    ]
  },
  "safety": {
    "id": "pilot.fast.safety",
    "title": "Safety comes before the exercise",
    "paragraphs": [
      "An apology can express sympathy or responsibility; the word alone does not tell us which. Apologising, agreeing or staying quiet to protect yourself is not a failure of this skill.",
      "Do not use this practice to disclose something unsafe or confront someone who may retaliate. You can return, stop or use support."
    ]
  },
  "actions": [
    {
      "id": "keep",
      "label": "Keep",
      "effect": "Keep this original fictional phrase."
    },
    {
      "id": "change",
      "label": "Change",
      "effect": "Use the explicitly shown authored alternative for this phrase."
    },
    {
      "id": "trim",
      "label": "Trim",
      "effect": "Remove this phrase from this fictional preview only."
    },
    {
      "id": "uncertain",
      "label": "Leave uncertain",
      "effect": "Keep the original phrase visible with a separate undecided indicator; do not treat it as endorsed, wrong or complete."
    }
  ],
  "scenarios": [
    {
      "id": "ali",
      "label": "Ali: a limit, with no earlier promise",
      "context": {
        "id": "pilot.fast.ali.context",
        "title": "Ali’s situation",
        "paragraphs": [
          "Ali is asked to lend money for a repair and cannot lend from the rent budget. No earlier promise to lend or harm by Ali is assumed.",
          "The following draft is an additional fictional exercise, not a replacement for Ali’s original example. It explores protecting essential expenses while recognising the relative’s difficulty."
        ]
      },
      "phrases": [
        {
          "id": "apology",
          "original": "I’m sorry for needing money for rent.",
          "alternative": "I need to keep money for rent.",
          "consideration": {
            "id": "pilot.fast.ali.apology.consider",
            "title": "Consider this phrase",
            "paragraphs": [
              "In the facts given, Ali has not done something wrong by needing rent covered. Consider whether these words apologise for a reasonable need. You may change or trim them, or leave the choice open; do not turn this into a rule against every apology."
            ]
          },
          "originalScope": {
            "id": "pilot.fast.ali.apology.original",
            "title": "The original fictional phrase",
            "paragraphs": [
              "I’m sorry for needing money for rent."
            ]
          },
          "alternativeScope": {
            "id": "pilot.fast.ali.apology.alternative",
            "title": "An offered change",
            "paragraphs": [
              "I need to keep money for rent."
            ]
          }
        },
        {
          "id": "limit",
          "original": "I can’t lend money from my rent budget.",
          "alternative": "I can’t lend money.",
          "consideration": {
            "id": "pilot.fast.ali.limit.consider",
            "title": "Consider this phrase",
            "paragraphs": [
              "Both versions state a limit. The shorter one gives less personal detail. Being truthful does not require explaining the budget. Trimming the limit entirely may leave Ali’s answer unclear, but this is an exploration, not a test."
            ]
          },
          "originalScope": {
            "id": "pilot.fast.ali.limit.original",
            "title": "The original fictional phrase",
            "paragraphs": [
              "I can’t lend money from my rent budget."
            ]
          },
          "alternativeScope": {
            "id": "pilot.fast.ali.limit.alternative",
            "title": "An offered change",
            "paragraphs": [
              "I can’t lend money."
            ]
          }
        },
        {
          "id": "care",
          "original": "I know the repair bill is difficult.",
          "alternative": "That sounds difficult.",
          "consideration": {
            "id": "pilot.fast.ali.care.consider",
            "title": "Consider this phrase",
            "paragraphs": [
              "This recognises the relative’s difficulty without offering money. Ali can care about family and still protect essential expenses. Keep, change or omit it according to the purpose of the response; no extra offer is owed."
            ]
          },
          "originalScope": {
            "id": "pilot.fast.ali.care.original",
            "title": "The original fictional phrase",
            "paragraphs": [
              "I know the repair bill is difficult."
            ]
          },
          "alternativeScope": {
            "id": "pilot.fast.ali.care.alternative",
            "title": "An offered change",
            "paragraphs": [
              "That sounds difficult."
            ]
          }
        }
      ]
    },
    {
      "id": "commitment",
      "label": "Devon: a separate missed commitment",
      "context": {
        "id": "pilot.fast.commitment.context",
        "title": "A different fictional situation",
        "paragraphs": [
          "Devon said they would return a friend’s book yesterday and did not. The friend was left waiting. Devon wants to acknowledge that and work out what is realistic now.",
          "This is not an added fact about Ali. It practises accountability for an actual missed commitment, not apologising merely for having a need."
        ]
      },
      "phrases": [
        {
          "id": "fact",
          "original": "I said I would return your book yesterday, and I didn’t.",
          "alternative": "I missed the return time we agreed.",
          "consideration": {
            "id": "pilot.fast.commitment.fact.consider",
            "title": "Consider this phrase",
            "paragraphs": [
              "Both versions acknowledge a known action rather than guessing anyone’s motives. Trimming the fact does not remove the missed commitment. Consider whether the remaining words still make clear what Devon is taking responsibility for."
            ]
          },
          "originalScope": {
            "id": "pilot.fast.commitment.fact.original",
            "title": "The original fictional phrase",
            "paragraphs": [
              "I said I would return your book yesterday, and I didn’t."
            ]
          },
          "alternativeScope": {
            "id": "pilot.fast.commitment.fact.alternative",
            "title": "An offered change",
            "paragraphs": [
              "I missed the return time we agreed."
            ]
          }
        },
        {
          "id": "apology",
          "original": "I’m sorry I left you waiting.",
          "alternative": "I’m sorry I did not return it when I said I would.",
          "consideration": {
            "id": "pilot.fast.commitment.apology.consider",
            "title": "Consider this phrase",
            "paragraphs": [
              "This apology refers to an actual missed commitment in the fictional facts. Avoiding unnecessary apologies does not mean deleting a warranted acknowledgement. Words alone may not repair the situation; Devon can consider a realistic next step without inventing a promise."
            ]
          },
          "originalScope": {
            "id": "pilot.fast.commitment.apology.original",
            "title": "The original fictional phrase",
            "paragraphs": [
              "I’m sorry I left you waiting."
            ]
          },
          "alternativeScope": {
            "id": "pilot.fast.commitment.apology.alternative",
            "title": "An offered change",
            "paragraphs": [
              "I’m sorry I did not return it when I said I would."
            ]
          }
        },
        {
          "id": "judgment",
          "original": "I’m a terrible person.",
          "alternative": "I need to work out a realistic return plan.",
          "consideration": {
            "id": "pilot.fast.commitment.judgment.consider",
            "title": "Consider this phrase",
            "paragraphs": [
              "The original phrase judges Devon’s whole character. The alternative turns attention to the missed commitment without claiming a plan has already been agreed. Acknowledging harm does not require a global put-down. You can also trim the judgement and leave the next step open."
            ]
          },
          "originalScope": {
            "id": "pilot.fast.commitment.judgment.original",
            "title": "The original fictional phrase",
            "paragraphs": [
              "I’m a terrible person."
            ]
          },
          "alternativeScope": {
            "id": "pilot.fast.commitment.judgment.alternative",
            "title": "An offered change",
            "paragraphs": [
              "I need to work out a realistic return plan."
            ]
          }
        }
      ]
    }
  ],
  "review": {
    "id": "pilot.fast.review",
    "title": "Look at the draft, without grading it",
    "paragraphs": [
      "Does the remaining wording communicate the limit or responsibility you intended? Is it accurate, fair to both people and consistent with the values involved? Could less detail be enough?",
      "You can keep an appropriate apology, remove a put-down, change a phrase or remain unsure. Do not keep checking until the sentence feels perfect; you can leave it here or discuss the question with your therapist."
    ]
  },
  "behavior": {
    "initial": "No scenario selected. Either scenario can be read without editing. After selection, show its explicit context and three original phrases as an unedited draft; all action controls initially unselected. Initial appearance is not a Keep decision.",
    "perPhrase": "Show one selected phrase with its consideration and authored alternative. Keep/Change/Trim/Leave uncertain are neutral choices, always reversible. No automated hint of the correct action or appraisal of user worth.",
    "preview": "Join only the selected scenario’s fictional phrase outputs in source order, using original text for untouched/uncertain/keep, alternative for change and omission for trim. This is a visible authored-fiction preview, not user writing or a recommendation. No audio binding to this dynamically assembled preview.",
    "allTrimmed": "Show “No phrases remain in this fictional preview. You can restore one or leave it here.” Do not label empty output success, a completed response, truthful or fair.",
    "uncertain": "Show “Choice left open” adjacent to the phrase, outside the sentence. No checkmark, completion badge or persistent tally.",
    "scenarioChange": "Stop audio and reset all local edits/action indicators before rendering the other scenario. Never blend Ali and Devon facts; clearly name the selected scenario. Main practice notes and current context remain untouched.",
    "export": "No new copy/download/export affordance for these pilots. Existing selected-note export remains unchanged and must not include fictional edits as personal notes.",
    "narration": "Only context, one exact phrase, its offered alternative, consideration or review may be explicitly narrated while visible. No auto-read after selecting an edit. Do not narrate edited preview, hidden alternative/scenario or any private underlying note."
  },
  "close": {
    "id": "pilot.fast.close",
    "title": "Return without a finished sentence",
    "paragraphs": [
      "You can return to FAST, leave a phrase undecided or stop. No edit, apology, disclosure or promise is required to finish this exercise."
    ]
  },
  "narrationSegments": [
    {
      "id": "pilot.fast.intro",
      "title": "Look at what the words are doing",
      "text": "Explore one of two separate fictional drafts. For any phrase, you can keep it, try the offered change, trim it, or leave the choice open.\n\nThere is no best final sentence or required edit. This exercise does not examine your own writing, decide whether you owe an apology or ask you to disclose private information.",
      "textSha256": "b37326afb7e4c634e522328a3045dda90b2237d85c8bf8f2979d6c4b274b2bad",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.safety",
      "title": "Safety comes before the exercise",
      "text": "An apology can express sympathy or responsibility; the word alone does not tell us which. Apologising, agreeing or staying quiet to protect yourself is not a failure of this skill.\n\nDo not use this practice to disclose something unsafe or confront someone who may retaliate. You can return, stop or use support.",
      "textSha256": "76b26b4acc29e88b27eb8bd76d7b17764f166b523c9bd6895ebab55ef51ac75f",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.context",
      "title": "Ali’s situation",
      "text": "Ali is asked to lend money for a repair and cannot lend from the rent budget. No earlier promise to lend or harm by Ali is assumed.\n\nThe following draft is an additional fictional exercise, not a replacement for Ali’s original example. It explores protecting essential expenses while recognising the relative’s difficulty.",
      "textSha256": "a0c87b4266768c4fc14de58dfd3de418de02788521fe21f4154a9015bf9610b0",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.apology.consider",
      "title": "Consider this phrase",
      "text": "In the facts given, Ali has not done something wrong by needing rent covered. Consider whether these words apologise for a reasonable need. You may change or trim them, or leave the choice open; do not turn this into a rule against every apology.",
      "textSha256": "c0e33fe1fb524437df5682b5fea3557907398c03d16271145f8e42afee6474db",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.apology.original",
      "title": "The original fictional phrase",
      "text": "I’m sorry for needing money for rent.",
      "textSha256": "5641f5328df53a9672d421145788d16bf9a6de97aa1fce2ac38469b641b7b470",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.apology.alternative",
      "title": "An offered change",
      "text": "I need to keep money for rent.",
      "textSha256": "ddb619948ec28a61c6a7d67abfbe48f95a564b004cfcc28abcc1d49a4fafc3e6",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.limit.consider",
      "title": "Consider this phrase",
      "text": "Both versions state a limit. The shorter one gives less personal detail. Being truthful does not require explaining the budget. Trimming the limit entirely may leave Ali’s answer unclear, but this is an exploration, not a test.",
      "textSha256": "2bd55435da4c5d21522af20c770ef35e81ace97dbc5f6ee26e7636350ad07028",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.limit.original",
      "title": "The original fictional phrase",
      "text": "I can’t lend money from my rent budget.",
      "textSha256": "44b2e60befdd5b3975c32a584c988b3a05619d6f2361e511351e8c36014d8b72",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.limit.alternative",
      "title": "An offered change",
      "text": "I can’t lend money.",
      "textSha256": "ac4cb3824e3ddbbc02b3598cc533ce56d68c9d62a0a94b47b641b8ea8142fc31",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.care.consider",
      "title": "Consider this phrase",
      "text": "This recognises the relative’s difficulty without offering money. Ali can care about family and still protect essential expenses. Keep, change or omit it according to the purpose of the response; no extra offer is owed.",
      "textSha256": "c308c54c9b0691c61893e35d47f2e86c858c9f7ee136c1925671f348cecc81a3",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.care.original",
      "title": "The original fictional phrase",
      "text": "I know the repair bill is difficult.",
      "textSha256": "ea03a56d82d875341a4604daf30dda18dd070254a4ecd43fbda1b77c5ff57bf1",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.ali.care.alternative",
      "title": "An offered change",
      "text": "That sounds difficult.",
      "textSha256": "28caf8cbe331cb5172bbf9db0193bdbd91f73519759e841fd237012f7cb8bb39",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.context",
      "title": "A different fictional situation",
      "text": "Devon said they would return a friend’s book yesterday and did not. The friend was left waiting. Devon wants to acknowledge that and work out what is realistic now.\n\nThis is not an added fact about Ali. It practises accountability for an actual missed commitment, not apologising merely for having a need.",
      "textSha256": "b6de520c84e3f5cea193daa2eb46f3f80303dde5580d5925d21b213b86da838a",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.fact.consider",
      "title": "Consider this phrase",
      "text": "Both versions acknowledge a known action rather than guessing anyone’s motives. Trimming the fact does not remove the missed commitment. Consider whether the remaining words still make clear what Devon is taking responsibility for.",
      "textSha256": "38051f0a22db99a2faf611350a5f32a0a9250dd29bdf37908c0086a8b24205df",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.fact.original",
      "title": "The original fictional phrase",
      "text": "I said I would return your book yesterday, and I didn’t.",
      "textSha256": "51f93dade7ee450b502f2e3b26b9d4a471212ebe9b6b064821d945c4ad17a1b8",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.fact.alternative",
      "title": "An offered change",
      "text": "I missed the return time we agreed.",
      "textSha256": "cca41ebfda86053b07755e29247d434d22e5b91f6a0f7a8489e8975a8a432075",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.apology.consider",
      "title": "Consider this phrase",
      "text": "This apology refers to an actual missed commitment in the fictional facts. Avoiding unnecessary apologies does not mean deleting a warranted acknowledgement. Words alone may not repair the situation; Devon can consider a realistic next step without inventing a promise.",
      "textSha256": "ccbe4c6b9cf7e04436b474c8f08f8db9cfa2d99c1797871dfb73704491925d61",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.apology.original",
      "title": "The original fictional phrase",
      "text": "I’m sorry I left you waiting.",
      "textSha256": "cdd0e47a06eb7d5b942255caf27418ba2c98f876ac6a12ae0a2e65b120b15072",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.apology.alternative",
      "title": "An offered change",
      "text": "I’m sorry I did not return it when I said I would.",
      "textSha256": "3dd01ac67378c0d1ea50a9c167029ec881fae6b7624359d37314908337ccfd50",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.judgment.consider",
      "title": "Consider this phrase",
      "text": "The original phrase judges Devon’s whole character. The alternative turns attention to the missed commitment without claiming a plan has already been agreed. Acknowledging harm does not require a global put-down. You can also trim the judgement and leave the next step open.",
      "textSha256": "3c8facd43eb0b1765304cd063bcaf942251edc1e7f8e95f8ad81c55f392eadab",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.judgment.original",
      "title": "The original fictional phrase",
      "text": "I’m a terrible person.",
      "textSha256": "927876592af37c9b22c95cfa941f52c653ec18a21caa8a18b455d154e9f4583c",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.commitment.judgment.alternative",
      "title": "An offered change",
      "text": "I need to work out a realistic return plan.",
      "textSha256": "5ebcde9e352ce57f473c30116312309e0b3438e38e92292cec448c8dea2ed276",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.review",
      "title": "Look at the draft, without grading it",
      "text": "Does the remaining wording communicate the limit or responsibility you intended? Is it accurate, fair to both people and consistent with the values involved? Could less detail be enough?\n\nYou can keep an appropriate apology, remove a put-down, change a phrase or remain unsure. Do not keep checking until the sentence feels perfect; you can leave it here or discuss the question with your therapist.",
      "textSha256": "dc9a8683822790b0ecbeb575ce4a913c95d6331806c6fb2e4c4859c45bbef0c5",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.fast.close",
      "title": "Return without a finished sentence",
      "text": "You can return to FAST, leave a phrase undecided or stop. No edit, apology, disclosure or promise is required to finish this exercise.",
      "textSha256": "ad85900b89a4c1560dc1fe430427d2375a3bb3dca97a8f46f6c742a6c6715056",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    }
  ]
};
