window.InterpersonalContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass.",
    "All named method elements have an actual optional attempt, not only acronym definitions.",
    "Response selection reveals only that branch and asks for a next-turn attempt; changing branch stops old audio and warns that retained response notes may refer to the prior branch.",
    "Source example text, selected-note export, existing guide linkage and saved identities preserved or explicitly version-reconciled.",
    "No renderer may claim selected export works until the adapter, preview and user-selected download/copy are tested.",
    "No runtime claims from this script-only contract; content, integration, accessibility and listening approvals remain separate."
  ],
  "id": "classic/fast",
  "resourceId": "tool/fast",
  "routeProposal": "tool/fast",
  "title": "FAST",
  "subtitle": "Consider fairness and self-respect",
  "version": "2026-11-03-interpersonal-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "The complete named FAST element set in an original guided rehearsal. Not the whole interpersonal effectiveness module, a safety assessment or comprehensive DBT.",
  "clinicalContract": {
    "learningObjective": "FAST helps you consider your own needs and the other person’s while speaking truthfully and choosing what fits your values.",
    "practiceObjective": "Rehearse a fair, truthful and values-aware response; distinguish unnecessary apology from accountability, and practise handling pressure or competing responsibilities.",
    "sourcePopulationContext": "Therapist-introduced practice with individual developmental, communication, consent, privacy, safeguarding and support review. No universal age gate or all-age validation claim. Historical and revised DBT sources do not validate this specific digital adaptation.",
    "observedPractice": "A privately spoken, imagined or optionally written attempt and a possible-response rehearsal. Reading, rehearsing and having a real conversation are distinct; no automatic completion inference."
  },
  "privacy": {
    "id": "fast.privacy",
    "title": "Writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay in this open tool while you use its practice, example and help.",
      "Leaving this tool, reloading, clearing or starting again removes the notes here. If you choose to keep notes, only the notes you explicitly select are included in the copy or download you request. That copy remains outside this tool until you remove it.",
      "Saving this tool keeps a shortcut, not your writing. Nothing is sent to your therapist or read aloud. This tool is not monitored."
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; free jump, Show all, Back and Finish remain available. Practice enters or resumes practice directly; no duplicated intro Start button.",
    "writing": "Hidden by default, optional; hide all private echoes and previews when hidden. No mandatory field or automatic analysis.",
    "modes": [
      "practice"
    ],
    "persistence": "In-memory active-tool session only. Internal help/example/back preserves choice and notes. Leave/reload/restart/clear removes notes and echoes. Selected-note copy/download only by explicit selection and separate user action; no backend, localStorage or diary.",
    "narration": "Script only; no asset assumed to match. Listen/Pause/Resume; Replay unavailable until actual playback of that exact current clip. No TTS, new provider, private-answer narration or approval claim.",
    "timer": "None",
    "visual": "Method letters and textual labels orient; no score, streak, mastery badge or success animation.",
    "fictionalPractice": "Explicit optional personal / retained fictional example choice, no default inference or personal input prefill. Neither choice is a completion gate. Changing context preserves existing notes but visibly warns they may refer to earlier context; clear only on explicit reset or leaving.",
    "responsePractice": "One explicitly selected authored possible reply is visible at a time. It is a possibility, not a prediction. Prompt a second-turn attempt, then optional revision. No AI interlocutor or automatic scoring. Unselected branches are not narrated.",
    "pendingSharedPatterns": "Candidate only: critique may redirect shell, focus, choice presentation and closure. Preserve clinical meaning and privacy invariants when adapting."
  },
  "intro": {
    "id": "fast.intro",
    "title": "FAST",
    "paragraphs": [
      "FAST helps you consider your own needs and the other person’s while speaking truthfully and choosing what fits your values.",
      "Choose an ordinary conversation where it is reasonably safe to practise, or use the fictional example. You can rehearse silently, aloud or with optional notes. You do not have to contact anyone."
    ],
    "actions": []
  },
  "fit": {
    "id": "fast.fit",
    "title": "Check whether this fits",
    "paragraphs": [
      "Use this with your therapist’s guidance and a situation that is manageable for you. You can leave out personal details, use fiction, or stop.",
      "If someone may threaten, control, punish or harm you for speaking up, start with support and safety rather than a communication script. This tool cannot assess what is safe. You do not have to keep engaging with threats or abuse.",
      "A clear, respectful response does not control another person’s reaction. Lack of agreement does not mean you failed."
    ]
  },
  "practice": [
    {
      "id": "fast.practice.prepare",
      "title": "Choose the conversation and priority",
      "paragraphs": [
        "Use Ali’s request-for-money example or choose your own manageable situation. What matters most here: a specific request or refusal, the relationship, or how you act in relation to your values?",
        "These priorities may overlap or conflict. Choose a focus for this practice without treating the others as unimportant. You can switch to a related skill or finish."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "Situation, if I want to write",
          "optional": true
        },
        {
          "key": "priority",
          "label": "What matters most here",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot choose a priority",
        "text": "You can try the fictional example or discuss the situation with your therapist. This is not a score that decides how forceful to be."
      }
    },
    {
      "id": "fast.practice.fair",
      "title": "F: Be Fair",
      "paragraphs": [
        "Consider the relevant needs and responsibilities on both sides, including your own limits. Fairness does not require giving both people exactly what they want."
      ],
      "fields": [
        {
          "key": "fast-f",
          "label": "Fairness to both people",
          "optional": true
        }
      ],
      "help": {
        "title": "If fairness feels like self-sacrifice",
        "text": "Your needs count too. Consider what you know rather than assuming all responsibility belongs to you. You can seek help if competing obligations are unclear."
      }
    },
    {
      "id": "fast.practice.apologies",
      "title": "A: Avoid unnecessary Apologies",
      "paragraphs": [
        "Try stating the need, opinion or limit without apologising merely for having it.",
        "Then check separately: is there an actual action, broken commitment or harm to acknowledge? If so, practise a specific acknowledgement or proportionate repair without erasing your limit."
      ],
      "fields": [
        {
          "key": "fast-a",
          "label": "An unnecessary apology to leave out, or responsibility to acknowledge",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am unsure whether I caused harm",
        "text": "You do not have to decide instantly or accept an accusation as fact. You can acknowledge uncertainty, ask what happened or seek advice. FAST is not a reason to deny real responsibility."
      }
    },
    {
      "id": "fast.practice.values",
      "title": "S: Stick to values",
      "paragraphs": [
        "Name a value that matters in this situation. Try words or an action that respects it while taking relevant responsibilities and consequences seriously.",
        "Values can conflict. Consider a workable compromise or seek advice; you do not need an absolute rule or proof that you are a good person."
      ],
      "fields": [
        {
          "key": "fast-s",
          "label": "A value to consider",
          "optional": true
        }
      ],
      "help": {
        "title": "If two values pull in different directions",
        "text": "For Ali, caring about family and protecting essential living costs can both matter. Recognising both does not automatically decide the answer."
      }
    },
    {
      "id": "fast.practice.truthful",
      "title": "T: Be Truthful",
      "paragraphs": [
        "Try a response that is accurate without an invented excuse or exaggeration. You can say you are unsure when you are unsure.",
        "Being truthful does not require disclosing private details or explaining everything. A short honest limit can be enough."
      ],
      "fields": [
        {
          "key": "fast-t",
          "label": "What is true",
          "optional": true
        }
      ],
      "help": {
        "title": "If an invented excuse feels easier",
        "text": "Try a truthful statement with less detail instead. Do not use this exercise to practise unsafe disclosure or confrontation."
      }
    },
    {
      "id": "fast.practice.rehearse",
      "title": "Rehearse the opening",
      "paragraphs": [
        "Try your opening once, privately, aloud or in optional notes. You can try just the part you are working on rather than a polished speech.",
        "Then choose a possible response below if you want to rehearse the next turn. Another person may respond differently."
      ],
      "fields": [
        {
          "key": "opening",
          "label": "My opening attempt, if useful",
          "optional": true
        }
      ]
    },
    {
      "id": "fast.practice.respond",
      "title": "Practise a possible next turn",
      "paragraphs": [
        "Choose one possible response. Read it, then try what you might say or do next. A pause or ending the exchange can be a response.",
        "If no branch fits, you can imagine your own ordinary reply or leave this step. Nothing is selected for you."
      ],
      "fields": [
        {
          "key": "response",
          "label": "My possible next response, if useful",
          "optional": true
        }
      ]
    },
    {
      "id": "fast.practice.review",
      "title": "Review and, if useful, try again",
      "paragraphs": [
        "Did your response consider both people, distinguish a need from an action requiring accountability, reflect a relevant value and stay truthful? A change in confidence or the other person’s agreement is not required.",
        "Try one revised response if you want. You can also leave the practice here with uncertainty, discomfort or no change."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I noticed or might revise",
          "optional": true
        }
      ]
    }
  ],
  "close": {
    "id": "fast.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can finish after reading, rehearsing, revising or stopping. Agreement, confidence and a change in feeling are not required.",
      "You can return to any part, keep only notes you deliberately select, save a shortcut to the tool, or finish and clear the notes here."
    ],
    "actions": [
      "Back to practice",
      "Choose notes to keep",
      "Save this tool",
      "Finish and clear"
    ],
    "reflectionReview": {
      "legacyOptions": [
        "Helpful",
        "No change",
        "Unsure",
        "Uncomfortable",
        "Skip"
      ],
      "status": "Preserve as retained provenance, not automatically rendered. Usefulness-versus-outcome ambiguity needs independent/shared-pattern review. No rating required."
    }
  },
  "sources": [
    {
      "id": "linehan-handouts-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical interpersonal handouts 4–7 establish priorities and 7/4/4 named elements; not copied client worksheets.",
      "limits": "Not exact revised 2025 wording or evidence validating this app. Restricted reproduction license."
    },
    {
      "id": "linehan-worksheets-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Interpersonal worksheets 3–5 include priorities, mental/spoken rehearsal and reviewing use.",
      "limits": "Original app copy and examples only; no worksheet redistribution."
    },
    {
      "id": "linehan-revised-2025",
      "url": "https://www.guilford.com/books/DBT-Skills-Training-Handouts-and-Worksheets/Marsha-Linehan/9781462556342",
      "reviewed": "2026-11-03",
      "supports": "Current revised edition and inclusive-language update.",
      "limits": "Accessible sample does not contain the target handouts; exact revised target procedure not verified."
    },
    {
      "id": "rathus-miller",
      "url": "https://www.guilford.com/excerpts/rathus_ch1.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Developmentally informed adolescent DBT and differing support needs.",
      "limits": "No universal age threshold or all-age/app validation inference."
    }
  ],
  "learn": {
    "id": "fast.learn",
    "title": "Self-respect includes fairness and responsibility",
    "paragraphs": [
      "FAST stands for Fair, avoiding unnecessary Apologies, Sticking to values and being Truthful. It is not a rule to win, never compromise or never apologise.",
      "A reasonable need or opinion does not require an apology merely for existing. If you caused harm or broke a commitment, acknowledging that and considering repair can still be appropriate.",
      "DEAR MAN focuses on the request or refusal, and GIVE on the relationship. FAST helps you consider how you want to act, even when agreement or confidence is absent."
    ]
  },
  "example": {
    "id": "fast.example",
    "title": "Example: Ali is asked to lend money",
    "paragraphs": [
      "Ali cannot lend money a relative requests. Ali says, “I know the repair bill is difficult. I can’t lend money from my rent budget.” Ali doesn’t invent an excuse or apologise for having essential expenses.",
      "If Ali had made a promise and not followed through, that would also matter. Avoiding unnecessary apologies does not mean refusing to acknowledge an actual mistake or harm. Values and responsibilities can conflict; the task is to make a considered choice, not prove you are a good person."
    ]
  },
  "practiceScenario": {
    "id": "fast.scenario",
    "title": "Practise with Ali",
    "paragraphs": [
      "Ali wants to protect essential expenses while recognising the relative’s difficulty. No earlier promise to lend is assumed in this example.",
      "You can rehearse this fictional response without entering your own money details. A later accountability branch is explicitly a different hypothetical situation, not an added fact about Ali."
    ]
  },
  "responses": [
    {
      "id": "apology",
      "label": "I feel pressure to apologise for my limit",
      "reply": {
        "id": "fast.response.apology.reply",
        "title": "One possible reply",
        "paragraphs": [
          "The relative says, “I thought you would help me.”"
        ]
      },
      "practice": {
        "id": "fast.response.apology.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try recognising the difficulty without apologising for needing essential expenses covered or inventing another reason.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Ali: “I know this is difficult. I can’t lend from my rent budget.” No extra offer is required."
        }
      }
    },
    {
      "id": "conflict",
      "label": "Two responsibilities pull in different directions",
      "reply": {
        "id": "fast.response.conflict.reply",
        "title": "One possible reply",
        "paragraphs": [
          "In a separate hypothetical situation, you had made a commitment and now cannot follow through. This is not an assumed fact about Ali."
        ]
      },
      "practice": {
        "id": "fast.response.conflict.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try acknowledging the actual commitment and its impact while explaining the present limit truthfully. Consider a feasible repair, or leave it open if you need advice.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "A possible response is: “I said I would do that and I haven’t. I’m sorry for leaving you waiting. I need to look at what I can realistically do now.” Do not invent a new promise."
        }
      }
    },
    {
      "id": "unchanged",
      "label": "I do not need to change anything now",
      "reply": {
        "id": "fast.response.unchanged.reply",
        "title": "One possible reply",
        "paragraphs": [
          "No further response is needed at this point."
        ]
      },
      "practice": {
        "id": "fast.response.unchanged.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try leaving the response as it is, or silently rehearsing the truthful limit once. You can finish without seeking more agreement or reassurance.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Ali, the limit can stand without another justification. If a real responsibility later becomes clear, it can still be considered."
        }
      }
    }
  ],
  "methodElements": [
    "Fair",
    "Avoid unnecessary Apologies",
    "Stick to values",
    "Truthful"
  ],
  "legacyCompatibility": {
    "savedIdentity": {
      "passage": "interpersonal",
      "card": "card-interpersonal-fast-keep-your-self-respect-intact"
    },
    "guide": {
      "status": "Retain route association; exact current PDF compatibility must be checked or explicitly versioned before replacement."
    },
    "selectedExport": "Preserve NativeRefinements.selectedExport behavior through an explicit adapter: no default-selected private content, preview exact selected notes, separate copy/download action, include built draft only if explicitly selected. Hide every private echo when writing hides. No automatic export on Finish.",
    "preview": "Legacy note-preview behavior must remain available or be explicitly reconciled, not silently replaced by a generic assembled conversation. New method/rehearsal notes can be individually selected without changing original field meaning.",
    "records": "Preserve original narration entries and text/asset hashes as provenance; no new text may inherit an old recording merely because route or title matches.",
    "previewDetails": "Original preview uses T/S/F order with retained contextual prefixes. No invented moral judgement or automatic apology; fast-a is a separate optional note."
  },
  "productAdaptations": [
    "Original guided prompts and second-turn rehearsals deepen existing named practice, not official numbered worksheet steps.",
    "Retained Rae/Kit/Ali example paragraphs preserved exactly from retained written examples; extra fictional replies explicitly authored candidates.",
    "No universal age gate, mandatory gaze/humour/speech fluency, coerced negotiation, guaranteed agreement or automatic clinical fit.",
    "Seven/four/four elements remain visible and practicable; no field is required; all prompts can be jumped to or left."
  ],
  "implementationGates": {
    "capabilityClaims": "Do not render or narrate privacy/close claims until verified session retention/clearing, shortcut save, explicit selected-note preview/copy/download, and accurate external-copy warning work in the actual candidate renderer. Otherwise keep the contract unimplemented; do not silently omit actions or promise unsupported behavior.",
    "gatedSectionIds": [
      "fast.privacy",
      "fast.close"
    ],
    "testsRequired": [
      "Internal example/help/back retains notes and choices",
      "Leave/reload/restart/clear erases notes and every echo",
      "Save shortcut preserves correct legacy identity and saves no notes",
      "No selected export by default; exact explicit selection and preview before copy/download",
      "Hiding writing hides selected previews and all private echoes"
    ]
  },
  "narrationSegments": [
    {
      "id": "fast.privacy",
      "title": "Writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay in this open tool while you use its practice, example and help.\n\nLeaving this tool, reloading, clearing or starting again removes the notes here. If you choose to keep notes, only the notes you explicitly select are included in the copy or download you request. That copy remains outside this tool until you remove it.\n\nSaving this tool keeps a shortcut, not your writing. Nothing is sent to your therapist or read aloud. This tool is not monitored.",
      "textSha256": "16d3bdc898d6fedb141c993bad0bb7cf436026c064bd1822ff0aabab7f149047",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "capabilityGate": "Do not bind or make this script available until implementationGates capability tests pass in the actual renderer.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.intro",
      "title": "FAST",
      "text": "FAST helps you consider your own needs and the other person’s while speaking truthfully and choosing what fits your values.\n\nChoose an ordinary conversation where it is reasonably safe to practise, or use the fictional example. You can rehearse silently, aloud or with optional notes. You do not have to contact anyone.",
      "textSha256": "73d0d5b1646d161e5a4aa5980bf8b1a312886dc4fb6590469e2459c91b475e4a",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.fit",
      "title": "Check whether this fits",
      "text": "Use this with your therapist’s guidance and a situation that is manageable for you. You can leave out personal details, use fiction, or stop.\n\nIf someone may threaten, control, punish or harm you for speaking up, start with support and safety rather than a communication script. This tool cannot assess what is safe. You do not have to keep engaging with threats or abuse.\n\nA clear, respectful response does not control another person’s reaction. Lack of agreement does not mean you failed.",
      "textSha256": "6cbf0a98205bf1dddc8f916022fb17924642c763c5445cafc9ac1407708de583",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.learn",
      "title": "Self-respect includes fairness and responsibility",
      "text": "FAST stands for Fair, avoiding unnecessary Apologies, Sticking to values and being Truthful. It is not a rule to win, never compromise or never apologise.\n\nA reasonable need or opinion does not require an apology merely for existing. If you caused harm or broke a commitment, acknowledging that and considering repair can still be appropriate.\n\nDEAR MAN focuses on the request or refusal, and GIVE on the relationship. FAST helps you consider how you want to act, even when agreement or confidence is absent.",
      "textSha256": "ce067f9f96efd3c275ba2ac676fd1a0893e6802c9586a3f02768bd32c12d6429",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.example",
      "title": "Example: Ali is asked to lend money",
      "text": "Ali cannot lend money a relative requests. Ali says, “I know the repair bill is difficult. I can’t lend money from my rent budget.” Ali doesn’t invent an excuse or apologise for having essential expenses.\n\nIf Ali had made a promise and not followed through, that would also matter. Avoiding unnecessary apologies does not mean refusing to acknowledge an actual mistake or harm. Values and responsibilities can conflict; the task is to make a considered choice, not prove you are a good person.",
      "textSha256": "21d48a0296eab66745a11af072132add32b24eb74a158a4c8220967e43e55b79",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": [
        "full-fast-example"
      ]
    },
    {
      "id": "fast.scenario",
      "title": "Practise with Ali",
      "text": "Ali wants to protect essential expenses while recognising the relative’s difficulty. No earlier promise to lend is assumed in this example.\n\nYou can rehearse this fictional response without entering your own money details. A later accountability branch is explicitly a different hypothetical situation, not an added fact about Ali.",
      "textSha256": "914416614feba4d04caafc117ff9246de6c44d8644cd0b2fd92fa0d52dc3e689",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.prepare",
      "title": "Choose the conversation and priority",
      "text": "Use Ali’s request-for-money example or choose your own manageable situation. What matters most here: a specific request or refusal, the relationship, or how you act in relation to your values?\n\nThese priorities may overlap or conflict. Choose a focus for this practice without treating the others as unimportant. You can switch to a related skill or finish.",
      "textSha256": "0f1aff777587dde363be5cd6b148110a62986ea6f8fd69807e94e77eb987f156",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.prepare.help",
      "title": "If I cannot choose a priority",
      "text": "You can try the fictional example or discuss the situation with your therapist. This is not a score that decides how forceful to be.",
      "textSha256": "f9eff6512039008a0485ff1d5397bd6a36b38ee3d5a5033f12001c35a0f7e104",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.fair",
      "title": "F: Be Fair",
      "text": "Consider the relevant needs and responsibilities on both sides, including your own limits. Fairness does not require giving both people exactly what they want.",
      "textSha256": "0f71e4eb14b1cf3753f098f44f771f8846bca1e39e15fc5c12d8d918ef329dfd",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.fair.help",
      "title": "If fairness feels like self-sacrifice",
      "text": "Your needs count too. Consider what you know rather than assuming all responsibility belongs to you. You can seek help if competing obligations are unclear.",
      "textSha256": "c3fa87648a91f94080634c468794a8a61185239ad8c61b394a57713497331155",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.apologies",
      "title": "A: Avoid unnecessary Apologies",
      "text": "Try stating the need, opinion or limit without apologising merely for having it.\n\nThen check separately: is there an actual action, broken commitment or harm to acknowledge? If so, practise a specific acknowledgement or proportionate repair without erasing your limit.",
      "textSha256": "79611473afddc5669f1ff75d2e78f5e9e62f1a5abcc31a96d27fd49dd3ac4414",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.apologies.help",
      "title": "If I am unsure whether I caused harm",
      "text": "You do not have to decide instantly or accept an accusation as fact. You can acknowledge uncertainty, ask what happened or seek advice. FAST is not a reason to deny real responsibility.",
      "textSha256": "73f092f0bd25e79d0608b336c3ca209b993c7642372afd662ac76162ccc3b620",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.values",
      "title": "S: Stick to values",
      "text": "Name a value that matters in this situation. Try words or an action that respects it while taking relevant responsibilities and consequences seriously.\n\nValues can conflict. Consider a workable compromise or seek advice; you do not need an absolute rule or proof that you are a good person.",
      "textSha256": "8ef9176b8a1b2edb25a7d0d1557eb49594be8606f6a45dbe280107e7b0afe2cb",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.values.help",
      "title": "If two values pull in different directions",
      "text": "For Ali, caring about family and protecting essential living costs can both matter. Recognising both does not automatically decide the answer.",
      "textSha256": "6fa2de4fdc0f91ceddeddf02eaa50c3c81dfd5abad58db17eb4c6a1147206810",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.truthful",
      "title": "T: Be Truthful",
      "text": "Try a response that is accurate without an invented excuse or exaggeration. You can say you are unsure when you are unsure.\n\nBeing truthful does not require disclosing private details or explaining everything. A short honest limit can be enough.",
      "textSha256": "98dd2a1673e36ccc36ea78e76ee8f5afd0b150f6e2fdb593a547314cbf7080d6",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.truthful.help",
      "title": "If an invented excuse feels easier",
      "text": "Try a truthful statement with less detail instead. Do not use this exercise to practise unsafe disclosure or confrontation.",
      "textSha256": "0daa7299f6feb15c559b83a0145b29ac0e946babe323ed9e4e67f63df3a55f48",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.rehearse",
      "title": "Rehearse the opening",
      "text": "Try your opening once, privately, aloud or in optional notes. You can try just the part you are working on rather than a polished speech.\n\nThen choose a possible response below if you want to rehearse the next turn. Another person may respond differently.",
      "textSha256": "5f2a3eca8f75a47a3e9d287b7fbf5f4879c1109a96c73c0892fb658e255f8a01",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.respond",
      "title": "Practise a possible next turn",
      "text": "Choose one possible response. Read it, then try what you might say or do next. A pause or ending the exchange can be a response.\n\nIf no branch fits, you can imagine your own ordinary reply or leave this step. Nothing is selected for you.",
      "textSha256": "c949599d21f2c903ce6aebf4579eef7e1497a0f4c802ea0c5e40f7d7e1eaae1d",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.practice.review",
      "title": "Review and, if useful, try again",
      "text": "Did your response consider both people, distinguish a need from an action requiring accountability, reflect a relevant value and stay truthful? A change in confidence or the other person’s agreement is not required.\n\nTry one revised response if you want. You can also leave the practice here with uncertainty, discomfort or no change.",
      "textSha256": "fb6f3e826075fd8d772f0f6cee055f5fb50c73d54933582d74742a5519a9151a",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.apology.reply",
      "title": "One possible reply",
      "text": "The relative says, “I thought you would help me.”",
      "textSha256": "74a4ce34f1a2da7212352e5d590ae738e900345e989e2a8b5c3092426268cf97",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.apology.practice",
      "title": "Try your next response",
      "text": "Try recognising the difficulty without apologising for needing essential expenses covered or inventing another reason.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "6ed1ee4a6a14f82763463f8799eb449aed3d0fec115229b082398fa0a939fa1b",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.apology.practice.help",
      "title": "If you want a starting point",
      "text": "For Ali: “I know this is difficult. I can’t lend from my rent budget.” No extra offer is required.",
      "textSha256": "2bc8de5f0adda261a93aede8db67f1c2a275aed56f21015d1ec2bbdbd897b26a",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.conflict.reply",
      "title": "One possible reply",
      "text": "In a separate hypothetical situation, you had made a commitment and now cannot follow through. This is not an assumed fact about Ali.",
      "textSha256": "4794e6ba856ddb35712502de5834358b7ab7e826907950f3645b3f8d3d02f072",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.conflict.practice",
      "title": "Try your next response",
      "text": "Try acknowledging the actual commitment and its impact while explaining the present limit truthfully. Consider a feasible repair, or leave it open if you need advice.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "39ed05e3b327b147c5f7da2055b5518e77a2c695cd0acb3f3e71fac559a3889a",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.conflict.practice.help",
      "title": "If you want a starting point",
      "text": "A possible response is: “I said I would do that and I haven’t. I’m sorry for leaving you waiting. I need to look at what I can realistically do now.” Do not invent a new promise.",
      "textSha256": "9fdae93e1d399a7a03885abc1a0c46921fce9395fba1a8be9d988bfbf5ad9758",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.unchanged.reply",
      "title": "One possible reply",
      "text": "No further response is needed at this point.",
      "textSha256": "3b314da039efd440c5f4e775c969ae12d6f13e7d668ad68fbb2e6d07eca87922",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.unchanged.practice",
      "title": "Try your next response",
      "text": "Try leaving the response as it is, or silently rehearsing the truthful limit once. You can finish without seeking more agreement or reassurance.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "8c420e6d6d6f1d204818aad2f3a6b2f157d268f3c829f598aea4ad3772ab1205",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.response.unchanged.practice.help",
      "title": "If you want a starting point",
      "text": "For Ali, the limit can stand without another justification. If a real responsibility later becomes clear, it can still be considered.",
      "textSha256": "3b56d35ef7c35b54ab054fd4f583f3835707f050213c1ccc24fba340da55e6a4",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "fast.close",
      "title": "Leave the practice here",
      "text": "You can finish after reading, rehearsing, revising or stopping. Agreement, confidence and a change in feeling are not required.\n\nYou can return to any part, keep only notes you deliberately select, save a shortcut to the tool, or finish and clear the notes here.",
      "textSha256": "98842bb1caa1cd4c7f24055cbd5db61e5c4e89be997ac002d557721caab6ffd3",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "capabilityGate": "Do not bind or make this script available until implementationGates capability tests pass in the actual renderer.",
      "legacyExactMatchIds": []
    }
  ]
};
