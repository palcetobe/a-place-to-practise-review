
(()=>{const data=structuredClone(window.PracticeWorkspacesReviewData);data.tools.urge.timerHelp+=' Pause the timer before leaving this page or switching apps. When you return, check the timer and choose Resume timer if you want to continue.';window.PracticeWorkspacesReviewData=data;})();
