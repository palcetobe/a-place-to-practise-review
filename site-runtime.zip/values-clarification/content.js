window.ContinuedSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/values",
  "version": "2026-11-02-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "title": "Values Clarification",
  "subtitle": "Explore how you want to act",
  "scope": "A bounded values-in-action clarification practice; not a values test, complete ACT programme or separate committed-action course.",
  "clinicalContract": {
    "learningObjective": "Distinguish a freely chosen quality of action from a goal, an outcome or a rule imposed by someone else.",
    "practiceObjective": "In one ordinary situation, consider a personally meaningful direction, distinguish a possible expression from its hoped-for result, and check fit without a required commitment.",
    "observedPractice": "A privately considered or optional written distinction between chosen quality, possible expression and hoped-for result; no action, positive feeling or declaration of a fixed identity required.",
    "sourcePopulationContext": "Primary sources describe broader clinical methods, not validation of this digital adaptation or suitability across ages. Therapist selection and adaptation should account for development, communication, context, consent, privacy and safeguarding. Method-specific source populations and suitability limits still apply."
  },
  "privacy": {
    "id": "values.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Exact scripts below await generation, listening and integration. Audio repair is a separate workstream; no old asset is presumed to match changed text.",
    "timer": "No timer required or proposed.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "sources": [
    {
      "id": "va-values",
      "url": "https://www.va.gov/WHOLEHEALTHLIBRARY/docs/Values.pdf",
      "reviewed": "2026-11-02",
      "supports": "Values as freely chosen ongoing directions distinct from goals; contextual barriers and collaborative clarification. Adult/veteran-oriented educational source, not app or16–17 validation."
    },
    {
      "id": "who-values",
      "url": "https://cdn.who.int/media/docs/default-source/thailand/doing-what-matters-in-times-of-stress-eng.pdf?sfvrsn=d166ad74_1",
      "reviewed": "2026-11-02",
      "supports": "Part3, acting on values: chosen qualities, goals and realistic expressions. Conceptual source only; no WHO text/artwork or programme claims reproduced."
    },
    {
      "id": "va-act-manual",
      "url": "https://www.mirecc.va.gov/visn19/treatmentworksforvets/docs/ACT-D-Therapist-Manual.pdf",
      "reviewed": "2026-11-02",
      "supports": "Search-indexed primary source corroborates ongoing values versus achieved goals; full PDF re-open failed2026-11-02. Supplementary only; exact content rests on verified VA Values and WHO Part3."
    }
  ],
  "productAdaptations": [
    "Condenses existing Sam and Robin authored scenes while retaining quality/action/result and uncertain outcome.",
    "One focused reflection, not card sorting, moral ranking, assessment, or complete committed-action practice.",
    "No mandatory action, export, schedule or media; current cloud privacy differs from historical optional downloads."
  ],
  "resourceId": "tool/values-in-action",
  "routeProposal": "tool/values-in-action",
  "intro": {
    "id": "values.intro",
    "title": "A direction, not a test",
    "paragraphs": [
      "Values are qualities you choose to bring to how you act. You might want to be curious while learning, considerate with your time, or caring towards yourself. Your own words matter more than choosing from a list.",
      "Explore one situation, not your whole life. You can use the fictional practice or keep your own situation private. Nothing here commits you to an action."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "values.fit",
    "title": "Make room for your circumstances",
    "paragraphs": [
      "Use this between sessions with your therapist. Choose an ordinary situation already suitable for reflection, or use fiction.",
      "Safety, consent, culture, disability, energy, resources and competing responsibilities matter. A value is not an instruction to ignore these limits, accept mistreatment or prove your worth. You can pause or ask for support."
    ]
  },
  "learn": {
    "id": "values.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "A goal names something you want to reach. A value describes how you want to approach life along the way. An outcome can matter without being the only measure of what you brought to an action.",
      "Separating these can leave more than one way forward. If a plan no longer fits, you may be able to express the same quality differently. This does not mean every action fits a value merely because you intended it.",
      "Values are chosen, not assigned by this page or another person. “I must always please people” is a rule worth exploring, not a value you have to accept. You can remain unsure."
    ]
  },
  "example": {
    "id": "values.example",
    "title": "Example — Sam explores curiosity",
    "paragraphs": [
      "Sam wants to draw and chooses curiosity as the quality to bring: looking closely and noticing something new. A polished drawing is a hoped-for result, not the quality itself.",
      "Sam notices the oval rim, curved handle and rounded body of a mug, then sketches them. Sam dislikes the drawing.",
      "In review, Sam notices that looking closely did express curiosity, even though the result was disappointing. The result still matters to Sam. Sam can change the activity, continue, or stop; the exercise does not require another drawing."
    ]
  },
  "practiceScenario": {
    "id": "values.scenario",
    "title": "Optional fictional practice — Robin",
    "paragraphs": [
      "Robin wants to arrange a catch-up with a friend and says, “I want to be considerate about both our time.” Robin has fifteen minutes available today and hopes to agree a time this week. The friend has not replied. No call is agreed and the reason for no reply is unknown.",
      "Use Robin for the prompts, invent a manageable situation, or use your own. Fictional practice is not a request to contact anyone."
    ]
  },
  "practice": [
    {
      "id": "values.practice.direction",
      "title": "What quality matters here?",
      "paragraphs": [
        "Bring one ordinary situation to mind. How would you like to act in it? Use a quality that feels personally meaningful, or leave the question open.",
        "If using Robin, work from the meaning Robin stated rather than guessing a different value."
      ],
      "fields": [
        {
          "key": "direction",
          "label": "A quality or direction in my words",
          "optional": true
        }
      ],
      "help": {
        "title": "If you named a goal",
        "text": "Keep the goal if it matters. “Get a call booked” describes a result. You might also ask how you want to treat yourself and the other person while arranging it."
      }
    },
    {
      "id": "values.practice.expression",
      "title": "Consider one possible expression",
      "paragraphs": [
        "What could you do or say that might express this quality? It can be small, quiet or private. Then separate it from the result you hope for.",
        "For Robin, a possible invitation still needs to respect both people’s available time and choices. No reply is not agreement."
      ],
      "fields": [
        {
          "key": "expression",
          "label": "One possible expression",
          "optional": true
        },
        {
          "key": "outcome",
          "label": "The result I hope for, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If an outcome is outside your control",
        "text": "Another person can decline, and a creative attempt can disappoint. Ask what your action could express without pretending its effects or result do not matter."
      }
    },
    {
      "id": "values.practice.fit",
      "title": "Check whether it fits",
      "paragraphs": [
        "Would this possibility respect your needs, other people’s wishes and the circumstances? Could rest, support, a smaller action or a different expression fit better?",
        "You can choose not to act. A barrier does not prove that a value is absent."
      ],
      "fields": [
        {
          "key": "fit",
          "label": "What needs consideration",
          "optional": true
        }
      ],
      "help": {
        "title": "If two values pull in different directions",
        "text": "You do not have to rank your whole life. Consider what fits this situation with your therapist, including limits you cannot change."
      }
    },
    {
      "id": "values.practice.review",
      "title": "Review the distinction",
      "paragraphs": [
        "Can you distinguish the chosen quality, the possible action and the hoped-for result? If you tried something already, consider what you actually did and what happened. Intention alone does not establish its effect.",
        "Keep a direction, a question, or nothing. No new action is required."
      ],
      "fields": [
        {
          "key": "review",
          "label": "Something I want to keep or reconsider",
          "optional": true
        }
      ],
      "help": {
        "title": "A possible Robin account",
        "text": "Consideration for both people is the stated quality. Robin could ask about a suitable time using an agreed way to communicate, without demanding a reply. Agreeing a catch-up is the hoped-for result, not guaranteed by sending a message. Robin can adapt or leave it if no suitable time is available. This is one model, not an assessment of your words."
      }
    }
  ],
  "close": {
    "id": "values.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "You can finish without a fixed value label or a plan. If useful, bring a question or observation to your therapist. Nothing is sent from this page."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "narrationSegments": [
    {
      "id": "values.intro",
      "title": "A direction, not a test",
      "text": "Values are qualities you choose to bring to how you act. You might want to be curious while learning, considerate with your time, or caring towards yourself. Your own words matter more than choosing from a list.\n\nExplore one situation, not your whole life. You can use the fictional practice or keep your own situation private. Nothing here commits you to an action.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.fit",
      "title": "Make room for your circumstances",
      "text": "Use this between sessions with your therapist. Choose an ordinary situation already suitable for reflection, or use fiction.\n\nSafety, consent, culture, disability, energy, resources and competing responsibilities matter. A value is not an instruction to ignore these limits, accept mistreatment or prove your worth. You can pause or ask for support.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.learn",
      "title": "Why this skill may help",
      "text": "A goal names something you want to reach. A value describes how you want to approach life along the way. An outcome can matter without being the only measure of what you brought to an action.\n\nSeparating these can leave more than one way forward. If a plan no longer fits, you may be able to express the same quality differently. This does not mean every action fits a value merely because you intended it.\n\nValues are chosen, not assigned by this page or another person. “I must always please people” is a rule worth exploring, not a value you have to accept. You can remain unsure.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.example",
      "title": "Example — Sam explores curiosity",
      "text": "Sam wants to draw and chooses curiosity as the quality to bring: looking closely and noticing something new. A polished drawing is a hoped-for result, not the quality itself.\n\nSam notices the oval rim, curved handle and rounded body of a mug, then sketches them. Sam dislikes the drawing.\n\nIn review, Sam notices that looking closely did express curiosity, even though the result was disappointing. The result still matters to Sam. Sam can change the activity, continue, or stop; the exercise does not require another drawing.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.scenario",
      "title": "Optional fictional practice — Robin",
      "text": "Robin wants to arrange a catch-up with a friend and says, “I want to be considerate about both our time.” Robin has fifteen minutes available today and hopes to agree a time this week. The friend has not replied. No call is agreed and the reason for no reply is unknown.\n\nUse Robin for the prompts, invent a manageable situation, or use your own. Fictional practice is not a request to contact anyone.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.practice.direction",
      "title": "What quality matters here?",
      "text": "Bring one ordinary situation to mind. How would you like to act in it? Use a quality that feels personally meaningful, or leave the question open.\n\nIf using Robin, work from the meaning Robin stated rather than guessing a different value.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.practice.direction.help",
      "title": "If you named a goal",
      "text": "Keep the goal if it matters. “Get a call booked” describes a result. You might also ask how you want to treat yourself and the other person while arranging it.",
      "status": "Script only"
    },
    {
      "id": "values.practice.expression",
      "title": "Consider one possible expression",
      "text": "What could you do or say that might express this quality? It can be small, quiet or private. Then separate it from the result you hope for.\n\nFor Robin, a possible invitation still needs to respect both people’s available time and choices. No reply is not agreement.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.practice.expression.help",
      "title": "If an outcome is outside your control",
      "text": "Another person can decline, and a creative attempt can disappoint. Ask what your action could express without pretending its effects or result do not matter.",
      "status": "Script only"
    },
    {
      "id": "values.practice.fit",
      "title": "Check whether it fits",
      "text": "Would this possibility respect your needs, other people’s wishes and the circumstances? Could rest, support, a smaller action or a different expression fit better?\n\nYou can choose not to act. A barrier does not prove that a value is absent.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.practice.fit.help",
      "title": "If two values pull in different directions",
      "text": "You do not have to rank your whole life. Consider what fits this situation with your therapist, including limits you cannot change.",
      "status": "Script only"
    },
    {
      "id": "values.practice.review",
      "title": "Review the distinction",
      "text": "Can you distinguish the chosen quality, the possible action and the hoped-for result? If you tried something already, consider what you actually did and what happened. Intention alone does not establish its effect.\n\nKeep a direction, a question, or nothing. No new action is required.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.practice.review.help",
      "title": "A possible Robin account",
      "text": "Consideration for both people is the stated quality. Robin could ask about a suitable time using an agreed way to communicate, without demanding a reply. Agreeing a catch-up is the hoped-for result, not guaranteed by sending a message. Robin can adapt or leave it if no suitable time is available. This is one model, not an assessment of your words.",
      "status": "Script only"
    },
    {
      "id": "values.close",
      "title": "Leave it here for now",
      "text": "You can finish without a fixed value label or a plan. If useful, bring a question or observation to your therapist. Nothing is sent from this page.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "values.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    }
  ]
}
;
