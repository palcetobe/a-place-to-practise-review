window.ABCComponentContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/abcplease",
  "componentId": "component/abcplease/mastery",
  "resourceId": "tool/build-mastery",
  "routeProposal": "/build-mastery/",
  "title": "Build Mastery",
  "version": "2026-11-03-abc-components-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "A complete named Build Mastery component practice: calibrate challenge, attempt in life, review and adjust across opportunities. Not a productivity test, exposure hierarchy or the full ABC PLEASE set.",
  "groupedSetStatus": "This is one uncounted component of classic/abcplease. Other ABC components and PLEASE have separate statuses. No new canonical count and no complete ABC PLEASE or DBT claim.",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always reachable outside focus folds, including before practice.",
    "destination": "Reuse verified project support route; do not invent contacts."
  },
  "clinicalContract": {
    "sourcePopulationContext": "Therapist-introduced and individually adapted for developmental, communication, safeguarding, health and access needs. No universal age gate or all-age/app validation claim.",
    "observedPractice": "Reading, planning, rehearsing, real-world attempting and reviewing are different. No automatic completion or success inference.",
    "learningObjective": "Choose and adjust a challenge that lets you practise capability without setting an unrealistic demand.",
    "practiceObjective": "Choose a manageable challenge, attempt it when appropriate outside the page, and return to review what happened and calibrate the next attempt."
  },
  "privacy": {
    "id": "build-mastery.privacy",
    "title": "Writing is optional",
    "paragraphs": [
      "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.",
      "Leaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.",
      "Review session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored."
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "Practice enters/resumes directly; no duplicate Start. One focused prompt group by default; free jump, Show all, Back and Finish always available. No completion locks.",
    "writing": "Hidden by default and optional; hiding removes every private echo/preview from view. No required fields, analysis, ratings or generated feedback.",
    "persistence": "Active-tool memory only. Internal navigation retains choices/notes; leaving/reload/restart/clear erases them. No localStorage, backend, diary or automatic carry-forward. Returning later allows a fresh account or privately kept notes, never claims restoration.",
    "narration": "Exact static section text only, user-initiated Listen/Pause/Resume; Replay only after this exact current clip was actually played. Leaving section/branch/tool stops playback. No autoplay, concatenated hidden branches, private-answer speech or TTS fallback. No recording acceptance implied.",
    "timer": "None. Rehearsal and actual activity are user-paced; no countdown or prescribed dose.",
    "visual": "Textually labelled method map only. No scores, ticks implying completion, streaks, positive-outcome badges or forced reflection.",
    "context": "Use an ordinary personal situation or the self-contained fictional example without an extra mode selector. Never prefill private fields with fiction.",
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Where would you like to begin?",
      "options": [
        {
          "value": "plan",
          "label": "Plan a challenge",
          "startSectionId": "build-mastery.practice.choose"
        },
        {
          "value": "review",
          "label": "Review an attempt",
          "startSectionId": "build-mastery.practice.review"
        }
      ],
      "purpose": "Genuine different temporal entry points, not mood check or completion state. Free jump to all sections remains. No forced return question or attempt checkbox."
    },
    "stateBoundary": "Keep a separate focus position for each real mode/branch. Accumulation notes are namespaced by short/long. Mastery plan and review are entry points into one challenge record, not separate duplicate records. Same-open-page activity while away from screen retains in-memory notes; actual leave/reload clears. Never infer attempted/completed state from clicks, fields or navigation.",
    "shortcut": "Existing public REVIEW session-only shortcut keyed by exact component/resource identity. No usual Toolbox write, durable persistence, localStorage or personal notes. Display the exact review-session lifetime notice; shortcut lifetime distinct from active-tool note clearing.",
    "reviewAccess": "Every review prompt freely accessible, including no attempt, partial attempt, changed activity or changed circumstances. No I did it gate, success confirmation, outcome flag or required account."
  },
  "close": {
    "id": "build-mastery.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.",
      "Return to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here."
    ],
    "actions": [
      "Back to practice",
      "Choose notes to keep",
      "Save session shortcut",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "id": "linehan-er-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-3.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical official emotion-regulation handouts 14–19 and worksheets 10–13; exact component locations in methodTraceability.",
      "limits": "Original wording/examples only; no reproduction license for electronic display. Recognition and procedure evidence, not digital/adolescent validation or exact revised-2025 wording."
    },
    {
      "id": "linehan-er-teaching-2015",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-3teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Teacher explanation and practice/review distinctions, including not penalizing a different mastery activity than planned.",
      "limits": "Professional source, not a standalone client script. No efficacy or completeness certification for this app."
    }
  ],
  "implementationGates": {
    "capabilityClaims": "Privacy/close text must not be offered or narrated until exact persistence, explicit selected-note preview/copy/download and shortcut behaviors pass actual runtime tests. Implement the contract, do not silently remove capabilities or promise them before tests.",
    "gatedSectionIds": [
      "build-mastery.privacy",
      "build-mastery.close"
    ],
    "testsRequired": [
      "Internal Practice/Example/Learn/help/back retains notes and mode",
      "Leave/reload/restart/clear removes all notes and echoes",
      "Hidden writing hides all private previews",
      "No note selected by default; exact selection/preview before explicit copy/download",
      "Shortcut retains only distinct component identity in the open preview session; reload/session closure removes it; usual Toolbox is unchanged",
      "Audio contains only visible static current section, stops on navigation, and never uses private fields",
      "Free jump/Show all/Finish works without input, completion or improved emotion",
      "Later return is fresh; no planned or attempted status inferred"
    ]
  },
  "acceptance": [
    "Complete named component operations remain teachable and actually practicable, not just definitions.",
    "Original worked example includes actual rehearsal/attempt and neutral review.",
    "All help, fit and full teaching accessible without enforced reading.",
    "No writing, rating, emotion change or real-world activity required to leave.",
    "Content review is separate from clinical validation, UI testing, guide/export review and audio listening."
  ],
  "intro": {
    "id": "build-mastery.intro",
    "title": "Build Mastery",
    "paragraphs": [
      "Build Mastery is practising something that stretches your ability without asking the impossible. The aim is to develop capability over repeated opportunities, not to prove your worth or get everything right.",
      "You can plan an attempt, return after trying something, or explore the example. Planning is preparation; the practice happens when you try the activity in your life."
    ]
  },
  "fit": {
    "id": "build-mastery.fit",
    "title": "Check whether this fits",
    "paragraphs": [
      "Choose an ordinary task that fits your health, energy, access and responsibilities, with your therapist’s guidance. Rest or asking for practical help may be what you need now.",
      "Do not use this page to push through pain, exhaustion, illness or unsafe conditions, or to set an exposure challenge. Follow individual medical or rehabilitation advice rather than increasing physical demands here.",
      "A task can be small and still challenging for you. Your capacity can change from day to day. You do not have to feel capable, finish a task or increase its difficulty on every attempt."
    ]
  },
  "learn": {
    "id": "build-mastery.learn",
    "title": "What makes this mastery practice?",
    "paragraphs": [
      "Choose something that takes some effort but is possible with the time, support and resources available. Try it, then use what happened to decide whether to repeat, make it easier, add support or gradually stretch it.",
      "A graded-task ladder helps break down a task. Build Mastery adds a particular focus: repeated practice of capability through a well-matched challenge. An activity is not mastery practice simply because you ticked it off.",
      "The source encourages regular practice. Agree a realistic rhythm with your therapist rather than treating this page as a daily requirement. There are no streaks or penalties for missed opportunities.",
      "Review the actual attempt, even if you tried a different activity than planned. A difficult outcome can tell you about task fit, access or support; it is not a verdict on your character."
    ]
  },
  "example": {
    "id": "build-mastery.example",
    "title": "Example: Nia learns a short piece",
    "paragraphs": [
      "Nia wants to learn a melody on a small keyboard. Playing the whole piece is too difficult, but two unfamiliar bars seem possible. They choose those bars, a slower pace and a time when the room is available.",
      "During the real attempt, Nia plays the first bar several times and keeps losing their place in the second. They stop when they are tired. This was an attempt even though the planned two bars were not finished.",
      "When Nia reviews it, they notice they could find the first notes but switching between bars was too much at once. Next time they choose just the transition, with the notes marked on their own sheet.",
      "Later the transition becomes easier. Nia can repeat it for steadiness or add the next few notes when it fits. They do not have to increase the challenge every time or use feeling confident as proof of progress."
    ]
  },
  "practice": [
    {
      "id": "build-mastery.practice.choose",
      "title": "Choose a capability to practise",
      "paragraphs": [
        "What ordinary ability would you like to develop or reconnect with? Choose one activity that matters to you, or use Nia’s keyboard example to understand the process.",
        "If you have already tried something, you can go directly to the review prompts. You do not need a plan recorded here first."
      ],
      "fields": [
        {
          "key": "ability",
          "label": "The capability or activity",
          "optional": true
        }
      ],
      "help": {
        "title": "If everything feels like a demand",
        "text": "You can stop, discuss the pressure with your therapist, or choose a much smaller task with support. Rest does not have to earn its place by becoming another challenge."
      }
    },
    {
      "id": "build-mastery.practice.calibrate",
      "title": "Find a challenge that fits today",
      "paragraphs": [
        "What is the part you can reasonably attempt, and what makes it a stretch rather than routine? Consider current energy, time, equipment, support and access.",
        "If it is too much, reduce the part or add support. If it is already easy and you want a challenge, choose a small additional stretch. Do not increase difficulty just to satisfy the page."
      ],
      "fields": [
        {
          "key": "challenge",
          "label": "A possible challenge",
          "optional": true
        },
        {
          "key": "fit",
          "label": "What makes this possible today",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot judge the difficulty",
        "text": "Use previous experience or ask someone who knows the task. You can treat the first attempt as information and adjust afterward; no numerical difficulty score is needed."
      }
    },
    {
      "id": "build-mastery.practice.opportunity",
      "title": "Prepare an opportunity and a stopping point",
      "paragraphs": [
        "Choose a realistic occasion to try, and what needs to be available. How will you recognise that it is time to pause, stop or ask for help?",
        "Nia chooses a quiet time with the keyboard available and stops when tired. Your stopping point should fit your own task and any guidance you have."
      ],
      "fields": [
        {
          "key": "opportunity",
          "label": "A suitable opportunity and what I need",
          "optional": true
        },
        {
          "key": "stop",
          "label": "When I would pause or ask for help",
          "optional": true
        }
      ],
      "help": {
        "title": "If the opportunity changes",
        "text": "Change the plan, choose another activity or leave it for now. The point is the practice you can actually do, not obedience to a schedule."
      }
    },
    {
      "id": "build-mastery.practice.attempt",
      "title": "Try it in your life when it fits",
      "paragraphs": [
        "The attempt happens away from this page. If the task is suitable now, you can leave and try it. If not, keep it for an appropriate opportunity or stop here.",
        "When you return, open “Review an attempt” to describe what actually happened. This tool does not save your notes after you leave. You can remember the plan, keep your own note, or explicitly select a copy before leaving."
      ],
      "help": {
        "title": "If I have not tried it yet",
        "text": "There is nothing to mark complete. You can revise the plan, view the example or finish. The review is available later without proving that you did the task."
      }
    },
    {
      "id": "build-mastery.practice.review",
      "title": "Review an attempt",
      "paragraphs": [
        "Think of a real attempt, even a partial one or something different from the original plan. What did you actually do? What felt manageable, and where did the task, circumstances or support not fit?",
        "If you did not attempt it, you can consider what prevented an opportunity, change the plan or leave this blank. Do not turn an imagined success into an account of something you did."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What I actually tried, if anything",
          "optional": true
        },
        {
          "key": "learning",
          "label": "What the attempt showed about fit",
          "optional": true
        }
      ],
      "help": {
        "title": "If I feel disappointed",
        "text": "You do not need to replace that feeling with pride. Look at a concrete part of the task and the circumstances; a difficult attempt does not determine your worth."
      }
    },
    {
      "id": "build-mastery.practice.adjust",
      "title": "Calibrate the next opportunity",
      "paragraphs": [
        "Based on the actual attempt, would it fit to repeat, reduce the challenge, add support, try a different activity or take a small further step? You can also pause the practice.",
        "Choose an adjustment only if useful. Increasing difficulty makes sense when the earlier challenge has become manageable and your current circumstances allow it, not because progress must always go upward."
      ],
      "fields": [
        {
          "key": "adjustment",
          "label": "What I might repeat or change",
          "optional": true
        }
      ],
      "help": {
        "title": "If a task is easy one day and difficult another",
        "text": "Use today’s capacity. Repeating or reducing a challenge can be a sensible adjustment, not lost progress."
      }
    }
  ],
  "methodElements": [
    "Capability-linked activity",
    "Achievable challenge calibration",
    "Opportunity and support",
    "Actual real-world attempt distinct from plan",
    "Review actual activity without penalizing changed plan",
    "Repeat or adjust challenge across opportunities"
  ],
  "methodTraceability": {
    "sourceLocation": "Emotion Regulation Handout 19, PDF page 51; Worksheet 12, PDF page 89; teaching notes PDF pages 76–77",
    "componentIdentity": "Existing component/abcplease/mastery. No verified separate accepted legacy route/resource ID; tool/build-mastery and /build-mastery/ are new local proposals only.",
    "adaptations": [
      "Original examples and accessible planning/return review.",
      "Regular practice retained as a learning process; source daily instruction adapted to individually agreed rhythm.",
      "No physical exercise prescription or demand to feel accomplishment."
    ]
  },
  "relatedResources": {
    "status": "Preserve existing identities; links only after route verification in isolated runtime. No silent redirection/replacement.",
    "resources": [
      "classic/graded",
      "classic/ba"
    ]
  },
  "narrationSegments": [
    {
      "id": "build-mastery.privacy",
      "title": "Writing is optional",
      "text": "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.\n\nLeaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.\n\nReview session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored.",
      "textSha256": "08e5d33489f269867a52f82337eafbed695f22fd860232e4a1260c736a31d56d",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "capabilityGate": "Unavailable until all relevant actual renderer capability tests pass."
    },
    {
      "id": "build-mastery.intro",
      "title": "Build Mastery",
      "text": "Build Mastery is practising something that stretches your ability without asking the impossible. The aim is to develop capability over repeated opportunities, not to prove your worth or get everything right.\n\nYou can plan an attempt, return after trying something, or explore the example. Planning is preparation; the practice happens when you try the activity in your life.",
      "textSha256": "d78edfc0b6c067e601cd9abd50a4de799a1668b86f387c8f233d17131ca4bfe2",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.fit",
      "title": "Check whether this fits",
      "text": "Choose an ordinary task that fits your health, energy, access and responsibilities, with your therapist’s guidance. Rest or asking for practical help may be what you need now.\n\nDo not use this page to push through pain, exhaustion, illness or unsafe conditions, or to set an exposure challenge. Follow individual medical or rehabilitation advice rather than increasing physical demands here.\n\nA task can be small and still challenging for you. Your capacity can change from day to day. You do not have to feel capable, finish a task or increase its difficulty on every attempt.",
      "textSha256": "1e6dc9298243c1b835d32a7bc1fcb4e7a6f8530e7f17c57ff01b8eb54138a6bb",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.learn",
      "title": "What makes this mastery practice?",
      "text": "Choose something that takes some effort but is possible with the time, support and resources available. Try it, then use what happened to decide whether to repeat, make it easier, add support or gradually stretch it.\n\nA graded-task ladder helps break down a task. Build Mastery adds a particular focus: repeated practice of capability through a well-matched challenge. An activity is not mastery practice simply because you ticked it off.\n\nThe source encourages regular practice. Agree a realistic rhythm with your therapist rather than treating this page as a daily requirement. There are no streaks or penalties for missed opportunities.\n\nReview the actual attempt, even if you tried a different activity than planned. A difficult outcome can tell you about task fit, access or support; it is not a verdict on your character.",
      "textSha256": "ee61cedaa0f4851caab997e3f52ef7d7bf950be1d5c9a637fd9bdea82dee0508",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.example",
      "title": "Example: Nia learns a short piece",
      "text": "Nia wants to learn a melody on a small keyboard. Playing the whole piece is too difficult, but two unfamiliar bars seem possible. They choose those bars, a slower pace and a time when the room is available.\n\nDuring the real attempt, Nia plays the first bar several times and keeps losing their place in the second. They stop when they are tired. This was an attempt even though the planned two bars were not finished.\n\nWhen Nia reviews it, they notice they could find the first notes but switching between bars was too much at once. Next time they choose just the transition, with the notes marked on their own sheet.\n\nLater the transition becomes easier. Nia can repeat it for steadiness or add the next few notes when it fits. They do not have to increase the challenge every time or use feeling confident as proof of progress.",
      "textSha256": "3fcf2e10e4db3004666fc0e4df2535061c514f94f0517b24820405deb0e92e94",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.practice.choose",
      "title": "Choose a capability to practise",
      "text": "What ordinary ability would you like to develop or reconnect with? Choose one activity that matters to you, or use Nia’s keyboard example to understand the process.\n\nIf you have already tried something, you can go directly to the review prompts. You do not need a plan recorded here first.",
      "textSha256": "d6dc7ad5c018296716bfa94842abdd710a319a8082b0d3eb6e40e60802372e93",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.practice.choose.help",
      "title": "If everything feels like a demand",
      "text": "You can stop, discuss the pressure with your therapist, or choose a much smaller task with support. Rest does not have to earn its place by becoming another challenge.",
      "textSha256": "ad2dc2df62d1fbf6cd70dd4f7121732cd172633e06b4dbf698c06a64e5ad1603",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "build-mastery.practice.calibrate",
      "title": "Find a challenge that fits today",
      "text": "What is the part you can reasonably attempt, and what makes it a stretch rather than routine? Consider current energy, time, equipment, support and access.\n\nIf it is too much, reduce the part or add support. If it is already easy and you want a challenge, choose a small additional stretch. Do not increase difficulty just to satisfy the page.",
      "textSha256": "c3882dcbde060932402feb11ddbd8d1b608661d2fb6dd1e9161b145d2775ff55",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.practice.calibrate.help",
      "title": "If I cannot judge the difficulty",
      "text": "Use previous experience or ask someone who knows the task. You can treat the first attempt as information and adjust afterward; no numerical difficulty score is needed.",
      "textSha256": "0af89e4062f3c96cf4bf68e80fe9d79c6c61d837a9a80cf18baf78da3491351b",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "build-mastery.practice.opportunity",
      "title": "Prepare an opportunity and a stopping point",
      "text": "Choose a realistic occasion to try, and what needs to be available. How will you recognise that it is time to pause, stop or ask for help?\n\nNia chooses a quiet time with the keyboard available and stops when tired. Your stopping point should fit your own task and any guidance you have.",
      "textSha256": "1033ad85364bb8b7f0b30871aeefac8a9903e820501c583ac1bc7b99daf07433",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.practice.opportunity.help",
      "title": "If the opportunity changes",
      "text": "Change the plan, choose another activity or leave it for now. The point is the practice you can actually do, not obedience to a schedule.",
      "textSha256": "0937b3a8c5941901e61afbdc8c78d079286baabb033dfdf063a98e9c91de0f78",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "build-mastery.practice.attempt",
      "title": "Try it in your life when it fits",
      "text": "The attempt happens away from this page. If the task is suitable now, you can leave and try it. If not, keep it for an appropriate opportunity or stop here.\n\nWhen you return, open “Review an attempt” to describe what actually happened. This tool does not save your notes after you leave. You can remember the plan, keep your own note, or explicitly select a copy before leaving.",
      "textSha256": "74ac1d42b9dc1c5768d7db05042e79e0128eb9994140227bfbf255527604c5ce",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.practice.attempt.help",
      "title": "If I have not tried it yet",
      "text": "There is nothing to mark complete. You can revise the plan, view the example or finish. The review is available later without proving that you did the task.",
      "textSha256": "d64ce10c848d37a4e9a0fb177cc5e65cd789938a5cce50357370c733c9c5dcb7",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "build-mastery.practice.review",
      "title": "Review an attempt",
      "text": "Think of a real attempt, even a partial one or something different from the original plan. What did you actually do? What felt manageable, and where did the task, circumstances or support not fit?\n\nIf you did not attempt it, you can consider what prevented an opportunity, change the plan or leave this blank. Do not turn an imagined success into an account of something you did.",
      "textSha256": "4ffd713a46e140d698a0d94d321d0eb97623f7667c7ded34cfa4c2c21ec062ee",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.practice.review.help",
      "title": "If I feel disappointed",
      "text": "You do not need to replace that feeling with pride. Look at a concrete part of the task and the circumstances; a difficult attempt does not determine your worth.",
      "textSha256": "048e24dcb3bcd2e101db8f90695f6204d08f4ed730b91bba24bb9ec5de6d3cb7",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "build-mastery.practice.adjust",
      "title": "Calibrate the next opportunity",
      "text": "Based on the actual attempt, would it fit to repeat, reduce the challenge, add support, try a different activity or take a small further step? You can also pause the practice.\n\nChoose an adjustment only if useful. Increasing difficulty makes sense when the earlier challenge has become manageable and your current circumstances allow it, not because progress must always go upward.",
      "textSha256": "990df1b9921cd8d75f4cf1aed76a8e085a84bb870aaaebb1f179bd13450394e9",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded."
    },
    {
      "id": "build-mastery.practice.adjust.help",
      "title": "If a task is easy one day and difficult another",
      "text": "Use today’s capacity. Repeating or reducing a challenge can be a sensible adjustment, not lost progress.",
      "textSha256": "33ceff6ed0933ee274562ea366a463fb39d39eca1a8ca47a97a259e3cb85e5da",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact authored help text only while this help is expanded; private answers excluded."
    },
    {
      "id": "build-mastery.close",
      "title": "Leave the practice here",
      "text": "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.\n\nReturn to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here.",
      "textSha256": "c9171e9f0e25d189db3f09fbfa5ba8707d92ece31276d5ba3baa1b8bcbdbf102",
      "status": "Candidate script only; no audio generated or listening-approved",
      "visibleScope": "Exact currently visible authored paragraphs only; headings, controls, field labels, private answers and hidden branches excluded.",
      "capabilityGate": "Unavailable until all relevant actual renderer capability tests pass."
    }
  ],
  "staticTextCopyContract": {
    "scope": "An explicitly requested copy/download of authored teaching or narration transcript is separate from selected personal notes. No clipboard/export on navigation, Finish, Listen, mode selection or source visit.",
    "permissions": "No source PDF copying or redistribution. Cite sources; offer only original authored static content. Personal notes never appended by default."
  }
}
;
