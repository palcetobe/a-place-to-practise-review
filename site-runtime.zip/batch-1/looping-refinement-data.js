
window.LoopingThoughtRefinement={
  "id": "looping-thought",
  "route": "tool/looping-thought",
  "root": "thought-spiral-guided",
  "savedIdentity": {
    "p": "thought-spiral-guided",
    "c": null
  },
  "title": "Work Through a Looping Thought",
  "intro": [
    "Practise noticing a repeated thought and choosing how to respond. This does not decide whether a concern is true or make you stop thinking it.",
    "Use an ordinary, manageable situation. “See an example” offers a fictional situation if you prefer. You can think, speak privately, write, skip or stop. If practical safety or support is needed, you do not have to finish an exercise first."
  ],
  "sections": [
    {
      "title": "Notice one thought",
      "paragraphs": [
        "Choose one thought that has been repeating in an ordinary, manageable situation. Notice its words. You can keep them in mind, say them privately, or write them below.",
        "You do not need to explain its cause or solve it before trying this practice."
      ],
      "fields": [
        [
          "The thought's words (optional)",
          "thought"
        ]
      ]
    },
    {
      "title": "Try noticing it as a thought",
      "paragraphs": [
        "Try: \"I'm having the thought that...\" followed by the thought's words. Read it slowly or say it privately if that fits.",
        "This phrase doesn't have to make the thought go away. It offers another way to notice the thought. It doesn't establish whether the concern is true.",
        "The wording may feel different, the same or unhelpful. You can stop using it. You do not need to repeat it until it feels different."
      ],
      "fields": []
    },
    {
      "title": "Choose what to do next",
      "paragraphs": [
        "If useful, notice what the thought draws your attention to. That doesn't prove its message or a hidden motive. Its meaning can remain uncertain.",
        "What would you like to do with the next few minutes? Consider an ordinary activity, a practical step, rest or support that fits. The thought can still be present.",
        "If the thought returns, you can notice it again and choose your next move. A quieter mind is not required."
      ],
      "fields": [
        [
          "What it brings to mind, if anything (optional)",
          "meaning"
        ],
        [
          "A possible next move (optional)",
          "next"
        ]
      ]
    }
  ],
  "finish": [
    "You can finish whether the thought feels different, the same or still present.",
    "If useful, notice what you tried and whether you want to use it again, adapt it or choose another approach. You can skip reflecting."
  ],
  "optional": {
    "example": {
      "title": "Worked example: noticing a thought without deciding it is false",
      "paragraphs": [
        "Sam keeps thinking, ‘They’ll reject my application.’ Sam tries, ‘I’m having the thought that they’ll reject my application.’ The phrase identifies a prediction; it does not settle what the decision will be.",
        "Sam notices the thought is still there and checks one ordinary application requirement rather than repeating the phrase until worry fades. After checking, Sam returns to the rest of the evening without knowing the outcome.",
        "In review, Sam notices that the words offered a different way to hold the prediction, not a guarantee. Sam could adapt the wording or leave it next time. The useful question is whether it helped Sam respond flexibly, not whether the prediction disappeared."
      ]
    },
    "learn": {
      "title": "A little more about this practice",
      "paragraphs": [
        "Cognitive defusion means noticing a thought as something your mind is producing, rather than treating its words as an instruction you must follow. A thought can contain a real concern; noticing it does not prove it false.",
        "This page uses one thought-label phrase. It is not a test of positive thinking, a debate with the thought or a way to remove it. After noticing, you can choose a response that fits the situation, including checking a practical fact, resting or getting support.",
        "You do not need to keep saying the phrase until it feels right. If it becomes another check or a struggle to get rid of the thought, pause and discuss that pattern with your therapist. Other defusion exercises are separate options, not extra steps to finish here."
      ]
    },
    "barriers": {
      "title": "If the practice is hard to use",
      "paragraphs": [
        "If the phrase does not fit, try a plain description such as ‘I notice that prediction,’ change approach or stop. You do not have to replace the thought, feel distant from it or agree with a new statement.",
        "Do not label away information about actual danger, mistreatment or a health concern. Attend to needed information or support; this exercise does not decide the facts.",
        "For a thought you want to examine using evidence, the separate Thought Record offers a different method. You do not need to switch tools to finish here."
      ]
    }
  },
  "sourceRoot": "thought-spiral-guided",
  "privacy": "Optional writing and choices stay in this open practice. In-page Back keeps them. Leaving, reloading, clearing or starting fresh removes them, including hidden fields. My Toolbox saves a shortcut, not your answers. If you explicitly download selected notes or copy text, that copy remains wherever you put it. Private thinking is not reconstructed or exported.",
  "reviewStatus": "Written REVIEW wording; clinical, rights and browser acceptance remain pending.",
  "designRationale": {
    "paragraphs": [
      "A repeating thought can pull you into responding to it automatically. Noticing “I’m having the thought that…” may give you room to choose your response instead. This is not a way to prove the thought wrong or make it disappear; you can still attend to a practical concern."
    ],
    "sources": [
      {
        "title": "Association for Contextual Behavioral Science · Core ACT processes",
        "url": "https://contextualscience.org/six_core_processes_act"
      }
    ]
  },
  "fit": {
    "id": "looping-thought.fit",
    "title": "Choose an ordinary thought",
    "paragraphs": [
      "Use this with your therapist between sessions. Choose an ordinary manageable thought or Sam’s example, not a distressing memory you have been advised to work on with support.",
      "This is a thought-noticing exercise, not treatment for voices or other experiences needing assessment. If it feels confusing, makes you feel more detached or distressed, or turns into repeated checking, stop and seek guidance. Practical safety and support come first."
    ]
  },
  "clinicalContract": {
    "canonicalId": "classic/defusion",
    "componentId": "component/defusion/thought-phrase",
    "learningObjective": "Distinguish noticing a thought from disproving, obeying or suppressing it.",
    "practiceObjective": "Notice one manageable thought, actually try the thought-label phrase or a plain alternative if suitable, then consider a context-appropriate response while allowing the thought to remain.",
    "scope": "Thought-phrase exercise only. Leaves on a Stream and other defusion resources are not made complete or replaced.",
    "developmentalFit": "Individual therapist review of development, communication, consent, privacy, safeguarding and circumstances; adult source recognition does not validate this digital adaptation or establish suitability across ages."
  },
  "sources": [
    {
      "url": "https://www.mirecc.va.gov/MIRECC/visn16/docs/act-strategies-guide.pdf",
      "reviewed": "2026-11-02",
      "supports": "Printed pp28–33: flexible relationship to thoughts, ways of speaking and context-appropriate behavior rather than literal obedience or suppression.",
      "limits": "Clinician-facing adult-veteran guide; no unsupervised exposure or adolescent effectiveness claim transferred."
    },
    {
      "url": "https://contextualscience.org/six_core_processes_act",
      "reviewed": "2026-11-02",
      "supports": "Current professional society account: defusion changes the relationship/function of thoughts rather than their form or frequency; flexible action is the context.",
      "limits": "Framework recognition, not exact app efficacy or youth validation."
    }
  ],
  "productAdaptations": [
    "Existing three-prompt structure and saved resource identity preserved. Sam application example extended to actual action/outcome/review. Original explanatory wording; no new metaphor or extra required practice step.",
    "Existing privacy/export capability is preserved, not replaced with newer component privacy assumptions. Existing exact export and clearing behavior remains implementation QA responsibility."
  ],
  "narrationSegments": [
    {
      "id": "looping-thought.intro",
      "title": "Work Through a Looping Thought",
      "text": "Practise noticing a repeated thought and choosing how to respond. This does not decide whether a concern is true or make you stop thinking it.\n\nUse an ordinary, manageable situation. “See an example” offers a fictional situation if you prefer. You can think, speak privately, write, skip or stop. If practical safety or support is needed, you do not have to finish an exercise first.",
      "textSha256": "25a2d102e25f68da627a31f79280331711e29053cb772cfa449447e40cf8e6b4",
      "status": "Written script only; audio unavailable and listening approval not inferred"
    },
    {
      "id": "looping-thought.prompt.1",
      "title": "Notice one thought",
      "text": "Choose one thought that has been repeating in an ordinary, manageable situation. Notice its words. You can keep them in mind, say them privately, or write them below.\n\nYou do not need to explain its cause or solve it before trying this practice.",
      "textSha256": "6363af649dda624c4e080f074cb4d83139d5d825053383c762cf454cbb0cd4cf",
      "status": "Written script only; audio unavailable and listening approval not inferred"
    },
    {
      "id": "looping-thought.prompt.2",
      "title": "Try noticing it as a thought",
      "text": "Try: \"I'm having the thought that...\" followed by the thought's words. Read it slowly or say it privately if that fits.\n\nThis phrase doesn't have to make the thought go away. It offers another way to notice the thought. It doesn't establish whether the concern is true.\n\nThe wording may feel different, the same or unhelpful. You can stop using it. You do not need to repeat it until it feels different.",
      "textSha256": "ceecaea277de1dd74f441ec3fccfeef848c8aa047ce40e7cb343d563cf865e71",
      "status": "Written script only; audio unavailable and listening approval not inferred"
    },
    {
      "id": "looping-thought.prompt.3",
      "title": "Choose what to do next",
      "text": "If useful, notice what the thought draws your attention to. That doesn't prove its message or a hidden motive. Its meaning can remain uncertain.\n\nWhat would you like to do with the next few minutes? Consider an ordinary activity, a practical step, rest or support that fits. The thought can still be present.\n\nIf the thought returns, you can notice it again and choose your next move. A quieter mind is not required.",
      "textSha256": "29aea775202c487e837924385383201a58b503a32aa44d88191f60ac6d4dbfd4",
      "status": "Written script only; audio unavailable and listening approval not inferred"
    },
    {
      "id": "looping-thought.finish",
      "title": "Closing",
      "text": "You can finish whether the thought feels different, the same or still present.\n\nIf useful, notice what you tried and whether you want to use it again, adapt it or choose another approach. You can skip reflecting.",
      "textSha256": "9dc2b38f7866cab2c379658ed3de4036a0c77d0ca7fd7d1d5bcaf34c4db79b79",
      "status": "Written script only; audio unavailable and listening approval not inferred"
    },
    {
      "id": "looping-thought.example",
      "title": "Worked example: noticing a thought without deciding it is false",
      "text": "Sam keeps thinking, ‘They’ll reject my application.’ Sam tries, ‘I’m having the thought that they’ll reject my application.’ The phrase identifies a prediction; it does not settle what the decision will be.\n\nSam notices the thought is still there and checks one ordinary application requirement rather than repeating the phrase until worry fades. After checking, Sam returns to the rest of the evening without knowing the outcome.\n\nIn review, Sam notices that the words offered a different way to hold the prediction, not a guarantee. Sam could adapt the wording or leave it next time. The useful question is whether it helped Sam respond flexibly, not whether the prediction disappeared.",
      "textSha256": "61da850a79384f92d823850920af01da885f3129ebae9c33d70bf5cd54fc3985",
      "status": "Replacement script only"
    },
    {
      "id": "looping-thought.why",
      "title": "Why this skill may help",
      "text": "A repeating thought can pull you into responding to it automatically. Noticing “I’m having the thought that…” may give you room to choose your response instead. This is not a way to prove the thought wrong or make it disappear; you can still attend to a practical concern.",
      "textSha256": "2ef4cb7c740a2bd205a0828b4ca61aeb771819f4277bd33016e6ae289c7e74e8",
      "status": "Written script only; audio unavailable and listening approval not inferred"
    },
    {
      "id": "looping-thought.learn",
      "title": "A little more about this practice",
      "text": "Cognitive defusion means noticing a thought as something your mind is producing, rather than treating its words as an instruction you must follow. A thought can contain a real concern; noticing it does not prove it false.\n\nThis page uses one thought-label phrase. It is not a test of positive thinking, a debate with the thought or a way to remove it. After noticing, you can choose a response that fits the situation, including checking a practical fact, resting or getting support.\n\nYou do not need to keep saying the phrase until it feels right. If it becomes another check or a struggle to get rid of the thought, pause and discuss that pattern with your therapist. Other defusion exercises are separate options, not extra steps to finish here.",
      "textSha256": "3be99486e310f207e288d41ddcb9e7e23068fa9b95fb5d6431e8b02d864274e6",
      "status": "Replacement script only"
    },
    {
      "id": "looping-thought.barriers",
      "title": "If this is hard to use",
      "text": "If the phrase does not fit, try a plain description such as ‘I notice that prediction,’ change approach or stop. You do not have to replace the thought, feel distant from it or agree with a new statement.\n\nDo not label away information about actual danger, mistreatment or a health concern. Attend to needed information or support; this exercise does not decide the facts.\n\nFor a thought you want to examine using evidence, the separate Thought Record offers a different method. You do not need to switch tools to finish here.",
      "textSha256": "045183a805be5ad8109db6fce8678088ef68881fe68a806dfaf456f18d5e72ba",
      "status": "Replacement script only"
    },
    {
      "id": "looping-thought.fit",
      "title": "Choose an ordinary thought",
      "text": "Use this with your therapist between sessions. Choose an ordinary manageable thought or Sam’s example, not a distressing memory you have been advised to work on with support.\n\nThis is a thought-noticing exercise, not treatment for voices or other experiences needing assessment. If it feels confusing, makes you feel more detached or distressed, or turns into repeated checking, stop and seek guidance. Practical safety and support come first.",
      "textSha256": "9bbff4285230dc51b72b02c8f99df0a2b4366ce341e5fac6276870c0b9f4a737",
      "status": "New script only"
    }
  ]
}
;
(()=>{const d=window.LoopingThoughtRefinement;window.DeliveryFrameworkBatchData.tools[d.id]=structuredClone(d);const t=window.ToolLayoutNarrationDraft.tools[d.id];Object.assign(t,{example:d.optional.example.paragraphs.join("\n\n"),learningContext:d.optional.learn.paragraphs.join("\n\n"),difficultyHelp:d.optional.barriers.paragraphs.join("\n\n"),fit:d.fit.paragraphs.join("\n\n")});})();
