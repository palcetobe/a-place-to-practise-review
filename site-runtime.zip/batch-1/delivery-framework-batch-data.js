window.DeliveryFrameworkBatchData={
  "version": "delivery-framework-batch1-v1.1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "feedbackQuestion": "Optional: was this approach useful just now?",
  "feedbackChoices": [
    "Helpful",
    "Not helpful",
    "Unsure",
    "Uncomfortable",
    "Skip"
  ],
  "tools": {
    "looping-thought": {
      "id": "looping-thought",
      "route": "tool/looping-thought",
      "root": "thought-spiral-guided",
      "savedIdentity": {
        "p": "thought-spiral-guided",
        "c": null
      },
      "title": "Work Through a Looping Thought",
      "intro": [
        "Practise noticing a repeated thought and choosing how to respond. This does not decide whether a concern is true or make you stop thinking it.",
        "Use an ordinary, manageable situation or the fictional example. You can think, speak privately, write, skip or stop. If practical safety or support is needed, you do not have to finish an exercise first."
      ],
      "sections": [
        {
          "title": "Notice one thought",
          "paragraphs": [
            "Notice a thought. You can write its words below or keep them in mind.",
            "Use one ordinary thought or Sam's example. You do not need to explain its cause or solve it before trying the practice."
          ],
          "fields": [
            [
              "The thought's words (optional)",
              "thought"
            ]
          ]
        },
        {
          "title": "Try noticing it as a thought",
          "paragraphs": [
            "Try: \"I'm having the thought that...\" followed by the thought's words. Read it slowly or say it privately if that fits.",
            "This phrase doesn't have to make the thought go away. It offers another way to notice the thought. It doesn't establish whether the concern is true.",
            "The wording may feel different, the same or unhelpful. You can stop using it. You do not need to repeat it until it feels different."
          ],
          "fields": []
        },
        {
          "title": "Choose what to do next",
          "paragraphs": [
            "If useful, notice what the thought draws your attention to. That doesn't prove its message or a hidden motive. Its meaning can remain uncertain.",
            "What would you like to do with the next few minutes? Consider an ordinary activity, a practical step, rest or support that fits. The thought can still be present.",
            "If the thought returns, you can notice it again and choose your next move. A quieter mind is not required."
          ],
          "fields": [
            [
              "What it brings to mind, if anything (optional)",
              "meaning"
            ],
            [
              "A possible next move (optional)",
              "next"
            ]
          ]
        }
      ],
      "finish": [
        "You can finish whether the thought feels different, the same or still present.",
        "If useful, notice what you tried and whether you want to use it again, adapt it or choose another approach. You can skip reflecting."
      ],
      "optional": {
        "example": {
          "title": "Worked example: noticing a thought without deciding it is false",
          "paragraphs": [
            "Sam keeps thinking, ‘They'll reject my application.’ Sam tries, ‘I'm having the thought that they'll reject my application.’",
            "The phrase helps Sam notice a prediction, but it does not establish what the decision will be. Sam can check an application requirement or leave the outcome uncertain. The thought may still return."
          ]
        },
        "learn": {
          "title": "A little more about this practice",
          "paragraphs": [
            "Is there another fair way to hold this thought?",
            "One that still takes the concern seriously, but doesn't let it run the show.",
            "You don't have to answer this. Sometimes just sitting with the question is enough.",
            "Noticing a thought as a thought is different from deciding it is false. You can still check a practical concern or seek support."
          ]
        },
        "barriers": {
          "title": "If the practice is hard to use",
          "paragraphs": [
            "If the phrase does not fit, continue in ordinary words, change approach or stop. It is not a test of whether you can make a feeling change.",
            "If useful, consider another fair way to hold the concern. You do not have to replace the thought or agree with a new statement.",
            "For a thought you want to examine using evidence, the separate Thought Record offers a different method."
          ]
        }
      },
      "sourceRoot": "thought-spiral-guided",
      "privacy": "Optional writing and choices stay in this open practice. In-page Back keeps them. Leaving, reloading, clearing or starting fresh removes them, including hidden fields. My Toolbox saves a shortcut, not your answers. If you explicitly download selected notes or copy text, that copy remains wherever you put it. Private thinking is not reconstructed or exported.",
      "reviewStatus": "Written REVIEW wording; clinical, rights and browser acceptance remain pending."
    },
    "reframe-inner-critic": {
      "id": "reframe-inner-critic",
      "route": "tool/reframe-inner-critic",
      "root": "self-talk-guided",
      "savedIdentity": {
        "p": "self-talk-guided",
        "c": null
      },
      "title": "Reframe the Inner Critic",
      "intro": [
        "Look at a harsh statement and consider a fair, believable response. You can acknowledge a mistake without turning it into a judgement about your whole self.",
        "Use an ordinary, manageable situation or the fictional example. You can think, speak privately, write, skip or stop. If practical safety or support is needed, you do not have to finish an exercise first."
      ],
      "sections": [
        {
          "title": "Notice the statement",
          "paragraphs": [
            "Notice the words as they come. You can write them below or keep them in mind.",
            "Choose one specific statement or use Ari's example. You do not have to decide where this voice came from."
          ],
          "fields": [
            [
              "The statement (optional)",
              "statement"
            ]
          ]
        },
        {
          "title": "Consider facts, interpretations and context",
          "paragraphs": [
            "Some words may describe what happened; others may be a judgement or an uncertain interpretation. What evidence supports each part?",
            "What happened that you can describe specifically? What supports or does not support the broader judgement? What context, limits or uncertainty matter? You can leave an answer open."
          ],
          "fields": [
            [
              "Facts, context or what is unknown (optional)",
              "evidence"
            ]
          ]
        },
        {
          "title": "Try a fair response",
          "paragraphs": [
            "Imagine someone you care about saying this about themselves. What would be fair to say to them? Include relevant facts, limits and responsibility; reassurance alone may not fit.",
            "Try a few words you can stand behind. A fair response can acknowledge a real mistake without turning it into a judgement about your whole self. It does not need to sound especially warm or positive."
          ],
          "fields": [
            [
              "A possible fair response (optional)",
              "response"
            ]
          ]
        },
        {
          "title": "Check whether the response fits",
          "paragraphs": [
            "Consider whether this response is fair and believable for you too. You do not have to repeat it, force yourself to believe it or feel better.",
            "You can revise the words, leave them open, or choose a practical next step."
          ],
          "fields": [
            [
              "What I would revise or do next (optional)",
              "next"
            ]
          ]
        }
      ],
      "finish": [
        "You can leave the response as a possibility rather than a conclusion you must accept.",
        "If useful, notice what was accurate, what remains uncertain and what would help next. You can finish without a new statement or a change in feeling."
      ],
      "optional": {
        "example": {
          "title": "Worked example: accurate criticism without a global judgement",
          "paragraphs": [
            "Ari missed an agreed deadline. The thought is, ‘I'm useless.’ Missing the deadline is observable; ‘useless’ is a judgement about the whole person.",
            "Ari considers: ‘I did miss it, and that matters. I also completed other work. I can acknowledge this and ask what needs attention.’ This keeps responsibility without pretending nothing happened.",
            "Ari still feels disappointed. The useful question is whether the response is fair and helps choose a next step, not whether it removes the feeling."
          ]
        },
        "learn": {
          "title": "A little more about this practice",
          "paragraphs": [
            "This practice examines a particular self-critical statement. It is not a complete self-esteem pathway.",
            "A different perspective is a possibility to check, not automatically more accurate because it is kinder. Keep responsibility for actual actions separate from a judgement about your whole identity."
          ]
        },
        "barriers": {
          "title": "If the practice is hard to use",
          "paragraphs": [
            "A fairer response can be hard to believe. It can acknowledge a real mistake without condemning your whole self.",
            "The voice may reflect a learned rule, a worry, an accurate concern, or something you don't understand yet. This exercise can't determine its origin.",
            "Try words you can stand behind. They don't have to be especially warm or make you feel better."
          ]
        }
      },
      "sourceRoot": "self-talk-guided",
      "privacy": "Optional writing and choices stay in this open practice. In-page Back keeps them. Leaving, reloading, clearing or starting fresh removes them, including hidden fields. My Toolbox saves a shortcut, not your answers. If you explicitly download selected notes or copy text, that copy remains wherever you put it. Private thinking is not reconstructed or exported.",
      "reviewStatus": "Written REVIEW wording; clinical, rights and browser acceptance remain pending."
    },
    "sort-whats-yours-to-carry": {
      "id": "sort-whats-yours-to-carry",
      "route": "tool/sort-whats-yours-to-carry",
      "root": "control-check-guided",
      "savedIdentity": {
        "p": "control-check-guided",
        "c": null
      },
      "title": "Sort What's Yours to Carry",
      "intro": [
        "Separate your own choices, possible influence and circumstances outside your control. A category is not a judgement about whose fault something is or what you must take responsibility for.",
        "Use an ordinary, manageable situation or the fictional example. You can think, speak privately, write, skip or stop. If practical safety or support is needed, you do not have to finish an exercise first."
      ],
      "sections": [
        {
          "title": "Choose one situation",
          "paragraphs": [
            "Use an ordinary situation or Jo's example. What is happening? Separate what you know from what you are guessing.",
            "Choose one part to work through. You do not have to sort your whole life at once."
          ],
          "fields": [
            [
              "The situation (optional)",
              "situation"
            ]
          ]
        },
        {
          "title": "Consider choice, influence and uncertainty",
          "paragraphs": [
            "What action could you choose yourself? What could you influence, while someone else still chooses the result? What depends on other people or circumstances?",
            "You can sort parts privately, use the optional written items below, or leave an item uncertain. A category is your current way of looking at it, not an assessment of blame or duty."
          ],
          "fields": [
            [
              "Items to consider, one per line (optional)",
              "items"
            ]
          ]
        },
        {
          "title": "Include responsibility and limits",
          "paragraphs": [
            "Having a choice or some influence does not make everything your job. Time, energy, access, safety and other people's responsibilities matter too.",
            "What would be useful and reasonable for you here? What support or boundary might help? The aim is a workable view, not a perfect set of categories."
          ],
          "fields": [
            [
              "Limits, responsibilities or support (optional)",
              "limits"
            ]
          ]
        },
        {
          "title": "Consider a possible next step",
          "paragraphs": [
            "You could check a fact, make a request, try a small action, ask for support, rest or decide not to act now. Choose what fits this situation and your limits.",
            "If you want to try something, consider when and what support you might need. You can change the plan. Thinking of an action is not the same as doing it."
          ],
          "fields": [
            [
              "A possible step (optional)",
              "next"
            ],
            [
              "Possible timing or support (optional)",
              "when"
            ]
          ]
        }
      ],
      "finish": [
        "What seems clearer? What is still uncertain? You can keep a possibility, revise it or leave it open.",
        "This is a possible step, not a record of doing it. You can try it, adapt it, seek support or decide not to act now."
      ],
      "optional": {
        "example": {
          "title": "Worked example: choice, influence and limits",
          "paragraphs": [
            "Jo can decide whether to send an application and check its accuracy. Clear information may influence the decision, but Jo can't choose whom the employer hires.",
            "A rejection doesn't prove Jo had no influence or did something wrong. Having influence also doesn't mean every possible effort is Jo's responsibility.",
            "Jo chooses to ask one practical question, then stop revising for today. Another reasonable choice might be to wait, change the plan or seek support."
          ]
        },
        "learn": {
          "title": "A little more about this practice",
          "paragraphs": [
            "Not controlling an outcome doesn't settle every responsibility. You may still choose a boundary, a request, support or no action for now.",
            "Having some influence doesn't make you responsible for every outcome or require action now. Categories can change when you have more information."
          ]
        },
        "barriers": {
          "title": "If the practice is hard to use",
          "paragraphs": [
            "If categories overlap, keep an item uncertain or describe the part you can influence separately from the outcome you cannot choose.",
            "The sort does not have to change how you feel. You can stop or ask for help if it is not useful."
          ]
        }
      },
      "sourceRoot": "control-check-guided",
      "privacy": "Optional writing and choices stay in this open practice. In-page Back keeps them. Leaving, reloading, clearing or starting fresh removes them, including hidden fields. My Toolbox saves a shortcut, not your answers. If you explicitly download selected notes or copy text, that copy remains wherever you put it. Private thinking is not reconstructed or exported.",
      "reviewStatus": "Written REVIEW wording; clinical, rights and browser acceptance remain pending."
    },
    "support-plan": {
      "id": "support-plan",
      "route": "tool/support-plan",
      "root": "support-plan-guided",
      "savedIdentity": {
        "p": "support-plan-guided",
        "c": null
      },
      "title": "Make a support plan",
      "intro": [
        "Work out what kind of support might help, who or where you could turn to, and a next step that feels manageable. You can draft a message without deciding to send it.",
        "This is routine support preparation, not a suicide safety plan.",
        "This tool doesn't contact anyone or monitor your situation. If there's immediate danger, use urgent support rather than waiting to finish a plan. Choose someone or a service that seems appropriate and safe for your circumstances."
      ],
      "sections": [
        {
          "title": "Consider the kind of support",
          "paragraphs": [
            "What kind of support might help most right now? You can choose below, think privately or keep the question open."
          ],
          "fields": []
        },
        {
          "title": "Consider who or where",
          "paragraphs": [
            "Choose someone or a service that seems appropriate and safe for your circumstances. You can keep the person or place privately in mind."
          ],
          "fields": [
            [
              "A possible person or service (optional)",
              "contact"
            ]
          ]
        },
        {
          "title": "Try a manageable next step",
          "paragraphs": [
            "What would feel least overwhelming right now? You can practise a request privately, draft a few words or simply keep a possible contact in mind.",
            "For a request, think about who you are asking, what you would like help with and any timing that matters. A request does not mean the person has agreed."
          ],
          "fields": [
            [
              "What I would want them to know (optional)",
              "message"
            ]
          ]
        },
        {
          "title": "If a contact is unavailable",
          "paragraphs": [
            "If you do not get a reply, consider another suitable contact. If you need urgent help, use urgent support rather than waiting for a reply. This page sets no required wait."
          ],
          "fields": []
        }
      ],
      "finish": [
        "You can finish here without sending a message or having support agreed.",
        "If useful, notice what kind of support might help, what remains unclear, and what next contact step fits. You can keep this private or skip reflecting.",
        "Writing a draft doesn't send it or establish that anyone has agreed to help."
      ],
      "optional": {
        "example": {
          "title": "A fictional example",
          "paragraphs": [
            "Jules wants practical help after a busy week. Jules thinks of a friend and drafts, 'Would you have time to help me collect groceries on Saturday?' Jules decides to check the timing before sending. A draft is a possible next step, not a record of getting help or a promise that the friend can assist."
          ]
        },
        "learn": {
          "title": "A little more about this practice",
          "paragraphs": [
            "Writing a plan records a possibility, not an agreement with another person. You can change it when your needs, circumstances or available support change."
          ]
        },
        "barriers": {
          "title": "If the practice is hard to use",
          "paragraphs": [
            "If no person comes to mind, the next support does not have to be someone you already know. It could be a peer line, a group, a community space or professional support.",
            "You can leave the kind of support uncertain or ask a therapist to help you think through what fits. Urgent support does not require finishing this tool."
          ]
        }
      },
      "sourceRoot": "support-plan-guided",
      "privacy": "Optional writing and choices stay in this open practice. In-page Back keeps them. Leaving, reloading, clearing or starting fresh removes them, including hidden fields. My Toolbox saves a shortcut, not your answers. If you explicitly download selected notes or copy text, that copy remains wherever you put it. Private thinking is not reconstructed or exported. If you choose Open as a letter draft, your written message goes to the existing letter writer, with its separate draft and save controls. Nothing is sent.",
      "kindChoices": [
        {
          "id": "listen",
          "label": "Someone to listen",
          "guidance": [
            "What would you want someone to hear or understand? You can practise saying a few words privately or draft them below."
          ]
        },
        {
          "id": "practical",
          "label": "Practical help",
          "guidance": [
            "Think of a specific kind of practical help you might ask for, such as Jules' grocery request in the example. You can decide later whether to ask."
          ]
        },
        {
          "id": "company",
          "label": "Distraction or company",
          "guidance": [
            "Consider company, a shared activity or a brief check-in that might fit. You do not have to decide or reach out during this practice."
          ]
        },
        {
          "id": "professional",
          "label": "Professional support",
          "guidance": [
            "Professional support doesn't have to be one specific person you already know.",
            "You could start with a service directory, a therapist search, a crisis line if this is urgent, or a professional you already have contact with."
          ]
        },
        {
          "id": "unsure",
          "label": "I'm not sure / keep this open",
          "guidance": [
            "You can leave this open. Consider what is hardest right now and whether listening, practical help, company or professional support might fit."
          ]
        }
      ],
      "contactChoices": [
        {
          "id": "known",
          "label": "Someone I have in mind",
          "guidance": [
            "You can keep this person privately in mind. You do not need to type a name."
          ]
        },
        {
          "id": "service",
          "label": "A professional or service",
          "guidance": [
            "Professional support does not have to be one specific person you already know. Existing support options are available below."
          ]
        },
        {
          "id": "noone",
          "label": "No one comes to mind",
          "guidance": [
            "The next support does not have to be someone you already know. It could be a peer line, a group, a community space or professional support."
          ]
        },
        {
          "id": "open",
          "label": "Keep this open",
          "guidance": [
            "You can continue without naming a contact, or finish here and return later."
          ]
        }
      ],
      "reviewStatus": "Written REVIEW wording; clinical, rights and browser acceptance remain pending.",
      "nextChoices": [
        {
          "id": "request",
          "label": "Practise a short request",
          "guidance": [
            "Try saying the request privately or use the optional message space. You can decide later whether to contact anyone."
          ]
        },
        {
          "id": "draft",
          "label": "Draft words and decide later",
          "guidance": [
            "A draft is not sent or automatically saved. You can change it or leave it here."
          ]
        },
        {
          "id": "name",
          "label": "Keep a possible contact in mind",
          "guidance": [
            "You can finish without writing a message or contacting anyone."
          ]
        },
        {
          "id": "skip",
          "label": "Keep the next step open",
          "guidance": [
            "You can stop or return later. Urgent help does not depend on completing this plan."
          ]
        }
      ]
    }
  }
};
