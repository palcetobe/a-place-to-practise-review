window.WiseMindRetainedContent={
  "title": "Earlier Wise Mind reflection",
  "label": "Earlier Wise Mind reflection (includes chosen-note download)",
  "overview": "Wise Mind means considering your feelings and the facts together as you choose a response. You don't have to feel calm first.",
  "reference": {
    "title": "Three Mind States",
    "paragraphs": [
      "Emotion Mind — feelings are leading your attention and response.\n        Rational Mind — facts and logical analysis are leading your attention.\n        Wise Mind — consider feelings, facts, values and the situation together. Uncertainty can remain."
    ],
    "helpTitle": "Why pure logic isn't always the answer",
    "help": "Feelings can tell you what matters or needs attention. Facts can help you check the situation and possible consequences. This reflection makes room for both; it does not prove which choice is right or require you to get rid of an emotion."
  },
  "reflection": {
    "title": "How to Access It Right Now",
    "steps": [
      "If a pause or grounding helps, you can use it. It is optional.",
      "Ask: What are my emotions telling me?",
      "Ask: What do the facts suggest?",
      "Consider: What response fits both, along with what matters to me?"
    ],
    "note": "A quieter feeling is not proof that an answer is wiser or true. You can consider a response, ask for information or support, or leave the decision open.",
    "helpTitle": "An optional pause",
    "help": "When feelings are strong, a pause may make reflection easier for some people. You can notice something around you, breathe normally, ask for support or return later. Grounding is not a prerequisite, and you do not have to become calm before your feelings and the facts can both matter."
  },
  "try": {
    "title": "Try it now.",
    "intro": "Pause if helpful. You can think, write a few words or leave this open:",
    "question": "What feels true right now?",
    "detail": "What do you notice in your feelings and the facts? What response might fit both?",
    "fieldLabel": "What you notice alongside feelings and facts (optional)",
    "button": "That's what I heard",
    "ack": "You can consider what you noticed alongside the facts and your circumstances. You do not have to reach a conclusion or act now.",
    "privacy": "You can reflect privately instead of writing. Unsaved writing clears when you leave."
  },
  "preservedExample": {
    "id": "wise-guided.reference-morgan",
    "title": "Earlier example: Morgan considers feelings and facts",
    "paragraphs": [
      "Morgan feels hurt when a friend cancels dinner. The feeling matters: Morgan wanted time together. The known facts are that the friend cancelled and said they were ill. Morgan does not know whether anything else is going on.",
      "Emotion alone urges Morgan to send, 'You never care.' Facts alone could lead Morgan to ignore the hurt. Morgan considers both: 'I'm disappointed. I hope you feel better. Could we pick another day?' Morgan can also wait before replying.",
      "This response does not prove the friend's reason or guarantee a new plan. Wise Mind means considering feelings and facts together, along with what matters and the situation. Feeling calm is not a test of whether the answer is wise."
    ]
  },
  "sourceReference": {
    "originalHref": "review-sources.html#wise-mind",
    "href": null, "availability": "Older external reference withheld from this written REVIEW build; not verified as equivalent.",
    "label": "Original sources and scope"
  },
  "originalDestinations": [
    {
      "label": "Original Wise Mind overview",
      "href": null, "availability": "Older external reference withheld from this written REVIEW build; not verified as equivalent."
    },
    {
      "label": "Original Three Mind States reference",
      "href": null, "availability": "Older external reference withheld from this written REVIEW build; not verified as equivalent."
    }
  ],
  "exportFilename": "chosen-reflection-notes.txt"
};
