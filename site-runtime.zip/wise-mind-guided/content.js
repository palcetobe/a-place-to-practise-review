window.WiseMindGuidedContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Frozen authored scripts only until exact asset, perceptual listening and integration gates pass. No personal words in audio. Existing audio assets do not imply these new words are voiced.",
    "timer": "No timer. The actual voluntary pause is user-paced; no automatic advance, success state or required duration.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show optional fictional practice before prompts and keep available contextually. Do not prefill or evaluate private words. Reading the example is not marked as actual practice.",
    "preservedReference": "Show preservedExample within Learn more as an optional labelled earlier example, separately from the new See an example practice continuation. No auto-opening extra readings.",
    "context": "Keep the optional Morgan scenario reachable beside every prompt. Show all reveals all four prompts; no fields or ratings required. Notes remain literal and hidden when writing is hidden. No inferred wise answer or evaluation.",
    "retainedReflection": {
      "placement": "Optional link within Learn more, not an extra required step.",
      "label": "Open the earlier Wise Mind reflection",
      "behavior": "Preserve the recovered reflection and its effective blank-allowed acknowledgement, chosen-note export and clearing behavior in a labelled retained view. Keep original reference links available. Do not import the raw writing-gated fragment without nested-privacy-repairs behavior.",
      "noteIsolation": "Guided-practice notes and earlier-reflection notes are separate. No automatic transfer, prefill or reclassification. Explain and confirm clearing when leaving a tool view with notes, using the established host privacy behavior.",
      "export": "Earlier reflection retains explicit selected-note preview/export with nothing preselected. New guided practice may keep current no-export session-only policy; make that difference visible in each view.",
      "identity": "Release auditor determines whether the existing tool route opens the upgraded guided entry with a retained-view link or requires an isolated provisional route. Do not invent a public alias, overwrite saved-ID role or count another canonical skill."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/mindful",
  "componentId": "component/mindful/wise-mind",
  "resourceId": "tool/wise-mind",
  "routeProposal": "tool/wise-mind",
  "title": "Wise Mind",
  "subtitle": "Bring feelings and reason into one considered response",
  "version": "2026-11-03-guided-wise-mind-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "One guided Wise Mind question-and-listening practice within DBT Mindfulness Skills. New original adaptation, not a recovered complete practice or the whole mindfulness curriculum.",
  "clinicalContract": {
    "learningObjective": "Distinguish Emotion Mind, Reasonable Mind and Wise Mind without ranking people or treating an emotion as false. Explain why an inner answer still needs context and real-world information.",
    "practiceObjective": "For an ordinary therapist-introduced situation, notice emotional and reasonable perspectives, ask a concise question, pause to listen without forcing an answer, and consider any response or uncertainty.",
    "observedPractice": "Optional mental, spoken-off-device or written participation. No inference of practice from reading, navigation, notes or calm.",
    "sourcePopulationContext": "This guided practice was initially designed for therapist-supported adults. That earlier product scope is not a source-established minimum age. The cited DBT teaching materials do not validate this digital adaptation or establish suitability across ages. Therapist selection and adaptation should account for development, communication, consent, privacy, safeguarding and circumstances."
  },
  "intro": {
    "id": "wise-guided.intro",
    "title": "Make room for both",
    "paragraphs": [
      "Strong feelings can pull toward one response. Reason alone can overlook what matters emotionally. Wise Mind is the DBT idea of bringing these ways of knowing together.",
      "Here you can try asking a question and giving yourself room to listen. You do not need to discover a perfect answer or feel calm."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "wise-guided.fit",
    "title": "Use an ordinary, manageable situation",
    "paragraphs": [
      "Use this guided practice after your therapist has introduced the skill. Choose a small everyday situation, or practise with Morgan’s fictional situation instead.",
      "Attend to immediate safety, health needs or urgent responsibilities first. This reflection cannot decide whether a situation is safe, establish another person’s intentions or replace professional advice.",
      "You may keep your eyes open and breathe normally without focusing on your body. If looking inward increases distress or disconnection, stop, notice your surroundings if useful, and use your agreed support."
    ]
  },
  "learn": {
    "id": "wise-guided.learn",
    "title": "Why practise Wise Mind?",
    "paragraphs": [
      "Emotion Mind describes a moment when feelings and urges lead. Reasonable Mind describes a moment when facts, logic and practical considerations lead. Each can offer useful information; either alone can leave something out.",
      "Wise Mind brings emotional experience and reason together with your understanding of the situation. It is not splitting the difference, suppressing emotion, or proving that an instinct is right.",
      "The practice gives you a chance to notice before responding. A thought that appears during a pause is something to consider, not an instruction you must follow. No particular feeling proves that you have found Wise Mind."
    ]
  },
  "preservedExample": {
    "id": "wise-guided.reference-morgan",
    "title": "Earlier example: Morgan considers feelings and facts",
    "paragraphs": [
      "Morgan feels hurt when a friend cancels dinner. The feeling matters: Morgan wanted time together. The known facts are that the friend cancelled and said they were ill. Morgan does not know whether anything else is going on.",
      "Emotion alone urges Morgan to send, 'You never care.' Facts alone could lead Morgan to ignore the hurt. Morgan considers both: 'I'm disappointed. I hope you feel better. Could we pick another day?' Morgan can also wait before replying.",
      "This response does not prove the friend's reason or guarantee a new plan. Wise Mind means considering feelings and facts together, along with what matters and the situation. Feeling calm is not a test of whether the answer is wise."
    ]
  },
  "example": {
    "id": "wise-guided.example",
    "title": "Morgan tries the guided practice",
    "paragraphs": [
      "This is a new practice continuation of the earlier fictional Morgan example. The earlier example remains available unchanged.",
      "Morgan notices hurt and the urge to send an accusation. Morgan also recognises the cancellation and stated illness as known information, while the friend’s other motives are unknown. Connection and honest communication matter to Morgan.",
      "Morgan asks privately, ‘How can I respond while making room for my hurt and what I actually know?’ Morgan pauses without composing a reply for a moment. The accusation comes back; Morgan notices it without treating it as the answer.",
      "After listening, Morgan considers, ‘I’m disappointed. I hope you feel better. Could we pick another day?’ Morgan checks that this names the hurt without claiming to know the friend’s motives. Morgan quietly rehearses the sentence, then chooses not to send anything yet.",
      "The hurt remains. Morgan notices that a less accusatory response is available, but there is still uncertainty. Morgan finishes the practice; no reply from the friend or calmer feeling is needed. If no response had emerged, leaving the question open would also have been an option."
    ]
  },
  "practiceScenario": {
    "id": "wise-guided.scenario",
    "title": "You can practise with Morgan",
    "paragraphs": [
      "A friend cancelled dinner and said they were ill. Morgan feels hurt, wants connection and is tempted to send an accusation. Other reasons for the cancellation are unknown.",
      "If personal reflection does not fit, use this situation to notice the two perspectives and try the question-and-listening practice yourself. You do not have to disclose anything or contact anyone."
    ]
  },
  "practice": [
    {
      "id": "wise-guided.practice.notice",
      "title": "Notice the two perspectives",
      "paragraphs": [
        "Bring to mind one manageable everyday situation. What feeling or urge is present? What would acting only from that urge look like?",
        "Now notice what you actually know and the practical considerations. What might reason alone suggest? Include unknowns rather than guessing. Neither perspective has to be rejected."
      ],
      "fields": [
        {
          "key": "notice",
          "label": "Feelings, facts and unknowns, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot name a state",
        "text": "You can describe a feeling, urge or known detail without choosing a label. These are ways attention can work, not personality types or diagnoses."
      }
    },
    {
      "id": "wise-guided.practice.ask",
      "title": "Ask, then give yourself room to listen",
      "paragraphs": [
        "Ask yourself one small question: “What response could make room for my feelings and the facts here?” You can use different words that fit.",
        "Try the question now, mentally or quietly off-device. Pause for a moment without deliberately supplying the answer you think you should give. Notice what, if anything, comes to mind. There is no required length, posture or breathing pattern.",
        "If thoughts keep moving, you can acknowledge that and return to the question once if useful, or stop. You do not need to repeat it until you feel certain."
      ],
      "fields": [
        {
          "key": "ask",
          "label": "My question or what I noticed, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If no answer comes",
        "text": "An unanswered question is allowed. You can leave it open and return with your therapist. Do not invent an answer, wait indefinitely or use repeated checking to force certainty."
      }
    },
    {
      "id": "wise-guided.practice.consider",
      "title": "Consider what emerged",
      "paragraphs": [
        "If a response came to mind, consider it alongside your emotional experience, known facts, unknowns, values and the actual situation. Does it leave out something important?",
        "You can privately rehearse a sentence or imagine the response briefly. This is consideration, not a commitment to act. You may revise it, seek information or support, or leave the decision open."
      ],
      "fields": [
        {
          "key": "consider",
          "label": "A response or an open question, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If the answer feels very certain",
        "text": "Certainty, relief or a strong bodily feeling does not establish truth or safety. Check what is known and what remains uncertain. You do not have to act on an inner response."
      }
    },
    {
      "id": "wise-guided.practice.review",
      "title": "Notice the process, then finish",
      "paragraphs": [
        "Did you make room for both emotional experience and reason? What happened when you asked and listened, even if nothing clear emerged?",
        "You may finish with the same feeling and an unresolved question. No message, action plan or extra exercise is required."
      ],
      "fields": [
        {
          "key": "review",
          "label": "Something I noticed, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you read or stopped instead",
        "text": "Reading, trying and stopping are different choices. There is no completion score. You can discuss what did or did not fit with your therapist."
      }
    }
  ],
  "privacy": {
    "id": "wise-guided.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, speak off-device, use paper or write here. Notes stay in this open tool; no microphone is used. Learn more, examples and Back keep your notes.",
      "Leaving this tool, reloading, clearing or starting again removes notes. Nothing is sent to your therapist or used for narration. The page is not monitored."
    ]
  },
  "close": {
    "id": "wise-guided.close",
    "title": "You can leave the question open",
    "paragraphs": [
      "You do not need certainty, calm or an action to finish. Keep what was useful in mind, or leave it here for now."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "id": "linehan-handouts",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Mindfulness Handouts3 and3a: three states and several optional Wise Mind practices. No worksheet or diagram copied."
    },
    {
      "id": "linehan-manual",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Teaching notes for Handouts3/3a: experiential practice, asking/listening and allowing no answer. Source supports broader clinician-led teaching, not effectiveness of this app."
    }
  ],
  "productAdaptations": [
    "Original short question-and-listening adaptation. Source exercises often pair asking/listening with breathing; this version offers ordinary breathing without breath synchronisation or body focus. This accessibility adaptation is explicit, not a claim of verbatim protocol equivalence.",
    "Additional brief emotional/factual preparation and real-world review preserve uncertainty and context. No timer or fixed dose.",
    "New Morgan practice continuation is clearly distinguished from earlier example. New script IDs do not overwrite older recordings.",
    "Therapist-introduced guided component; no claim of validation for every age or a complete DBT mindfulness curriculum."
  ],
  "narrationSegments": [
    {
      "id": "wise-guided.intro",
      "title": "Make room for both",
      "text": "Strong feelings can pull toward one response. Reason alone can overlook what matters emotionally. Wise Mind is the DBT idea of bringing these ways of knowing together.\n\nHere you can try asking a question and giving yourself room to listen. You do not need to discover a perfect answer or feel calm.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "9b2d7cf5a2a3460e57d4680b682d61c2b94e6bc1f7ff9b1f42e07e0a426cea88"
    },
    {
      "id": "wise-guided.fit",
      "title": "Use an ordinary, manageable situation",
      "text": "Use this guided practice after your therapist has introduced the skill. Choose a small everyday situation, or practise with Morgan’s fictional situation instead.\n\nAttend to immediate safety, health needs or urgent responsibilities first. This reflection cannot decide whether a situation is safe, establish another person’s intentions or replace professional advice.\n\nYou may keep your eyes open and breathe normally without focusing on your body. If looking inward increases distress or disconnection, stop, notice your surroundings if useful, and use your agreed support.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "dcaca718ac9d94e8df15cd9d1f58694b46ae9e14a4e81bed3ec952fe467fb130"
    },
    {
      "id": "wise-guided.learn",
      "title": "Why practise Wise Mind?",
      "text": "Emotion Mind describes a moment when feelings and urges lead. Reasonable Mind describes a moment when facts, logic and practical considerations lead. Each can offer useful information; either alone can leave something out.\n\nWise Mind brings emotional experience and reason together with your understanding of the situation. It is not splitting the difference, suppressing emotion, or proving that an instinct is right.\n\nThe practice gives you a chance to notice before responding. A thought that appears during a pause is something to consider, not an instruction you must follow. No particular feeling proves that you have found Wise Mind.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "0bc22206da5cddc57480a37d3600163848c2bdc16148545f0dae37e28f2ba49c"
    },
    {
      "id": "wise-guided.example",
      "title": "Morgan tries the guided practice",
      "text": "This is a new practice continuation of the earlier fictional Morgan example. The earlier example remains available unchanged.\n\nMorgan notices hurt and the urge to send an accusation. Morgan also recognises the cancellation and stated illness as known information, while the friend’s other motives are unknown. Connection and honest communication matter to Morgan.\n\nMorgan asks privately, ‘How can I respond while making room for my hurt and what I actually know?’ Morgan pauses without composing a reply for a moment. The accusation comes back; Morgan notices it without treating it as the answer.\n\nAfter listening, Morgan considers, ‘I’m disappointed. I hope you feel better. Could we pick another day?’ Morgan checks that this names the hurt without claiming to know the friend’s motives. Morgan quietly rehearses the sentence, then chooses not to send anything yet.\n\nThe hurt remains. Morgan notices that a less accusatory response is available, but there is still uncertainty. Morgan finishes the practice; no reply from the friend or calmer feeling is needed. If no response had emerged, leaving the question open would also have been an option.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "b9b6f1edba9b897a50606be444a88198c23d396047fbae06de1d1c8c28e78f7d"
    },
    {
      "id": "wise-guided.scenario",
      "title": "You can practise with Morgan",
      "text": "A friend cancelled dinner and said they were ill. Morgan feels hurt, wants connection and is tempted to send an accusation. Other reasons for the cancellation are unknown.\n\nIf personal reflection does not fit, use this situation to notice the two perspectives and try the question-and-listening practice yourself. You do not have to disclose anything or contact anyone.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "f229096b7414ee203339ee15f72e9b348add01674df4924c23931d1f940f9883"
    },
    {
      "id": "wise-guided.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, speak off-device, use paper or write here. Notes stay in this open tool; no microphone is used. Learn more, examples and Back keep your notes.\n\nLeaving this tool, reloading, clearing or starting again removes notes. Nothing is sent to your therapist or used for narration. The page is not monitored.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "2d843cd661cfedad40e687c0939c53f6be384703d5308a82c7beab735cc03ba0"
    },
    {
      "id": "wise-guided.close",
      "title": "You can leave the question open",
      "text": "You do not need certainty, calm or an action to finish. Keep what was useful in mind, or leave it here for now.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "d123436a246625779947e1e88968ba7c784f27df26a8dfd4d4d1299e592d56ea"
    },
    {
      "id": "wise-guided.practice.notice",
      "title": "Notice the two perspectives",
      "text": "Bring to mind one manageable everyday situation. What feeling or urge is present? What would acting only from that urge look like?\n\nNow notice what you actually know and the practical considerations. What might reason alone suggest? Include unknowns rather than guessing. Neither perspective has to be rejected.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "b4778ffe13d8eb593603b5861a855fcbd7d647eca66c06b3606f5c69179cacbb"
    },
    {
      "id": "wise-guided.practice.notice.help",
      "title": "If you cannot name a state",
      "text": "You can describe a feeling, urge or known detail without choosing a label. These are ways attention can work, not personality types or diagnoses.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "5bb402cb136fba9d2df353e2f7099f0d58a37eaf160f0fa207ad62b45b0c9b87"
    },
    {
      "id": "wise-guided.practice.ask",
      "title": "Ask, then give yourself room to listen",
      "text": "Ask yourself one small question: “What response could make room for my feelings and the facts here?” You can use different words that fit.\n\nTry the question now, mentally or quietly off-device. Pause for a moment without deliberately supplying the answer you think you should give. Notice what, if anything, comes to mind. There is no required length, posture or breathing pattern.\n\nIf thoughts keep moving, you can acknowledge that and return to the question once if useful, or stop. You do not need to repeat it until you feel certain.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "b9969146a95efc6806a3bcc66c11bbc95fd4b43fccd39188c5107d08d788350c"
    },
    {
      "id": "wise-guided.practice.ask.help",
      "title": "If no answer comes",
      "text": "An unanswered question is allowed. You can leave it open and return with your therapist. Do not invent an answer, wait indefinitely or use repeated checking to force certainty.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "d582d9c397cc5803b3aad3ac803d9b5d3498654130c750300d857c7978652a77"
    },
    {
      "id": "wise-guided.practice.consider",
      "title": "Consider what emerged",
      "text": "If a response came to mind, consider it alongside your emotional experience, known facts, unknowns, values and the actual situation. Does it leave out something important?\n\nYou can privately rehearse a sentence or imagine the response briefly. This is consideration, not a commitment to act. You may revise it, seek information or support, or leave the decision open.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "c6572d161d7706cfe0297984c72cc9ab570016e91dfb2e373f37714fa5aad0ee"
    },
    {
      "id": "wise-guided.practice.consider.help",
      "title": "If the answer feels very certain",
      "text": "Certainty, relief or a strong bodily feeling does not establish truth or safety. Check what is known and what remains uncertain. You do not have to act on an inner response.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "e7bf93700157a4c6cd0952a97b991002bf462c860780e33a1b51cdc5134ce6b2"
    },
    {
      "id": "wise-guided.practice.review",
      "title": "Notice the process, then finish",
      "text": "Did you make room for both emotional experience and reason? What happened when you asked and listened, even if nothing clear emerged?\n\nYou may finish with the same feeling and an unresolved question. No message, action plan or extra exercise is required.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "654f873303a0a3f74e8468201d907a44f14d841cf596918b5d8c149fc337cb56"
    },
    {
      "id": "wise-guided.practice.review.help",
      "title": "If you read or stopped instead",
      "text": "Reading, trying and stopping are different choices. There is no completion score. You can discuss what did or did not fit with your therapist.",
      "status": "Script only; not generated, listened or active",
      "textSha256": "874742313b4716f3b5073ef2365e141069cca94f65830c6e06d602b59ac463d5"
    }
  ]
}
;
