window.EmotionSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "facts.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "contextReview": {
      "placement": "interpretation/threat/review prompts",
      "fields": [
        "emotion",
        "event",
        "interpretation",
        "information",
        "outcome",
        "coping"
      ],
      "behavior": "Keep a compact optional read-only context view adjacent so the person can compare their account without repeated Back. Show only entered text and only when writing is shown; empty entries are not inferred. Hide every echo when writing is hidden; clear with tool notes. Never narrate private text."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/facts",
  "title": "Check the Facts",
  "subtitle": "Separate what is known from what is assumed",
  "scope": "A bounded DBT-informed check of one ordinary emotional interpretation; not proof of safety, a diagnostic assessment or a requirement to change an emotion.",
  "version": "2026-11-02-emotion-batch-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish an observed or reported event, an interpretation, an uncertain prediction and the fit of an emotion or its intensity.",
    "practiceObjective": "Review one manageable situation, consider what supports or remains unknown about its meaning, and form an updated account of emotion fit and an appropriate response without forcing a reassuring conclusion.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.guilford.com/books/DBT-Skills-Training-Manual/Marsha-Linehan/9781462556359/contents",
      "reviewed": "2026-11-02",
      "supports": "Current 2025 revised edition and module scope confirmed from publisher.",
      "limits": "Public contents are not exact procedure text; no assertion of equivalence to unavailable revised teaching notes."
    },
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-02",
      "supports": "Emotion Regulation handouts 8 and 8a: event, interpretations, threat/coping and emotion fit; original bounded adaptation.",
      "limits": "Original app language only. Restricted reproduction licence; no copied handouts or complete DBT/effectiveness claim."
    }
  ],
  "resourceId": "tool/check-the-facts",
  "routeProposal": "tool/check-the-facts",
  "intro": {
    "id": "facts.intro",
    "title": "Check the account, not your right to feel",
    "paragraphs": [
      "An emotion can be understandable while some details or predictions remain uncertain. This practice looks at what happened, what you are adding to it, and how the emotion and its strength fit what is known.",
      "You do not have to prove your feeling wrong. Use an ordinary situation discussed with your therapist or the fictional example. Writing and number ratings are not needed."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "facts.fit",
    "title": "Use a situation that fits",
    "paragraphs": [
      "Use this with your therapist between sessions. Choose a manageable current situation, not a detailed traumatic memory or a dispute this page must settle.",
      "Do not use this to dismiss danger, discrimination, coercion or mistreatment, or to delay medical or urgent help. Your own account matters; a missing witness does not make it false. If safety or key information is unclear, keep that uncertainty and seek appropriate support.",
      "If checking becomes repetitive reassurance-seeking or makes you more distressed, pause and discuss the pattern with your therapist. One bounded review is enough for this page."
    ]
  },
  "learn": {
    "id": "facts.learn",
    "title": "Why check the facts?",
    "paragraphs": [
      "The meaning we give an event can influence emotion, and emotion can influence what we notice. Separating information from interpretation can make the account more accurate, not necessarily more comforting.",
      "Check the event, your interpretation and any predicted threat. Consider a plausible alternative without treating it as a new fact. Then review whether the type, strength or duration of the emotion fits the information you have.",
      "An emotion may fit and a practical response may be needed. It may partly fit, or the answer may remain uncertain. This is different from merely naming an emotion or trying to replace it with a positive thought."
    ]
  },
  "example": {
    "id": "facts.example",
    "title": "Example — a short reply",
    "paragraphs": [
      "Taylor receives “Can’t talk now” from a friend after asking an ordinary question. Taylor feels hurt and strongly worried, with the prediction “Our friendship is over.” The known event is the message; the friend’s reason is not known.",
      "Taylor notes that the reply could reflect being busy or being upset. Neither explanation is established. There has been no statement ending the friendship. Taylor can acknowledge the possibility of a difficult conversation without treating it as certain; support would be available if that happened.",
      "Taylor revises the account: “I wanted contact and feel disappointed. I don’t yet know why the reply was short; it does not establish that the friendship is over.” Taylor judges disappointment about missed contact understandable, while the strength of fear that the friendship is ending goes beyond what this message establishes. That comparison does not make the feeling illegitimate, and hurt remains. Taylor decides no immediate action is needed and can ask an ordinary question later if useful, rather than repeatedly rechecking the message."
    ]
  },
  "practiceScenario": {
    "id": "facts.scenario",
    "title": "Optional fictional practice — Jules",
    "paragraphs": [
      "Jules sees that an ordinary group meeting has been moved to another day. Jules thinks, “They changed it because they don’t want me there,” and feels hurt. The notice gives a new time but no reason.",
      "Work with what the story says. Do not invent reassurance or a hidden motive. You can use Jules, your own manageable example, or just read."
    ]
  },
  "practice": [
    {
      "id": "facts.practice.event",
      "title": "Name the emotion and describe the event",
      "paragraphs": [
        "What emotion are you considering, and what happened? Describe what you observed, remember or were told, distinguishing those sources where useful.",
        "How strong or persistent does the feeling seem in your own words? A number is optional, not required."
      ],
      "fields": [
        {
          "key": "emotion",
          "label": "Emotion and strength, if useful",
          "optional": true
        },
        {
          "key": "event",
          "label": "What happened or was reported",
          "optional": true
        }
      ],
      "help": {
        "title": "If details are uncertain",
        "text": "Write or think “I remember…” or “I was told…” rather than forcing certainty. Uncertainty does not erase your experience."
      }
    },
    {
      "id": "facts.practice.interpretation",
      "title": "Separate information from meaning",
      "paragraphs": [
        "What conclusion or prediction are you making? What information supports it, and what information is missing or points another way?",
        "Consider a plausible alternative only if one fits the situation. You do not have to supply an innocent explanation for harm."
      ],
      "fields": [
        {
          "key": "interpretation",
          "label": "My interpretation or prediction",
          "optional": true
        },
        {
          "key": "information",
          "label": "What supports it, differs, or is unknown",
          "optional": true
        }
      ],
      "help": {
        "title": "For Jules’s example",
        "text": "The time changed; the reason is unknown. Scheduling difficulty is possible, but not established. Exclusion is also an interpretation, not something the notice itself proves."
      }
    },
    {
      "id": "facts.practice.threat",
      "title": "Check the feared outcome, if relevant",
      "paragraphs": [
        "If you are predicting something threatening, what is the outcome you fear, and how likely does the available information make it? “I cannot tell” is an acceptable answer.",
        "Without dwelling on or imagining a catastrophe, consider what support or coping could be available if a manageable feared outcome happened. Skip this if it is not relevant. Real danger calls for protection or support, not reassurance from this page."
      ],
      "fields": [
        {
          "key": "outcome",
          "label": "Feared outcome and what is known, if relevant",
          "optional": true
        },
        {
          "key": "coping",
          "label": "Possible support or coping, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If this opens a chain of what-ifs",
        "text": "Stop expanding the story. Return to the information you have, or leave the review for your therapist. This is not an uncertainty-removal exercise."
      }
    },
    {
      "id": "facts.practice.review",
      "title": "Review emotion fit and your account",
      "paragraphs": [
        "Given what is known, does the emotion fit, partly fit, seem stronger or more persistent than the information supports, or remain unclear? This is a question, not a verdict that your feeling is wrong.",
        "Form a brief updated account that keeps the facts and honest uncertainty. Consider whether any support or practical response is needed; no action plan is required and you do not need another tool to finish."
      ],
      "fields": [
        {
          "key": "account",
          "label": "My updated account or unresolved question",
          "optional": true
        }
      ],
      "help": {
        "title": "If the facts support the feeling",
        "text": "You do not need to talk yourself out of it. Acknowledge the situation and consider what support, boundary or practical response fits."
      }
    }
  ],
  "close": {
    "id": "facts.close",
    "title": "An honest account is enough",
    "paragraphs": [
      "You can finish with a changed interpretation, confirmation of a real concern, or uncertainty. Feeling better is not the test, and repeated checking is not required."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "Short focused review instead of reproduced worksheet; no obligatory numeric intensity, exhaustive alternatives or catastrophe imagery. Threat/coping is conditional and manageable.",
    "Original Taylor/Jules cases; no fact classifier or automated clinical conclusion."
  ],
  "narrationSegments": [
    {
      "id": "facts.intro",
      "title": "Check the account, not your right to feel",
      "text": "An emotion can be understandable while some details or predictions remain uncertain. This practice looks at what happened, what you are adding to it, and how the emotion and its strength fit what is known.\n\nYou do not have to prove your feeling wrong. Use an ordinary situation discussed with your therapist or the fictional example. Writing and number ratings are not needed.",
      "status": "Script only"
    },
    {
      "id": "facts.fit",
      "title": "Use a situation that fits",
      "text": "Use this with your therapist between sessions. Choose a manageable current situation, not a detailed traumatic memory or a dispute this page must settle.\n\nDo not use this to dismiss danger, discrimination, coercion or mistreatment, or to delay medical or urgent help. Your own account matters; a missing witness does not make it false. If safety or key information is unclear, keep that uncertainty and seek appropriate support.\n\nIf checking becomes repetitive reassurance-seeking or makes you more distressed, pause and discuss the pattern with your therapist. One bounded review is enough for this page.",
      "status": "Script only"
    },
    {
      "id": "facts.learn",
      "title": "Why check the facts?",
      "text": "The meaning we give an event can influence emotion, and emotion can influence what we notice. Separating information from interpretation can make the account more accurate, not necessarily more comforting.\n\nCheck the event, your interpretation and any predicted threat. Consider a plausible alternative without treating it as a new fact. Then review whether the type, strength or duration of the emotion fits the information you have.\n\nAn emotion may fit and a practical response may be needed. It may partly fit, or the answer may remain uncertain. This is different from merely naming an emotion or trying to replace it with a positive thought.",
      "status": "Script only"
    },
    {
      "id": "facts.example",
      "title": "Example — a short reply",
      "text": "Taylor receives “Can’t talk now” from a friend after asking an ordinary question. Taylor feels hurt and strongly worried, with the prediction “Our friendship is over.” The known event is the message; the friend’s reason is not known.\n\nTaylor notes that the reply could reflect being busy or being upset. Neither explanation is established. There has been no statement ending the friendship. Taylor can acknowledge the possibility of a difficult conversation without treating it as certain; support would be available if that happened.\n\nTaylor revises the account: “I wanted contact and feel disappointed. I don’t yet know why the reply was short; it does not establish that the friendship is over.” Taylor judges disappointment about missed contact understandable, while the strength of fear that the friendship is ending goes beyond what this message establishes. That comparison does not make the feeling illegitimate, and hurt remains. Taylor decides no immediate action is needed and can ask an ordinary question later if useful, rather than repeatedly rechecking the message.",
      "status": "Script only"
    },
    {
      "id": "facts.scenario",
      "title": "Optional fictional practice — Jules",
      "text": "Jules sees that an ordinary group meeting has been moved to another day. Jules thinks, “They changed it because they don’t want me there,” and feels hurt. The notice gives a new time but no reason.\n\nWork with what the story says. Do not invent reassurance or a hidden motive. You can use Jules, your own manageable example, or just read.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.event",
      "title": "Name the emotion and describe the event",
      "text": "What emotion are you considering, and what happened? Describe what you observed, remember or were told, distinguishing those sources where useful.\n\nHow strong or persistent does the feeling seem in your own words? A number is optional, not required.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.event.help",
      "title": "If details are uncertain",
      "text": "Write or think “I remember…” or “I was told…” rather than forcing certainty. Uncertainty does not erase your experience.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.interpretation",
      "title": "Separate information from meaning",
      "text": "What conclusion or prediction are you making? What information supports it, and what information is missing or points another way?\n\nConsider a plausible alternative only if one fits the situation. You do not have to supply an innocent explanation for harm.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.interpretation.help",
      "title": "For Jules’s example",
      "text": "The time changed; the reason is unknown. Scheduling difficulty is possible, but not established. Exclusion is also an interpretation, not something the notice itself proves.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.threat",
      "title": "Check the feared outcome, if relevant",
      "text": "If you are predicting something threatening, what is the outcome you fear, and how likely does the available information make it? “I cannot tell” is an acceptable answer.\n\nWithout dwelling on or imagining a catastrophe, consider what support or coping could be available if a manageable feared outcome happened. Skip this if it is not relevant. Real danger calls for protection or support, not reassurance from this page.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.threat.help",
      "title": "If this opens a chain of what-ifs",
      "text": "Stop expanding the story. Return to the information you have, or leave the review for your therapist. This is not an uncertainty-removal exercise.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.review",
      "title": "Review emotion fit and your account",
      "text": "Given what is known, does the emotion fit, partly fit, seem stronger or more persistent than the information supports, or remain unclear? This is a question, not a verdict that your feeling is wrong.\n\nForm a brief updated account that keeps the facts and honest uncertainty. Consider whether any support or practical response is needed; no action plan is required and you do not need another tool to finish.",
      "status": "Script only"
    },
    {
      "id": "facts.practice.review.help",
      "title": "If the facts support the feeling",
      "text": "You do not need to talk yourself out of it. Acknowledge the situation and consider what support, boundary or practical response fits.",
      "status": "Script only"
    },
    {
      "id": "facts.close",
      "title": "An honest account is enough",
      "text": "You can finish with a changed interpretation, confirmation of a real concern, or uncertainty. Feeling better is not the test, and repeated checking is not required.",
      "status": "Script only"
    },
    {
      "id": "facts.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    }
  ]
}
;
