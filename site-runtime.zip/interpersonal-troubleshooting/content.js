window.InterpersonalTroubleshootingContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/dear",
  "componentId": "component/dear/troubleshooting-interpersonal-effectiveness",
  "resourceId": "tool/dearman",
  "routeProposal": null,
  "reviewHarnessRoute": "/interpersonal-troubleshooting/",
  "title": "Troubleshooting Interpersonal Effectiveness",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Explore what made an ordinary conversation or attempt hard, match an adjustment to that barrier, and review what it changed or left unresolved.",
  "groupedSetStatus": "Existing uncounted component under classic/dear, shared follow-through for DEAR MAN, GIVE and FAST. No new resource identity, complete communication method or canonical count. Review harness only; no proposed public route.",
  "integrationContract": {
    "placement": "Shared optional troubleshooting within existing communication resources, not a competing standalone tool.",
    "existingResourceIds": [
      "tool/dearman",
      "tool/give",
      "tool/fast"
    ],
    "canonicalCountDelta": 0,
    "publicRouteProposed": false,
    "linkedPracticeBehavior": "No automatic selection, navigation to another method, note transfer, diagnosis or completion inference."
  },
  "clinicalContract": {
    "learningObjective": "Distinguish six possible barriers: skill knowledge/use, unclear aims, short-term versus longer-term goals, emotion-related interference, worries/assumptions, and environmental power or limits; consider other explanations and pair a provisional finding with a suitable response.",
    "practiceObjective": "Choose one ordinary episode or fictional scene, compare actual behavior and outcomes, check the six domains with free access to context/safety first, identify a supported barrier or uncertainty, choose and actually rehearse an adjustment, and review later use or non-use without blaming the person for another person’s response.",
    "sourcePopulationContext": "2015 author/publisher DBT teaching establishes the component, not efficacy of this digital adaptation or latest-edition equivalence. No age floor. Therapist checks clinical, developmental, cultural, communication, safeguarding and access fit.",
    "exclusions": [
      "No diagnosis, inferred barrier, universal forcefulness score, Dime Game or automatic skill prescription",
      "No unsafe confrontation, compelled disclosure, pressure after refusal, approval guarantee or duty to preserve a harmful relationship",
      "No treating tears, disability, access needs or reasonable fear as proof of poor skills",
      "No unsupervised TIP, exposure, opposite action, crisis treatment or advice to accept abuse",
      "No copied worksheet, mandatory ratings, persistent notes, monitoring or therapist report"
    ],
    "adaptations": [
      "Original plain-language teaching, low-stakes example and optional notes, not reproduced source form or examples",
      "Six source domains retain conditional barrier-to-adjustment reasoning; no forced yes/no ladder, success score or mandatory retrial",
      "Context and safety may be checked before personal skill factors; several factors may coexist and unknowns may remain",
      "Related methods are prerequisites or clinician-selected referrals, not reduced to one-line treatment instructions",
      "Accessible private thought, speech, signing, communication aids or supported rehearsal; no required mirror, gaze, stillness or writing",
      "Review distinguishes reading, practice, actual conversation, no opportunity and non-use; an unchanged external result is not proof of failure"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of the complete bounded troubleshooting component and shared placement; source-use rights",
      "Individual clinical, developmental, cultural, communication, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not a validated reading level",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration generation and listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose exploring or reviewing",
      "options": [
        {
          "value": "prepare",
          "label": "Explore a difficulty",
          "startSectionId": "interpersonal-troubleshooting.practice.situation"
        },
        {
          "value": "review",
          "label": "Review an adjustment",
          "startSectionId": "interpersonal-troubleshooting.practice.review"
        }
      ]
    },
    "entryGate": "Scope and safety visible before selection. No situation or contact approved by this page.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence or writing.",
    "reviewAccess": "Direct blank review without a stored plan, inferred attempt or result. Both modes expose all groups.",
    "writing": "Optional and hidden initially. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording upload or autoplay.",
    "timer": "None. No contact deadline, required duration, exposure ladder or repetition count.",
    "completion": "No inferred barrier, diagnosis, adjustment, rehearsal, contact, safety, agreement or improvement."
  },
  "intro": {
    "id": "interpersonal-troubleshooting.intro",
    "title": "Find what needs a different approach",
    "paragraphs": [
      "Sometimes you use a conversation skill and still do not get the result you hoped for. Sometimes you get stuck before you can use it. Troubleshooting means looking at what got in the way and choosing a change that fits.",
      "This practice adds to DEAR MAN, GIVE and FAST. Use it with conversation skills your therapist has taught you. It looks at six possible barriers, not six faults in you. A clear request can still meet a real limit or a no.",
      "Use one manageable event, private rehearsal or the example. You can explore what happened, review an adjustment, ask for help or finish without contacting anyone."
    ]
  },
  "fit": {
    "id": "interpersonal-troubleshooting.fit",
    "title": "Check context and safety first",
    "paragraphs": [
      "Start with your therapist’s guidance. Consider power, culture, access, duties and support. If speaking up could bring threats, control, punishment or harm, seek suitable support and a safety plan rather than trying to improve your script.",
      "You can go straight to the group about other people and the setting. You do not have to rule out faults in yourself before taking a real limit or danger seriously. This page cannot assess safety or decide who is to blame.",
      "No one has to disclose private facts, stay in an unsafe relationship or keep asking after a refusal. If reviewing becomes overwhelming or turns into repeated checking, pause. You can use fiction or stop.",
      "Think, speak, sign, use an aid or write in the way that fits. No set eye contact, posture or fluent speech is needed. This is not urgent help, legal advice or a plan for handling danger alone."
    ]
  },
  "privacy": {
    "id": "interpersonal-troubleshooting.privacy",
    "title": "Writing and sharing are your choice",
    "paragraphs": [
      "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.",
      "Notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep notes, choose only the parts you want, check the preview, then copy or download. Those copies remain wherever you save them.",
      "Hiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return while the page stays open. It does not keep your answers or add a saved item to your usual Toolbox."
    ]
  },
  "close": {
    "id": "interpersonal-troubleshooting.close",
    "title": "You can leave it here",
    "paragraphs": [
      "You can finish after reading, exploring, rehearsing, reviewing or deciding not to continue. No solved problem, new plan or good feeling is required.",
      "If useful, keep selected notes or bring a question to your therapist. No contact, reminder or report has been created. Leaving clears the notes here."
    ]
  },
  "example": {
    "id": "interpersonal-troubleshooting.example",
    "title": "Example: Lee cannot borrow a game for Saturday",
    "paragraphs": [
      "In this made-up example, Lee clearly asks a club organiser to borrow a board game for Saturday. The organiser says it is booked then. Lee replies politely and leaves without a game. Lee thinks, \"I must have asked badly.\" There is no threat or conflict in this ordinary scene.",
      "Lee checks the actual attempt with their therapist. The request named the game and day; no missing skill is clear from this account. Lee wants a game for Saturday, wants a fair relationship with the club and wants to be honest. None of those aims requires this one game.",
      "Lee notices a wish to get a yes at once, but did not keep pressing. Lee felt disappointed yet could follow the reply. The thought about asking badly is a guess, not a fact. The known barrier is that the game is already booked. Other details may still be unknown.",
      "Lee chooses a change that fits that limit: find out whether a different game is free. In private rehearsal, Lee tries, \"That one is booked. Is there another game I could borrow for Saturday?\" Lee also practises accepting no and choosing another activity, rather than repeating the first request.",
      "Later in the made-up story, Lee asks the question. The organiser says no games are left. Lee accepts that answer and chooses an activity using things already at home. There is still no borrowed game and Lee is still disappointed.",
      "In review, Lee separates a clear attempt from the unavailable result. The new question checked an option but did not make stock appear. Lee does not conclude that more confidence would fix it. For next time, Lee may check availability earlier; that remains a plan, not something this page has arranged."
    ]
  },
  "learn": {
    "id": "interpersonal-troubleshooting.learn",
    "title": "Match the response to the barrier",
    "paragraphs": [
      "The six checks cover knowing and using the skill, clear aims, goals now and later, strong feelings, unhelpful thoughts, and limits in the setting. Other causes can matter too. More than one may fit, or you may not yet know.",
      "If a skill needs teaching, practice can help. If the person cannot agree, a better speech may change nothing. If your aims clash, another script may miss the real choice. Match the next step to what the evidence suggests.",
      "You can stop at a useful finding, try an agreed adjustment and review it later. If it did not help, reconsider the explanation or another factor with your therapist. You do not have to work through every check or keep trying until someone agrees.",
      "This is not a full Chain Analysis or Missing-Links Analysis. Those examine an action’s sequence or why an agreed action did not happen. Here the focus is what may be limiting a conversation skill and what kind of response fits. It does not teach the full linked skills or the Dime Game."
    ]
  },
  "practice": [
    {
      "id": "interpersonal-troubleshooting.practice.situation",
      "title": "Choose one event and the result you wanted",
      "paragraphs": [
        "Use an ordinary event agreed with your therapist or Lee’s example. What result did you want, and what did you actually say or do? You can review a rehearsal or a chance when you did little or nothing.",
        "What happened next? Separate facts, memories, guesses and unknowns. A person saying no is an outcome, not proof that you used a skill badly. Keep the event small enough to explore without retelling private history."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The event and result I wanted",
          "optional": true
        },
        {
          "key": "actual-at-start",
          "label": "What I actually tried, what happened and what is unknown",
          "optional": true
        }
      ],
      "help": {
        "title": "If there was no conversation",
        "text": "You can explore what stopped you or use fiction. Do not invent a reply or call a private rehearsal a real exchange."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.skills",
      "title": "Check the skill you tried",
      "paragraphs": [
        "With the instructions you learned, compare the skill with what you actually did. Did you know the needed part and how to use it here? Was it a clear request, a fair refusal or the right kind of response for the aim?",
        "If a part is missing or unclear, ask for teaching or coaching. Try a short version privately with your therapist, or review the full skill you already know. Name the specific part rather than deciding you are bad at talking.",
        "If you used the skill and still met a limit, consider other factors. Access needs, an unfamiliar language or lack of support are not fixed by trying harder to perform."
      ],
      "fields": [
        {
          "key": "skill-check",
          "label": "The part I tried and any gap or uncertainty",
          "optional": true
        },
        {
          "key": "skill-adjustment",
          "label": "Teaching, practice or access support that may fit",
          "optional": true
        }
      ],
      "help": {
        "title": "If I know the letters but get stuck using them",
        "text": "Understanding the labels and using the skill in a real setting are different. Ask to practise the stuck part with support; this is not proof of low effort."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.goals",
      "title": "Check whether the aims were clear",
      "paragraphs": [
        "Could you name the result you wanted, what mattered for the relationship, and how you wanted to act? Were those aims pulling in different directions? Fear or shame may also make it hard to admit a need.",
        "If the aim was unclear, compare the useful and costly parts of the options with your therapist. Use Clarifying Interpersonal Priorities if you have learned it. You may need support with feelings before the choice becomes clearer.",
        "An aim can change. You do not have to invent a request, agree to everything or refuse everything to prove you have a boundary."
      ],
      "fields": [
        {
          "key": "goal-check",
          "label": "Clear aims, conflicts or what I have not decided",
          "optional": true
        },
        {
          "key": "goal-adjustment",
          "label": "A choice to clarify or support I may need",
          "optional": true
        }
      ],
      "help": {
        "title": "If I only want the discomfort to stop",
        "text": "Notice that wish kindly. Also ask what you need from the situation beyond this moment. If you cannot tell yet, leave it as a question rather than force an answer."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.time",
      "title": "Compare what helps now and what matters later",
      "paragraphs": [
        "Did a quick gain or relief work against something that matters over time? For example, agreeing only to avoid an awkward moment may leave a promise you cannot keep. Insisting on a quick yes may damage a connection you value.",
        "If this fits, compare the effects now and later of your options when you have enough space to think. Use a familiar Wise Mind or pros-and-cons practice with support if needed. Choose what fits your values, real duties and limits.",
        "Getting through danger or meeting an urgent need is not a fault. Do not delay needed help just to put a future goal first."
      ],
      "fields": [
        {
          "key": "time-check",
          "label": "Possible effects now and later",
          "optional": true
        },
        {
          "key": "time-adjustment",
          "label": "A change or decision to consider with more space",
          "optional": true
        }
      ],
      "help": {
        "title": "If both time frames matter",
        "text": "Name both. The aim is to see the trade-off, not always choose the distant goal or blame yourself for wanting relief."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.emotions",
      "title": "Check whether feelings blocked use of the skill",
      "paragraphs": [
        "At the time, could you follow the exchange and choose what to do, or were you too overwhelmed? Strong feelings can make a complex skill hard to use. Tears, a quiet voice or visible stress alone do not tell you that it was unusable.",
        "If you were overwhelmed, pause the difficult practice and use support or a coping skill already taught and agreed with your therapist. A shorter exchange, a break or a different way to communicate may help. Practise the conversation skill at a more manageable time.",
        "If you could still choose, feeling nervous need not stop you. No set calmness level is required. This page does not teach crisis skills or physical exercises to change arousal."
      ],
      "fields": [
        {
          "key": "emotion-check",
          "label": "What feelings affected my ability to choose or communicate",
          "optional": true
        },
        {
          "key": "emotion-adjustment",
          "label": "An agreed coping skill, pause or support that fits",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot think clearly now",
        "text": "Stop this review and use your agreed support plan. You do not need to finish complicated questions while overwhelmed."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.thoughts",
      "title": "Check the thought against what is known",
      "paragraphs": [
        "Was a prediction, harsh label or rule getting in the way? You might think a fair request always makes you selfish, or that another person should know what you need without being told.",
        "If a thought may be part of the barrier, separate the facts from the guess. What supports it, what does not, and what remains unknown? Try a fairer statement that leaves room for the facts. You can use a thought or facts-checking skill you have learned.",
        "Some concerns are realistic. Do not talk yourself out of evidence of harm or unfair treatment. Any test of a fear or opposite-action practice needs its own fit check with your therapist; none is assigned here."
      ],
      "fields": [
        {
          "key": "thought-check",
          "label": "The thought, relevant facts and what is unknown",
          "optional": true
        },
        {
          "key": "thought-adjustment",
          "label": "A fairer statement or a question for my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If the worry could come true",
        "text": "You do not need certainty or a positive story. Consider what support, limits or response would fit if it happened. Real danger calls for safety support, not testing your fear."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.environment",
      "title": "Look at other people and the setting",
      "paragraphs": [
        "Could the person agree? Who controls the decision, resources or timing? Rules, lack of resources, unequal power, unfair treatment or another person’s limits may matter. You can check this first, not only after checking yourself.",
        "If the setting limits the result, consider practical options or support from someone able to help. An advocate may help with a real access or power barrier. Seek advice about whether and how to involve them; do not use an ally to pressure someone past their consent.",
        "Sometimes the wanted result is not available. Acceptance can mean facing that fact while choosing what to do next. It does not mean approving harm, surrendering rights or agreeing to an unsafe demand. You may need a different goal or support, not a stronger request."
      ],
      "fields": [
        {
          "key": "environment-check",
          "label": "What outside limits, power or information may matter",
          "optional": true
        },
        {
          "key": "environment-adjustment",
          "label": "A practical option, support, changed goal or limit to accept",
          "optional": true
        }
      ],
      "help": {
        "title": "If I keep thinking better words would fix everything",
        "text": "Skills can improve how you act, but cannot make every person or system respond. Lee’s clear question could not make a booked game available."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.other",
      "title": "Leave room for another explanation",
      "paragraphs": [
        "Did these checks miss something? Timing, tiredness, pain, competing duties, a misunderstanding or missing information may matter. You can name another possibility without sharing health or personal details.",
        "Which explanations fit what you know, and which are guesses? More than one can apply. Keep uncertainty visible and ask your therapist if a wider review or different kind of help is needed."
      ],
      "fields": [
        {
          "key": "other-factor",
          "label": "Another factor or missing information",
          "optional": true
        },
        {
          "key": "uncertainty",
          "label": "What is supported, uncertain or needs a wider review",
          "optional": true
        }
      ],
      "help": {
        "title": "If none of the checks seems to fit",
        "text": "Do not choose a fault just to fill the page. An unclear account or a result outside your control may be enough reason to stop and discuss it."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.match",
      "title": "Choose a change that fits the finding",
      "paragraphs": [
        "Name your best working explanation, not a final diagnosis. What change matches it? Examples include learning a missing part, clarifying a choice, weighing later effects, using agreed coping support, checking a thought, or addressing an outside limit.",
        "Choose one feasible adjustment with your therapist, and say why it fits. Include needed access, consent and support. If you need a new skill, keep that as a teaching request rather than trying an unfamiliar method alone.",
        "You can go here as soon as a useful factor is clear. If a change is not needed, or the goal no longer fits, you can leave it, seek support or stop."
      ],
      "fields": [
        {
          "key": "working-explanation",
          "label": "The possible barrier and evidence for it",
          "optional": true
        },
        {
          "key": "chosen-adjustment",
          "label": "One fitting adjustment, support need or choice to stop",
          "optional": true
        }
      ],
      "help": {
        "title": "If the answer is just try harder",
        "text": "Make it concrete: what would be different, and why would that address the barrier? More effort cannot supply missing resources or another person’s consent."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.try",
      "title": "Try the adjustment privately",
      "paragraphs": [
        "If the adjustment is ready and safe to rehearse, actually try its first part. Say, sign, think through or write the new response. If you need coaching, practise asking for that help. You can use Lee’s changed question instead.",
        "Then try what you would do if the answer or result stays the same. You might accept a no, pause, choose another option or get support. No one needs to play the other person, and you do not have to contact anyone.",
        "What did you notice while trying it? Change a stuck part if useful, or take it back to your therapist. Reading a plan is not the same as trying it, and rehearsal cannot predict a real reply."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I actually tried, or why I did not",
          "optional": true
        },
        {
          "key": "same-result-response",
          "label": "A response to an unchanged result, and what needs support",
          "optional": true
        }
      ],
      "help": {
        "title": "If no rehearsal fits",
        "text": "You can explain your choice to yourself or leave it for supported work. There is no need to invent a script for a barrier that needs practical help instead."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.review",
      "title": "Review the adjustment and what happened",
      "paragraphs": [
        "Recall the adjustment you agreed, or leave it unknown if you cannot remember. Was there a suitable chance to use it? What did you actually try, change, stop or not try? You can review without earlier notes.",
        "Did it help with the barrier, your actions or the result? These can differ. Include an unchanged result, cost, discomfort or something still unknown. No chance to use it is different from choosing not to use it.",
        "If it helped, decide whether to keep it. If it did not, reconsider the explanation, another factor or needed support with your therapist. You do not have to retry. Moving through this page proves no action, agreement or improvement."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "The adjustment and what I actually did or did not do",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What changed, did not change or remains unknown",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What this suggests and what needs discussion",
          "optional": true
        }
      ],
      "help": {
        "title": "If I got no again",
        "text": "Look separately at the skill, the barrier and the other person’s choice. A repeated no does not by itself show that you used the skill badly or should keep pressing."
      }
    },
    {
      "id": "interpersonal-troubleshooting.practice.next",
      "title": "Choose whether anything comes next",
      "paragraphs": [
        "You may keep the adjustment, revise it, learn a different skill, seek practical help, change the goal or stop. If a next opportunity makes sense, agree the first action, needed support and when to review it with your therapist.",
        "A future plan is not a record of doing it. No contact or reminder is set here. You can keep selected notes if useful, or finish without a new plan."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, change, pause or stop",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any next opportunity, support or review to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing needs doing now",
        "text": "You can finish. Finding a limit does not create a duty to solve it or contact someone."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 interpersonal Handout 9",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed pp. 134–135: six barrier domains and space for other factors.",
      "limits": "Historical Second Edition, not verified 2025 Revised wording. Original prose only; source form and examples not reproduced."
    },
    {
      "id": "Linehan/Guilford: 2015 interpersonal teaching notes, section IX",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Printed pp. 266–270: identify the barrier, match teaching or another response, and recognize limits of interpersonal influence.",
      "limits": "Clinical teaching does not validate this app. Non-shaming, consent, access and safety qualifications are explicit adaptations. Related treatment methods need their own teaching and fit checks."
    },
    {
      "id": "Linehan/Guilford: 2015 interpersonal Worksheet 7",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed pp. 178–179: conditional barrier checks, fitting adjustments and follow-through review, including no further attempt.",
      "limits": "No worksheet, source checkboxes or evaluative feedback reproduced. Optional prose review replaces the source checkbox format; no mandatory sequence."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal, meaningful communication and access to needed support.",
      "limits": "Rights guidance, not validation of this clinical component."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from the individual purchaser licence.",
      "limits": "Accessible sources do not grant publication rights. No release-rights approval requested or received."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Define actual episode and separate wanted from actual outcome",
      "sections": [
        "practice.situation"
      ],
      "source": "Worksheet 7 context and original product framing"
    },
    {
      "operation": "Six conditional barrier checks paired with adjustments",
      "sections": [
        "practice.skills",
        "practice.goals",
        "practice.time",
        "practice.emotions",
        "practice.thoughts",
        "practice.environment"
      ],
      "source": "Handout 9; Manual section IX; Worksheet 7. No mandatory ladder or diagnosis."
    },
    {
      "operation": "Other factors, provisional formulation and matching adjustment",
      "sections": [
        "practice.other",
        "practice.match"
      ],
      "source": "Handout 9 other ideas; source barrier-to-response teaching and original accessible formulation"
    },
    {
      "operation": "Actual private attempt, unchanged-result response and later review",
      "sections": [
        "practice.try",
        "practice.review",
        "practice.next"
      ],
      "source": "Manual coaching/practice and Worksheet 7 follow-through; original safeguards and planning. Full linked methods retained separately."
    }
  ],
  "narrationSegments": [
    {
      "id": "interpersonal-troubleshooting.intro",
      "title": "Find what needs a different approach",
      "text": "Sometimes you use a conversation skill and still do not get the result you hoped for. Sometimes you get stuck before you can use it. Troubleshooting means looking at what got in the way and choosing a change that fits.\n\nThis practice adds to DEAR MAN, GIVE and FAST. Use it with conversation skills your therapist has taught you. It looks at six possible barriers, not six faults in you. A clear request can still meet a real limit or a no.\n\nUse one manageable event, private rehearsal or the example. You can explore what happened, review an adjustment, ask for help or finish without contacting anyone.",
      "sha256": "c902531039a82da784950eb2f07d70012f27937458c69212f19c61a3d28517b7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.fit",
      "title": "Check context and safety first",
      "text": "Start with your therapist’s guidance. Consider power, culture, access, duties and support. If speaking up could bring threats, control, punishment or harm, seek suitable support and a safety plan rather than trying to improve your script.\n\nYou can go straight to the group about other people and the setting. You do not have to rule out faults in yourself before taking a real limit or danger seriously. This page cannot assess safety or decide who is to blame.\n\nNo one has to disclose private facts, stay in an unsafe relationship or keep asking after a refusal. If reviewing becomes overwhelming or turns into repeated checking, pause. You can use fiction or stop.\n\nThink, speak, sign, use an aid or write in the way that fits. No set eye contact, posture or fluent speech is needed. This is not urgent help, legal advice or a plan for handling danger alone.",
      "sha256": "6d3d9f97030a225cb46bc1f5ce9c116804e541fc6c940b7b167125448d93f0fc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.privacy",
      "title": "Writing and sharing are your choice",
      "text": "You can practise without writing or use your own paper. A short label is enough; names and private history are not needed. This tool records no voice and sends no notes or messages to anyone.\n\nNotes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep notes, choose only the parts you want, check the preview, then copy or download. Those copies remain wherever you save them.\n\nHiding writing removes its private displays but keeps it in this open page. Someone using your device or a screen reader may still access writing when it is shown. A session shortcut lets you return while the page stays open. It does not keep your answers or add a saved item to your usual Toolbox.",
      "sha256": "ea7c2a2aefc5a68a961d8b05ce5ee5d550e8018b0f20dfa1ab56b32821f5c885",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.close",
      "title": "You can leave it here",
      "text": "You can finish after reading, exploring, rehearsing, reviewing or deciding not to continue. No solved problem, new plan or good feeling is required.\n\nIf useful, keep selected notes or bring a question to your therapist. No contact, reminder or report has been created. Leaving clears the notes here.",
      "sha256": "bd35af5ea024e6e01e8bed2d6e5300bccc967e6b84d858191db8039afe751864",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.example",
      "title": "Example: Lee cannot borrow a game for Saturday",
      "text": "In this made-up example, Lee clearly asks a club organiser to borrow a board game for Saturday. The organiser says it is booked then. Lee replies politely and leaves without a game. Lee thinks, \"I must have asked badly.\" There is no threat or conflict in this ordinary scene.\n\nLee checks the actual attempt with their therapist. The request named the game and day; no missing skill is clear from this account. Lee wants a game for Saturday, wants a fair relationship with the club and wants to be honest. None of those aims requires this one game.\n\nLee notices a wish to get a yes at once, but did not keep pressing. Lee felt disappointed yet could follow the reply. The thought about asking badly is a guess, not a fact. The known barrier is that the game is already booked. Other details may still be unknown.\n\nLee chooses a change that fits that limit: find out whether a different game is free. In private rehearsal, Lee tries, \"That one is booked. Is there another game I could borrow for Saturday?\" Lee also practises accepting no and choosing another activity, rather than repeating the first request.\n\nLater in the made-up story, Lee asks the question. The organiser says no games are left. Lee accepts that answer and chooses an activity using things already at home. There is still no borrowed game and Lee is still disappointed.\n\nIn review, Lee separates a clear attempt from the unavailable result. The new question checked an option but did not make stock appear. Lee does not conclude that more confidence would fix it. For next time, Lee may check availability earlier; that remains a plan, not something this page has arranged.",
      "sha256": "d8cfdec429bc9a80dd994a264f3ff207d221cd9c7f7585823402b856871f087b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.learn",
      "title": "Match the response to the barrier",
      "text": "The six checks cover knowing and using the skill, clear aims, goals now and later, strong feelings, unhelpful thoughts, and limits in the setting. Other causes can matter too. More than one may fit, or you may not yet know.\n\nIf a skill needs teaching, practice can help. If the person cannot agree, a better speech may change nothing. If your aims clash, another script may miss the real choice. Match the next step to what the evidence suggests.\n\nYou can stop at a useful finding, try an agreed adjustment and review it later. If it did not help, reconsider the explanation or another factor with your therapist. You do not have to work through every check or keep trying until someone agrees.\n\nThis is not a full Chain Analysis or Missing-Links Analysis. Those examine an action’s sequence or why an agreed action did not happen. Here the focus is what may be limiting a conversation skill and what kind of response fits. It does not teach the full linked skills or the Dime Game.",
      "sha256": "8da4ed6ceab4bd9d24b1d4eb1b418eb32b43ca83e7cc712aab0977feaa0c714d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.situation",
      "title": "Choose one event and the result you wanted",
      "text": "Use an ordinary event agreed with your therapist or Lee’s example. What result did you want, and what did you actually say or do? You can review a rehearsal or a chance when you did little or nothing.\n\nWhat happened next? Separate facts, memories, guesses and unknowns. A person saying no is an outcome, not proof that you used a skill badly. Keep the event small enough to explore without retelling private history.",
      "sha256": "4d065970344ca2961fd40d5d63650a25356d6e082e4d7ed9affc23d7fb4bf5f6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.situation.help",
      "title": "If there was no conversation",
      "text": "You can explore what stopped you or use fiction. Do not invent a reply or call a private rehearsal a real exchange.",
      "sha256": "002b1ecaaf4125b7ff17593b23c1457b75f8a93f5bc2e7f76831ed37fc229e64",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.skills",
      "title": "Check the skill you tried",
      "text": "With the instructions you learned, compare the skill with what you actually did. Did you know the needed part and how to use it here? Was it a clear request, a fair refusal or the right kind of response for the aim?\n\nIf a part is missing or unclear, ask for teaching or coaching. Try a short version privately with your therapist, or review the full skill you already know. Name the specific part rather than deciding you are bad at talking.\n\nIf you used the skill and still met a limit, consider other factors. Access needs, an unfamiliar language or lack of support are not fixed by trying harder to perform.",
      "sha256": "6a7223f3fe101c6b9ea3d81e3badc1317583ed52067b36bdee93bb689529732d",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.skills.help",
      "title": "If I know the letters but get stuck using them",
      "text": "Understanding the labels and using the skill in a real setting are different. Ask to practise the stuck part with support; this is not proof of low effort.",
      "sha256": "d00f6acc64e0759071d651bea605f51018ffa6bcfbebd883e82a0b68a20a1319",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.goals",
      "title": "Check whether the aims were clear",
      "text": "Could you name the result you wanted, what mattered for the relationship, and how you wanted to act? Were those aims pulling in different directions? Fear or shame may also make it hard to admit a need.\n\nIf the aim was unclear, compare the useful and costly parts of the options with your therapist. Use Clarifying Interpersonal Priorities if you have learned it. You may need support with feelings before the choice becomes clearer.\n\nAn aim can change. You do not have to invent a request, agree to everything or refuse everything to prove you have a boundary.",
      "sha256": "08d885cf8cf10dfe74159a8d8e93c9ddd0a8066a2f3b5acff6a9d54866f572e7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.goals.help",
      "title": "If I only want the discomfort to stop",
      "text": "Notice that wish kindly. Also ask what you need from the situation beyond this moment. If you cannot tell yet, leave it as a question rather than force an answer.",
      "sha256": "e69420eb1148c4764a36414eaf8d6017ce28c667e98ff19ec74a97287eec1ba1",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.time",
      "title": "Compare what helps now and what matters later",
      "text": "Did a quick gain or relief work against something that matters over time? For example, agreeing only to avoid an awkward moment may leave a promise you cannot keep. Insisting on a quick yes may damage a connection you value.\n\nIf this fits, compare the effects now and later of your options when you have enough space to think. Use a familiar Wise Mind or pros-and-cons practice with support if needed. Choose what fits your values, real duties and limits.\n\nGetting through danger or meeting an urgent need is not a fault. Do not delay needed help just to put a future goal first.",
      "sha256": "dd42747ba4079b1524360fd1f5c2ba7ac384a9e2e74775d6f54603296fe6e174",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.time.help",
      "title": "If both time frames matter",
      "text": "Name both. The aim is to see the trade-off, not always choose the distant goal or blame yourself for wanting relief.",
      "sha256": "6ba4b31523303f5844a059a97d7296f878a24f0a49b206503e64a486f0679c17",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.emotions",
      "title": "Check whether feelings blocked use of the skill",
      "text": "At the time, could you follow the exchange and choose what to do, or were you too overwhelmed? Strong feelings can make a complex skill hard to use. Tears, a quiet voice or visible stress alone do not tell you that it was unusable.\n\nIf you were overwhelmed, pause the difficult practice and use support or a coping skill already taught and agreed with your therapist. A shorter exchange, a break or a different way to communicate may help. Practise the conversation skill at a more manageable time.\n\nIf you could still choose, feeling nervous need not stop you. No set calmness level is required. This page does not teach crisis skills or physical exercises to change arousal.",
      "sha256": "81329d306f5f394bc4eaf5b99506aca7c49adc127577fe04767d21d686575d32",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.emotions.help",
      "title": "If I cannot think clearly now",
      "text": "Stop this review and use your agreed support plan. You do not need to finish complicated questions while overwhelmed.",
      "sha256": "af2a2622317a7f04465b2e74d4bec35cc22ffa20e2667874e1d84707597367e3",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.thoughts",
      "title": "Check the thought against what is known",
      "text": "Was a prediction, harsh label or rule getting in the way? You might think a fair request always makes you selfish, or that another person should know what you need without being told.\n\nIf a thought may be part of the barrier, separate the facts from the guess. What supports it, what does not, and what remains unknown? Try a fairer statement that leaves room for the facts. You can use a thought or facts-checking skill you have learned.\n\nSome concerns are realistic. Do not talk yourself out of evidence of harm or unfair treatment. Any test of a fear or opposite-action practice needs its own fit check with your therapist; none is assigned here.",
      "sha256": "3635c6256594448d1a53eeba754054f65ef7c8a938c736838901d22db7a54943",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.thoughts.help",
      "title": "If the worry could come true",
      "text": "You do not need certainty or a positive story. Consider what support, limits or response would fit if it happened. Real danger calls for safety support, not testing your fear.",
      "sha256": "f7fc3deb84c011c4800fe39120e0abba3860cc2fd739fb2a4768d48969a58750",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.environment",
      "title": "Look at other people and the setting",
      "text": "Could the person agree? Who controls the decision, resources or timing? Rules, lack of resources, unequal power, unfair treatment or another person’s limits may matter. You can check this first, not only after checking yourself.\n\nIf the setting limits the result, consider practical options or support from someone able to help. An advocate may help with a real access or power barrier. Seek advice about whether and how to involve them; do not use an ally to pressure someone past their consent.\n\nSometimes the wanted result is not available. Acceptance can mean facing that fact while choosing what to do next. It does not mean approving harm, surrendering rights or agreeing to an unsafe demand. You may need a different goal or support, not a stronger request.",
      "sha256": "6cdcdeeb52508a03b2c70a4cfe33e6a24e332d7c3abc340e465fd9a20fe5b907",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.environment.help",
      "title": "If I keep thinking better words would fix everything",
      "text": "Skills can improve how you act, but cannot make every person or system respond. Lee’s clear question could not make a booked game available.",
      "sha256": "d58cff73f3cccb876c89ad923a474a1103169f3a84422e6c79d2debb80407197",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.other",
      "title": "Leave room for another explanation",
      "text": "Did these checks miss something? Timing, tiredness, pain, competing duties, a misunderstanding or missing information may matter. You can name another possibility without sharing health or personal details.\n\nWhich explanations fit what you know, and which are guesses? More than one can apply. Keep uncertainty visible and ask your therapist if a wider review or different kind of help is needed.",
      "sha256": "361138d6341e1ea3377b85f5bacfe7745fd28c2cd110ce458052fd8b3a011868",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.other.help",
      "title": "If none of the checks seems to fit",
      "text": "Do not choose a fault just to fill the page. An unclear account or a result outside your control may be enough reason to stop and discuss it.",
      "sha256": "56c28d885fc7b2df137a0ba3b2d011ecfa7470fc80a412c2957ae81ce442d6e0",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.match",
      "title": "Choose a change that fits the finding",
      "text": "Name your best working explanation, not a final diagnosis. What change matches it? Examples include learning a missing part, clarifying a choice, weighing later effects, using agreed coping support, checking a thought, or addressing an outside limit.\n\nChoose one feasible adjustment with your therapist, and say why it fits. Include needed access, consent and support. If you need a new skill, keep that as a teaching request rather than trying an unfamiliar method alone.\n\nYou can go here as soon as a useful factor is clear. If a change is not needed, or the goal no longer fits, you can leave it, seek support or stop.",
      "sha256": "1c27b46bc43c3741c62158d893fbe9ee08b212a2cec348e23d67a6abfdc0bba6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.match.help",
      "title": "If the answer is just try harder",
      "text": "Make it concrete: what would be different, and why would that address the barrier? More effort cannot supply missing resources or another person’s consent.",
      "sha256": "168ec3f056d202a170f80acafeda6b318dea38bd00b9d475d53c188a14c48b23",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.try",
      "title": "Try the adjustment privately",
      "text": "If the adjustment is ready and safe to rehearse, actually try its first part. Say, sign, think through or write the new response. If you need coaching, practise asking for that help. You can use Lee’s changed question instead.\n\nThen try what you would do if the answer or result stays the same. You might accept a no, pause, choose another option or get support. No one needs to play the other person, and you do not have to contact anyone.\n\nWhat did you notice while trying it? Change a stuck part if useful, or take it back to your therapist. Reading a plan is not the same as trying it, and rehearsal cannot predict a real reply.",
      "sha256": "48f8a203eff4121084f2a0a5fa49cac758858faec324e14de953a2b357eaf0bd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.try.help",
      "title": "If no rehearsal fits",
      "text": "You can explain your choice to yourself or leave it for supported work. There is no need to invent a script for a barrier that needs practical help instead.",
      "sha256": "20014ea8e176fa7fb125a40c36dd3eca0c8a158f37d665bfc9484019ed41ed24",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.review",
      "title": "Review the adjustment and what happened",
      "text": "Recall the adjustment you agreed, or leave it unknown if you cannot remember. Was there a suitable chance to use it? What did you actually try, change, stop or not try? You can review without earlier notes.\n\nDid it help with the barrier, your actions or the result? These can differ. Include an unchanged result, cost, discomfort or something still unknown. No chance to use it is different from choosing not to use it.\n\nIf it helped, decide whether to keep it. If it did not, reconsider the explanation, another factor or needed support with your therapist. You do not have to retry. Moving through this page proves no action, agreement or improvement.",
      "sha256": "515faa30c60c0eeac349e26ac2f463a0b6a813602647842bde9978f5c9828a64",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.review.help",
      "title": "If I got no again",
      "text": "Look separately at the skill, the barrier and the other person’s choice. A repeated no does not by itself show that you used the skill badly or should keep pressing.",
      "sha256": "ae9d051dc508a906ac018fdfd59fb3e6e55473e7f56659ff46cc8906f15f7574",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "interpersonal-troubleshooting.practice.next",
      "title": "Choose whether anything comes next",
      "text": "You may keep the adjustment, revise it, learn a different skill, seek practical help, change the goal or stop. If a next opportunity makes sense, agree the first action, needed support and when to review it with your therapist.\n\nA future plan is not a record of doing it. No contact or reminder is set here. You can keep selected notes if useful, or finish without a new plan.",
      "sha256": "55aa9b244e9f22bee87d8212727d56b5de6282e4d63c9317aefe6b6870e3cc4e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "interpersonal-troubleshooting.practice.next.help",
      "title": "If nothing needs doing now",
      "text": "You can finish. Finding a limit does not create a duty to solve it or contact someone.",
      "sha256": "d8b4bf7e67c84f66e968b57b6a0070e54b6894dbcc8691ad01e44c30f2da6f6e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
