window.EndingRelationshipsContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/relationships",
  "componentId": "component/relationships/ending-relationships",
  "resourceId": "tool/ending-relationships",
  "routeProposal": "/ending-relationships/",
  "title": "Ending Relationships",
  "subtitle": "Considering a nonabusive situation with your therapist",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Therapist-supported consideration of an unwanted nonabusive relationship, with choice, possible repair, practical limits, communication planning, actual rehearsal and review. This is not an abuse safety plan or the whole source ending-relationships procedure.",
  "groupedSetStatus": "Existing uncounted component under classic/relationships. Bounded nonabusive adaptation only. Conditional opposite action for love is deferred in full for separate therapist assessment. No grouped-set completion or new canonical count.",
  "clinicalContract": {
    "learningObjective": "Consider a nonabusive relationship without steering toward staying or leaving; integrate facts, emotions, values, repair options and real constraints; prepare respectful clear communication and practical follow-through without requiring agreement or unsafe contact.",
    "practiceObjective": "Check individualized fit with a therapist; compare possible choices, consider repair if appropriate, state a decision or uncertainty, account for dependencies, select a suitable communication method, prepare words using previously learned skills, actually rehearse a manageable response and complication, then review what really occurred and what support remains.",
    "sourcePopulationContext": "Historical 2015 author/publisher DBT interpersonal teaching and a worksheet expressly bounded to nonabusive situations inform this original adaptation. No age floor or all-age suitability claim. Prior therapist teaching and individual clinical, developmental, communication, cultural, safeguarding, legal and access fit are needed.",
    "exclusions": [
      "No abuse assessment, intimate-partner violence screening, escape plan, emergency service or determination of safety",
      "No instruction to confront, stay, leave, reconcile, cut all contact or involve family/caregivers automatically",
      "No prediction of another person’s response, diagnosis of them or promise that respect prevents retaliation",
      "No broad opposite-action-for-love avoidance, suppression or no-contact instructions; that whole separate branch is deferred",
      "No legal, custody, housing, financial, safeguarding or care advice, and no automated messages or therapist reporting",
      "No pressure to feel calm, stop caring, obtain agreement, offer false benefits or negotiate a decision under pressure"
    ],
    "adaptations": [
      "Original optional single-situation practice and fictional low-stakes example, not reproduced worksheet, rating system, answer key or source wording",
      "Immediate bounded scope and safety exit; understandable uncertainty about abuse or safety is a reason for qualified support, not a pass/fail self-screen",
      "Separate undecided, repair and ending choices; rehearsal does not require sending or acting",
      "Explicit communication aids and safe individual support; no automatic caregiver disclosure or speaking requirement",
      "Full conditional opposite-action-for-love branch deferred for therapist assessment, so full original component and grouped set remain incomplete"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of bounded scope, deferred branch and source-use rights before any release",
      "Individual clinical, developmental, cultural, communication, access, safeguarding and safety fit; qualified help for uncertain or unsafe situations",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected export and lifecycle testing",
      "Authorized exact-script narration production and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose preparation or review",
      "options": [
        {
          "value": "prepare",
          "label": "Consider or prepare a nonabusive situation",
          "startSectionId": "ending-relationships.practice.situation"
        },
        {
          "value": "review",
          "label": "Review what I actually did",
          "startSectionId": "ending-relationships.practice.review"
        }
      ]
    },
    "entryGate": "Bounded scope and safety visible before selection. Choosing a mode never confirms safety or approves contact.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required sequence, writing, decision or communication.",
    "reviewAccess": "Direct blank review without a prior plan or inferred communication. Both modes expose every group.",
    "writing": "Optional and hidden initially. Hiding removes private displays and invalidates export; no guarantee against device monitoring.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording or autoplay.",
    "timer": "None. No breakup deadline, contact schedule, daily quota or exposure ladder.",
    "completion": "No inferred decision, safety, practice, contact, relationship ending, consent or improved outcome."
  },
  "intro": {
    "id": "ending-relationships.intro",
    "title": "Considering a nonabusive situation with your therapist",
    "paragraphs": [
      "This practice is for thinking about an unwanted relationship where abuse is not part of the situation. Use it after your therapist has helped you check the fit. It can help you consider choices or prepare words. It does not tell you to stay or leave.",
      "You may be unsure, want to explore repair, or have chosen to end a part of a relationship. A practice plan is not a promise to act. Ending one kind of relationship may still leave practical ties to work through.",
      "This uses skills you have learned with your therapist: Wise Mind, problem solving, Cope Ahead and clear, respectful communication. It does not teach every part of the source method. A separate skill for strong attachment is left for therapist guidance."
    ]
  },
  "fit": {
    "id": "ending-relationships.fit",
    "title": "Safety and support come before a script",
    "paragraphs": [
      "Do not use this as a plan for abuse, threats, coercion, stalking or fear of retaliation. If you are unsure about safety, pause this practice and seek help from your therapist or a specialist who understands abuse. You do not need to prove abuse to ask for help.",
      "Leaving or telling someone you may leave can increase danger in an abusive situation. Do not confront someone to test safety. This page cannot assess risk or make a safety plan. For immediate danger, use local emergency help or your existing urgent support plan.",
      "Check real ties such as care, money, housing, work, school, children or other shared duties with suitable support. This practice cannot settle legal rights or care duties. Support must fit your situation; involving relatives, carers or a joint meeting is not automatically safe.",
      "Your therapist can help choose an age-appropriate, accessible practice. Think, speak, sign or use a communication aid. If this feels overwhelming, pause, use agreed support or discuss it in therapy. You do not have to send a message or make a decision here."
    ]
  },
  "privacy": {
    "id": "ending-relationships.privacy",
    "title": "Keep private details out if that is safer",
    "paragraphs": [
      "You can use the made-up example without entering personal details. A short label is enough. This tool records no voice and sends no notes or messages, but it cannot tell whether someone monitors your device, accounts or screen. Use a safer way to seek support if needed.",
      "Optional notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. That does not erase browser history, device activity or copies saved elsewhere, and it does not make your activity untraceable.",
      "Hiding writing removes its private displays but keeps the text in this open page. Someone using the device or a screen reader may access it when shown. To keep notes, select only what you want, check the preview, then copy or download. Those copies stay where you put them.",
      "The session shortcut works while this page stays open. It does not save answers or add a saved item to your usual Toolbox. You can finish without writing, saving or sharing anything."
    ]
  },
  "close": {
    "id": "ending-relationships.close",
    "title": "Finish with your choice still your own",
    "paragraphs": [
      "You may finish after reading, considering choices, rehearsing or reviewing. The page does not count this as an ended relationship or a completed conversation.",
      "If useful, bring a question or chosen notes to your therapist. No message, report, reminder or plan is sent. Leaving clears notes in this tool, not activity or copies elsewhere."
    ]
  },
  "example": {
    "id": "ending-relationships.example",
    "title": "Made-up example: changing a hobby partnership",
    "paragraphs": [
      "Ari and a friend meet each week to make model buildings. Ari no longer wants this shared project, but would like to stay friendly. In this made-up situation, there are no threats or shared care, housing or money needs. The therapist has helped Ari check that the practice fits.",
      "Ari considers continuing, trying a shorter project and ending the weekly partnership. They already tried shorter meetings, but Ari still wants to use the time differently. Ari chooses to end the shared project, not to demand that the friend agree or promise to stay friends.",
      "There is a box of the friend’s supplies to return. Ari chooses a phone conversation that fits this ordinary situation and rehearses: \"I have decided to stop our weekly model project. My interests have changed. I would like to return your supplies. We can work out a suitable way to do that.\" No promise of friendship or benefit is used to soften the decision.",
      "Ari actually practises saying the words, then rehearses a possible reply: \"Can we just meet less often?\" Ari tries: \"I hear that you would like to keep it going. I have decided to stop the project. I can still talk about returning the supplies.\" This is a possible response, not a prediction.",
      "In the made-up follow-up, Ari has rehearsed but has not called. The first version felt too long, so Ari shortened it. The friend’s response, supply return and future friendship are unknown. Ari plans to check the next step in therapy. Rehearsal has not been counted as contact."
    ]
  },
  "learn": {
    "id": "ending-relationships.learn",
    "title": "A clear choice can still include care and uncertainty",
    "paragraphs": [
      "Wise Mind brings feelings, facts, values and wider context into a choice. It is not a test of calm or a rule to distrust strong feelings. If the situation allows, take enough space to think before a major step. Do not delay urgent safety help to complete this exercise.",
      "For an important nonabusive relationship, repair may be worth exploring if you want it and change seems possible. Repair is an option, not a duty or proof that you tried hard enough. Ending a relationship does not require a diagnosis or a verdict that someone is a bad person.",
      "DEAR MAN helps make your message clear. GIVE supports respectful attention to the other person. FAST helps you stay fair, truthful and close to your values. Use the parts you have learned that fit. Respect does not mean promising a benefit you do not believe or giving up your decision.",
      "You may still feel care, grief, relief or doubt. Those feelings alone do not decide whether to stay or leave. The source also includes opposite action for love when it fits. That is a separate therapist-guided choice and skill, not taught here. This page does not prescribe avoiding someone or removing all reminders."
    ]
  },
  "practice": [
    {
      "id": "ending-relationships.practice.situation",
      "title": "Name the question, not a verdict",
      "paragraphs": [
        "Choose one nonabusive situation already checked with your therapist, or use Ari’s example. Briefly name the relationship and what you are considering. You do not need names, a full history or a label for the other person.",
        "What has actually happened, and what matters to you now? Keep observations separate from guesses about motives. If safety is uncertain or new concerns arise, stop planning the conversation and seek suitable support."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The nonabusive situation or made-up example",
          "optional": true
        },
        {
          "key": "facts-and-needs",
          "label": "What happened and what matters to me",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am not sure this is nonabusive",
        "text": "You do not have to decide that alone. Pause the script and seek qualified support. Filling this page cannot confirm safety."
      }
    },
    {
      "id": "ending-relationships.practice.choice",
      "title": "Consider staying, changing or ending",
      "paragraphs": [
        "What are the realistic options? They might include continuing as things are, trying an agreed change, ending one part of the relationship, or taking more time with support. You do not need to choose every option or choose now.",
        "For each option you are considering, look at possible helpful and difficult effects now and later. Include your values, needs, real duties and what remains unknown. A list is not a score that tells you what to do."
      ],
      "fields": [
        {
          "key": "options",
          "label": "The options I am considering",
          "optional": true
        },
        {
          "key": "effects-and-values",
          "label": "Possible effects now and later, values and unknowns",
          "optional": true
        }
      ],
      "help": {
        "title": "If the costs seem too tangled",
        "text": "Bring them to your therapist or someone with the right expertise. Real dependence is not a lack of skill. Do not use this exercise to justify harm or make a choice under pressure."
      }
    },
    {
      "id": "ending-relationships.practice.repair",
      "title": "Consider repair only if it fits",
      "paragraphs": [
        "If the relationship matters to you, is nonabusive and you want to explore repair, what specific change might help? Consider whether it is realistic, whether others would need to agree, and what has already been tried.",
        "Use problem solving you have learned with your therapist if that fits. Repair may involve a clear request or different arrangement, but you do not owe another attempt. If you do not want repair, or do not know, note that without inventing a plan."
      ],
      "fields": [
        {
          "key": "repair-choice",
          "label": "Whether I want to consider repair, or do not know",
          "optional": true
        },
        {
          "key": "repair-possibility",
          "label": "Any specific realistic change and what is still unknown",
          "optional": true
        }
      ],
      "help": {
        "title": "If someone says I must keep trying",
        "text": "You can consider your values and duties without accepting pressure to stay. Joint conversations or counselling are not automatically suitable, especially if safety is uncertain."
      }
    },
    {
      "id": "ending-relationships.practice.constraints",
      "title": "Check practical ties and support",
      "paragraphs": [
        "What would still need attention if the relationship changed? Think about shared belongings, agreed tasks, care needs or other real ties. Some situations need advice before any step; this page cannot decide legal, financial or care duties.",
        "Who could offer suitable, safe support, and what would you want help with? Keep shared details limited to what the support person needs to help. You do not need the other person’s permission to seek professional or safety support. Do not assume family, carers, colleagues or joint support are the right people for this situation."
      ],
      "fields": [
        {
          "key": "practical-ties",
          "label": "Practical ties or duties that may remain",
          "optional": true
        },
        {
          "key": "needed-support",
          "label": "Support or advice I need before a next step",
          "optional": true
        }
      ],
      "help": {
        "title": "If a young person or dependent person is involved",
        "text": "Work with an appropriate professional on care, consent, development and safeguarding. This page cannot arrange a safe change in care or decide who should be told."
      }
    },
    {
      "id": "ending-relationships.practice.decision",
      "title": "State what is decided and what is not",
      "paragraphs": [
        "Bring together the facts, feelings, values and options using the Wise Mind work you know. What, if anything, have you chosen? It is valid to be undecided, consider repair, pause or ask for more help.",
        "If you have chosen to end a relationship or one part of it, describe that clearly. Keep it separate from details still open to discussion. Caring about the person or feeling sad does not require you to reverse a choice."
      ],
      "fields": [
        {
          "key": "current-choice",
          "label": "My current choice, or what is undecided",
          "optional": true
        },
        {
          "key": "open-details",
          "label": "What is settled and what still needs thought or discussion",
          "optional": true
        }
      ],
      "help": {
        "title": "If strong feelings are here",
        "text": "Strong feelings carry information; they do not automatically make a choice wrong. Get enough support to consider the wider situation. Calm is not required, and urgent safety help should not wait."
      }
    },
    {
      "id": "ending-relationships.practice.contact",
      "title": "Choose whether and how to communicate",
      "paragraphs": [
        "If a decision to communicate has been made and fits the agreed scope, consider a message, phone call, in-person talk or another accessible method. No method is always best, and you can choose not to contact someone through this practice.",
        "Think about timing, privacy, needed support and practical limits. What would be a suitable point to stop the conversation? If risk or pressure changes, pause and seek help rather than use rehearsal to push through it."
      ],
      "fields": [
        {
          "key": "contact-choice",
          "label": "Whether to communicate and a suitable method",
          "optional": true
        },
        {
          "key": "setting-and-limit",
          "label": "Timing, support and a suitable stopping point",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am only considering options",
        "text": "You can skip the communication and rehearsal groups or use the made-up example. Being undecided is not a failure to finish."
      }
    },
    {
      "id": "ending-relationships.practice.words",
      "title": "Prepare a clear and truthful message",
      "paragraphs": [
        "Using DEAR MAN as you have learned it, briefly describe what is relevant, say what you mean or feel, and state the decision or request. You can keep personal reasons brief. You do not need to prove that your choice is the only reasonable one.",
        "If there is a genuine helpful effect to mention, you may include it. Do not promise friendship, relief or a benefit you cannot know. Stay with the main point if the talk drifts. A clear message can be written, signed, spoken or supported by a communication aid."
      ],
      "fields": [
        {
          "key": "main-message",
          "label": "The words or communication I want to practise",
          "optional": true
        },
        {
          "key": "main-point",
          "label": "The main point I want to keep clear",
          "optional": true
        }
      ],
      "help": {
        "title": "If I do not know DEAR MAN yet",
        "text": "Use the example or return to therapist teaching first. This page applies a learned skill; it is not a replacement for learning the full communication method."
      }
    },
    {
      "id": "ending-relationships.practice.respect",
      "title": "Keep respect without giving up the choice",
      "paragraphs": [
        "Using GIVE and FAST as they fit, listen or acknowledge the other person’s view without attacks, threats or false agreement. Be fair to both people and truthful about your part. A real apology can fit if you caused harm; you need not apologize for having a need or boundary.",
        "What practical details could be discussed, and what decision is not open for debate? You can check whether your message was understood without requiring approval. Do not promise ongoing contact or negotiate away a choice just to end an uncomfortable moment."
      ],
      "fields": [
        {
          "key": "respect-and-values",
          "label": "How to be respectful, fair and truthful",
          "optional": true
        },
        {
          "key": "discussion-limits",
          "label": "Practical details to discuss and any settled limit",
          "optional": true
        }
      ],
      "help": {
        "title": "If the other person is upset",
        "text": "You can acknowledge that without taking charge of their feelings or changing your choice. Clear and respectful words cannot guarantee their response or prevent harm. New threats or fear need suitable support, not a better script."
      }
    },
    {
      "id": "ending-relationships.practice.rehearse",
      "title": "Actually rehearse without sending",
      "paragraphs": [
        "If the practice still fits, try the message once in a way that works for you: silently, aloud, in writing, signing or with a communication aid. Keep this page as a cue if useful. Use the planned method as closely as practical. Do not send a draft as part of rehearsal.",
        "Notice whether the decision, tone and practical limits are clear enough for your purpose. You can shorten or change the words. Preparing the words is different from running through the message. A silent, written, signed or aided run-through can be real rehearsal. Record only what you actually tried."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I actually rehearsed, or did not rehearse",
          "optional": true
        },
        {
          "key": "script-change",
          "label": "Anything to keep, shorten or change",
          "optional": true
        }
      ],
      "help": {
        "title": "If rehearsal feels too much",
        "text": "Stop or use the made-up example. You can practise later with your therapist. You do not need to repeat the words until distress goes away."
      }
    },
    {
      "id": "ending-relationships.practice.complications",
      "title": "Rehearse a manageable complication",
      "paragraphs": [
        "Choose one ordinary possible response within the agreed nonabusive situation, such as a question or request to reconsider. This is not a prediction. If it fits, actually rehearse your response while keeping the main point and any practical details separate.",
        "Also consider what you would do if you need time, cannot answer or want to stop the conversation. You may pause or seek support. Do not rehearse threats, abuse or a feared worst case alone. If someone threatens to hurt themselves or anyone else, seek urgent qualified support rather than manage it through this script. A new safety concern changes the plan."
      ],
      "fields": [
        {
          "key": "possible-response",
          "label": "One manageable possible response, or why I will not rehearse it",
          "optional": true
        },
        {
          "key": "rehearsed-response",
          "label": "What I actually rehearsed in response",
          "optional": true
        },
        {
          "key": "pause-or-support",
          "label": "How to pause or seek suitable support if needed",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot predict the response",
        "text": "You do not need to. Cope Ahead prepares a possible response; it cannot control another person. You may choose supported discussion instead of more rehearsal."
      }
    },
    {
      "id": "ending-relationships.practice.next",
      "title": "Choose a next step without pressure to act",
      "paragraphs": [
        "What fits now: more thought, therapist discussion, repair work, revising the plan, no action now, or a considered communication step? This page does not send anything or approve action. A plan is not a record that you acted.",
        "If you do communicate outside this page, keep needed support and practical duties in view. A single message may not settle a long or complex relationship. Follow-up details can need separate advice and time."
      ],
      "fields": [
        {
          "key": "next-step",
          "label": "My chosen next step, including no action or more support",
          "optional": true
        },
        {
          "key": "follow-through-support",
          "label": "Any practical or emotional support needed",
          "optional": true
        }
      ],
      "help": {
        "title": "If I keep caring about the person",
        "text": "That feeling can remain alongside a choice. Ask your therapist whether any separate work fits. This page does not teach opposite action for love or tell you to remove all contact and reminders."
      }
    },
    {
      "id": "ending-relationships.practice.review",
      "title": "Review what actually happened",
      "paragraphs": [
        "You can review without a plan or earlier notes. What did you actually do: read, consider, practise, communicate, pause or not act? Keep rehearsal separate from real contact. No opportunity and choosing not to act are different facts.",
        "If you communicated, what did you observe, what did you do and what remains unknown? Separate the other person’s words or actions from guesses about their motives. An unchanged or difficult outcome does not prove you lacked skill.",
        "What remains open: the decision, practical ties, support or another conversation? Do not assume agreement, safety or a fully ended relationship from completing this page. Bring new risk, unwanted effects or uncertainty to suitable support."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What I actually did or did not do",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What happened, if anything, and what is unknown",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What remains open or needs support",
          "optional": true
        }
      ],
      "help": {
        "title": "If the result was not what I wanted",
        "text": "Your skills do not control another person. Look at context and needs with your therapist rather than blaming yourself or repeating contact until you get agreement."
      }
    },
    {
      "id": "ending-relationships.practice.followup",
      "title": "Decide what support comes next",
      "paragraphs": [
        "With your therapist, consider what you learned and whether any next work fits. That might be practical planning, emotional support, a separate skill, a revised communication plan or leaving this practice for now.",
        "You can choose what, if anything, to bring to that discussion. No repeated contact, daily practice or progress report is required. This page does not set an alarm or tell anyone what you decided."
      ],
      "fields": [
        {
          "key": "followup-choice",
          "label": "What to keep, change, pause or discuss",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Any question or support to bring to therapy",
          "optional": true
        }
      ],
      "help": {
        "title": "If I am still undecided",
        "text": "You can leave the question open while seeking the support you need. Do not use repeated page completion as proof that you must make one particular choice."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 Interpersonal Effectiveness Handouts 13 and 13a",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed pp. 145–146: Wise Mind choice, possible repair, Cope Ahead, interpersonal skills, conditional opposite action for love and safety first.",
      "limits": "Historical Second Edition. No source forms, quiz, answer key or dated hotline details copied. Conditional opposite-action branch is deferred, not silently treated as completed."
    },
    {
      "id": "Linehan/Guilford: 2015 interpersonal teaching, section XIII",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Printed pp. 280–285: integrate existing skills, weigh choices, practical ties, suitable communication medium, actual rehearsal and possible complications; abusive situations need specialist safety planning.",
      "limits": "This bounded original adaptation is not a full DBT treatment, current revised-edition verification or evidence of digital efficacy."
    },
    {
      "id": "Linehan/Guilford: 2015 Interpersonal Effectiveness Worksheet 10",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed pp. 185–186 expressly bounds the ending script to unwanted nonabusive relationships; review choices and prepare a clear, respectful message.",
      "limits": "No source worksheet or line-by-line script reproduced. No abuse safety plan or automatic leave/stay decision."
    },
    {
      "id": "Specialist safety guidance: individualized support and safer technology use",
      "url": "https://www.thehotline.org/plan-for-safety/",
      "supports": "Safety planning is individualized; the person causing abuse is responsible for it.",
      "limits": "Checked 4 November 2026. This page is not a safety plan, abuse screening or a location-specific referral."
    },
    {
      "id": "Refuge: planning to leave",
      "url": "https://www.nationaldahelpline.org.uk/i-am-planning-to-leave-my-abuser/",
      "supports": "Leaving an abusive situation can increase danger and needs suitable specialist support.",
      "limits": "Checked 4 November 2026. No leaving checklist or service-specific eligibility recommendation reproduced."
    },
    {
      "id": "National Domestic Violence Hotline: internet safety",
      "url": "https://www.thehotline.org/plan-for-safety/internet-safety/",
      "supports": "Device use may be monitored and clearing app notes cannot guarantee an untraceable activity.",
      "limits": "Checked 4 November 2026. No claim that this app provides comprehensive digital safety."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal, communication access and meaningful support.",
      "limits": "Rights guidance, not validation of this clinical adaptation."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from an individual purchaser duplication licence.",
      "limits": "Openly accessible source text does not grant public app rights. Release-rights and clinician decisions remain open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Scope, choice, possible repair and practical dependencies",
      "sections": [
        "practice.situation",
        "practice.choice",
        "practice.repair",
        "practice.constraints",
        "practice.decision"
      ],
      "source": "Handout13; ManualXIII A–C; Worksheet10 nonabusive limit; original individual-fit and dependency safeguards"
    },
    {
      "operation": "Communication method, script and respectful settled versus negotiable details",
      "sections": [
        "practice.contact",
        "practice.words",
        "practice.respect"
      ],
      "source": "ManualXIII D–E; Worksheet10; learned DEAR MAN/GIVE/FAST, not their replacement"
    },
    {
      "operation": "Actual rehearsal, ordinary complication and voluntary next step",
      "sections": [
        "practice.rehearse",
        "practice.complications",
        "practice.next"
      ],
      "source": "ManualXIII D Cope Ahead and E communication; opposite action for love deferred entirely"
    },
    {
      "operation": "Honest actual-event review, ongoing ties and support",
      "sections": [
        "practice.review",
        "practice.followup"
      ],
      "source": "Original between-session adaptation of rehearsal and skills review; no decision, safety or outcome inference"
    }
  ],
  "narrationSegments": [
    {
      "id": "ending-relationships.intro",
      "title": "Considering a nonabusive situation with your therapist",
      "text": "This practice is for thinking about an unwanted relationship where abuse is not part of the situation. Use it after your therapist has helped you check the fit. It can help you consider choices or prepare words. It does not tell you to stay or leave.\n\nYou may be unsure, want to explore repair, or have chosen to end a part of a relationship. A practice plan is not a promise to act. Ending one kind of relationship may still leave practical ties to work through.\n\nThis uses skills you have learned with your therapist: Wise Mind, problem solving, Cope Ahead and clear, respectful communication. It does not teach every part of the source method. A separate skill for strong attachment is left for therapist guidance.",
      "sha256": "f40fb10e9c2f7e5d899818f89f7ccfb881573aaa3b4aefb222992c3df5724808",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.fit",
      "title": "Safety and support come before a script",
      "text": "Do not use this as a plan for abuse, threats, coercion, stalking or fear of retaliation. If you are unsure about safety, pause this practice and seek help from your therapist or a specialist who understands abuse. You do not need to prove abuse to ask for help.\n\nLeaving or telling someone you may leave can increase danger in an abusive situation. Do not confront someone to test safety. This page cannot assess risk or make a safety plan. For immediate danger, use local emergency help or your existing urgent support plan.\n\nCheck real ties such as care, money, housing, work, school, children or other shared duties with suitable support. This practice cannot settle legal rights or care duties. Support must fit your situation; involving relatives, carers or a joint meeting is not automatically safe.\n\nYour therapist can help choose an age-appropriate, accessible practice. Think, speak, sign or use a communication aid. If this feels overwhelming, pause, use agreed support or discuss it in therapy. You do not have to send a message or make a decision here.",
      "sha256": "f8f4618eaeb1123a869f8f935033fe6f507db3244e22156484c54df293f05d32",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.privacy",
      "title": "Keep private details out if that is safer",
      "text": "You can use the made-up example without entering personal details. A short label is enough. This tool records no voice and sends no notes or messages, but it cannot tell whether someone monitors your device, accounts or screen. Use a safer way to seek support if needed.\n\nOptional notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. That does not erase browser history, device activity or copies saved elsewhere, and it does not make your activity untraceable.\n\nHiding writing removes its private displays but keeps the text in this open page. Someone using the device or a screen reader may access it when shown. To keep notes, select only what you want, check the preview, then copy or download. Those copies stay where you put them.\n\nThe session shortcut works while this page stays open. It does not save answers or add a saved item to your usual Toolbox. You can finish without writing, saving or sharing anything.",
      "sha256": "25f975fa07168b44a08456b585c9a8c0cacdd2c59e07b77891a5fc26835e78d2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.close",
      "title": "Finish with your choice still your own",
      "text": "You may finish after reading, considering choices, rehearsing or reviewing. The page does not count this as an ended relationship or a completed conversation.\n\nIf useful, bring a question or chosen notes to your therapist. No message, report, reminder or plan is sent. Leaving clears notes in this tool, not activity or copies elsewhere.",
      "sha256": "b60fbe57a4c795f05e8b176b3f652f9e03994893a3d14434e26fb7f9f8ea4dfd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.example",
      "title": "Made-up example: changing a hobby partnership",
      "text": "Ari and a friend meet each week to make model buildings. Ari no longer wants this shared project, but would like to stay friendly. In this made-up situation, there are no threats or shared care, housing or money needs. The therapist has helped Ari check that the practice fits.\n\nAri considers continuing, trying a shorter project and ending the weekly partnership. They already tried shorter meetings, but Ari still wants to use the time differently. Ari chooses to end the shared project, not to demand that the friend agree or promise to stay friends.\n\nThere is a box of the friend’s supplies to return. Ari chooses a phone conversation that fits this ordinary situation and rehearses: \"I have decided to stop our weekly model project. My interests have changed. I would like to return your supplies. We can work out a suitable way to do that.\" No promise of friendship or benefit is used to soften the decision.\n\nAri actually practises saying the words, then rehearses a possible reply: \"Can we just meet less often?\" Ari tries: \"I hear that you would like to keep it going. I have decided to stop the project. I can still talk about returning the supplies.\" This is a possible response, not a prediction.\n\nIn the made-up follow-up, Ari has rehearsed but has not called. The first version felt too long, so Ari shortened it. The friend’s response, supply return and future friendship are unknown. Ari plans to check the next step in therapy. Rehearsal has not been counted as contact.",
      "sha256": "7ec61266c86c4ebb3701669d4dabf43787a1606031ff7675dda4e6ce7542c31a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.learn",
      "title": "A clear choice can still include care and uncertainty",
      "text": "Wise Mind brings feelings, facts, values and wider context into a choice. It is not a test of calm or a rule to distrust strong feelings. If the situation allows, take enough space to think before a major step. Do not delay urgent safety help to complete this exercise.\n\nFor an important nonabusive relationship, repair may be worth exploring if you want it and change seems possible. Repair is an option, not a duty or proof that you tried hard enough. Ending a relationship does not require a diagnosis or a verdict that someone is a bad person.\n\nDEAR MAN helps make your message clear. GIVE supports respectful attention to the other person. FAST helps you stay fair, truthful and close to your values. Use the parts you have learned that fit. Respect does not mean promising a benefit you do not believe or giving up your decision.\n\nYou may still feel care, grief, relief or doubt. Those feelings alone do not decide whether to stay or leave. The source also includes opposite action for love when it fits. That is a separate therapist-guided choice and skill, not taught here. This page does not prescribe avoiding someone or removing all reminders.",
      "sha256": "3de16c2c67fc2ba3ddc8ee917dc35f031f68aa8451bf7db1bb103f42ad32caf3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.situation",
      "title": "Name the question, not a verdict",
      "text": "Choose one nonabusive situation already checked with your therapist, or use Ari’s example. Briefly name the relationship and what you are considering. You do not need names, a full history or a label for the other person.\n\nWhat has actually happened, and what matters to you now? Keep observations separate from guesses about motives. If safety is uncertain or new concerns arise, stop planning the conversation and seek suitable support.",
      "sha256": "d666b3ef937a89081cb00289048fcc5c6b01eb20bc85610997aa899d298ca919",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.situation.help",
      "title": "If I am not sure this is nonabusive",
      "text": "You do not have to decide that alone. Pause the script and seek qualified support. Filling this page cannot confirm safety.",
      "sha256": "6e322b512096646c5866acecb0a629dc5dee7c994c86a408a87bed6e4dc0b316",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.choice",
      "title": "Consider staying, changing or ending",
      "text": "What are the realistic options? They might include continuing as things are, trying an agreed change, ending one part of the relationship, or taking more time with support. You do not need to choose every option or choose now.\n\nFor each option you are considering, look at possible helpful and difficult effects now and later. Include your values, needs, real duties and what remains unknown. A list is not a score that tells you what to do.",
      "sha256": "fb8089d30005af71eabce98f3c3249ae87438d6dcb555322e71c5411d76fb370",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.choice.help",
      "title": "If the costs seem too tangled",
      "text": "Bring them to your therapist or someone with the right expertise. Real dependence is not a lack of skill. Do not use this exercise to justify harm or make a choice under pressure.",
      "sha256": "c96f78e3e809aa60e87fb6099540d705716c962d6f6c9eb5064cc989c064ae33",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.repair",
      "title": "Consider repair only if it fits",
      "text": "If the relationship matters to you, is nonabusive and you want to explore repair, what specific change might help? Consider whether it is realistic, whether others would need to agree, and what has already been tried.\n\nUse problem solving you have learned with your therapist if that fits. Repair may involve a clear request or different arrangement, but you do not owe another attempt. If you do not want repair, or do not know, note that without inventing a plan.",
      "sha256": "a611315bd4e08eb22dbc7b635990e2c1ddeccbda104229a6dc9d805444cb6ac7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.repair.help",
      "title": "If someone says I must keep trying",
      "text": "You can consider your values and duties without accepting pressure to stay. Joint conversations or counselling are not automatically suitable, especially if safety is uncertain.",
      "sha256": "f5bc96a850caaa7f61b5dfc343daf8fe7c84d852e5112558f219a58dcc65bc39",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.constraints",
      "title": "Check practical ties and support",
      "text": "What would still need attention if the relationship changed? Think about shared belongings, agreed tasks, care needs or other real ties. Some situations need advice before any step; this page cannot decide legal, financial or care duties.\n\nWho could offer suitable, safe support, and what would you want help with? Keep shared details limited to what the support person needs to help. You do not need the other person’s permission to seek professional or safety support. Do not assume family, carers, colleagues or joint support are the right people for this situation.",
      "sha256": "7ca21eae26dec7393e0a20f0218c1ac766fe4f45911fc1c822f2e8dbc12cf3ec",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.constraints.help",
      "title": "If a young person or dependent person is involved",
      "text": "Work with an appropriate professional on care, consent, development and safeguarding. This page cannot arrange a safe change in care or decide who should be told.",
      "sha256": "a61e9f1f48303ba564dfe892eb335b250ec81875226f8475ac58bd5f501862e6",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.decision",
      "title": "State what is decided and what is not",
      "text": "Bring together the facts, feelings, values and options using the Wise Mind work you know. What, if anything, have you chosen? It is valid to be undecided, consider repair, pause or ask for more help.\n\nIf you have chosen to end a relationship or one part of it, describe that clearly. Keep it separate from details still open to discussion. Caring about the person or feeling sad does not require you to reverse a choice.",
      "sha256": "f85220af9b555ab9c3a7d09f2086cb92fd7ec6ccb7e7c53deac1bb7e23c7fcf9",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.decision.help",
      "title": "If strong feelings are here",
      "text": "Strong feelings carry information; they do not automatically make a choice wrong. Get enough support to consider the wider situation. Calm is not required, and urgent safety help should not wait.",
      "sha256": "2b219f3a280cb436a8d8a42aff63c95c0c6fdad4e963f50a035d3721a35035ef",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.contact",
      "title": "Choose whether and how to communicate",
      "text": "If a decision to communicate has been made and fits the agreed scope, consider a message, phone call, in-person talk or another accessible method. No method is always best, and you can choose not to contact someone through this practice.\n\nThink about timing, privacy, needed support and practical limits. What would be a suitable point to stop the conversation? If risk or pressure changes, pause and seek help rather than use rehearsal to push through it.",
      "sha256": "ee5fa8c4c58499f7be7ddf71b9d5d8a50e75255206a12cc41206a8efb975d794",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.contact.help",
      "title": "If I am only considering options",
      "text": "You can skip the communication and rehearsal groups or use the made-up example. Being undecided is not a failure to finish.",
      "sha256": "36f9ec8ee254d85d723f002213c4c9b99cb647ccdcf09a5c90ca5f4f62767eeb",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.words",
      "title": "Prepare a clear and truthful message",
      "text": "Using DEAR MAN as you have learned it, briefly describe what is relevant, say what you mean or feel, and state the decision or request. You can keep personal reasons brief. You do not need to prove that your choice is the only reasonable one.\n\nIf there is a genuine helpful effect to mention, you may include it. Do not promise friendship, relief or a benefit you cannot know. Stay with the main point if the talk drifts. A clear message can be written, signed, spoken or supported by a communication aid.",
      "sha256": "ce5e0b6af56c77899124718a08cae3dec9d2abc3deec55c0c5a4d2c03ecd7ba2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.words.help",
      "title": "If I do not know DEAR MAN yet",
      "text": "Use the example or return to therapist teaching first. This page applies a learned skill; it is not a replacement for learning the full communication method.",
      "sha256": "2cdb18640408cd4e764fbe9155475aa1621c123d193e0e9f61a9fe2ab32ca153",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.respect",
      "title": "Keep respect without giving up the choice",
      "text": "Using GIVE and FAST as they fit, listen or acknowledge the other person’s view without attacks, threats or false agreement. Be fair to both people and truthful about your part. A real apology can fit if you caused harm; you need not apologize for having a need or boundary.\n\nWhat practical details could be discussed, and what decision is not open for debate? You can check whether your message was understood without requiring approval. Do not promise ongoing contact or negotiate away a choice just to end an uncomfortable moment.",
      "sha256": "a6c56665e90c9d1d9f1120acc17ad9103d36a5c41559c22073cd49e4d4fb8aee",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.respect.help",
      "title": "If the other person is upset",
      "text": "You can acknowledge that without taking charge of their feelings or changing your choice. Clear and respectful words cannot guarantee their response or prevent harm. New threats or fear need suitable support, not a better script.",
      "sha256": "4975a99a061cb9bc059f5368b1d23ec90af430db6fe5ca3687a4e3f5de3e575a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.rehearse",
      "title": "Actually rehearse without sending",
      "text": "If the practice still fits, try the message once in a way that works for you: silently, aloud, in writing, signing or with a communication aid. Keep this page as a cue if useful. Use the planned method as closely as practical. Do not send a draft as part of rehearsal.\n\nNotice whether the decision, tone and practical limits are clear enough for your purpose. You can shorten or change the words. Preparing the words is different from running through the message. A silent, written, signed or aided run-through can be real rehearsal. Record only what you actually tried.",
      "sha256": "dfcc69c8af4e13fcd45342966969482de961a74e2b68d75912dcb33e2e4d89c0",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.rehearse.help",
      "title": "If rehearsal feels too much",
      "text": "Stop or use the made-up example. You can practise later with your therapist. You do not need to repeat the words until distress goes away.",
      "sha256": "1535891e3aab9367e324bb95d34d1c36fd6d8090de14c7d23312695c07370280",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.complications",
      "title": "Rehearse a manageable complication",
      "text": "Choose one ordinary possible response within the agreed nonabusive situation, such as a question or request to reconsider. This is not a prediction. If it fits, actually rehearse your response while keeping the main point and any practical details separate.\n\nAlso consider what you would do if you need time, cannot answer or want to stop the conversation. You may pause or seek support. Do not rehearse threats, abuse or a feared worst case alone. If someone threatens to hurt themselves or anyone else, seek urgent qualified support rather than manage it through this script. A new safety concern changes the plan.",
      "sha256": "2511dd4da747b0d1c2360f0f18d598dbfe0c2c9f3e9b1391e6c67088ef0268e2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.complications.help",
      "title": "If I cannot predict the response",
      "text": "You do not need to. Cope Ahead prepares a possible response; it cannot control another person. You may choose supported discussion instead of more rehearsal.",
      "sha256": "6a534b3ee05e9db7b286d659266a2c0e5a122c04b64203a4ee44d521540d9087",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.next",
      "title": "Choose a next step without pressure to act",
      "text": "What fits now: more thought, therapist discussion, repair work, revising the plan, no action now, or a considered communication step? This page does not send anything or approve action. A plan is not a record that you acted.\n\nIf you do communicate outside this page, keep needed support and practical duties in view. A single message may not settle a long or complex relationship. Follow-up details can need separate advice and time.",
      "sha256": "718488b3150aaca80215f8ef8baacaeb7370cc3461fd860979982f28bb310bec",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.next.help",
      "title": "If I keep caring about the person",
      "text": "That feeling can remain alongside a choice. Ask your therapist whether any separate work fits. This page does not teach opposite action for love or tell you to remove all contact and reminders.",
      "sha256": "5111afb65fbdc380016824d48fc4ba4b6ab75acf45621d414a1c215883ca06a9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.review",
      "title": "Review what actually happened",
      "text": "You can review without a plan or earlier notes. What did you actually do: read, consider, practise, communicate, pause or not act? Keep rehearsal separate from real contact. No opportunity and choosing not to act are different facts.\n\nIf you communicated, what did you observe, what did you do and what remains unknown? Separate the other person’s words or actions from guesses about their motives. An unchanged or difficult outcome does not prove you lacked skill.\n\nWhat remains open: the decision, practical ties, support or another conversation? Do not assume agreement, safety or a fully ended relationship from completing this page. Bring new risk, unwanted effects or uncertainty to suitable support.",
      "sha256": "1a553534edef08e47386ebf09b85fbd69e55d33fef5401f9be15c4eba35b22b6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.review.help",
      "title": "If the result was not what I wanted",
      "text": "Your skills do not control another person. Look at context and needs with your therapist rather than blaming yourself or repeating contact until you get agreement.",
      "sha256": "5dfa71f174b7d306ff0558acf34d85142888729781a5e466e57dbc642d16db31",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "ending-relationships.practice.followup",
      "title": "Decide what support comes next",
      "text": "With your therapist, consider what you learned and whether any next work fits. That might be practical planning, emotional support, a separate skill, a revised communication plan or leaving this practice for now.\n\nYou can choose what, if anything, to bring to that discussion. No repeated contact, daily practice or progress report is required. This page does not set an alarm or tell anyone what you decided.",
      "sha256": "b5f6be3fa01d15312c3bda40c59737fed833eaa4356815e7466fe9ae5cdf4fc7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "ending-relationships.practice.followup.help",
      "title": "If I am still undecided",
      "text": "You can leave the question open while seeking the support you need. Do not use repeated page completion as proof that you must make one particular choice.",
      "sha256": "278f72ea1b4aa9876493da9bdd6ed7418276a8868f2d0e8aded26d1e62be6413",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
