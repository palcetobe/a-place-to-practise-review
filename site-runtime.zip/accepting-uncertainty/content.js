window.BoundedSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/uncertainty",
  "version": "2026-11-02-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "title": "Accepting Uncertainty",
  "subtitle": "Make room for not knowing in an agreed everyday situation",
  "scope": "A brief, therapist-introduced acceptance practice for an agreed ordinary low-stakes uncertainty; not a self-directed exposure or response-prevention protocol.",
  "clinicalContract": {
    "learningObjective": "Distinguish a demand for a guarantee from a practical need for information or action.",
    "practiceObjective": "In an agreed low-stakes situation, notice the wish for certainty, allow the unanswered thought without continuing to solve it through worry, return attention to the present task, and review the response without requiring calm.",
    "observedPractice": "Private consideration or optional writing demonstrates rehearsal only. An attempt and a later review are distinct from planning. No symptom change, rating, typed response or additional task is required to finish.",
    "sourcePopulationContext": "CCI sources describe broader clinical methods, not validation of this digital adaptation or suitability across ages. Therapist selection and adaptation should account for development, communication, context, consent, privacy and safeguarding. Method-specific source populations and suitability limits still apply."
  },
  "privacy": {
    "id": "uncertainty.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Matched authored scripts only. Established voice; do not imply generated, listened or live audio. Private inputs never sent to narration.",
    "timer": "No timer required or proposed.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "entryFit": "Show full fit guidance before practice, with choices: Use my agreed everyday situation; Read the example instead; Leave this practice. First choice is self-report, not clinical clearance. Example/Learn more/Support remain accessible; no text entry required."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "sources": [
    {
      "id": "cci-uncertainty-module",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/What-Me-Worry/What-Me-Worry---09---Accepting-Uncertainty.pdf",
      "reviewed": "2026-11-02",
      "supports": "Need for certainty and worry; acceptance branch builds on earlier programme skills. Product does not deliver the full module or programme."
    },
    {
      "id": "cci-uncertainty-sheet",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Generalised-Anxiety/Generalised-Anxiety---Information-Sheets/Generalised-Anxiety-Information-Sheet---06---Accepting-Uncertainty.pdf",
      "reviewed": "2026-11-02",
      "supports": "Noticing the need for certainty, nonjudgmental observation and returning to present activity."
    },
    {
      "id": "cci-uncertainty-worksheet",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Generalised-Anxiety/Generalised-Anxiety---Worksheets/Generalised-Anxiety-Worksheet---03---Accepting-Uncertainty.pdf",
      "reviewed": "2026-11-02",
      "supports": "Observe rather than engage with or suppress worry; gently return when attention wanders."
    },
    {
      "id": "cci-worry-index",
      "url": "https://www.cci.health.wa.gov.au/Resources/For-Clinicians/Generalised-Anxiety-and-Worry",
      "reviewed": "2026-11-02",
      "supports": "Sequential programme context; separate problem-solving and worry-postponement components."
    }
  ],
  "productAdaptations": [
    "Narrow therapist-agreed ordinary low-stakes scope and visible no-health/safety-delay boundary; these are product safeguards, not quoted source protocol.",
    "Acceptance branch only, not a belief-challenging worksheet, behavioural experiment hierarchy or ERP.",
    "Original Lee example with ongoing uncertainty and actual return to reading.",
    "Optional note, no timer, rating, certainty/reassurance loop or automatic harder practice."
  ],
  "routeProposal": "tool/accepting-uncertainty",
  "intro": {
    "id": "uncertainty.intro",
    "title": "A place to begin",
    "paragraphs": [
      "Use this after your therapist has explained the skill and you have chosen a suitable everyday situation together.",
      "The aim is not to prove that everything will work out. It is to practise responding differently when a guarantee is unavailable. Feeling uncertain may remain."
    ]
  },
  "fit": {
    "id": "uncertainty.fit",
    "title": "Check the situation before practising",
    "paragraphs": [
      "Use only the ordinary, low-stakes situation agreed with your therapist.",
      "Do not use this to ignore symptoms, warning signs, consent, safety checks, real deadlines or information you need to act responsibly. Get necessary information or support instead.",
      "If you have not agreed a suitable practice, read the example and discuss it with your therapist. This page does not decide whether something is safe, or replace a tailored plan for compulsions or exposure work."
    ]
  },
  "learn": {
    "id": "uncertainty.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "Trying to think through every possible outcome can keep worry going without supplying a guarantee. Acceptance means allowing some not-knowing, not approving of a bad outcome or giving up practical action.",
      "You can notice the pull to get certain, let the unanswered thought be present, and bring attention back to what you are doing. Returning is the practice; keeping your mind perfectly still is not.",
      "This is different from postponing worry to a scheduled time. Here you practise making room for uncertainty in the moment, within the situation agreed with your therapist."
    ]
  },
  "example": {
    "id": "uncertainty.example",
    "title": "Example — choosing a novel",
    "paragraphs": [
      "With their therapist, Lee chooses an ordinary practice: starting a library novel without knowing whether it will be enjoyable. There is no important decision or safety check involved.",
      "Lee notices the thought, “What if I choose the wrong book?” and the pull to mentally compare every option again. Lee names the wish for a guarantee, lets the question remain unanswered, and starts reading the first page.",
      "The doubt returns. Lee notices it and returns to the next sentence without trying to settle which book is best. Afterwards, Lee is still unsure about the book, but notices having read while uncertain. No claim that the worry disappeared is needed."
    ]
  },
  "practice": [
    {
      "id": "uncertainty.practice.choose",
      "title": "Bring to mind the agreed situation",
      "paragraphs": [
        "What ordinary uncertainty did you and your therapist choose? Keep to that situation rather than moving to a harder or more important one.",
        "If new information, a practical responsibility or safety concern needs attention, stop this practice and respond to it."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The agreed everyday uncertainty",
          "optional": true
        }
      ],
      "help": {
        "title": "Not sure it fits?",
        "text": "Do not use this page to decide that a concern is harmless. Leave the practice and check with your therapist or the appropriate source of help."
      }
    },
    {
      "id": "uncertainty.practice.notice",
      "title": "Notice the demand for a guarantee",
      "paragraphs": [
        "What is your mind asking to know for sure? Notice the thought and the pull to keep working it out. You do not need to answer the thought."
      ],
      "fields": [
        {
          "key": "certainty",
          "label": "What I want to know for sure",
          "optional": true
        }
      ],
      "help": {
        "title": "If noticing becomes more analysing",
        "text": "Keep it brief: name the wish for certainty, then move to making room. You do not need to list every possible outcome."
      }
    },
    {
      "id": "uncertainty.practice.allow",
      "title": "Let the question remain for this moment",
      "paragraphs": [
        "In this agreed situation, try allowing the unanswered thought to be here without continuing the mental search for a guarantee. You might say, “I can let this be unknown for now.”",
        "You are not trying to push the thought away or make yourself feel certain. Use your own words, or no words."
      ],
      "help": {
        "title": "If the phrase becomes a reassurance ritual",
        "text": "You do not need to repeat it until it feels right. Leave the phrase aside and discuss the difficulty with your therapist if this keeps happening."
      }
    },
    {
      "id": "uncertainty.practice.return",
      "title": "Return to what you are doing",
      "paragraphs": [
        "Gently place attention on the present activity: the words you are reading, an ordinary sound, or the next part of your task. Let uncertainty come along.",
        "If attention returns to the unanswered question, notice that and return again. No special breathing, closed eyes or fixed practice length is required."
      ],
      "help": {
        "title": "If it feels too much",
        "text": "Pause or stop. This is not an endurance test or a reason to escalate to a harder situation. Use your agreed support plan or speak with your therapist."
      }
    },
    {
      "id": "uncertainty.practice.review",
      "title": "Notice the response you practised",
      "paragraphs": [
        "Did you notice the demand for certainty or return to your activity, even briefly? What got in the way? It is okay if uncertainty or discomfort stayed.",
        "You can bring one observation to your therapist. You do not need to choose another practice now."
      ],
      "fields": [
        {
          "key": "review",
          "label": "Something I noticed, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you kept worrying",
        "text": "That is information for review, not a failed test. Notice where you got caught and discuss whether the situation or guidance needs adjusting."
      }
    }
  ],
  "close": {
    "id": "uncertainty.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "You can finish without resolving the question or feeling calmer. Return to your ordinary activity or get support if needed; there is no next challenge to complete."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "narrationSegments": [
    {
      "id": "uncertainty.intro",
      "title": "A place to begin",
      "text": "Use this after your therapist has explained the skill and you have chosen a suitable everyday situation together.\n\nThe aim is not to prove that everything will work out. It is to practise responding differently when a guarantee is unavailable. Feeling uncertain may remain.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.fit",
      "title": "Check the situation before practising",
      "text": "Use only the ordinary, low-stakes situation agreed with your therapist.\n\nDo not use this to ignore symptoms, warning signs, consent, safety checks, real deadlines or information you need to act responsibly. Get necessary information or support instead.\n\nIf you have not agreed a suitable practice, read the example and discuss it with your therapist. This page does not decide whether something is safe, or replace a tailored plan for compulsions or exposure work.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.learn",
      "title": "Why this skill may help",
      "text": "Trying to think through every possible outcome can keep worry going without supplying a guarantee. Acceptance means allowing some not-knowing, not approving of a bad outcome or giving up practical action.\n\nYou can notice the pull to get certain, let the unanswered thought be present, and bring attention back to what you are doing. Returning is the practice; keeping your mind perfectly still is not.\n\nThis is different from postponing worry to a scheduled time. Here you practise making room for uncertainty in the moment, within the situation agreed with your therapist.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.example",
      "title": "Example — choosing a novel",
      "text": "With their therapist, Lee chooses an ordinary practice: starting a library novel without knowing whether it will be enjoyable. There is no important decision or safety check involved.\n\nLee notices the thought, “What if I choose the wrong book?” and the pull to mentally compare every option again. Lee names the wish for a guarantee, lets the question remain unanswered, and starts reading the first page.\n\nThe doubt returns. Lee notices it and returns to the next sentence without trying to settle which book is best. Afterwards, Lee is still unsure about the book, but notices having read while uncertain. No claim that the worry disappeared is needed.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.practice.choose",
      "title": "Bring to mind the agreed situation",
      "text": "What ordinary uncertainty did you and your therapist choose? Keep to that situation rather than moving to a harder or more important one.\n\nIf new information, a practical responsibility or safety concern needs attention, stop this practice and respond to it.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.practice.choose.help",
      "title": "Not sure it fits?",
      "text": "Do not use this page to decide that a concern is harmless. Leave the practice and check with your therapist or the appropriate source of help.",
      "status": "Script only"
    },
    {
      "id": "uncertainty.practice.notice",
      "title": "Notice the demand for a guarantee",
      "text": "What is your mind asking to know for sure? Notice the thought and the pull to keep working it out. You do not need to answer the thought.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.practice.notice.help",
      "title": "If noticing becomes more analysing",
      "text": "Keep it brief: name the wish for certainty, then move to making room. You do not need to list every possible outcome.",
      "status": "Script only"
    },
    {
      "id": "uncertainty.practice.allow",
      "title": "Let the question remain for this moment",
      "text": "In this agreed situation, try allowing the unanswered thought to be here without continuing the mental search for a guarantee. You might say, “I can let this be unknown for now.”\n\nYou are not trying to push the thought away or make yourself feel certain. Use your own words, or no words.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.practice.allow.help",
      "title": "If the phrase becomes a reassurance ritual",
      "text": "You do not need to repeat it until it feels right. Leave the phrase aside and discuss the difficulty with your therapist if this keeps happening.",
      "status": "Script only"
    },
    {
      "id": "uncertainty.practice.return",
      "title": "Return to what you are doing",
      "text": "Gently place attention on the present activity: the words you are reading, an ordinary sound, or the next part of your task. Let uncertainty come along.\n\nIf attention returns to the unanswered question, notice that and return again. No special breathing, closed eyes or fixed practice length is required.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.practice.return.help",
      "title": "If it feels too much",
      "text": "Pause or stop. This is not an endurance test or a reason to escalate to a harder situation. Use your agreed support plan or speak with your therapist.",
      "status": "Script only"
    },
    {
      "id": "uncertainty.practice.review",
      "title": "Notice the response you practised",
      "text": "Did you notice the demand for certainty or return to your activity, even briefly? What got in the way? It is okay if uncertainty or discomfort stayed.\n\nYou can bring one observation to your therapist. You do not need to choose another practice now.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.practice.review.help",
      "title": "If you kept worrying",
      "text": "That is information for review, not a failed test. Notice where you got caught and discuss whether the situation or guidance needs adjusting.",
      "status": "Script only"
    },
    {
      "id": "uncertainty.close",
      "title": "Leave it here for now",
      "text": "You can finish without resolving the question or feeling calmer. Return to your ordinary activity or get support if needed; there is no next challenge to complete.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "uncertainty.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    }
  ]
}
;
