window.DBTChoiceContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "improve.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "choiceMethods": {
      "selectorLabel": "Choose one IMPROVE option",
      "default": "No selected method. Show seven names with one short summary each in one accessible selector; not seven required screens.",
      "methodsSource": "methods array; exact authored teaching/example/help for each id.",
      "placement": "choice selector beside practice.choose; selected teaching and actual-action instructions beside practice.try, not hidden behind extra reading.",
      "learnExample": "Practice / See an example / Learn more remain adjacent. If selected, Example shows that method’s exact example; with none, show the global example labeled as one example only. Learn includes general rationale and selected method teaching, not all seven expansions.",
      "showAll": "Show all exposes shared steps plus the selected method only. Optional overview can list all seven summaries; do not auto-expand seven full practices.",
      "noSelection": "At try, show choice selector or read/finish options; do not choose a default or imply practice occurred.",
      "changingChoice": "Stop old-method playback and replace teaching/example/help with new exact branch. Retain endpoint/review notes without rewriting or relabeling them. If either note is nonempty when method changes, set a context-change notice that remains visible beside both note areas until those notes are cleared or the tool restarts. Never mark a newly selected method tried.",
      "choiceChangeNotice": "Your existing stopping-point or review notes may refer to an earlier option. They have not been changed. Choosing a new option does not mean you have tried it.",
      "exampleIdentity": "A global example reuses the exact selected-method example ID of its originating method, with that method label visible. Viewing this default example never selects that method or labels it practised.",
      "navigation": "Internal Back/Learn/Example retains explicit choice and notes. Clear/restart/reload/leave resets choice and clears notes/echoes. Direct jumps recheck selection; no inferred method from history.",
      "audio": "Only selected static method scripts eligible for matching controls; never auto-play, sequentially play all methods or narrate personal writing. Normal-practice activation requires separate approval.",
      "privacy": "All private entries hidden with writing; no score, mastery, method-completion badge or stored diary."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/improve",
  "title": "IMPROVE the Moment",
  "subtitle": "Choose one way of supporting yourself through this moment",
  "scope": "All seven named IMPROVE options offered as an ordinary-context choice set. Not a promise to improve emotion, a complete DBT programme or a requirement to use spiritual practice.",
  "version": "2026-11-03-distress-choice-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Explain how the selected IMPROVE method supports a difficult moment without forcing a silver lining, belief or calm.",
    "practiceObjective": "Choose one suitable method, actually try its specific action briefly if appropriate, then review its fit and the situation without requiring a changed feeling or new task.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Official 2015 Distress Tolerance handout 9 provides method identity and procedure.",
      "limits": "Original app wording/examples only; no copied worksheet. Current 2025 edition scope recognised separately; exact revised procedure not asserted identical. Adult framework does not validate this digital 16–17 adaptation."
    },
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-4teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Qualified-professional crisis-survival teaching: temporary tolerating of distress without making things worse; balance with appropriate practical response.",
      "limits": "Not a substitute for assessment, personal safety plan or complete DBT. Restricted reproduction licence; source suggestions narrowed for this ordinary-context adaptation."
    }
  ],
  "resourceId": "tool/improve-the-moment",
  "routeProposal": "tool/improve-the-moment",
  "groupedSetStatus": "Seven named options available; one chosen practice per visit. No new count per choice.",
  "intro": {
    "id": "improve.intro",
    "title": "Support the moment without forcing a change",
    "paragraphs": [
      "IMPROVE names several ways to make a difficult moment more bearable while it cannot be fixed immediately. The name is not a promise that your mood will improve.",
      "Choose one option, not a sequence of seven. Spiritual language, imagery and body attention are optional; there are secular choices that do not use them."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "improve.fit",
    "title": "Choose a method that fits you",
    "paragraphs": [
      "Use this after your therapist introduces it for an ordinary, manageable situation. Urgent safety, healthcare and essential responsibilities take priority over this practice.",
      "Respect health limits, sensory preferences, beliefs and boundaries. Do not force a memory, closed eyes, breathing change, physical stretch or warm feeling. Pause if a choice brings distress, disconnection, pain or pressure.",
      "A brief break is not abandoning a problem indefinitely. Check back at a suitable stopping point, or seek support when needed. This page does not monitor you or replace a personal support plan."
    ]
  },
  "learn": {
    "id": "improve.learn",
    "title": "Why use a specific method?",
    "paragraphs": [
      "The options work in different ways: Imagery, Meaning, Prayer, Relaxation, One Thing in the Moment, Vacation and Encouragement. They are alternatives, not duties.",
      "Choose one whose rationale fits, try its concrete action and notice whether it is useful, neutral or unhelpful. Selecting an option is not the same as practising it.",
      "The aim is supporting how you move through this moment, not proving a painful event was good, making thoughts disappear, or earning relief. Returning to the situation includes noticing whether practical help or support is needed."
    ]
  },
  "methods": [
    {
      "id": "imagery",
      "label": "Imagery",
      "summary": "Try a tolerable supportive mental scene.",
      "teaching": {
        "id": "improve.method.imagery",
        "title": "Imagery",
        "paragraphs": [
          "An image can offer a different mental context for a moment. This is optional imagination, not trauma processing or proof that you are safe.",
          "If imagery suits you, picture a simple personally tolerable scene, such as a quiet garden, with eyes open if preferred. Notice one detail briefly, then orient to where you actually are. No caregiver or safe-place memory is needed."
        ]
      },
      "example": {
        "id": "improve.example.imagery",
        "title": "Example — Imagery",
        "paragraphs": [
          "Mika imagines a simple garden path and notices the shape of one tree. Mika does not try to make the picture vivid.",
          "Mika then looks at the actual room. Tension remains, and Mika decides the brief image was tolerable rather than declaring it calming."
        ]
      },
      "help": {
        "id": "improve.help.imagery",
        "title": "If this option does not fit",
        "paragraphs": [
          "If imagery is difficult, upsetting or makes you feel disconnected, stop and choose a non-imagery option. A blank image is not failure."
        ]
      }
    },
    {
      "id": "meaning",
      "label": "Meaning",
      "summary": "Connect with a chosen reason for caring.",
      "teaching": {
        "id": "improve.method.meaning",
        "title": "Meaning",
        "paragraphs": [
          "Meaning here can be a small purpose you choose for how to meet this moment. It does not require finding a benefit in suffering or justifying harm.",
          "If useful, name one thing that matters in how you want to respond, such as being gentle with yourself during an ordinary setback. Hold that purpose briefly without requiring a plan or lesson from the event."
        ]
      },
      "example": {
        "id": "improve.example.meaning",
        "title": "Example — Meaning",
        "paragraphs": [
          "Mika faces an ordinary delay and chooses “I want to treat myself respectfully while I wait.”",
          "Mika returns to that purpose once. Impatience remains; Mika has not called the delay good or necessary."
        ]
      },
      "help": {
        "id": "improve.help.meaning",
        "title": "If this option does not fit",
        "paragraphs": [
          "If meaning feels forced, leave the question open. You do not owe anyone a silver lining, growth story or spiritual explanation."
        ]
      }
    },
    {
      "id": "prayer",
      "label": "Prayer",
      "summary": "Use prayer only if it fits your beliefs.",
      "teaching": {
        "id": "improve.method.prayer",
        "title": "Prayer",
        "paragraphs": [
          "In the source mnemonic, prayer can involve a spiritual source or one’s own Wise Mind. Neither belief nor prayer is required to use this skill set.",
          "If it fits you, use a brief personal prayer for support or strength, without demanding a particular outcome. A secular alternative is a quiet appeal to your own considered judgment; choosing another IMPROVE method is equally available."
        ]
      },
      "example": {
        "id": "improve.example.prayer",
        "title": "Example — Prayer",
        "paragraphs": [
          "Prayer fits Mika’s beliefs, so Mika offers a brief familiar prayer for steadiness without asking for a guaranteed outcome.",
          "Mika then returns attention to the actual situation. Distress remains; the prayer was a chosen support, not a test of faith or a promise of relief."
        ]
      },
      "help": {
        "id": "improve.help.prayer",
        "title": "If this option does not fit",
        "paragraphs": [
          "Skip this if the language conflicts with your beliefs or experiences. Do not promise protection, healing or a guaranteed answer."
        ]
      }
    },
    {
      "id": "relaxation",
      "label": "Relaxation",
      "summary": "Make one comfortable settling adjustment.",
      "teaching": {
        "id": "improve.method.relaxation",
        "title": "Relaxation",
        "paragraphs": [
          "A gentle relaxing action may reduce unnecessary effort in the moment. It is not a demand to relax your whole body.",
          "If suitable, adjust a supported sitting or resting position for comfort, or let a hand rest without gripping. Keep breathing ordinary; no muscle-tensing sequence, stretching through pain or held technique is required."
        ]
      },
      "example": {
        "id": "improve.example.relaxation",
        "title": "Example — Relaxation",
        "paragraphs": [
          "Mika notices an uncomfortable sitting position and adjusts the chair support. Mika lets a hand rest on the table rather than gripping it.",
          "The position feels more comfortable, although worry remains. Mika stops there; this was not a PMR session."
        ]
      },
      "help": {
        "id": "improve.help.relaxation",
        "title": "If this option does not fit",
        "paragraphs": [
          "Follow health advice and avoid painful movement. If body attention is not useful, choose a non-body option. This does not introduce PMR or paired muscle relaxation."
        ]
      }
    },
    {
      "id": "one-thing",
      "label": "One Thing in the Moment",
      "summary": "Attend to the one ordinary thing happening now.",
      "teaching": {
        "id": "improve.method.one-thing",
        "title": "One Thing in the Moment",
        "paragraphs": [
          "A single focus can reduce the extra burden of trying to handle every future issue at once. It does not require a blank mind.",
          "Choose a safe ordinary activity already happening, such as putting a book on a shelf. Attend to that action and return when attention wanders. Finish that small moment before checking what else needs attention."
        ]
      },
      "example": {
        "id": "improve.example.one-thing",
        "title": "Example — One Thing in the Moment",
        "paragraphs": [
          "Mika puts one book away, noticing the shelf and the movement. A later worry appears, and Mika returns attention to the current action.",
          "After the book is placed, Mika checks the situation again. The future worry has not been solved."
        ]
      },
      "help": {
        "id": "improve.help.one-thing",
        "title": "If this option does not fit",
        "paragraphs": [
          "Use an accessible external focus if body awareness is uncomfortable. Do not narrow attention while driving or doing a safety-critical task."
        ]
      }
    },
    {
      "id": "vacation",
      "label": "Vacation",
      "summary": "Take a brief, safe break from a non-urgent demand.",
      "teaching": {
        "id": "improve.method.vacation",
        "title": "Vacation",
        "paragraphs": [
          "Vacation here means a small intentional respite, not a trip, purchase or abandoning responsibilities. A clear return point helps keep it a break.",
          "If responsibilities and safety allow, pause a non-urgent task for a short familiar rest. Choose an ordinary endpoint before starting, then check back. Do not turn off essential alerts or leave someone without needed care."
        ]
      },
      "example": {
        "id": "improve.example.vacation",
        "title": "Example — Vacation",
        "paragraphs": [
          "Mika pauses a non-urgent task until the end of a short rest on a nearby chair. Necessary responsibilities remain covered.",
          "At the endpoint Mika checks what needs attention. Tiredness remains, and Mika can decide whether support or an adjustment is needed."
        ]
      },
      "help": {
        "id": "improve.help.vacation",
        "title": "If this option does not fit",
        "paragraphs": [
          "If a safe break is not possible now, choose another option or seek practical help. Do not create guilt by setting an unrealistic return rule."
        ]
      }
    },
    {
      "id": "encouragement",
      "label": "Encouragement",
      "summary": "Try a believable supportive sentence.",
      "teaching": {
        "id": "improve.method.encouragement",
        "title": "Encouragement",
        "paragraphs": [
          "Encouragement offers a respectful way of speaking to yourself without claiming everything will be fine. It is not compulsory positive thinking.",
          "Try one credible sentence, such as “I can take this one moment at a time, and ask for support.” Say or think it once if useful, then notice its fit. You do not need to repeat it until it feels true."
        ]
      },
      "example": {
        "id": "improve.example.encouragement",
        "title": "Example — Encouragement",
        "paragraphs": [
          "Mika tries “Everything will be fine” and finds it unconvincing. Mika changes it to “I do not have to solve every part right now.”",
          "The revised sentence fits better, though distress remains. Mika stops rather than repeating it to force relief."
        ]
      },
      "help": {
        "id": "improve.help.encouragement",
        "title": "If this option does not fit",
        "paragraphs": [
          "Use plain respectful words or skip the sentence if it feels false. Encouragement never requires staying in harm or managing alone."
        ]
      }
    }
  ],
  "example": {
    "id": "improve.example.encouragement",
    "title": "Example — Encouragement",
    "paragraphs": [
      "Mika tries “Everything will be fine” and finds it unconvincing. Mika changes it to “I do not have to solve every part right now.”",
      "The revised sentence fits better, though distress remains. Mika stops rather than repeating it to force relief."
    ]
  },
  "practiceScenario": {
    "id": "improve.scenario",
    "title": "If you prefer a fictional rehearsal",
    "paragraphs": [
      "Mika is facing an ordinary delay, with no urgent duty being neglected. Mika wants a way to support this moment without pretending the problem has disappeared.",
      "Choose an option and consider its fit for Mika. A fictional rehearsal or reading is different from trying the method yourself."
    ]
  },
  "practice": [
    {
      "id": "improve.practice.choose",
      "title": "Choose one option and a stopping point",
      "paragraphs": [
        "Choose one method that fits this situation and your therapist’s guidance. You do not need to try them all or select the perfect one.",
        "Before trying, choose a brief ordinary stopping point at which to check back. If urgent help or a necessary action cannot wait, attend to that instead."
      ],
      "fields": [
        {
          "key": "endpoint",
          "label": "A suitable stopping point, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If choosing feels like too much",
        "text": "Read one example, use a familiar method already agreed with your therapist, or finish. No option is automatically selected for you."
      }
    },
    {
      "id": "improve.practice.try",
      "title": "Try the selected method",
      "paragraphs": [
        "Use the instructions for your selected option below. Try only as much as is suitable; stop or change choice if it does not fit.",
        "A thought or feeling may remain. The aim is not to keep practising until it disappears."
      ],
      "help": {
        "title": "Reading is also allowed",
        "text": "You can read the selected example or rehearse it privately instead. Do not label that as a completed personal practice."
      }
    },
    {
      "id": "improve.practice.review",
      "title": "Check back and review",
      "paragraphs": [
        "At your stopping point, notice what you actually tried and whether it was useful, neutral, uncomfortable or unclear. A changed feeling is not required.",
        "Check the situation again: does anything need attention or support now? You can keep that question open. This is not a new task list or an instruction to solve everything."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I tried or noticed, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you keep extending the break",
        "text": "Notice the pattern without blame. If a needed response keeps being deferred, pause the distraction or break and review with your therapist or other appropriate support."
      }
    }
  ],
  "close": {
    "id": "improve.close",
    "title": "Finish without a required result",
    "paragraphs": [
      "You can finish after reading, trying or stopping. Keep only what fits. There is no required rating, new plan or improved feeling."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "All seven named source options available, each with original taught action, example and help; one selected practice plus return review, not seven compulsory tasks.",
    "Ordinary therapist-introduced context; no emergency assessment or full DBT claim. Short-term endpoint and no-relief requirement are explicit product teaching adaptations.",
    "Prayer accurately named and optional; source Wise Mind alternative explained without labeling secular reflection religious prayer. Meaning does not require positive reinterpretation of harm; Relaxation uses a comfortable adjustment only, not held PMR/paired relaxation; Vacation is brief and safe; encouragement avoids guarantees."
  ],
  "narrationSegments": [
    {
      "id": "improve.intro",
      "title": "Support the moment without forcing a change",
      "text": "IMPROVE names several ways to make a difficult moment more bearable while it cannot be fixed immediately. The name is not a promise that your mood will improve.\n\nChoose one option, not a sequence of seven. Spiritual language, imagery and body attention are optional; there are secular choices that do not use them.",
      "status": "Script only"
    },
    {
      "id": "improve.fit",
      "title": "Choose a method that fits you",
      "text": "Use this after your therapist introduces it for an ordinary, manageable situation. Urgent safety, healthcare and essential responsibilities take priority over this practice.\n\nRespect health limits, sensory preferences, beliefs and boundaries. Do not force a memory, closed eyes, breathing change, physical stretch or warm feeling. Pause if a choice brings distress, disconnection, pain or pressure.\n\nA brief break is not abandoning a problem indefinitely. Check back at a suitable stopping point, or seek support when needed. This page does not monitor you or replace a personal support plan.",
      "status": "Script only"
    },
    {
      "id": "improve.learn",
      "title": "Why use a specific method?",
      "text": "The options work in different ways: Imagery, Meaning, Prayer, Relaxation, One Thing in the Moment, Vacation and Encouragement. They are alternatives, not duties.\n\nChoose one whose rationale fits, try its concrete action and notice whether it is useful, neutral or unhelpful. Selecting an option is not the same as practising it.\n\nThe aim is supporting how you move through this moment, not proving a painful event was good, making thoughts disappear, or earning relief. Returning to the situation includes noticing whether practical help or support is needed.",
      "status": "Script only"
    },
    {
      "id": "improve.example.encouragement",
      "title": "Example — Encouragement",
      "text": "Mika tries “Everything will be fine” and finds it unconvincing. Mika changes it to “I do not have to solve every part right now.”\n\nThe revised sentence fits better, though distress remains. Mika stops rather than repeating it to force relief.",
      "status": "Script only"
    },
    {
      "id": "improve.scenario",
      "title": "If you prefer a fictional rehearsal",
      "text": "Mika is facing an ordinary delay, with no urgent duty being neglected. Mika wants a way to support this moment without pretending the problem has disappeared.\n\nChoose an option and consider its fit for Mika. A fictional rehearsal or reading is different from trying the method yourself.",
      "status": "Script only"
    },
    {
      "id": "improve.practice.choose",
      "title": "Choose one option and a stopping point",
      "text": "Choose one method that fits this situation and your therapist’s guidance. You do not need to try them all or select the perfect one.\n\nBefore trying, choose a brief ordinary stopping point at which to check back. If urgent help or a necessary action cannot wait, attend to that instead.",
      "status": "Script only"
    },
    {
      "id": "improve.practice.choose.help",
      "title": "If choosing feels like too much",
      "text": "Read one example, use a familiar method already agreed with your therapist, or finish. No option is automatically selected for you.",
      "status": "Script only"
    },
    {
      "id": "improve.practice.try",
      "title": "Try the selected method",
      "text": "Use the instructions for your selected option below. Try only as much as is suitable; stop or change choice if it does not fit.\n\nA thought or feeling may remain. The aim is not to keep practising until it disappears.",
      "status": "Script only"
    },
    {
      "id": "improve.practice.try.help",
      "title": "Reading is also allowed",
      "text": "You can read the selected example or rehearse it privately instead. Do not label that as a completed personal practice.",
      "status": "Script only"
    },
    {
      "id": "improve.practice.review",
      "title": "Check back and review",
      "text": "At your stopping point, notice what you actually tried and whether it was useful, neutral, uncomfortable or unclear. A changed feeling is not required.\n\nCheck the situation again: does anything need attention or support now? You can keep that question open. This is not a new task list or an instruction to solve everything.",
      "status": "Script only"
    },
    {
      "id": "improve.practice.review.help",
      "title": "If you keep extending the break",
      "text": "Notice the pattern without blame. If a needed response keeps being deferred, pause the distraction or break and review with your therapist or other appropriate support.",
      "status": "Script only"
    },
    {
      "id": "improve.close",
      "title": "Finish without a required result",
      "text": "You can finish after reading, trying or stopping. Keep only what fits. There is no required rating, new plan or improved feeling.",
      "status": "Script only"
    },
    {
      "id": "improve.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    },
    {
      "id": "improve.method.imagery",
      "title": "Imagery",
      "text": "An image can offer a different mental context for a moment. This is optional imagination, not trauma processing or proof that you are safe.\n\nIf imagery suits you, picture a simple personally tolerable scene, such as a quiet garden, with eyes open if preferred. Notice one detail briefly, then orient to where you actually are. No caregiver or safe-place memory is needed.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.example.imagery",
      "title": "Example — Imagery",
      "text": "Mika imagines a simple garden path and notices the shape of one tree. Mika does not try to make the picture vivid.\n\nMika then looks at the actual room. Tension remains, and Mika decides the brief image was tolerable rather than declaring it calming.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.help.imagery",
      "title": "If this option does not fit",
      "text": "If imagery is difficult, upsetting or makes you feel disconnected, stop and choose a non-imagery option. A blank image is not failure.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.method.meaning",
      "title": "Meaning",
      "text": "Meaning here can be a small purpose you choose for how to meet this moment. It does not require finding a benefit in suffering or justifying harm.\n\nIf useful, name one thing that matters in how you want to respond, such as being gentle with yourself during an ordinary setback. Hold that purpose briefly without requiring a plan or lesson from the event.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.example.meaning",
      "title": "Example — Meaning",
      "text": "Mika faces an ordinary delay and chooses “I want to treat myself respectfully while I wait.”\n\nMika returns to that purpose once. Impatience remains; Mika has not called the delay good or necessary.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.help.meaning",
      "title": "If this option does not fit",
      "text": "If meaning feels forced, leave the question open. You do not owe anyone a silver lining, growth story or spiritual explanation.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.method.prayer",
      "title": "Prayer",
      "text": "In the source mnemonic, prayer can involve a spiritual source or one’s own Wise Mind. Neither belief nor prayer is required to use this skill set.\n\nIf it fits you, use a brief personal prayer for support or strength, without demanding a particular outcome. A secular alternative is a quiet appeal to your own considered judgment; choosing another IMPROVE method is equally available.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.example.prayer",
      "title": "Example — Prayer",
      "text": "Prayer fits Mika’s beliefs, so Mika offers a brief familiar prayer for steadiness without asking for a guaranteed outcome.\n\nMika then returns attention to the actual situation. Distress remains; the prayer was a chosen support, not a test of faith or a promise of relief.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.help.prayer",
      "title": "If this option does not fit",
      "text": "Skip this if the language conflicts with your beliefs or experiences. Do not promise protection, healing or a guaranteed answer.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.method.relaxation",
      "title": "Relaxation",
      "text": "A gentle relaxing action may reduce unnecessary effort in the moment. It is not a demand to relax your whole body.\n\nIf suitable, adjust a supported sitting or resting position for comfort, or let a hand rest without gripping. Keep breathing ordinary; no muscle-tensing sequence, stretching through pain or held technique is required.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.example.relaxation",
      "title": "Example — Relaxation",
      "text": "Mika notices an uncomfortable sitting position and adjusts the chair support. Mika lets a hand rest on the table rather than gripping it.\n\nThe position feels more comfortable, although worry remains. Mika stops there; this was not a PMR session.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.help.relaxation",
      "title": "If this option does not fit",
      "text": "Follow health advice and avoid painful movement. If body attention is not useful, choose a non-body option. This does not introduce PMR or paired muscle relaxation.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.method.one-thing",
      "title": "One Thing in the Moment",
      "text": "A single focus can reduce the extra burden of trying to handle every future issue at once. It does not require a blank mind.\n\nChoose a safe ordinary activity already happening, such as putting a book on a shelf. Attend to that action and return when attention wanders. Finish that small moment before checking what else needs attention.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.example.one-thing",
      "title": "Example — One Thing in the Moment",
      "text": "Mika puts one book away, noticing the shelf and the movement. A later worry appears, and Mika returns attention to the current action.\n\nAfter the book is placed, Mika checks the situation again. The future worry has not been solved.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.help.one-thing",
      "title": "If this option does not fit",
      "text": "Use an accessible external focus if body awareness is uncomfortable. Do not narrow attention while driving or doing a safety-critical task.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.method.vacation",
      "title": "Vacation",
      "text": "Vacation here means a small intentional respite, not a trip, purchase or abandoning responsibilities. A clear return point helps keep it a break.\n\nIf responsibilities and safety allow, pause a non-urgent task for a short familiar rest. Choose an ordinary endpoint before starting, then check back. Do not turn off essential alerts or leave someone without needed care.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.example.vacation",
      "title": "Example — Vacation",
      "text": "Mika pauses a non-urgent task until the end of a short rest on a nearby chair. Necessary responsibilities remain covered.\n\nAt the endpoint Mika checks what needs attention. Tiredness remains, and Mika can decide whether support or an adjustment is needed.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.help.vacation",
      "title": "If this option does not fit",
      "text": "If a safe break is not possible now, choose another option or seek practical help. Do not create guilt by setting an unrealistic return rule.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.method.encouragement",
      "title": "Encouragement",
      "text": "Encouragement offers a respectful way of speaking to yourself without claiming everything will be fine. It is not compulsory positive thinking.\n\nTry one credible sentence, such as “I can take this one moment at a time, and ask for support.” Say or think it once if useful, then notice its fit. You do not need to repeat it until it feels true.",
      "status": "Selected-method static script only"
    },
    {
      "id": "improve.help.encouragement",
      "title": "If this option does not fit",
      "text": "Use plain respectful words or skip the sentence if it feels false. Encouragement never requires staying in harm or managing alone.",
      "status": "Selected-method static script only"
    }
  ]
}
;
