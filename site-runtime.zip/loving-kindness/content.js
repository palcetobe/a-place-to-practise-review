window.LovingKindnessContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/mindful",
  "componentId": "component/mindful/loving-kindness",
  "resourceId": "tool/loving-kindness",
  "routeProposal": "/loving-kindness/",
  "title": "Loving-Kindness",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Practise kind wishes for yourself or someone you choose, with attention to their meaning and freedom to stop.",
  "groupedSetStatus": "Existing uncounted Loving-Kindness component under DBT Mindfulness. Complete bounded introductory practice, not the literal Handout8 sequence, a complete progressive programme or the whole mindfulness set. Distinct from a compassionate letter, thought diary, kind action or affirmation. No new canonical count.",
  "clinicalContract": {
    "learningObjective": "Distinguish deliberate benevolent wishes from facts, promises, forced feelings, moral duty, contact or forgiveness; keep recipient choice and protective action intact.",
    "practiceObjective": "Choose a suitable willing recipient and meaningful varied set of wishes, prepare in an accessible way, repeat with attention to meaning, notice wandering and return if useful, optionally widen only as agreed, close and review actual use/non-use.",
    "sourcePopulationContext": "2015 author/publisher DBT teaching establishes the method, not this app’s efficacy, latest-edition fidelity or universal suitability. No age floor. Therapist checks individual clinical, developmental, cultural/spiritual, communication, safeguarding and access fit.",
    "exclusions": [
      "No forced compassion for unwanted, difficult or harmful recipients",
      "No forgiveness, reconciliation, contact, disclosure or abandonment of boundaries required",
      "No promise that wishes change another person, establish safety or remove distress",
      "No compulsory imagery, closed eyes, breath change, palm position or bodily feeling",
      "No repetition until warmth, certainty, purity or calm; no daily quota or escalating recipient ladder",
      "No replacing real care, protection, advocacy, practical help or an agreed care plan",
      "No automatic message, timer, saved practice, spiritual claim, score or inferred outcome"
    ],
    "adaptations": [
      "Original wording, four illustrative wishes and fictional example; no publisher script or worksheet copied",
      "Retains a varied meaningful set, actual repetition, attention-return, recipient choice, optional widening, closing and review",
      "Visualization is optional in the teaching notes; this candidate supports a simple idea of the recipient rather than requiring an image",
      "Slow/deep preparatory breathing and open palms from Handout8 are omitted in favour of ordinary breathing and a comfortable accessible position",
      "A chosen bounded ending replaces the Handout8 instruction to continue until immersed; no emotional endpoint is inferred",
      "No daily quota or compulsory progression through difficult people/enemies; wider recipient teaching remains visible and optional",
      "Non-imagery and bounded practice is an explicitly adapted introduction, not a claim of validated equivalence to the full source programme"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of the stated introductory scope and breath/palm/ending/dose adaptations; source-use rights",
      "Individual clinical, developmental, cultural/spiritual, communication, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not a validated reading level",
      "Integrated desktop/mobile/keyboard/screen-reader and notes/navigation/lifecycle acceptance",
      "Authorized narration generation, exact-script listening and binding/control review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose practice or review",
      "options": [
        {
          "value": "prepare",
          "label": "Prepare and practise kind wishes",
          "startSectionId": "loving-kindness.practice.intention"
        },
        {
          "value": "review",
          "label": "Review a practice or no use",
          "startSectionId": "loving-kindness.practice.review"
        }
      ]
    },
    "entryGate": "Scope and safety visible before selection. No recipient or clinical fit approved by the page.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing or completed sequence.",
    "reviewAccess": "Direct blank review without a stored plan, claimed repetition or inferred attempt. Both modes expose all groups.",
    "writing": "Optional, hidden initially, never filled by fiction. Hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static public teaching/help only; never private wishes or notes. No audio, TTS, recording upload or autoplay.",
    "timer": "None. No automatic repetitions, count, schedule, daily dose or emotional endpoint.",
    "completion": "No inferred meditation, repetition, wider recipient, kindness, warmth, safety, contact or improvement."
  },
  "intro": {
    "id": "loving-kindness.intro",
    "title": "Offer wishes without forcing a feeling",
    "paragraphs": [
      "Loving-kindness is a practice of offering good wishes. You choose words that express care for yourself or another person, repeat them with attention to their meaning, and gently return when your mind wanders.",
      "A wish is not a statement that life is already easy or that something will happen. You can wish someone well while a difficult feeling remains. This page does not ask you to love everyone, forgive harm or feel warm on demand.",
      "This is an introductory practice after teaching with your therapist. You can prepare, try the wishes if they fit, stop and review. You can also read the example or finish without practising."
    ]
  },
  "fit": {
    "id": "loving-kindness.fit",
    "title": "Use a willing choice and keep your limits",
    "paragraphs": [
      "Choose this with your therapist, who can check whether it fits your needs, beliefs and stage of learning. If kindness practice brings up grief, shame, painful memories, feeling unreal or repeated upsetting thoughts, pause and discuss what support or a different practice would fit.",
      "Do not choose someone you do not want to offer kindness toward. You do not need to include a person who harmed you, imagine a painful scene or work up to a difficult person. Wishing well is not excusing harm, giving consent, forgiving, making contact or giving up protection.",
      "You may keep your eyes open, use an ordinary comfortable position and breathe as usual. No image, hand pose, touch, special breathing or body focus is needed here. If focusing inward is not helpful, stop and return attention to the room or seek support.",
      "Use words and a form of communication that make sense to you. You may think, read, sign or speak quietly. No spiritual belief or ritual is required. This is not urgent support, a safety plan or a reason to delay needed care or action."
    ]
  },
  "privacy": {
    "id": "loving-kindness.privacy",
    "title": "Keep your choice and wishes private if you want",
    "paragraphs": [
      "You can practise without writing or use your own paper. Optional notes are here only if useful. A label such as \"myself\" or \"someone I care about\" is enough; no name or personal history is needed. This tool records no voice and sends no wishes, messages or notes to anyone.",
      "Notes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep selected notes, check their preview, then copy or download. The page does not save a practice for later.",
      "A shared device, screen reader or outside copy may expose your words. Skill narration reads only the public teaching, never your private wishes or notes. Outside copies remain until you remove them. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "loving-kindness.close",
    "title": "Finish without an emotional target",
    "paragraphs": [
      "Reading, choosing words and actually repeating them are different. You can finish at any point. You do not need warmth, calm, forgiveness or wishes for more people.",
      "If you want a copy, choose and check the notes you keep. Finish and clear removes notes here, not outside copies. Bring any useful observation or concern to your therapist in your own way."
    ]
  },
  "example": {
    "id": "loving-kindness.example",
    "title": "Robin tries a set of wishes",
    "paragraphs": [
      "This is made up. Robin and the therapist have discussed a brief loving-kindness practice. Starting with wishes for themself feels too painful today. Robin willingly chooses a friend they already care about, without needing to picture the friend.",
      "Robin chooses four wishes: \"May you find care in hard times. May there be room for rest. May you have moments you enjoy. May you be treated with kindness.\" They express support, rest, enjoyment and care from others. Robin knows the wishes do not make these things happen.",
      "Robin stays seated with eyes open and ordinary breathing. Robin actually reads the four wishes slowly, then repeats the set quietly, attending to what each means. When a shopping thought appears, Robin notices it and returns to the next wish rather than restarting to get it perfect.",
      "After another chosen round Robin notices sadness. Robin stops, looks at the shelf nearby and lets the exercise end. Robin does not add another person or keep repeating until warmth appears. No message has been sent to the friend.",
      "In review Robin notes the actual repetition, the wandering thought and sadness. The words about rest felt easier than the first line. Robin will discuss whether to change that line or use another practice. A future change is not recorded as already tried."
    ]
  },
  "learn": {
    "id": "loving-kindness.learn",
    "title": "Kind wishes are an intention, not a test",
    "paragraphs": [
      "Loving-kindness has roots in Buddhist meditation and is also used in DBT. People may practise it with or without a spiritual meaning. It is your choice whether it fits your beliefs; the page makes no claim about sending a force or changing another person.",
      "A compassionate letter or diary puts caring words around a particular experience. A kind action is something you do. Here the distinct practice is a small varied set of good wishes, repeated with attention to meaning. It is not a demand to believe positive statements about yourself.",
      "The source method can broaden from yourself or a loved person to others and wider groups. It also describes people who bring difficult feelings. That is not a ladder everyone must climb. You can stay with a willing choice; difficult or harmful people are not an assignment here.",
      "This version does not change breathing or hand position, require imagery, set a daily quota or continue until a feeling appears. Those are explicit delivery choices for a bounded introduction, not a claim to reproduce every step of the 2015 handout.",
      "A practice can feel caring, neutral, awkward or painful. None of those feelings proves your worth or intentions. Your therapist can help decide whether the words, who they are for, the amount or the practice itself should change."
    ]
  },
  "practice": [
    {
      "id": "loving-kindness.practice.intention",
      "title": "Choose what you want to practise",
      "paragraphs": [
        "What would you like to practise: offering care, softening a harsh stance if you want to, or learning how kind wishes feel to use? Keep the aim as something you can choose, not a promise that you or someone else will change.",
        "Notice if the task has become \"I must feel loving\" or \"These words must make things safe.\" A wish cannot guarantee either. You may discuss that pressure with your therapist rather than trying harder to produce a feeling."
      ],
      "fields": [
        {
          "key": "intention",
          "label": "What I want to practise, or why I am not trying today",
          "optional": true
        },
        {
          "key": "expectation",
          "label": "Any pressure or expectation to check",
          "optional": true
        }
      ],
      "help": {
        "title": "If the practice feels like a moral duty",
        "text": "You do not have to use it to prove you are kind or a good person. You can choose another practice, ask for help or stop."
      }
    },
    {
      "id": "loving-kindness.practice.recipient",
      "title": "Choose whom you want to offer wishes toward",
      "paragraphs": [
        "Choose yourself if that feels suitable, or a person you already care about and genuinely want to wish well. Use a choice you and your therapist have considered. No detailed memory, face or name is needed.",
        "Notice whether this choice feels workable today. Caring about someone can still bring painful memories or grief. You can choose differently, leave the choice undecided or stop. Do not pick someone because you think you should forgive them."
      ],
      "fields": [
        {
          "key": "recipient",
          "label": "Who I want the wishes to be for, without identifying details",
          "optional": true
        },
        {
          "key": "recipient-fit",
          "label": "What makes this choice fit, or a concern to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If no choice feels suitable",
        "text": "There is no need to force one. Pause and discuss another way to practise with your therapist. Simply finishing the page does not mean you offered wishes."
      }
    },
    {
      "id": "loving-kindness.practice.words",
      "title": "Choose a small set of meaningful wishes",
      "paragraphs": [
        "Choose a varied set of about four short wishes. Each should express something good you honestly want for yourself or the person you chose, such as care, rest, enjoyment or being treated kindly. Use words you understand, rather than a phrase you feel obliged to repeat.",
        "One made-up set is: \"May you find care in hard times. May there be room for rest. May you have moments you enjoy. May you be treated with kindness.\" You may change the words or use \"I\" for yourself. These are hopes, not promises or facts.",
        "Read the set once for meaning. Does it express goodwill without asking the person to please you, change their view or have no difficult feelings? A shorter wording or accessible written cue may help; do not turn it into a rule you must obey."
      ],
      "fields": [
        {
          "key": "wishes",
          "label": "The set of wishes I choose, if I want to write them",
          "optional": true
        },
        {
          "key": "meaning",
          "label": "What the wishes mean, or wording I want to change",
          "optional": true
        }
      ],
      "help": {
        "title": "If a wish feels false or upsetting",
        "text": "A wish does not need to describe what is true now. Still, do not force words that feel threatening or pressuring. Change them with support, make a different choice or stop."
      }
    },
    {
      "id": "loving-kindness.practice.prepare",
      "title": "Get ready in a way that fits you",
      "paragraphs": [
        "Choose a place and position where it is suitable to pause. Keep needed aids and support. You can sit, stand or lie in a way that works for you, keep your eyes open and let your breathing stay ordinary. There is no required hand position.",
        "Keep in mind who the wishes are for. A simple idea is enough. You may use an image only if you want and it fits; nothing needs to look vivid. Keep the wishes available to read if holding them in mind is hard.",
        "Agree a brief amount or stopping point with your therapist that suits you. This page runs no timer or count. You can stop sooner, and you do not need to repeat until it feels right."
      ],
      "fields": [
        {
          "key": "setup",
          "label": "Position, words or access support that fit",
          "optional": true
        },
        {
          "key": "stopping-point",
          "label": "The agreed amount or stopping point, with permission to stop sooner",
          "optional": true
        }
      ],
      "help": {
        "title": "If attention to the person or yourself feels too intense",
        "text": "Stop the exercise and notice something ordinary around you. You can move, use support or leave. Returning to the words is optional, not a test of staying with distress."
      }
    },
    {
      "id": "loving-kindness.practice.repeat",
      "title": "Try the wishes with attention to their meaning",
      "paragraphs": [
        "If you choose to practise now, remember who you have chosen to offer wishes toward. Read or say your set of wishes in your own accessible way, one wish at a time. Allow room to notice what each means. You do not need to create an image or a body feeling.",
        "Repeat the set slowly enough to stay connected with the meaning, rather than rushing through words. You can pause between rounds. If you already notice tension, you may let it ease if comfortable. You do not need to look for it or become relaxed. Follow your agreed brief plan or stop sooner; do not wait for warmth or calm as permission to finish.",
        "The practice is offering an intention, not sending a message or making an outcome happen. If you only read these instructions, that is preparation rather than evidence you repeated the wishes."
      ],
      "fields": [
        {
          "key": "practice-status",
          "label": "What I actually repeated, prepared or did not try",
          "optional": true
        }
      ],
      "help": {
        "title": "If repeating becomes a way to cancel a thought",
        "text": "Pause. You do not need to undo an unwanted thought or repeat until you are certain you meant every word. Discuss the pattern with your therapist instead of adding more rounds."
      }
    },
    {
      "id": "loving-kindness.practice.return",
      "title": "Notice wandering and choose whether to return",
      "paragraphs": [
        "Your mind may wander or offer a judgement. If continuing still fits, notice that briefly and bring attention back to the words and their meaning. You can continue where you are; no perfect restart is needed.",
        "If warmth or ease appears, you may notice it without holding on. If there is no special feeling, the words can still express an intention. If sadness, pressure, feeling unreal or upsetting thoughts grow, stop and seek suitable support rather than pushing through."
      ],
      "fields": [
        {
          "key": "attention",
          "label": "What I noticed about attention or feelings",
          "optional": true
        },
        {
          "key": "return-or-stop",
          "label": "How I returned, paused, stopped or chose not to continue",
          "optional": true
        }
      ],
      "help": {
        "title": "If self-criticism appears",
        "text": "Try not to make it another failure to correct. You can notice it, return if useful or stop. No number of distractions is too many to report honestly."
      }
    },
    {
      "id": "loving-kindness.practice.widen",
      "title": "Broaden only if it is wanted and agreed",
      "paragraphs": [
        "You can finish with who you chose. If your therapist has agreed it and you want to, you may later offer the wishes toward yourself, another chosen person, a wider group or living beings more broadly. Adjust the words so they still mean what you intend.",
        "The source method also discusses people who bring difficult feelings. That is not required for this practice, and this page does not ask you to choose one. Do not choose someone you do not want to include. Including a person who harmed you is not a test of progress. Wishing well never requires contact or giving up boundaries.",
        "If you actually include someone else within your agreed practice, check fit again and use the same meaningful attention. If it becomes too much, return to a suitable choice or stop. A plan to widen is not evidence it happened."
      ],
      "fields": [
        {
          "key": "widen-choice",
          "label": "Stay, stop or an agreed optional wider choice",
          "optional": true
        },
        {
          "key": "widen-actual",
          "label": "What I actually did, or only considered",
          "optional": true
        }
      ],
      "help": {
        "title": "If widening feels like a demand",
        "text": "Keep the original suitable plan or finish. The point is willing goodwill, not completing a list of people or forcing compassion toward someone."
      }
    },
    {
      "id": "loving-kindness.practice.close",
      "title": "Let the exercise end",
      "paragraphs": [
        "Stop the repetition when you choose. Notice your surroundings in a way that fits you. You may look at an object, notice an ordinary sound or move as comfortable. There is no special state you need to reach first.",
        "Check what you need now: a pause, an ordinary activity, support or practical care. The wishes do not replace those needs. You do not have to act on them or contact anyone, and this tool has sent nothing."
      ],
      "fields": [
        {
          "key": "closing",
          "label": "How I ended, or whether I did not begin",
          "optional": true
        },
        {
          "key": "current-need",
          "label": "Any ordinary need or support to attend to",
          "optional": true
        }
      ],
      "help": {
        "title": "If difficult feelings remain",
        "text": "Let finishing be allowed. Use the support you normally rely on or discuss the experience with your therapist. The page is not monitored and does not alert anyone."
      }
    },
    {
      "id": "loving-kindness.practice.review",
      "title": "Review the actual experience",
      "paragraphs": [
        "What happened: choosing who the wishes are for, preparing words, repeating them, widening, stopping or no practice? Keep each separate. No completed screen tells us what you did.",
        "Which words and way of practising fitted? What did you notice about attention, caring, neutrality, discomfort or pressure? You can report no change or an unwanted effect. Do not turn this into a test of whether you were kind enough.",
        "Were your choice, boundaries and real needs preserved? Did repetition stay meaningful or become something you felt you had to do? Note any question for your therapist, without drawing a verdict from one practice."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "What actually happened or did not happen",
          "optional": true
        },
        {
          "key": "observations",
          "label": "What fitted, what I noticed and what remains unclear",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "A concern or question to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If you did not practise",
        "text": "Record that only if useful. Preparation, a change of mind or a choice not to use the exercise can still inform the next discussion. There is no result to invent."
      }
    },
    {
      "id": "loving-kindness.practice.next",
      "title": "Choose what to keep, change or stop",
      "paragraphs": [
        "With your therapist, decide whether to keep the same plan, change the words or who they are for, use more support, choose a different practice or stop. Repetition may be part of learning, but this page sets no daily requirement.",
        "Any future practice remains a choice to review when it happens. Keep needed care, safety and boundaries. Save selected notes only if useful; no reminder or ongoing task is created here."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "What to keep, change, pause or stop",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Support or any future practice to discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If another practice fits better",
        "text": "You can choose it without treating loving-kindness as a failed test. Fit can vary over time, and not every exercise is useful for every person."
      }
    }
  ],
  "sources": [
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Handout 8",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed p70, PDF index44: willing recipient choice, benevolent wishes, meaningful repetition, attention-return and progressive broadening.",
      "limits": "This is not the literal handout sequence. Preparatory breath/palm instructions, continue-until-immersed endpoint and daily progression are adapted explicitly. No handout text, layout or full source script reproduced; no latest-revised-edition fidelity claim."
    },
    {
      "id": "Linehan/Guilford: 2015 mindfulness teaching notes",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Printed pp219–222: loving-kindness purpose, a meaningful varied set of wishes, optional visualization, choice of self or another cared-for person, and willingness about recipients.",
      "limits": "Clinician teaching does not establish efficacy or all-age fit of this isolated adaptation. Source cautions that fit may vary, including with brooding. No automatic substitute exercise, medical claim or demand to feel warmth is imported."
    },
    {
      "id": "Linehan/Guilford: 2015 Mindfulness Worksheet 6",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed p97: describes actual loving-kindness practice, chosen wishes and experienced effects.",
      "limits": "No source form, recipient checklist, weekly count or positive-effect score copied. This version preserves no-use, neutral and adverse observations, and no inferred kindness or emotional improvement."
    },
    {
      "id": "ASHA/NJC: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal and access to meaningful communication inform optional formats and support.",
      "limits": "Rights guidance, not evidence for this meditation or universal clinical suitability."
    },
    {
      "id": "Guilford: Limited duplication licence",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-1teaching.pdf?t=1",
      "supports": "Copyright page ii limits purchaser duplication and excludes public electronic redistribution without permission.",
      "limits": "Source access and links do not grant release rights. This candidate contains original prose and wishes; no rights approval requested or granted."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Choose a benevolent intention and willing recipient",
      "sections": [
        "practice.intention",
        "practice.recipient"
      ],
      "source": "Handout8 and Manualpp219–222; no required difficult or harmful recipient"
    },
    {
      "operation": "Use a varied meaningful set rather than a rote single phrase",
      "sections": [
        "practice.words"
      ],
      "source": "Manualp221; original four-wish illustration, not a reproduced source script"
    },
    {
      "operation": "Accessible preparation, actual repetition and attention-return",
      "sections": [
        "practice.prepare",
        "practice.repeat",
        "practice.return"
      ],
      "source": "Handout8 and Manualpp220–222; visualization optional in teaching; ordinary breathing/no palm pose/bounded endpoint are explicit adaptations"
    },
    {
      "operation": "Optional broadening while preserving willingness",
      "sections": [
        "practice.widen"
      ],
      "source": "Handout8 and Manualp222; no compulsory hierarchy or generic difficult-recipient assignment"
    },
    {
      "operation": "Close, review actual use/non-use and consider fit",
      "sections": [
        "practice.close",
        "practice.review",
        "practice.next"
      ],
      "source": "Worksheet6 plus bounded product safeguards; no copied positive-outcome score or daily quota"
    }
  ],
  "narrationSegments": [
    {
      "id": "loving-kindness.intro",
      "title": "Offer wishes without forcing a feeling",
      "text": "Loving-kindness is a practice of offering good wishes. You choose words that express care for yourself or another person, repeat them with attention to their meaning, and gently return when your mind wanders.\n\nA wish is not a statement that life is already easy or that something will happen. You can wish someone well while a difficult feeling remains. This page does not ask you to love everyone, forgive harm or feel warm on demand.\n\nThis is an introductory practice after teaching with your therapist. You can prepare, try the wishes if they fit, stop and review. You can also read the example or finish without practising.",
      "sha256": "b07b5636a50aff565f9d11505112b6ec7e7eb3c76fe6eb39b98bf9299f6f9098",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.fit",
      "title": "Use a willing choice and keep your limits",
      "text": "Choose this with your therapist, who can check whether it fits your needs, beliefs and stage of learning. If kindness practice brings up grief, shame, painful memories, feeling unreal or repeated upsetting thoughts, pause and discuss what support or a different practice would fit.\n\nDo not choose someone you do not want to offer kindness toward. You do not need to include a person who harmed you, imagine a painful scene or work up to a difficult person. Wishing well is not excusing harm, giving consent, forgiving, making contact or giving up protection.\n\nYou may keep your eyes open, use an ordinary comfortable position and breathe as usual. No image, hand pose, touch, special breathing or body focus is needed here. If focusing inward is not helpful, stop and return attention to the room or seek support.\n\nUse words and a form of communication that make sense to you. You may think, read, sign or speak quietly. No spiritual belief or ritual is required. This is not urgent support, a safety plan or a reason to delay needed care or action.",
      "sha256": "f58d322492c4d1cff48def1333ea490a821462dd1212687f73687d652d47e0fb",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.privacy",
      "title": "Keep your choice and wishes private if you want",
      "text": "You can practise without writing or use your own paper. Optional notes are here only if useful. A label such as \"myself\" or \"someone I care about\" is enough; no name or personal history is needed. This tool records no voice and sends no wishes, messages or notes to anyone.\n\nNotes stay in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes them. To keep selected notes, check their preview, then copy or download. The page does not save a practice for later.\n\nA shared device, screen reader or outside copy may expose your words. Skill narration reads only the public teaching, never your private wishes or notes. Outside copies remain until you remove them. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "abf351d518d0c1074c3c45bce174b8361497c1c6764207f18a002093e9392c18",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.close",
      "title": "Finish without an emotional target",
      "text": "Reading, choosing words and actually repeating them are different. You can finish at any point. You do not need warmth, calm, forgiveness or wishes for more people.\n\nIf you want a copy, choose and check the notes you keep. Finish and clear removes notes here, not outside copies. Bring any useful observation or concern to your therapist in your own way.",
      "sha256": "0273df3806ff615081cf83557eb1b0c65367e809eead0ca7df2d9d882caed0fa",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.example",
      "title": "Robin tries a set of wishes",
      "text": "This is made up. Robin and the therapist have discussed a brief loving-kindness practice. Starting with wishes for themself feels too painful today. Robin willingly chooses a friend they already care about, without needing to picture the friend.\n\nRobin chooses four wishes: \"May you find care in hard times. May there be room for rest. May you have moments you enjoy. May you be treated with kindness.\" They express support, rest, enjoyment and care from others. Robin knows the wishes do not make these things happen.\n\nRobin stays seated with eyes open and ordinary breathing. Robin actually reads the four wishes slowly, then repeats the set quietly, attending to what each means. When a shopping thought appears, Robin notices it and returns to the next wish rather than restarting to get it perfect.\n\nAfter another chosen round Robin notices sadness. Robin stops, looks at the shelf nearby and lets the exercise end. Robin does not add another person or keep repeating until warmth appears. No message has been sent to the friend.\n\nIn review Robin notes the actual repetition, the wandering thought and sadness. The words about rest felt easier than the first line. Robin will discuss whether to change that line or use another practice. A future change is not recorded as already tried.",
      "sha256": "3e20ded99c08599893ec1ed4c64530270e8f99ff4eb27a4e542282daa2f61452",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.learn",
      "title": "Kind wishes are an intention, not a test",
      "text": "Loving-kindness has roots in Buddhist meditation and is also used in DBT. People may practise it with or without a spiritual meaning. It is your choice whether it fits your beliefs; the page makes no claim about sending a force or changing another person.\n\nA compassionate letter or diary puts caring words around a particular experience. A kind action is something you do. Here the distinct practice is a small varied set of good wishes, repeated with attention to meaning. It is not a demand to believe positive statements about yourself.\n\nThe source method can broaden from yourself or a loved person to others and wider groups. It also describes people who bring difficult feelings. That is not a ladder everyone must climb. You can stay with a willing choice; difficult or harmful people are not an assignment here.\n\nThis version does not change breathing or hand position, require imagery, set a daily quota or continue until a feeling appears. Those are explicit delivery choices for a bounded introduction, not a claim to reproduce every step of the 2015 handout.\n\nA practice can feel caring, neutral, awkward or painful. None of those feelings proves your worth or intentions. Your therapist can help decide whether the words, who they are for, the amount or the practice itself should change.",
      "sha256": "e464ad801ed3feaab979c57903bf453cd39f440533c7ec45e1c58df2ae76419a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.intention",
      "title": "Choose what you want to practise",
      "text": "What would you like to practise: offering care, softening a harsh stance if you want to, or learning how kind wishes feel to use? Keep the aim as something you can choose, not a promise that you or someone else will change.\n\nNotice if the task has become \"I must feel loving\" or \"These words must make things safe.\" A wish cannot guarantee either. You may discuss that pressure with your therapist rather than trying harder to produce a feeling.",
      "sha256": "a2e2d90f903fb667a10a9b67733d9ca5a9d2539380c4872b7268557912eeaf9a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.intention.help",
      "title": "If the practice feels like a moral duty",
      "text": "You do not have to use it to prove you are kind or a good person. You can choose another practice, ask for help or stop.",
      "sha256": "69736c7f8d52a0c54cf83eb65cf562000c89fc000b750029b554011e735b3fc2",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.recipient",
      "title": "Choose whom you want to offer wishes toward",
      "text": "Choose yourself if that feels suitable, or a person you already care about and genuinely want to wish well. Use a choice you and your therapist have considered. No detailed memory, face or name is needed.\n\nNotice whether this choice feels workable today. Caring about someone can still bring painful memories or grief. You can choose differently, leave the choice undecided or stop. Do not pick someone because you think you should forgive them.",
      "sha256": "8ec83f445671df960c76a4400e6da54b4f6e947ee84be3f3a1da940f861054a3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.recipient.help",
      "title": "If no choice feels suitable",
      "text": "There is no need to force one. Pause and discuss another way to practise with your therapist. Simply finishing the page does not mean you offered wishes.",
      "sha256": "44865c029ecb863176e07209b8cbd58b2bfd5979631f5485fed6c75972237ecf",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.words",
      "title": "Choose a small set of meaningful wishes",
      "text": "Choose a varied set of about four short wishes. Each should express something good you honestly want for yourself or the person you chose, such as care, rest, enjoyment or being treated kindly. Use words you understand, rather than a phrase you feel obliged to repeat.\n\nOne made-up set is: \"May you find care in hard times. May there be room for rest. May you have moments you enjoy. May you be treated with kindness.\" You may change the words or use \"I\" for yourself. These are hopes, not promises or facts.\n\nRead the set once for meaning. Does it express goodwill without asking the person to please you, change their view or have no difficult feelings? A shorter wording or accessible written cue may help; do not turn it into a rule you must obey.",
      "sha256": "a37359959ebbdf40f1f06f6863d504342904c64c45ef7ba2613d129fa63a8a80",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.words.help",
      "title": "If a wish feels false or upsetting",
      "text": "A wish does not need to describe what is true now. Still, do not force words that feel threatening or pressuring. Change them with support, make a different choice or stop.",
      "sha256": "9665ee9eb07e8fadffcd708d77b429f6cfcf54b25ba13f651da38aab80281db0",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.prepare",
      "title": "Get ready in a way that fits you",
      "text": "Choose a place and position where it is suitable to pause. Keep needed aids and support. You can sit, stand or lie in a way that works for you, keep your eyes open and let your breathing stay ordinary. There is no required hand position.\n\nKeep in mind who the wishes are for. A simple idea is enough. You may use an image only if you want and it fits; nothing needs to look vivid. Keep the wishes available to read if holding them in mind is hard.\n\nAgree a brief amount or stopping point with your therapist that suits you. This page runs no timer or count. You can stop sooner, and you do not need to repeat until it feels right.",
      "sha256": "5007b80aefd178ce8d2a54bc6934cc6f73971e25d1e69cccc32130263401f89b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.prepare.help",
      "title": "If attention to the person or yourself feels too intense",
      "text": "Stop the exercise and notice something ordinary around you. You can move, use support or leave. Returning to the words is optional, not a test of staying with distress.",
      "sha256": "2da45fffde84b1db778b996ae95ddf2d42385e8670f5014fda67db883fa502c7",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.repeat",
      "title": "Try the wishes with attention to their meaning",
      "text": "If you choose to practise now, remember who you have chosen to offer wishes toward. Read or say your set of wishes in your own accessible way, one wish at a time. Allow room to notice what each means. You do not need to create an image or a body feeling.\n\nRepeat the set slowly enough to stay connected with the meaning, rather than rushing through words. You can pause between rounds. If you already notice tension, you may let it ease if comfortable. You do not need to look for it or become relaxed. Follow your agreed brief plan or stop sooner; do not wait for warmth or calm as permission to finish.\n\nThe practice is offering an intention, not sending a message or making an outcome happen. If you only read these instructions, that is preparation rather than evidence you repeated the wishes.",
      "sha256": "8442fb7371a3bd8254e5b8d49c5e98f234e39fcb72a14ff42bd2cf811a6c7361",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.repeat.help",
      "title": "If repeating becomes a way to cancel a thought",
      "text": "Pause. You do not need to undo an unwanted thought or repeat until you are certain you meant every word. Discuss the pattern with your therapist instead of adding more rounds.",
      "sha256": "ea5c0ccb14d39b31faadb4200c0fc55c27e21b4453108379807e9079abc98e37",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.return",
      "title": "Notice wandering and choose whether to return",
      "text": "Your mind may wander or offer a judgement. If continuing still fits, notice that briefly and bring attention back to the words and their meaning. You can continue where you are; no perfect restart is needed.\n\nIf warmth or ease appears, you may notice it without holding on. If there is no special feeling, the words can still express an intention. If sadness, pressure, feeling unreal or upsetting thoughts grow, stop and seek suitable support rather than pushing through.",
      "sha256": "f958318a25bde62106aa746665cfd3254d2533a1a0d66d2d28fb306787733d0e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.return.help",
      "title": "If self-criticism appears",
      "text": "Try not to make it another failure to correct. You can notice it, return if useful or stop. No number of distractions is too many to report honestly.",
      "sha256": "be317a3236c817cbd1f7a3dc6fe3f28f01d76b31e4c155df85e09e01cb4a3a8f",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.widen",
      "title": "Broaden only if it is wanted and agreed",
      "text": "You can finish with who you chose. If your therapist has agreed it and you want to, you may later offer the wishes toward yourself, another chosen person, a wider group or living beings more broadly. Adjust the words so they still mean what you intend.\n\nThe source method also discusses people who bring difficult feelings. That is not required for this practice, and this page does not ask you to choose one. Do not choose someone you do not want to include. Including a person who harmed you is not a test of progress. Wishing well never requires contact or giving up boundaries.\n\nIf you actually include someone else within your agreed practice, check fit again and use the same meaningful attention. If it becomes too much, return to a suitable choice or stop. A plan to widen is not evidence it happened.",
      "sha256": "c53d12e0d1f49a079f8ee55397b4a705216a2006339c04092c162c9d44f8e0e3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.widen.help",
      "title": "If widening feels like a demand",
      "text": "Keep the original suitable plan or finish. The point is willing goodwill, not completing a list of people or forcing compassion toward someone.",
      "sha256": "bcc3e9a92fd3c05fc0eb64b2f157a5131e0c1ee994b38a201959f67a09da7843",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.close",
      "title": "Let the exercise end",
      "text": "Stop the repetition when you choose. Notice your surroundings in a way that fits you. You may look at an object, notice an ordinary sound or move as comfortable. There is no special state you need to reach first.\n\nCheck what you need now: a pause, an ordinary activity, support or practical care. The wishes do not replace those needs. You do not have to act on them or contact anyone, and this tool has sent nothing.",
      "sha256": "4ed55f17c9cf421a76da949f665a70a492dc0c54791016fd31d1767282a4ccf1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.close.help",
      "title": "If difficult feelings remain",
      "text": "Let finishing be allowed. Use the support you normally rely on or discuss the experience with your therapist. The page is not monitored and does not alert anyone.",
      "sha256": "4cc5fa485cc4e7b255df601b65de2593e19cad4a219f01fcfec2d22816bea803",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.review",
      "title": "Review the actual experience",
      "text": "What happened: choosing who the wishes are for, preparing words, repeating them, widening, stopping or no practice? Keep each separate. No completed screen tells us what you did.\n\nWhich words and way of practising fitted? What did you notice about attention, caring, neutrality, discomfort or pressure? You can report no change or an unwanted effect. Do not turn this into a test of whether you were kind enough.\n\nWere your choice, boundaries and real needs preserved? Did repetition stay meaningful or become something you felt you had to do? Note any question for your therapist, without drawing a verdict from one practice.",
      "sha256": "ee9be780fc82f484fc30ba4f30decad67f647f1e3017b64e93f60487fb67bda4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.review.help",
      "title": "If you did not practise",
      "text": "Record that only if useful. Preparation, a change of mind or a choice not to use the exercise can still inform the next discussion. There is no result to invent.",
      "sha256": "7fb7a0f9fea3e3d14325fb5a67129a0517a9f6edcebddcd5e6de1eee83e0ec12",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "loving-kindness.practice.next",
      "title": "Choose what to keep, change or stop",
      "text": "With your therapist, decide whether to keep the same plan, change the words or who they are for, use more support, choose a different practice or stop. Repetition may be part of learning, but this page sets no daily requirement.\n\nAny future practice remains a choice to review when it happens. Keep needed care, safety and boundaries. Save selected notes only if useful; no reminder or ongoing task is created here.",
      "sha256": "d9ea14ae27f6e6fcc5bd4f3eab49594b20ef4856638f1b0e02ed7342252f7d9c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "loving-kindness.practice.next.help",
      "title": "If another practice fits better",
      "text": "You can choose it without treating loving-kindness as a failed test. Fit can vary over time, and not every exercise is useful for every person.",
      "sha256": "7cb414b5e9403e7db3531e58b40ffc4d56d0f65b7fa7e551c4860eb011323913",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
