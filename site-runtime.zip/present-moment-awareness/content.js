window.EveningSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "present.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Frozen authored scripts only until exact asset, perceptual listening and integration gates pass. No personal words in audio. Existing audio assets do not imply these new words are voiced.",
    "timer": "None unless explicitly specified in practiceAid.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show optional fictional practice before prompts and keep available contextually. Do not prefill or evaluate private words. Reading the example is not marked as actual practice."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/present",
  "title": "Present-Moment Awareness",
  "subtitle": "Return your attention to what is here",
  "scope": "An ordinary flexible-attention practice within present-moment awareness; not the full ACT or DBT curriculum, formal Attention Training Technique, exposure or dissociation treatment.",
  "resourceId": "tool/return-your-attention",
  "routeProposal": "tool/return-your-attention",
  "version": "2026-11-02-evening-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Explain that returning attention need not remove thoughts or feelings, and choosing an external focus is not a test of perfect concentration.",
    "practiceObjective": "Choose an ordinary accessible focus, notice a detail, notice wandering if it happens, and gently return or change focus; review what fitted without requiring calm.",
    "observedPractice": "Private consideration, actual optional practice and review are separate from reading; no typing, rating, symptom reduction or claim of mastery required.",
    "sourcePopulationContext": "The cited ACT, WHO and CCI materials inform this practice, but do not validate this digital adaptation or establish suitability across ages. Therapist selection and adaptation should account for development, communication, consent, privacy, safeguarding and circumstances. Method-specific source populations and suitability limits still apply."
  },
  "intro": {
    "id": "present.intro",
    "title": "A small return to this moment",
    "paragraphs": [
      "Attention can wander into plans, memories or worries. Here you can practise noticing one ordinary thing happening now, and returning when attention moves elsewhere.",
      "You do not need to empty your mind, close your eyes or focus on breathing. Use an accessible external focus, or leave the practice if it does not fit."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "present.fit",
    "title": "Choose a manageable moment",
    "paragraphs": [
      "Use this with your therapist between sessions. Choose an ordinary, safe moment, not an activity where shifting attention could put you at risk.",
      "Use a focus that is comfortable and available to you. You can look, listen or notice an ordinary task without turning attention inside your body.",
      "This practice does not assess danger or treat feeling disconnected from reality. If you feel more distressed or disconnected, stop and use your agreed support. Attend to real safety needs rather than trying to focus through them."
    ]
  },
  "learn": {
    "id": "present.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "Practising a gentle return can help you notice where your attention is and choose where to place it. The practice is the return, not keeping attention still.",
      "Thoughts and feelings can remain while you attend to an ordinary activity. This is not a way to force them away or an instruction to ignore something important.",
      "A focus is a temporary place to return to. You can change it when it becomes uncomfortable or when the situation needs a different response. This is one present-moment exercise, not every mindfulness skill."
    ]
  },
  "example": {
    "id": "present.example",
    "title": "Example — noticing a page",
    "paragraphs": [
      "Ari chooses to look at the cover of a book. Ari notices a blue line and the shape of a letter. A thought about tomorrow’s tasks appears.",
      "Ari notices being caught in planning, then returns to the line on the cover. The thought comes back; Ari returns once more without arguing with it.",
      "After a brief practice, Ari is still thinking about tomorrow. Ari notices that looking at the cover was workable and that a return happened. Ari finishes rather than trying to achieve an empty mind."
    ]
  },
  "practiceScenario": {
    "id": "present.scenario",
    "title": "You can learn with Ari",
    "paragraphs": [
      "If you do not want to try a focus now, consider Ari’s example: a thought returns after Ari looks at the book. Does that mean the exercise failed, or is noticing and returning part of it?",
      "Reading can help explain the method. You do not have to practise with a personal worry or disclose anything."
    ]
  },
  "practice": [
    {
      "id": "present.practice.choose",
      "title": "Choose one ordinary focus",
      "paragraphs": [
        "Choose something accessible: a detail on an object, an ordinary sound, or part of a safe everyday task. Keep your eyes open if that fits.",
        "Avoid anything intense, unpleasant or needing safety-critical attention. You do not have to use all your senses."
      ],
      "fields": [
        {
          "key": "focus",
          "label": "My focus, if I want to write",
          "optional": true
        }
      ],
      "help": {
        "title": "If a sense or activity does not fit",
        "text": "Choose a different available focus. No particular sense, posture, body sensation or breath is required. You can stop instead."
      }
    },
    {
      "id": "present.practice.notice",
      "title": "Notice a detail now",
      "paragraphs": [
        "Spend a brief moment with the focus. What is one detail you can notice: a colour, a shape, a sound, or what the task involves?",
        "You can simply notice without putting it into words. There is no fixed number of details to collect."
      ],
      "help": {
        "title": "If this becomes a search for the correct detail",
        "text": "There is no hidden answer. A simple detail is enough; you do not need to look harder or prove you are present."
      }
    },
    {
      "id": "present.practice.return",
      "title": "Return when attention wanders",
      "paragraphs": [
        "If you notice attention has moved into a thought or something else, acknowledge that briefly. Gently return to the chosen focus, or choose a more suitable one.",
        "Let thoughts be present without needing to settle or remove them. Try one or a few returns if they occur; you do not need to create a distraction to practise."
      ],
      "help": {
        "title": "If attention keeps wandering",
        "text": "Returning again is part of practice. If the focus feels uncomfortable, change it or stop. This is not an endurance test."
      }
    },
    {
      "id": "present.practice.review",
      "title": "Notice what fitted",
      "paragraphs": [
        "Was the focus accessible? Did you notice a detail or a return? It is okay if you are unsure or your feelings stayed the same.",
        "You can finish here and return to your ordinary activity. A real problem may still need your attention afterwards."
      ],
      "fields": [
        {
          "key": "review",
          "label": "Something I noticed, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you only read or stopped early",
        "text": "You can leave it here without marking the practice done. Discuss the fit with your therapist if that would help."
      }
    }
  ],
  "practiceAid": {
    "id": "present.timer",
    "title": "Optional practice time",
    "paragraphs": [
      "You can practise without a timer. If useful, choose one minute as a small space to try noticing and returning. It is not a target for concentration or calm.",
      "You may pause or stop before the minute ends. Stop the timer before switching tabs or apps. Its end is simply a cue to decide whether to finish, not proof you completed the skill."
    ],
    "kind": "optional60second-container",
    "placement": "present.practice.notice and present.practice.return",
    "default": "Off, no autoplay",
    "labels": {
      "start": "Start optional one-minute timer",
      "pause": "Pause timer",
      "resume": "Continue timer",
      "stop": "Stop timer",
      "ended": "Time is up. You can finish or leave the timer off."
    },
    "semantics": [
      "No automatic advancing or completion score.",
      "Timer has explicit start/pause/resume/stop. Navigating away, clearing, hidden tab or starting narration stops it; never auto-resume.",
      "No ticking, sound, motion requirement or compulsory duration. Text countdown with no persecond live-region announcement."
    ]
  },
  "close": {
    "id": "present.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "You do not need a quiet mind or a changed feeling to finish. Return to what fits your situation, or seek support if needed."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "id": "acbs-act",
      "url": "https://contextualscience.org/act",
      "reviewed": "2026-11-02",
      "supports": "Present-moment contact and flexible context-sensitive responding within broader ACT; does not validate isolated app or imply complete ACT."
    },
    {
      "id": "who-engaging",
      "url": "https://cdn.who.int/media/docs/default-source/thailand/doing-what-matters-in-times-of-stress-eng.pdf?sfvrsn=d166ad74_1",
      "reviewed": "2026-11-02",
      "supports": "Part1 engaging/attention to ordinary activities and surroundings; original exercise omits full grounding and WHO sequence/art."
    },
    {
      "id": "cci-attention",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/What-Me-Worry/What-Me-Worry---04---Attention-Training.pdf",
      "reviewed": "2026-11-02",
      "supports": "Supplementary support for noticing wandering and return without suppressing thoughts. CBT source does not establish ACT equivalence or formal ATT fidelity."
    }
  ],
  "productAdaptations": [
    "Preserves existing tool/return-your-attention identity under classic/present. No additional launch or completion claim under classic/mindful,classic/attention-training or classic/metacognitive-att.",
    "Original Ari exercise with ordinary external focus; no trauma or dissociation procedure.",
    "Short voluntary rehearsal and optional60second time container are product design, not a source-prescribed dose."
  ],
  "narrationSegments": [
    {
      "id": "present.intro",
      "title": "A small return to this moment",
      "text": "Attention can wander into plans, memories or worries. Here you can practise noticing one ordinary thing happening now, and returning when attention moves elsewhere.\n\nYou do not need to empty your mind, close your eyes or focus on breathing. Use an accessible external focus, or leave the practice if it does not fit.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.fit",
      "title": "Choose a manageable moment",
      "text": "Use this with your therapist between sessions. Choose an ordinary, safe moment, not an activity where shifting attention could put you at risk.\n\nUse a focus that is comfortable and available to you. You can look, listen or notice an ordinary task without turning attention inside your body.\n\nThis practice does not assess danger or treat feeling disconnected from reality. If you feel more distressed or disconnected, stop and use your agreed support. Attend to real safety needs rather than trying to focus through them.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.learn",
      "title": "Why this skill may help",
      "text": "Practising a gentle return can help you notice where your attention is and choose where to place it. The practice is the return, not keeping attention still.\n\nThoughts and feelings can remain while you attend to an ordinary activity. This is not a way to force them away or an instruction to ignore something important.\n\nA focus is a temporary place to return to. You can change it when it becomes uncomfortable or when the situation needs a different response. This is one present-moment exercise, not every mindfulness skill.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.example",
      "title": "Example — noticing a page",
      "text": "Ari chooses to look at the cover of a book. Ari notices a blue line and the shape of a letter. A thought about tomorrow’s tasks appears.\n\nAri notices being caught in planning, then returns to the line on the cover. The thought comes back; Ari returns once more without arguing with it.\n\nAfter a brief practice, Ari is still thinking about tomorrow. Ari notices that looking at the cover was workable and that a return happened. Ari finishes rather than trying to achieve an empty mind.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.scenario",
      "title": "You can learn with Ari",
      "text": "If you do not want to try a focus now, consider Ari’s example: a thought returns after Ari looks at the book. Does that mean the exercise failed, or is noticing and returning part of it?\n\nReading can help explain the method. You do not have to practise with a personal worry or disclose anything.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.practice.choose",
      "title": "Choose one ordinary focus",
      "text": "Choose something accessible: a detail on an object, an ordinary sound, or part of a safe everyday task. Keep your eyes open if that fits.\n\nAvoid anything intense, unpleasant or needing safety-critical attention. You do not have to use all your senses.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.practice.choose.help",
      "title": "If a sense or activity does not fit",
      "text": "Choose a different available focus. No particular sense, posture, body sensation or breath is required. You can stop instead.",
      "status": "Script only"
    },
    {
      "id": "present.practice.notice",
      "title": "Notice a detail now",
      "text": "Spend a brief moment with the focus. What is one detail you can notice: a colour, a shape, a sound, or what the task involves?\n\nYou can simply notice without putting it into words. There is no fixed number of details to collect.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.practice.notice.help",
      "title": "If this becomes a search for the correct detail",
      "text": "There is no hidden answer. A simple detail is enough; you do not need to look harder or prove you are present.",
      "status": "Script only"
    },
    {
      "id": "present.practice.return",
      "title": "Return when attention wanders",
      "text": "If you notice attention has moved into a thought or something else, acknowledge that briefly. Gently return to the chosen focus, or choose a more suitable one.\n\nLet thoughts be present without needing to settle or remove them. Try one or a few returns if they occur; you do not need to create a distraction to practise.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.practice.return.help",
      "title": "If attention keeps wandering",
      "text": "Returning again is part of practice. If the focus feels uncomfortable, change it or stop. This is not an endurance test.",
      "status": "Script only"
    },
    {
      "id": "present.practice.review",
      "title": "Notice what fitted",
      "text": "Was the focus accessible? Did you notice a detail or a return? It is okay if you are unsure or your feelings stayed the same.\n\nYou can finish here and return to your ordinary activity. A real problem may still need your attention afterwards.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.practice.review.help",
      "title": "If you only read or stopped early",
      "text": "You can leave it here without marking the practice done. Discuss the fit with your therapist if that would help.",
      "status": "Script only"
    },
    {
      "id": "present.timer",
      "title": "Optional practice time",
      "text": "You can practise without a timer. If useful, choose one minute as a small space to try noticing and returning. It is not a target for concentration or calm.\n\nYou may pause or stop before the minute ends. Stop the timer before switching tabs or apps. Its end is simply a cue to decide whether to finish, not proof you completed the skill.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.close",
      "title": "Leave it here for now",
      "text": "You do not need a quiet mind or a changed feeling to finish. Return to what fits your situation, or seek support if needed.",
      "status": "Script only; generation/listening/integration not asserted"
    },
    {
      "id": "present.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; generation/listening/integration not asserted"
    }
  ]
}
;
