
(()=>{'use strict';
let frame=document.getElementById('retained-method');const dialog=document.getElementById('host-confirm'),back=document.getElementById('library-return'),support=document.getElementById('support-return'),kind=document.body.dataset.method;let protocol=null,returnFocus=null,lastStage=null;
const initial=frame.getAttribute('src');
function send(choice){if(!protocol)return;const p=protocol;protocol=null;dialog.close();frame.contentWindow?.postMessage(p==='thought'?{reviewThoughtReset:1,choice}:{boundaryNative:1,type:'decision',choice},location.origin);if(choice==='cancel')returnFocus?.focus();}
function destroy(){protocol=null;if(dialog.open)dialog.close();frame.remove();}
function leave(){destroy();location.assign(window.PublicReviewPaths.href('/skills-library/'));}
addEventListener('message',event=>{if(event.origin!==location.origin||event.source!==frame.contentWindow)return;const d=event.data;if(!d||typeof d!=='object')return;

if(kind==='thought'&&d.retainedHost===1&&d.type==='stage'&&d.stage==='learn'&&d.section==='dana-short-example'){
const child=frame.contentDocument,main=child?.querySelector('main[data-route="learn"]'),example=main?.querySelector('#dana-short-example'),summary=example?.querySelector('summary');
if(example?.open&&summary){

frame.style.height=Math.max(400,Math.min(18000,Math.ceil(child.body.getBoundingClientRect().height)))+'px';
frame.contentWindow.scrollTo({top:0,left:0,behavior:'instant'});
lastStage=d.stage;window.scrollTo({top:window.scrollY+frame.getBoundingClientRect().top+frame.clientTop+summary.getBoundingClientRect().top,behavior:'instant'});return;
}
}
if(((kind==='thought'&&d.retainedHost===1)||(kind==='boundary'&&d.boundaryNative===1))&&d.type==='stage'&&typeof d.stage==='string'&&d.stage!==lastStage){lastStage=d.stage;frame.scrollIntoView({block:'start'});return;}
if(d.reviewDraft===1&&d.type==='height'&&Number.isFinite(d.height)){
let height=d.height;

if(kind==='thought'){const child=frame.contentDocument,example=child?.querySelector('main[data-route="learn"]')?.querySelector('#dana-short-example'),summary=example?.querySelector('summary');if(example?.open&&summary&&child.activeElement===summary)height=child.body.getBoundingClientRect().height;}
frame.style.height=Math.max(400,Math.min(18000,Math.ceil(height)))+'px';return;}
if((kind==='thought'&&d.reviewThoughtReset===1&&d.type==='open')||(kind==='boundary'&&d.boundaryNative===1&&d.type==='confirm')){protocol=kind;returnFocus=document.activeElement;document.getElementById('host-confirm-title').textContent='Clear this session?';document.getElementById('host-keep').hidden=kind==='boundary'&&!d.canReview;document.getElementById('host-clear').textContent=kind==='boundary'&&typeof d.confirmLabel==='string'?d.confirmLabel:'Clear and continue';if(!dialog.open)dialog.showModal();document.getElementById('host-cancel').focus();return;}
if((kind==='thought'&&d.reviewThoughtNative===1&&d.type==='exit'&&['page/review-finder','page/my-toolbox'].includes(d.route))||(kind==='boundary'&&d.boundaryNative===1&&d.type==='exit'&&d.target==='tools-index'))leave();
});
back.addEventListener('click',event=>{event.preventDefault();if(kind==='thought'){frame.contentWindow?.postMessage({retainedHost:1,type:'exit'},location.origin);}else{const button=frame.contentDocument?.getElementById('boundary-host-exit');if(button)button.click();else leave();}});
support.addEventListener('click',()=>destroy());
for(const choice of ['keep','clear','cancel'])document.getElementById('host-'+choice).addEventListener('click',()=>send(choice));
dialog.addEventListener('cancel',event=>{event.preventDefault();send('cancel');});
addEventListener('pagehide',destroy);addEventListener('pageshow',()=>{if(!frame.isConnected){protocol=null;lastStage=null;const fresh=frame.cloneNode(false);fresh.removeAttribute('style');fresh.src=initial;frame=fresh;dialog.before(frame);}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)frame.contentWindow?.postMessage(kind==='boundary'?{boundaryNative:1,type:'pause'}:{retainedHost:1,type:'pause'},location.origin);});
})();
