
(()=>{'use strict';
const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;};
function compose(main,{route,practiceRoute,prompt}){
 document.documentElement.classList.add('thought-modern');
 const heading=main.querySelector('h1');if(!heading)return;
 const intro=main.querySelector('.native-intro');const eyebrow=heading.previousElementSibling?.classList.contains('eyebrow')?heading.previousElementSibling:null;
 const masthead=el('header','thought-masthead');
 if(route==='intro'||route==='overview'){
  if(eyebrow)masthead.append(eyebrow);masthead.append(heading);
 }else{
  
  
  const title=el('h1','thought-tool-title','A thought record');title.tabIndex=-1;masthead.append(title);
  const routeHeading=el('h2','thought-route-heading');routeHeading.tabIndex=-1;
  for(const child of [...heading.childNodes])routeHeading.append(child);
  heading.replaceWith(routeHeading);
 }
 masthead.append(el('div','thought-secondary'));
 const choices=el('nav','skill-choices');choices.setAttribute('aria-label','Ways to use this skill');
 const active=route.startsWith('learn')?'learn':(['intro','overview','sources','clinician','share'].includes(route)?null:'practice');
 for(const [label,target,kind]of [['Practice this skill',practiceRoute,'practice'],['See an example','learn','example'],['Learn more','learn','learn']]){const b=el('button','skill-choice',label);b.type='button';b.dataset.route=target;if(kind==='example')b.dataset.section='dana-short-example';if(active===kind&&route!=='intro')b.setAttribute('aria-current','page');choices.append(b);}
 const content=el('section','thought-content');for(const child of [...main.childNodes])content.append(child);
 main.append(masthead,choices);
 if(prompt!==null){
  const workspace=el('div','practice-workspace');const nav=content.querySelector('.stepnav');nav.classList.add('prompt-navigation');nav.setAttribute('aria-label','Choose any practice prompt');content.classList.add('focus-stage');workspace.append(nav,content);main.append(workspace);
  const learner=content.querySelector('.learner-response'),dana=content.querySelector('.dana-response');if(learner&&dana)dana.before(learner);
 }else main.append(content);
 if(intro){
  choices.setAttribute('aria-label','Ways to use this skill, above description');choices.dataset.choicePosition='above';
  const lowerChoices=choices.cloneNode(true);lowerChoices.setAttribute('aria-label','Ways to use this skill, below description');lowerChoices.dataset.choicePosition='below';content.after(lowerChoices);
  intro.classList.add('orientation-sheet');const outline=intro.querySelector('.native-outline');if(outline)outline.classList.add('quiet-reading');
  
  
  intro.querySelector(':scope>.actions')?.remove();
  const oldGuidance=intro.querySelector(':scope>.small.muted');
  if(oldGuidance?.textContent.startsWith('Start opens the full teaching and examples.'))oldGuidance.remove();
 }
 if(route==='practise'){
  const independent=el('section','independent-option');independent.append(el('h2','','Casey’s independent example'));const b=el('button','secondary-action','Try it yourself with a new example');b.type='button';b.dataset.route='fresh';independent.append(b);content.append(independent);
 }
 if(route==='intro'||route==='overview'||route.startsWith('learn')){
  const resources=el('nav','background-links');resources.setAttribute('aria-label','Further background');for(const [label,target]of [['Sources and limits','sources'],['For therapists','clinician']]){const b=el('button','text-action',label);b.type='button';b.dataset.route=target;resources.append(b);}content.append(resources);
 }
 if(route==='learn'){
  const walkthrough=content.querySelector('#written-walkthrough');if(walkthrough)walkthrough.open=true;
  content.querySelector('.thought-film')?.classList.add('demonstration-section');
 }
 const review=document.querySelector('.native-review details'),footer=document.querySelector('.site-footer');if(review&&footer){review.classList.add('quiet-review');footer.append(review);}
}
function availability(main,node){const disclosure=el('details','delivery-note');disclosure.append(el('summary','','Reading, listening and privacy'),node);main.append(disclosure);}
window.ThoughtModernLayout=Object.freeze({compose,availability});
})();
