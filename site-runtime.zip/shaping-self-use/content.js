window.ShapingSelfUseContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/changing-behaviour",
  "componentId": "component/changing-behaviour/shaping",
  "resourceId": "tool/shaping-self-use",
  "routeProposal": "/shaping-self-use/",
  "title": "Shaping a Skill You Choose",
  "version": "2026-11-05-public-review-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. No recordings are provided for this practice; scripts are prepared and listening approval is not asserted.",
  "scope": "Therapist-introduced initial positive self-shaping of one freely chosen ordinary action: reinforce a reachable approximation, review real repeated occurrence, prospectively shift to a small closer criterion only after stability and consent, and repeat the reviewed process toward a finite goal.",
  "groupedSetStatus": "Complete bounded initial positive self-shaping acquisition cycle. Broader Shaping applications and classic/changing-behaviour remain incomplete. Other-person behavior management, negative reinforcement, schedule thinning, extinction and punishment are not implemented. No new canonical count.",
  "componentComplete": false,
  "implementedSubset": "initial-positive-self-shaping",
  "clinicalContract": {
    "learningObjective": "Distinguish shaping from a task list or reinforcement of one fixed target: successive approximations to the same chosen goal receive prompt positive consequences, and the qualifying step changes prospectively as the current step becomes stable.",
    "practiceObjective": "Define a finite goal and current ability, choose a reachable starting approximation and possible closer steps, select a safe wanted extra, state the current criterion and opportunities, actually use the contingent pair, review repeated occurrence and delivery, then keep, reduce, change, stop or prospectively advance one small criterion with therapist support.",
    "sourcePopulationContext": "2015 Linehan/Guilford Interpersonal Handouts20/22, Worksheet14 self-use branch and ManualXVII inform this bounded adaptation. Therapist introduction and individual fit are required. No age floor or all-age efficacy claim; developmental, communication, cultural, safeguarding, clinical and access fit remain necessary.",
    "exclusions": [
      "No changing another person, parenting/partner compliance programme, covert control or imposed goals",
      "No punishment, deprivation, response cost, removal of ordinary pleasures or making care, communication, safety or essential needs conditional",
      "No negative reinforcement application, extinction protocol, satiation, token economy, intermittent schedule or reward thinning",
      "No medical, eating, exercise, sleep, substance-use, self-harm, trauma/exposure or compulsive-checking targets",
      "No replacing needed skill instruction, rehabilitation, accommodation or access with a reward",
      "No fixed mastery quota, automatic advancement, behavior classification, purchases, monitoring or causal efficacy claim"
    ],
    "adaptations": [
      "Original finite ordinary self-use acquisition cycle rather than copied source forms, examples, other-person applications or group clicker game",
      "Only a safe optional added extra is linked to the current chosen approximation; care, rights, usual pleasures and support remain unconditional",
      "Current criterion is explicit and agreed before an opportunity; earlier earned extras are not removed and rules are never changed retrospectively",
      "Stability is reviewed from real comparable opportunities with the therapist, not inferred from one attempt, a mood, a click or a universal numerical threshold",
      "Direct blank review identifies the current criterion, actual action, delivery and subsequent occurrence before any advancement decision",
      "Acquisition endpoint includes review with the therapist; maintenance schedules and generalization to other settings are not claimed"
    ],
    "reviewGates": [
      "Owner/clinician acceptance of initial positive self-shaping scope, criterion advancement, exclusions, source adaptation and release rights",
      "Individual free choice, prior teaching, current ability, developmental/communication/cultural/safeguarding/access and clinical fit",
      "Human comprehension review; grade-five language is a target, not validated readability",
      "Integrated desktop/mobile/keyboard/screen-reader, navigation, selected-export and lifecycle acceptance",
      "Authorized exact-script narration production and actual listening before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "prepare",
      "review"
    ],
    "modeChoice": {
      "title": "Choose planning or review",
      "options": [
        {
          "value": "prepare",
          "label": "Plan a small shaping step",
          "startSectionId": "shaping-self-use.practice.situation"
        },
        {
          "value": "review",
          "label": "Review a step I tried or planned",
          "startSectionId": "shaping-self-use.practice.result"
        }
      ]
    },
    "entryGate": "Scope, free choice and safety boundaries visible before entry. No default mode, goal, step, consequence or fit inferred.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing, sequence, attempt or successful result.",
    "reviewAccess": "Direct blank review begins with the actual current criterion, action and consequence; then repeat observations and the next criterion decision. No saved plan, reinforcement effect or stability inferred.",
    "writing": "Optional and hidden initially; hiding removes private displays and invalidates export.",
    "persistence": "Open-page memory only; internal examples/help/mode changes retain. Clear/restart/leaving/reload/history/BFCache clear. Offscreen visibility alone retains.",
    "export": "No default selection. Literal selected preview/copy/download only. Edits, hiding, mode and stage changes invalidate export. Nothing sent.",
    "narration": "Exact static teaching/help only, never private notes. No audio, TTS, recording or autoplay.",
    "timer": "None. No required duration, practice count, reward amount, score, quota or streak.",
    "completion": "No inferred attempt, delivery, reinforcement, stability, criterion advancement, final goal or full component completion."
  },
  "intro": {
    "id": "shaping-self-use.intro",
    "title": "Build toward one chosen action",
    "paragraphs": [
      "Sometimes a whole action is not happening yet, but a small step toward it is possible. Shaping means starting with that step, adding a wanted extra after it, and moving to a slightly closer step once the current step is steady.",
      "This is more than making a list of easy and hard tasks. You decide what action counts now, what follows it, and what real practice shows before changing that rule. Enjoying an extra does not show that it helped the action happen more often later.",
      "Use this after your therapist has taught it and checked the fit. This page is for one freely chosen ordinary goal of your own. You can plan, use the made-up example, review an attempt or finish."
    ]
  },
  "fit": {
    "id": "shaping-self-use.fit",
    "title": "Your choice and needs stay in place",
    "paragraphs": [
      "Choose a safe action you want for your own reasons. The first step must be possible with the support you need. This page does not teach a missing skill or replace equipment, access, care or help.",
      "Food, water, medication, safety, toileting, communication aids, needed rest, care and ordinary support are never things to earn. Do not remove a usual pleasure, create discomfort or take something away to make a reward work. No penalty, debt or lost earned reward belongs here.",
      "Do not use this for changing another person or to push through pain, danger, abuse or distress. Medical, eating, exercise, sleep, substance-use, self-harm, trauma/exposure and compulsive-checking goals need other professional care, not this page.",
      "You can think, speak, sign, use a communication aid or explore the example. Writing and a particular sense or body action are not required. Agree the fit with your therapist, including age, understanding and access. Pause if this becomes pressure, shame or a rule you feel unable to stop."
    ]
  },
  "privacy": {
    "id": "shaping-self-use.privacy",
    "title": "Notes are optional and stay in this page",
    "paragraphs": [
      "Use a few words if helpful, or keep the plan in mind. This tool does not watch you, give rewards, record voice or send a report to anyone.",
      "Writing stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.",
      "Hiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox."
    ]
  },
  "close": {
    "id": "shaping-self-use.close",
    "title": "Finish at the point that fits",
    "paragraphs": [
      "You can finish after reading, planning, trying, reviewing or deciding not to use this. A partial attempt or unclear result does not say anything about your worth. You do not have to reach the final goal or feel better.",
      "If useful, take one observation or question to your therapist. No reminder or new task is created. Leaving clears notes from this tool, not outside copies."
    ]
  },
  "example": {
    "id": "shaping-self-use.example",
    "title": "A made-up practice: putting art tools in a tray",
    "paragraphs": [
      "Rowan wants to put three collage tools in a nearby tray at the end of art time. This would make the next session easier. Putting one tool away is possible, but putting all three away is not steady yet. Rowan chooses this goal freely with a therapist; access and usual help stay in place.",
      "The first agreed step is one tool in the tray. Right after that step at a planned art session, Rowan adds a small colored shape to a playful pattern page. Rowan likes this extra. Rest, usual art and other pleasures remain available whether or not the step happens.",
      "Rowan tries the pair at several suitable sessions and checks the actual action and extra. One session has no chance to try, so it is not counted as a missed step. At the others, one tool goes in the tray and the extra follows promptly. The pattern becomes steady; liking the extra alone would not show that.",
      "Before another practice, Rowan and the therapist agree to move to two tools. The same extra now follows two tools, rather than one. At first Rowan puts away only one. That does not meet the new step, so this planned extra is not added. Nothing already received is taken back, and ordinary care and pleasures stay available. Rowan reviews the size and support without a penalty.",
      "With a clearer place for both tools, Rowan later practises two tools and the extra together. When that step becomes steady across suitable chances, Rowan chooses to try three. At later suitable sessions, Rowan does put all three tools away and adds the extra promptly. The final review checks whether this is steady, what support helps and whether to end or change the plan. The extra may have helped, but the clearer tray and other changes may also matter. These made-up results do not predict yours."
    ]
  },
  "learn": {
    "id": "shaping-self-use.learn",
    "title": "A small step changes only after review",
    "paragraphs": [
      "In shaping, an approximation is a step that gets closer to the action you want. You begin with one you can do now. A wanted consequence follows that step. When it is steady, you agree a slightly closer step before trying it. The chosen consequence then follows the new step.",
      "A reinforcer is defined by what happens later: it makes an action more likely to happen again. Something pleasant is not proven to be a reinforcer just because you enjoy it. Informal notes can help you review, but cannot prove what caused a change.",
      "A graded task plan breaks a task into workable parts. Build Mastery focuses on a well-matched challenge. Reinforcing one fixed target keeps the same action-to-extra rule. Shaping adds careful changes to the step that qualifies for the extra, based on actual learning.",
      "This page covers only initial positive self-shaping toward one ordinary goal. Positive means adding a wanted extra. It does not mean being good. The page does not teach changing another person, removing unpleasant events, punishment, extinction or how to give rewards only some of the time.",
      "A plan that works in one setting may not work in another. Reaching a goal once does not mean it is steady or will stay that way. Review future use and support with your therapist; this page does not set a lasting reward schedule."
    ]
  },
  "practice": [
    {
      "id": "shaping-self-use.practice.situation",
      "title": "Choose a goal that belongs to you",
      "paragraphs": [
        "What ordinary action would you freely like to build toward? Choose one reason that matters to you, rather than a demand to be good, busy or pleasing to someone else. Rowan’s example is another way to learn the method.",
        "Check with your therapist that shaping fits. If you need new teaching, access or another kind of help, start there. You can decide this method is not right for you."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The ordinary goal I freely choose",
          "optional": true
        },
        {
          "key": "reason",
          "label": "Why it matters to me, or why it may not fit",
          "optional": true
        }
      ],
      "help": {
        "title": "If I do not want this goal",
        "text": "Pause and discuss whose goal it is. Shaping here is not a way to make you agree or to change someone else."
      }
    },
    {
      "id": "shaping-self-use.practice.target",
      "title": "Say what the finished action would look like",
      "paragraphs": [
        "Describe a clear, limited action you could notice. “Put these three tools in this tray after art” is clearer than “be tidy.” Keep the goal useful and realistic, not perfect or ever growing.",
        "Name the setting, suitable opportunity and support. What would show this chosen goal is happening? This is the endpoint to work toward, not a rule that you must reach before you receive any extra."
      ],
      "fields": [
        {
          "key": "target",
          "label": "The final action and what counts as doing it",
          "optional": true
        },
        {
          "key": "opportunity",
          "label": "The suitable occasion, setting and support",
          "optional": true
        }
      ],
      "help": {
        "title": "If the goal keeps growing",
        "text": "Keep one endpoint, or reconsider the goal with your therapist. This is not a plan for endless improvement."
      }
    },
    {
      "id": "shaping-self-use.practice.starting",
      "title": "Find the step you can do now",
      "paragraphs": [
        "What part or simpler version of that action already happens, or is within reach now? Use real recent examples if you have them. Leave unknown information unknown.",
        "Choose a first step close enough to be possible and clearly linked to the goal. Say exactly what counts. You do not have to wait for the whole action before adding the extra."
      ],
      "fields": [
        {
          "key": "starting-pattern",
          "label": "What currently happens at similar chances",
          "optional": true
        },
        {
          "key": "first-step",
          "label": "The first reachable step and what counts",
          "optional": true
        }
      ],
      "help": {
        "title": "If even the small step is not possible",
        "text": "Check support, instruction, size and access. A reward does not make an impossible action possible. Pause rather than push."
      }
    },
    {
      "id": "shaping-self-use.practice.path",
      "title": "Picture small steps toward the same goal",
      "paragraphs": [
        "Sketch a few possible closer versions between your first step and the final goal. Each should add only a small change. They are ideas to review, not a fixed ladder you must climb.",
        "Choose with your therapist what real repeated practice would show that a step is steady enough to consider changing it. A single success, a good feeling or a deadline is not enough by itself. There is no universal number set by this page."
      ],
      "fields": [
        {
          "key": "possible-steps",
          "label": "Possible small changes toward the final action",
          "optional": true
        },
        {
          "key": "steady-evidence",
          "label": "How we will judge a steady, workable step",
          "optional": true
        }
      ],
      "help": {
        "title": "If a later step looks too large",
        "text": "Break that change down or leave it undecided. You can choose a new smaller step after seeing what practice shows."
      }
    },
    {
      "id": "shaping-self-use.practice.extra",
      "title": "Choose a safe extra you want",
      "paragraphs": [
        "What small added extra would you welcome right after the current step? It needs to be safe, affordable, available and under your control. No purchase is required. It is a possible reinforcer to try, not one already proven to help.",
        "Keep food, rest, care, support and ordinary pleasures available either way. Do not make yourself go without to increase the extra’s value. Choose something else or leave the method if no suitable extra fits."
      ],
      "fields": [
        {
          "key": "extra",
          "label": "The wanted extra I might add",
          "optional": true
        },
        {
          "key": "extra-fit",
          "label": "Why it fits and any safety, access or cost limits",
          "optional": true
        }
      ],
      "help": {
        "title": "If I feel I must earn care",
        "text": "Stop this plan and discuss it. Your needs and rights are not a reward for reaching any step."
      }
    },
    {
      "id": "shaping-self-use.practice.link",
      "title": "State the current step-to-extra rule",
      "paragraphs": [
        "For the agreed practice opportunities, plan to add the extra promptly each time the current step happens. Do not wait for the final goal or for perfect performance beyond this step. Have the extra ready.",
        "Say what action qualifies now. If it does not happen, this particular planned extra does not follow. Do not add a penalty, take back an earlier extra or remove a normal pleasure. A missed or partial step is information to review."
      ],
      "fields": [
        {
          "key": "link-rule",
          "label": "The current qualifying step, then the extra",
          "optional": true
        },
        {
          "key": "timing",
          "label": "How the extra will be available right afterward",
          "optional": true
        }
      ],
      "help": {
        "title": "If the extra is delayed or missed",
        "text": "Keep that clear in review. An intended action-to-extra pair is not the same as one that actually happened."
      }
    },
    {
      "id": "shaping-self-use.practice.plan",
      "title": "Prepare suitable chances and a review",
      "paragraphs": [
        "Agree when this practice can fit and when to review it with your therapist. Keep the current step-to-extra rule clear during those chances. No automatic calendar, daily quota, streak or long-term reward schedule is set here.",
        "Prepare any cue, tools or support and decide when to pause. Think about how to remember the actual step, extra and later similar chances. Notes can be brief or absent. The page will not track them for you."
      ],
      "fields": [
        {
          "key": "plan-context",
          "label": "The agreed chances, cue and support",
          "optional": true
        },
        {
          "key": "plan-limits",
          "label": "Reasons to pause or change the plan",
          "optional": true
        },
        {
          "key": "plan-review",
          "label": "When and how I may review with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If life changes between practices",
        "text": "Check the fit again. Fewer opportunities or less capacity do not mean you have stopped caring about your goal."
      }
    },
    {
      "id": "shaping-self-use.practice.try",
      "title": "Try the current step in real life",
      "paragraphs": [
        "At a suitable agreed chance, try the current step. When it happens as defined, add the extra promptly as planned. Do not ask yourself to do the next step before giving the extra you already planned.",
        "You can stop, try only part or find that no opportunity happened. Do not repeat over and over just to earn more. Return to review the actual events, including a missed or delayed extra."
      ],
      "fields": [
        {
          "key": "actual-try",
          "label": "What I tried, partly tried, stopped or did not try",
          "optional": true
        },
        {
          "key": "try-context",
          "label": "Any relevant support, interruption or change",
          "optional": true
        }
      ],
      "help": {
        "title": "If I only planned",
        "text": "That is preparation, not a completed shaping attempt. You can finish here without inventing a result."
      }
    },
    {
      "id": "shaping-self-use.practice.result",
      "title": "Review the current step and what followed",
      "paragraphs": [
        "Which goal and current qualifying step are you reviewing? What did you actually do at the opportunity: the agreed step, part of it, something different or no attempt? You can start here without a saved plan.",
        "What extra actually followed, and how soon? Note when it was missed or delayed, or the rule differed from the plan. Was the extra welcome, neutral, uncomfortable or unclear? Liking it is not proof that the action became more likely."
      ],
      "fields": [
        {
          "key": "actual",
          "label": "The current step and what actually happened",
          "optional": true
        },
        {
          "key": "received",
          "label": "The actual extra, timing, or no extra",
          "optional": true
        },
        {
          "key": "experience",
          "label": "How the plan or extra felt, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot remember the rule",
        "text": "Leave that uncertain. You can review what is known and clarify a future rule before another attempt."
      }
    },
    {
      "id": "shaping-self-use.practice.compare",
      "title": "Check repeated practice before moving on",
      "paragraphs": [
        "Across later similar chances, did this same step become more steady, stay uneven, become harder or remain unclear? Compare real opportunities and starting information. A day with no suitable chance is different from a chance when the step did not happen.",
        "At those chances, did the extra follow the current step, and how soon? Check the actual action and delivery together. Different cues, support, health or settings may affect the pattern. Missing details stay unknown; a brief record does not prove cause.",
        "Use the signs of steadiness you agreed with your therapist. One successful attempt does not by itself mean it is time to raise the step. No improvement or too little information can be the honest result."
      ],
      "fields": [
        {
          "key": "observations",
          "label": "Later current-step actions and extras at similar chances",
          "optional": true
        },
        {
          "key": "comparison-limits",
          "label": "What is steady, changed, missing or uncertain",
          "optional": true
        },
        {
          "key": "review-question",
          "label": "What this may show, or what we need to check",
          "optional": true
        }
      ],
      "help": {
        "title": "If there have been no later chances",
        "text": "You cannot judge steadiness yet. Discuss whether more suitable practice fits; do not create extra demands just to get an answer."
      }
    },
    {
      "id": "shaping-self-use.practice.advance",
      "title": "Keep, reduce or agree one closer step",
      "paragraphs": [
        "If the current step is not steady or has become too hard, keep it, make it smaller, improve support or stop after review. Check whether the extra and timing fit. Do not answer difficulty by making the reward bigger or taking away ordinary pleasures.",
        "If the step is steady and a closer step is safe and freely chosen, agree one small change with your therapist before the next chance. State exactly what now qualifies for the same planned extra. From that point, the new step receives the extra; the earlier smaller step alone no longer does. This is a new plan, not a change to what you already did or earned.",
        "Repeat the practice and review for each agreed step toward the endpoint. You may pause or revise when capacity changes. No automatic next level is set by this page."
      ],
      "fields": [
        {
          "key": "adjustment",
          "label": "Keep, reduce, change, stop or move to one closer step",
          "optional": true
        },
        {
          "key": "adjustment-reason",
          "label": "What real observations support that choice",
          "optional": true
        },
        {
          "key": "new-rule",
          "label": "Any new qualifying step, extra and start point",
          "optional": true
        }
      ],
      "help": {
        "title": "If a new step turns out too large",
        "text": "Review the gap and support. Agree a smaller step for future chances if useful; do not quietly change past results or punish a partial attempt."
      }
    },
    {
      "id": "shaping-self-use.practice.next",
      "title": "Review the endpoint and what happens next",
      "paragraphs": [
        "If the final action is happening, check whether it is steady across suitable chances, not just done once. What support still helps, and does the goal still fit? You can end the shaping plan or discuss future practice with your therapist.",
        "This page does not teach how to reduce rewards or make the skill work in every setting. Do not assume it will last without support or switch to surprise rewards yourself. Take one observation or question forward if useful; a new plan is optional."
      ],
      "fields": [
        {
          "key": "next-choice",
          "label": "Where the goal stands and what I want to do next",
          "optional": true
        },
        {
          "key": "next-support",
          "label": "Support or a question for the next session",
          "optional": true
        }
      ],
      "help": {
        "title": "If I have not reached the final goal",
        "text": "You can finish this visit at any point. Review what happened and what fits now; your value does not depend on completing the plan."
      }
    }
  ],
  "sources": [
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "supports": "Printed pp.161/163: small reinforced approximations, stability before advancing, prompt delivery and person/context fit.",
      "limits": "Original bounded self-use acquisition adaptation, not copied forms or other-person applications; later intermittent schedules and other behavior-change procedures excluded.",
      "label": "Linehan/Guilford: 2015 Interpersonal Handouts20 and22"
    },
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "supports": "Printed p.194: self-use plan, actual use, observations and revision.",
      "limits": "Original optional prompts add explicit criterion and comparable-opportunity review; not the publisher worksheet or a validated digital protocol.",
      "label": "Linehan/Guilford: 2015 Interpersonal Worksheet14"
    },
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Printed pp.306–310: functional reinforcement, safe realistic choices, self-shaping, stability and timing; pp.314–316 address contextual fit.",
      "limits": "2015 source, not revised-2025 equivalence. Group clicker game, deprivation, controlling others and maintenance schedules are deliberately not implemented.",
      "label": "Linehan/Guilford: 2015 teaching manual sectionXVII"
    },
    {
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Choice, refusal and access to communication and support.",
      "limits": "Rights guidance, not clinical validation or proof of equivalent effects across adaptations.",
      "label": "ASHA/NJC: Communication Bill of Rights"
    },
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "supports": "Copyright page ii excludes public electronic redistribution from purchaser duplication permission.",
      "limits": "Source access does not grant public app rights; clinical and release-rights decisions remain open.",
      "label": "Guilford: Limited duplication licence"
    }
  ],
  "narrationSegments": [
    {
      "id": "shaping-self-use.intro",
      "title": "Build toward one chosen action",
      "text": "Sometimes a whole action is not happening yet, but a small step toward it is possible. Shaping means starting with that step, adding a wanted extra after it, and moving to a slightly closer step once the current step is steady.\n\nThis is more than making a list of easy and hard tasks. You decide what action counts now, what follows it, and what real practice shows before changing that rule. Enjoying an extra does not show that it helped the action happen more often later.\n\nUse this after your therapist has taught it and checked the fit. This page is for one freely chosen ordinary goal of your own. You can plan, use the made-up example, review an attempt or finish.",
      "sha256": "94d27d8afee98559f11c06ac30999aa9167b6b30f6275ad5bb477f3584a4c8e2",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.fit",
      "title": "Your choice and needs stay in place",
      "text": "Choose a safe action you want for your own reasons. The first step must be possible with the support you need. This page does not teach a missing skill or replace equipment, access, care or help.\n\nFood, water, medication, safety, toileting, communication aids, needed rest, care and ordinary support are never things to earn. Do not remove a usual pleasure, create discomfort or take something away to make a reward work. No penalty, debt or lost earned reward belongs here.\n\nDo not use this for changing another person or to push through pain, danger, abuse or distress. Medical, eating, exercise, sleep, substance-use, self-harm, trauma/exposure and compulsive-checking goals need other professional care, not this page.\n\nYou can think, speak, sign, use a communication aid or explore the example. Writing and a particular sense or body action are not required. Agree the fit with your therapist, including age, understanding and access. Pause if this becomes pressure, shame or a rule you feel unable to stop.",
      "sha256": "6f7db6b540d70fe2619df70d47a4ea5fc412e801399c1d8c5dc1071f0552002f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.privacy",
      "title": "Notes are optional and stay in this page",
      "text": "Use a few words if helpful, or keep the plan in mind. This tool does not watch you, give rewards, record voice or send a report to anyone.\n\nWriting stays in this open page through examples, help and mode changes. Leaving, reloading, clearing or starting again removes notes from this tool. To keep something, select only what you want, check the preview, then copy or download. Copies remain wherever you save them.\n\nHiding writing removes private displays but keeps the text in this open page. Someone using your device or a screen reader may access it when shown. Clearing the tool does not erase browser history, device activity or outside copies. The session shortcut saves no answers and is not a saved item in your usual Toolbox.",
      "sha256": "c577f59ed715da0e7b72f473214636a3e16c999dc8fdc9879841e158c52f7117",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.close",
      "title": "Finish at the point that fits",
      "text": "You can finish after reading, planning, trying, reviewing or deciding not to use this. A partial attempt or unclear result does not say anything about your worth. You do not have to reach the final goal or feel better.\n\nIf useful, take one observation or question to your therapist. No reminder or new task is created. Leaving clears notes from this tool, not outside copies.",
      "sha256": "62ca501f5a9bbb15b9e0114caa9b251d40b63184b369272e946e787b67464b11",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.example",
      "title": "A made-up practice: putting art tools in a tray",
      "text": "Rowan wants to put three collage tools in a nearby tray at the end of art time. This would make the next session easier. Putting one tool away is possible, but putting all three away is not steady yet. Rowan chooses this goal freely with a therapist; access and usual help stay in place.\n\nThe first agreed step is one tool in the tray. Right after that step at a planned art session, Rowan adds a small colored shape to a playful pattern page. Rowan likes this extra. Rest, usual art and other pleasures remain available whether or not the step happens.\n\nRowan tries the pair at several suitable sessions and checks the actual action and extra. One session has no chance to try, so it is not counted as a missed step. At the others, one tool goes in the tray and the extra follows promptly. The pattern becomes steady; liking the extra alone would not show that.\n\nBefore another practice, Rowan and the therapist agree to move to two tools. The same extra now follows two tools, rather than one. At first Rowan puts away only one. That does not meet the new step, so this planned extra is not added. Nothing already received is taken back, and ordinary care and pleasures stay available. Rowan reviews the size and support without a penalty.\n\nWith a clearer place for both tools, Rowan later practises two tools and the extra together. When that step becomes steady across suitable chances, Rowan chooses to try three. At later suitable sessions, Rowan does put all three tools away and adds the extra promptly. The final review checks whether this is steady, what support helps and whether to end or change the plan. The extra may have helped, but the clearer tray and other changes may also matter. These made-up results do not predict yours.",
      "sha256": "165131120a14e7c4105f7b2e5ad22784eb400bf325c9ac84d2ad7cc70f27cfc5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.learn",
      "title": "A small step changes only after review",
      "text": "In shaping, an approximation is a step that gets closer to the action you want. You begin with one you can do now. A wanted consequence follows that step. When it is steady, you agree a slightly closer step before trying it. The chosen consequence then follows the new step.\n\nA reinforcer is defined by what happens later: it makes an action more likely to happen again. Something pleasant is not proven to be a reinforcer just because you enjoy it. Informal notes can help you review, but cannot prove what caused a change.\n\nA graded task plan breaks a task into workable parts. Build Mastery focuses on a well-matched challenge. Reinforcing one fixed target keeps the same action-to-extra rule. Shaping adds careful changes to the step that qualifies for the extra, based on actual learning.\n\nThis page covers only initial positive self-shaping toward one ordinary goal. Positive means adding a wanted extra. It does not mean being good. The page does not teach changing another person, removing unpleasant events, punishment, extinction or how to give rewards only some of the time.\n\nA plan that works in one setting may not work in another. Reaching a goal once does not mean it is steady or will stay that way. Review future use and support with your therapist; this page does not set a lasting reward schedule.",
      "sha256": "0370194e6e354f9699dc103c16adcf7aa824d7f0414b23aad930cf99794c8948",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.situation",
      "title": "Choose a goal that belongs to you",
      "text": "What ordinary action would you freely like to build toward? Choose one reason that matters to you, rather than a demand to be good, busy or pleasing to someone else. Rowan’s example is another way to learn the method.\n\nCheck with your therapist that shaping fits. If you need new teaching, access or another kind of help, start there. You can decide this method is not right for you.",
      "sha256": "e105f4d0c8655f4451f5afec0be4ab8e06471a07973d9efc7c189b3051a825fc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.situation.help",
      "title": "If I do not want this goal",
      "text": "Pause and discuss whose goal it is. Shaping here is not a way to make you agree or to change someone else.",
      "sha256": "a460f3c8a01be5b5ab79f1c81803fa213fa501282a81fe7a963db18523c511bd",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.target",
      "title": "Say what the finished action would look like",
      "text": "Describe a clear, limited action you could notice. “Put these three tools in this tray after art” is clearer than “be tidy.” Keep the goal useful and realistic, not perfect or ever growing.\n\nName the setting, suitable opportunity and support. What would show this chosen goal is happening? This is the endpoint to work toward, not a rule that you must reach before you receive any extra.",
      "sha256": "4e740a73c44d8a51a35c190259f8da07fd9ace3a906e01eff2ea80ad16be7949",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.target.help",
      "title": "If the goal keeps growing",
      "text": "Keep one endpoint, or reconsider the goal with your therapist. This is not a plan for endless improvement.",
      "sha256": "056316e51820d69676f217aff65538340c751b65db5efa24e8bb94a95d115df2",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.starting",
      "title": "Find the step you can do now",
      "text": "What part or simpler version of that action already happens, or is within reach now? Use real recent examples if you have them. Leave unknown information unknown.\n\nChoose a first step close enough to be possible and clearly linked to the goal. Say exactly what counts. You do not have to wait for the whole action before adding the extra.",
      "sha256": "a84a6ca5a15a9d7af2eeb20bc4c9397a7d3c2dba4fbdd431d79b57837191fbe4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.starting.help",
      "title": "If even the small step is not possible",
      "text": "Check support, instruction, size and access. A reward does not make an impossible action possible. Pause rather than push.",
      "sha256": "e69cda66008c83a74afa425fcba2cde844718eb571b2565eddef4fe5a130a877",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.path",
      "title": "Picture small steps toward the same goal",
      "text": "Sketch a few possible closer versions between your first step and the final goal. Each should add only a small change. They are ideas to review, not a fixed ladder you must climb.\n\nChoose with your therapist what real repeated practice would show that a step is steady enough to consider changing it. A single success, a good feeling or a deadline is not enough by itself. There is no universal number set by this page.",
      "sha256": "6f1c51f53b32309291509d86e91bfbb69c9344d2c981ead22d7df209cc8c38e5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.path.help",
      "title": "If a later step looks too large",
      "text": "Break that change down or leave it undecided. You can choose a new smaller step after seeing what practice shows.",
      "sha256": "97b471319b75e47d2cca101eef6632066179f8e83554f83c6ae0ae49d5c1f295",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.extra",
      "title": "Choose a safe extra you want",
      "text": "What small added extra would you welcome right after the current step? It needs to be safe, affordable, available and under your control. No purchase is required. It is a possible reinforcer to try, not one already proven to help.\n\nKeep food, rest, care, support and ordinary pleasures available either way. Do not make yourself go without to increase the extra’s value. Choose something else or leave the method if no suitable extra fits.",
      "sha256": "469f49567ff0db6f787e5de63654f3a71baf120c96d5d6c15b7d5e9a9c6d31e6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.extra.help",
      "title": "If I feel I must earn care",
      "text": "Stop this plan and discuss it. Your needs and rights are not a reward for reaching any step.",
      "sha256": "7a77d02883449a05702ee5c67114879b4e75b6b5cba183c766a8e44ec11e0aae",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.link",
      "title": "State the current step-to-extra rule",
      "text": "For the agreed practice opportunities, plan to add the extra promptly each time the current step happens. Do not wait for the final goal or for perfect performance beyond this step. Have the extra ready.\n\nSay what action qualifies now. If it does not happen, this particular planned extra does not follow. Do not add a penalty, take back an earlier extra or remove a normal pleasure. A missed or partial step is information to review.",
      "sha256": "5408443c8c04782cea287985c18881dbbdd10a7e1fb9bc67014b364f945047cf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.link.help",
      "title": "If the extra is delayed or missed",
      "text": "Keep that clear in review. An intended action-to-extra pair is not the same as one that actually happened.",
      "sha256": "c0f975f259095f35c0c3409812f6499c4a237095ad467800a51a83ffc68f797f",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.plan",
      "title": "Prepare suitable chances and a review",
      "text": "Agree when this practice can fit and when to review it with your therapist. Keep the current step-to-extra rule clear during those chances. No automatic calendar, daily quota, streak or long-term reward schedule is set here.\n\nPrepare any cue, tools or support and decide when to pause. Think about how to remember the actual step, extra and later similar chances. Notes can be brief or absent. The page will not track them for you.",
      "sha256": "6e19c6920549cf80bd1f08d8e9e476b8c97e0c3970f8c63daaf5ecbb1abbda67",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.plan.help",
      "title": "If life changes between practices",
      "text": "Check the fit again. Fewer opportunities or less capacity do not mean you have stopped caring about your goal.",
      "sha256": "d984defcd8fd79560758584eb78cf2f1d20df8f6472eff378ab822cf833c01fa",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.try",
      "title": "Try the current step in real life",
      "text": "At a suitable agreed chance, try the current step. When it happens as defined, add the extra promptly as planned. Do not ask yourself to do the next step before giving the extra you already planned.\n\nYou can stop, try only part or find that no opportunity happened. Do not repeat over and over just to earn more. Return to review the actual events, including a missed or delayed extra.",
      "sha256": "15625c2ff06932fe1042096c2f781bd683e82c3672f334965dbdb7b743c106e7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.try.help",
      "title": "If I only planned",
      "text": "That is preparation, not a completed shaping attempt. You can finish here without inventing a result.",
      "sha256": "a860cce91768ae45f269a65c2cc26262a8ff15be92d39dd85db5cd678ad55617",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.result",
      "title": "Review the current step and what followed",
      "text": "Which goal and current qualifying step are you reviewing? What did you actually do at the opportunity: the agreed step, part of it, something different or no attempt? You can start here without a saved plan.\n\nWhat extra actually followed, and how soon? Note when it was missed or delayed, or the rule differed from the plan. Was the extra welcome, neutral, uncomfortable or unclear? Liking it is not proof that the action became more likely.",
      "sha256": "942d41b3afbf404be6fe9c7ad29e63ad187457ab6ae34e825ce17bd9173ef5e3",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.result.help",
      "title": "If I cannot remember the rule",
      "text": "Leave that uncertain. You can review what is known and clarify a future rule before another attempt.",
      "sha256": "0fe54987fe82e8430a90ce9dbe87c9695c2ead321298f155e6223d1b9b351635",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.compare",
      "title": "Check repeated practice before moving on",
      "text": "Across later similar chances, did this same step become more steady, stay uneven, become harder or remain unclear? Compare real opportunities and starting information. A day with no suitable chance is different from a chance when the step did not happen.\n\nAt those chances, did the extra follow the current step, and how soon? Check the actual action and delivery together. Different cues, support, health or settings may affect the pattern. Missing details stay unknown; a brief record does not prove cause.\n\nUse the signs of steadiness you agreed with your therapist. One successful attempt does not by itself mean it is time to raise the step. No improvement or too little information can be the honest result.",
      "sha256": "0cb6bcccbb7bc1a10bf5a41aaec719213df7a77308df0223ada9f96863d3a7ae",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.compare.help",
      "title": "If there have been no later chances",
      "text": "You cannot judge steadiness yet. Discuss whether more suitable practice fits; do not create extra demands just to get an answer.",
      "sha256": "4adb9ab487ce4773a63c0dcbe42e2306f5e700341dc248eada3538491439b4f9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.advance",
      "title": "Keep, reduce or agree one closer step",
      "text": "If the current step is not steady or has become too hard, keep it, make it smaller, improve support or stop after review. Check whether the extra and timing fit. Do not answer difficulty by making the reward bigger or taking away ordinary pleasures.\n\nIf the step is steady and a closer step is safe and freely chosen, agree one small change with your therapist before the next chance. State exactly what now qualifies for the same planned extra. From that point, the new step receives the extra; the earlier smaller step alone no longer does. This is a new plan, not a change to what you already did or earned.\n\nRepeat the practice and review for each agreed step toward the endpoint. You may pause or revise when capacity changes. No automatic next level is set by this page.",
      "sha256": "8bfe2239f61337973444a85c11a8896e3af389328ad2a752c8959be8116107c8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.advance.help",
      "title": "If a new step turns out too large",
      "text": "Review the gap and support. Agree a smaller step for future chances if useful; do not quietly change past results or punish a partial attempt.",
      "sha256": "f7248633d15919e1298e4f115928f2921c8eafb00c2383aaf1f93784cce3f168",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "shaping-self-use.practice.next",
      "title": "Review the endpoint and what happens next",
      "text": "If the final action is happening, check whether it is steady across suitable chances, not just done once. What support still helps, and does the goal still fit? You can end the shaping plan or discuss future practice with your therapist.\n\nThis page does not teach how to reduce rewards or make the skill work in every setting. Do not assume it will last without support or switch to surprise rewards yourself. Take one observation or question forward if useful; a new plan is optional.",
      "sha256": "63cb20ef8bfdaa04203b61c08426c72b14b1c632da352d872de45f71932a1549",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "shaping-self-use.practice.next.help",
      "title": "If I have not reached the final goal",
      "text": "You can finish this visit at any point. Review what happened and what fits now; your value does not depend on completing the plan.",
      "sha256": "799c81107dd3a1d0b80f086f10ae8a36d3694da1662bc32f98ed556ed1453ef1",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
