window.InterpersonalLegacy = {
  "preview": [
    [
      "give-g",
      "Going in, I want to avoid: ",
      "."
    ],
    [
      "give-i",
      "If there's a pause, I can ask: "
    ],
    [
      "give-v",
      "I can acknowledge their side by saying: "
    ]
  ]
};
