window.InterpersonalContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass.",
    "All named method elements have an actual optional attempt, not only acronym definitions.",
    "Response selection reveals only that branch and asks for a next-turn attempt; changing branch stops old audio and warns that retained response notes may refer to the prior branch.",
    "Source example text, selected-note export, existing guide linkage and saved identities preserved or explicitly version-reconciled.",
    "No renderer may claim selected export works until the adapter, preview and user-selected download/copy are tested.",
    "No runtime claims from this script-only contract; content, integration, accessibility and listening approvals remain separate."
  ],
  "id": "classic/give",
  "resourceId": "tool/give",
  "routeProposal": "tool/give",
  "title": "GIVE",
  "subtitle": "Communicate with care",
  "version": "2026-11-03-interpersonal-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "The complete named GIVE element set in an original guided rehearsal. Not the whole interpersonal effectiveness module, a safety assessment or comprehensive DBT.",
  "clinicalContract": {
    "learningObjective": "GIVE practises listening and expressing a concern with respect for the relationship, without giving up your own limits.",
    "practiceObjective": "Rehearse a gentle opening, genuine listening, accurate acknowledgement and a suitable manner, then respond to another perspective without compelled agreement.",
    "sourcePopulationContext": "Therapist-introduced practice with individual developmental, communication, consent, privacy, safeguarding and support review. No universal age gate or all-age validation claim. Historical and revised DBT sources do not validate this specific digital adaptation.",
    "observedPractice": "A privately spoken, imagined or optionally written attempt and a possible-response rehearsal. Reading, rehearsing and having a real conversation are distinct; no automatic completion inference."
  },
  "privacy": {
    "id": "give.privacy",
    "title": "Writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay in this open tool while you use its practice, example and help.",
      "Leaving this tool, reloading, clearing or starting again removes the notes here. If you choose to keep notes, only the notes you explicitly select are included in the copy or download you request. That copy remains outside this tool until you remove it.",
      "Saving this tool keeps a shortcut, not your writing. Nothing is sent to your therapist or read aloud. This tool is not monitored."
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; free jump, Show all, Back and Finish remain available. Practice enters or resumes practice directly; no duplicated intro Start button.",
    "writing": "Hidden by default, optional; hide all private echoes and previews when hidden. No mandatory field or automatic analysis.",
    "modes": [
      "practice"
    ],
    "persistence": "In-memory active-tool session only. Internal help/example/back preserves choice and notes. Leave/reload/restart/clear removes notes and echoes. Selected-note copy/download only by explicit selection and separate user action; no backend, localStorage or diary.",
    "narration": "Script only; no asset assumed to match. Listen/Pause/Resume; Replay unavailable until actual playback of that exact current clip. No TTS, new provider, private-answer narration or approval claim.",
    "timer": "None",
    "visual": "Method letters and textual labels orient; no score, streak, mastery badge or success animation.",
    "fictionalPractice": "Explicit optional personal / retained fictional example choice, no default inference or personal input prefill. Neither choice is a completion gate. Changing context preserves existing notes but visibly warns they may refer to earlier context; clear only on explicit reset or leaving.",
    "responsePractice": "One explicitly selected authored possible reply is visible at a time. It is a possibility, not a prediction. Prompt a second-turn attempt, then optional revision. No AI interlocutor or automatic scoring. Unselected branches are not narrated.",
    "pendingSharedPatterns": "Candidate only: critique may redirect shell, focus, choice presentation and closure. Preserve clinical meaning and privacy invariants when adapting."
  },
  "intro": {
    "id": "give.intro",
    "title": "GIVE",
    "paragraphs": [
      "GIVE practises listening and expressing a concern with respect for the relationship, without giving up your own limits.",
      "Choose an ordinary conversation where it is reasonably safe to practise, or use the fictional example. You can rehearse silently, aloud or with optional notes. You do not have to contact anyone."
    ],
    "actions": []
  },
  "fit": {
    "id": "give.fit",
    "title": "Check whether this fits",
    "paragraphs": [
      "Use this with your therapist’s guidance and a situation that is manageable for you. You can leave out personal details, use fiction, or stop.",
      "If someone may threaten, control, punish or harm you for speaking up, start with support and safety rather than a communication script. This tool cannot assess what is safe. You do not have to keep engaging with threats or abuse.",
      "A clear, respectful response does not control another person’s reaction. Lack of agreement does not mean you failed."
    ]
  },
  "practice": [
    {
      "id": "give.practice.prepare",
      "title": "Choose the conversation and priority",
      "paragraphs": [
        "Use Kit’s cancelled-plans example or choose your own manageable situation. What matters most here: a specific request or refusal, the relationship, or how you act in relation to your values?",
        "These priorities may overlap or conflict. Choose a focus for this practice without treating the others as unimportant. You can switch to a related skill or finish."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "Situation, if I want to write",
          "optional": true
        },
        {
          "key": "priority",
          "label": "What matters most here",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot choose a priority",
        "text": "You can try the fictional example or discuss the situation with your therapist. This is not a score that decides how forceful to be."
      }
    },
    {
      "id": "give.practice.gentle",
      "title": "G: Be Gentle",
      "paragraphs": [
        "Try a respectful opening without insults, threats, ridicule or attacks. Anger can be expressed directly without attacking the person."
      ],
      "fields": [
        {
          "key": "give-g",
          "label": "What to avoid",
          "optional": true
        }
      ],
      "help": {
        "title": "If gentle sounds like agreeing",
        "text": "You can be direct about disappointment or a limit. Gentle does not mean appeasing someone or continuing an unsafe exchange."
      }
    },
    {
      "id": "give.practice.interested",
      "title": "I: Act Interested",
      "paragraphs": [
        "Ask one genuine question or listen to what the other person says. Leave space for an answer instead of preparing a rebuttal.",
        "In fiction, read the supplied reply before rehearsing your next turn. In a real conversation, do not invent what the person must mean."
      ],
      "fields": [
        {
          "key": "give-i",
          "label": "A listening question",
          "optional": true
        }
      ],
      "help": {
        "title": "If they do not want to talk now",
        "text": "You can respect that limit and consider another time. Interest does not entitle you to an explanation or require a particular gaze or posture."
      }
    },
    {
      "id": "give.practice.validate",
      "title": "V: Validate",
      "paragraphs": [
        "Try acknowledging a feeling, difficulty or perspective you can reasonably understand. Check uncertain interpretations rather than stating them as facts.",
        "You can acknowledge their experience and still disagree, express your own experience or keep a limit."
      ],
      "fields": [
        {
          "key": "give-v",
          "label": "What I can acknowledge",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot agree with the account",
        "text": "You might acknowledge disappointment without confirming an accusation. Do not invent a sympathetic reason, validate a harmful claim as true or excuse harmful behaviour."
      }
    },
    {
      "id": "give.practice.easy",
      "title": "E: Use an Easy manner",
      "paragraphs": [
        "Try your words in a respectful manner that fits the situation and your way of communicating. Notice whether an unnecessary jab or sarcastic phrase can be left out.",
        "Warmth or humour may fit, but they are optional. You do not have to smile, joke, make eye contact or conceal distress."
      ],
      "fields": [
        {
          "key": "give-e",
          "label": "A manner or wording I could try",
          "optional": true
        }
      ],
      "help": {
        "title": "If humour would feel wrong",
        "text": "Do not use it. A straightforward, respectful delivery can fit better. The other person’s approval is not the test."
      }
    },
    {
      "id": "give.practice.rehearse",
      "title": "Rehearse the opening",
      "paragraphs": [
        "Try your opening once, privately, aloud or in optional notes. You can try just the part you are working on rather than a polished speech.",
        "Then choose a possible response below if you want to rehearse the next turn. Another person may respond differently."
      ],
      "fields": [
        {
          "key": "opening",
          "label": "My opening attempt, if useful",
          "optional": true
        }
      ]
    },
    {
      "id": "give.practice.respond",
      "title": "Practise a possible next turn",
      "paragraphs": [
        "Choose one possible response. Read it, then try what you might say or do next. A pause or ending the exchange can be a response.",
        "If no branch fits, you can imagine your own ordinary reply or leave this step. Nothing is selected for you."
      ],
      "fields": [
        {
          "key": "response",
          "label": "My possible next response, if useful",
          "optional": true
        }
      ]
    },
    {
      "id": "give.practice.review",
      "title": "Review and, if useful, try again",
      "paragraphs": [
        "Did you leave room for the other person’s account, acknowledge only what you could reasonably understand, and keep any needed limit? Could you try a more respectful version without forcing warmth or agreement?",
        "Try one revised response if you want. You can also leave the practice here with uncertainty, discomfort or no change."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I noticed or might revise",
          "optional": true
        }
      ]
    }
  ],
  "close": {
    "id": "give.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can finish after reading, rehearsing, revising or stopping. Agreement, confidence and a change in feeling are not required.",
      "You can return to any part, keep only notes you deliberately select, save a shortcut to the tool, or finish and clear the notes here."
    ],
    "actions": [
      "Back to practice",
      "Choose notes to keep",
      "Save this tool",
      "Finish and clear"
    ],
    "reflectionReview": {
      "legacyOptions": [
        "Helpful",
        "No change",
        "Unsure",
        "Uncomfortable",
        "Skip"
      ],
      "status": "Preserve as retained provenance, not automatically rendered. Usefulness-versus-outcome ambiguity needs independent/shared-pattern review. No rating required."
    }
  },
  "sources": [
    {
      "id": "linehan-handouts-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical interpersonal handouts 4–7 establish priorities and 7/4/4 named elements; not copied client worksheets.",
      "limits": "Not exact revised 2025 wording or evidence validating this app. Restricted reproduction license."
    },
    {
      "id": "linehan-worksheets-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Interpersonal worksheets 3–5 include priorities, mental/spoken rehearsal and reviewing use.",
      "limits": "Original app copy and examples only; no worksheet redistribution."
    },
    {
      "id": "linehan-revised-2025",
      "url": "https://www.guilford.com/books/DBT-Skills-Training-Handouts-and-Worksheets/Marsha-Linehan/9781462556342",
      "reviewed": "2026-11-03",
      "supports": "Current revised edition and inclusive-language update.",
      "limits": "Accessible sample does not contain the target handouts; exact revised target procedure not verified."
    },
    {
      "id": "rathus-miller",
      "url": "https://www.guilford.com/excerpts/rathus_ch1.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Developmentally informed adolescent DBT and differing support needs.",
      "limits": "No universal age threshold or all-age/app validation inference."
    }
  ],
  "learn": {
    "id": "give.learn",
    "title": "Care for the relationship without losing your position",
    "paragraphs": [
      "GIVE concerns how you relate while talking: Gentle, Interested, Validate and Easy manner. It is not a promise that someone will like you or agree.",
      "Validation acknowledges something understandable in the other person’s experience. It does not establish that every interpretation is true, approve harm or require you to abandon a boundary.",
      "DEAR MAN helps make a request or refusal; FAST helps consider fairness and self-respect. A caring manner does not replace either purpose."
    ]
  },
  "example": {
    "id": "give.example",
    "title": "Example: Kit wants more notice",
    "paragraphs": [
      "Kit is disappointed after a friend cancels twice. Kit says, “I’m disappointed we haven’t met. What’s been getting in the way?” The friend explains an unpredictable work schedule. Kit replies, “It sounds hard to plan around changing shifts. I still need some notice if we’re changing plans.”",
      "Kit listens and acknowledges the explanation without pretending the disappointment has gone or that every cancellation is acceptable. A respectful manner can be direct; humour, eye contact and a smile aren’t required."
    ]
  },
  "practiceScenario": {
    "id": "give.scenario",
    "title": "Practise with Kit",
    "paragraphs": [
      "Kit wants to understand the friend’s circumstances while asking for notice when plans change. Use that fictional conversation or a manageable situation of your own.",
      "You do not have to make the friend feel better or decide whose feelings are correct."
    ]
  },
  "responses": [
    {
      "id": "different",
      "label": "They describe it differently",
      "reply": {
        "id": "give.response.different.reply",
        "title": "One possible reply",
        "paragraphs": [
          "“I thought our plans were only tentative.”"
        ]
      },
      "practice": {
        "id": "give.response.different.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try checking what you heard, acknowledging any understandable uncertainty and saying what you understood without declaring motives.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Kit: “You thought we had not confirmed. I thought we had. Could we make that clearer next time?”"
        }
      }
    },
    {
      "id": "cannot",
      "label": "They understand but cannot meet the request",
      "reply": {
        "id": "give.response.cannot.reply",
        "title": "One possible reply",
        "paragraphs": [
          "“I understand, but sometimes my shift changes without notice.”"
        ]
      },
      "practice": {
        "id": "give.response.cannot.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try acknowledging the constraint and saying what remains workable for you. You do not have to pretend the difficulty is solved.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Kit: “That sounds hard to plan around. Could you let me know when you find out? I may need to make other plans.”"
        }
      }
    },
    {
      "id": "dismiss",
      "label": "They dismiss the concern",
      "reply": {
        "id": "give.response.dismiss.reply",
        "title": "One possible reply",
        "paragraphs": [
          "“You are making too much of this.”"
        ]
      },
      "practice": {
        "id": "give.response.dismiss.practice",
        "title": "Try your next response",
        "paragraphs": [
          "Try a respectful restatement or a pause. You do not have to persuade the person to validate you.",
          "Think it, say it or use the optional response notes. You can pause or leave this unpractised."
        ],
        "help": {
          "title": "If you want a starting point",
          "text": "For Kit: “It matters to me to know when plans change. I’m going to pause this conversation for now.” If there is harm or coercion, prioritise support rather than preserving warmth."
        }
      }
    }
  ],
  "methodElements": [
    "Gentle",
    "Interested",
    "Validate",
    "Easy manner"
  ],
  "legacyCompatibility": {
    "savedIdentity": {
      "passage": "interpersonal",
      "card": "card-interpersonal-give-stay-connected-while-you-say-it"
    },
    "guide": {
      "status": "Retain route association; exact current PDF compatibility must be checked or explicitly versioned before replacement."
    },
    "selectedExport": "Preserve NativeRefinements.selectedExport behavior through an explicit adapter: no default-selected private content, preview exact selected notes, separate copy/download action, include built draft only if explicitly selected. Hide every private echo when writing hides. No automatic export on Finish.",
    "preview": "Legacy note-preview behavior must remain available or be explicitly reconciled, not silently replaced by a generic assembled conversation. New method/rehearsal notes can be individually selected without changing original field meaning.",
    "records": "Preserve original narration entries and text/asset hashes as provenance; no new text may inherit an old recording merely because route or title matches.",
    "previewDetails": "Original give-g/give-i/give-v preview uses retained authored contextual prefixes. Label it a note preview, not a verbatim transcript. Keep new give-e separate unless explicitly selected."
  },
  "productAdaptations": [
    "Original guided prompts and second-turn rehearsals deepen existing named practice, not official numbered worksheet steps.",
    "Retained Rae/Kit/Ali example paragraphs preserved exactly from retained written examples; extra fictional replies explicitly authored candidates.",
    "No universal age gate, mandatory gaze/humour/speech fluency, coerced negotiation, guaranteed agreement or automatic clinical fit.",
    "Seven/four/four elements remain visible and practicable; no field is required; all prompts can be jumped to or left."
  ],
  "implementationGates": {
    "capabilityClaims": "Do not render or narrate privacy/close claims until verified session retention/clearing, shortcut save, explicit selected-note preview/copy/download, and accurate external-copy warning work in the actual candidate renderer. Otherwise keep the contract unimplemented; do not silently omit actions or promise unsupported behavior.",
    "gatedSectionIds": [
      "give.privacy",
      "give.close"
    ],
    "testsRequired": [
      "Internal example/help/back retains notes and choices",
      "Leave/reload/restart/clear erases notes and every echo",
      "Save shortcut preserves correct legacy identity and saves no notes",
      "No selected export by default; exact explicit selection and preview before copy/download",
      "Hiding writing hides selected previews and all private echoes"
    ]
  },
  "narrationSegments": [
    {
      "id": "give.privacy",
      "title": "Writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay in this open tool while you use its practice, example and help.\n\nLeaving this tool, reloading, clearing or starting again removes the notes here. If you choose to keep notes, only the notes you explicitly select are included in the copy or download you request. That copy remains outside this tool until you remove it.\n\nSaving this tool keeps a shortcut, not your writing. Nothing is sent to your therapist or read aloud. This tool is not monitored.",
      "textSha256": "16d3bdc898d6fedb141c993bad0bb7cf436026c064bd1822ff0aabab7f149047",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "capabilityGate": "Do not bind or make this script available until implementationGates capability tests pass in the actual renderer.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.intro",
      "title": "GIVE",
      "text": "GIVE practises listening and expressing a concern with respect for the relationship, without giving up your own limits.\n\nChoose an ordinary conversation where it is reasonably safe to practise, or use the fictional example. You can rehearse silently, aloud or with optional notes. You do not have to contact anyone.",
      "textSha256": "181bdaee3b5bc0f7b89729159f4e33112dd9fce08bfe4f93303dfac998025036",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.fit",
      "title": "Check whether this fits",
      "text": "Use this with your therapist’s guidance and a situation that is manageable for you. You can leave out personal details, use fiction, or stop.\n\nIf someone may threaten, control, punish or harm you for speaking up, start with support and safety rather than a communication script. This tool cannot assess what is safe. You do not have to keep engaging with threats or abuse.\n\nA clear, respectful response does not control another person’s reaction. Lack of agreement does not mean you failed.",
      "textSha256": "6cbf0a98205bf1dddc8f916022fb17924642c763c5445cafc9ac1407708de583",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.learn",
      "title": "Care for the relationship without losing your position",
      "text": "GIVE concerns how you relate while talking: Gentle, Interested, Validate and Easy manner. It is not a promise that someone will like you or agree.\n\nValidation acknowledges something understandable in the other person’s experience. It does not establish that every interpretation is true, approve harm or require you to abandon a boundary.\n\nDEAR MAN helps make a request or refusal; FAST helps consider fairness and self-respect. A caring manner does not replace either purpose.",
      "textSha256": "e5760540ebf8d1952423f0bce5d20c657b8f883457e7f7e7c3b6ce69345aed9f",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.example",
      "title": "Example: Kit wants more notice",
      "text": "Kit is disappointed after a friend cancels twice. Kit says, “I’m disappointed we haven’t met. What’s been getting in the way?” The friend explains an unpredictable work schedule. Kit replies, “It sounds hard to plan around changing shifts. I still need some notice if we’re changing plans.”\n\nKit listens and acknowledges the explanation without pretending the disappointment has gone or that every cancellation is acceptable. A respectful manner can be direct; humour, eye contact and a smile aren’t required.",
      "textSha256": "beeeef83432704301145dad19af076518f568448cc059d81742871954a9c77ee",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": [
        "full-give-example"
      ]
    },
    {
      "id": "give.scenario",
      "title": "Practise with Kit",
      "text": "Kit wants to understand the friend’s circumstances while asking for notice when plans change. Use that fictional conversation or a manageable situation of your own.\n\nYou do not have to make the friend feel better or decide whose feelings are correct.",
      "textSha256": "c8a161c86e3474c725986005bceb5400476be901f292b28c6d3463522c6ce260",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.prepare",
      "title": "Choose the conversation and priority",
      "text": "Use Kit’s cancelled-plans example or choose your own manageable situation. What matters most here: a specific request or refusal, the relationship, or how you act in relation to your values?\n\nThese priorities may overlap or conflict. Choose a focus for this practice without treating the others as unimportant. You can switch to a related skill or finish.",
      "textSha256": "905b1ceeca03c19b8e1202a57f0748f651a00d3ebb3de9d0161b79fbbbcf911d",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.prepare.help",
      "title": "If I cannot choose a priority",
      "text": "You can try the fictional example or discuss the situation with your therapist. This is not a score that decides how forceful to be.",
      "textSha256": "f9eff6512039008a0485ff1d5397bd6a36b38ee3d5a5033f12001c35a0f7e104",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.gentle",
      "title": "G: Be Gentle",
      "text": "Try a respectful opening without insults, threats, ridicule or attacks. Anger can be expressed directly without attacking the person.",
      "textSha256": "634ed481a0b374f4e6d681bd156d485b646693e9b6e04421a33cfbbbe7c40330",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.gentle.help",
      "title": "If gentle sounds like agreeing",
      "text": "You can be direct about disappointment or a limit. Gentle does not mean appeasing someone or continuing an unsafe exchange.",
      "textSha256": "4fe1d67acb5c1eaac294610e84567a5c94b5391b58365499ff9d3d2826cb3e12",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.interested",
      "title": "I: Act Interested",
      "text": "Ask one genuine question or listen to what the other person says. Leave space for an answer instead of preparing a rebuttal.\n\nIn fiction, read the supplied reply before rehearsing your next turn. In a real conversation, do not invent what the person must mean.",
      "textSha256": "c1de292abf4f5a8ef065cdc55407dc2af1927ab0f560092c49deb201d8dbc101",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.interested.help",
      "title": "If they do not want to talk now",
      "text": "You can respect that limit and consider another time. Interest does not entitle you to an explanation or require a particular gaze or posture.",
      "textSha256": "f121dcd78851fd33493050e071d3d7526612a9b37b9ac1ea1ed5ffdd0e6d5c32",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.validate",
      "title": "V: Validate",
      "text": "Try acknowledging a feeling, difficulty or perspective you can reasonably understand. Check uncertain interpretations rather than stating them as facts.\n\nYou can acknowledge their experience and still disagree, express your own experience or keep a limit.",
      "textSha256": "6b4b637610570a8bcd6af6e8b57fdba7538f3b4e4cba68a9cb5a8a3eb82e44bd",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.validate.help",
      "title": "If I cannot agree with the account",
      "text": "You might acknowledge disappointment without confirming an accusation. Do not invent a sympathetic reason, validate a harmful claim as true or excuse harmful behaviour.",
      "textSha256": "fe59c699691c6c9761c58da0dcf845bc96a01453cc1834efdd04f05ae5cc486a",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.easy",
      "title": "E: Use an Easy manner",
      "text": "Try your words in a respectful manner that fits the situation and your way of communicating. Notice whether an unnecessary jab or sarcastic phrase can be left out.\n\nWarmth or humour may fit, but they are optional. You do not have to smile, joke, make eye contact or conceal distress.",
      "textSha256": "7f3178f5eedb3712dc510b01d8a62ed049d0cfa4493c93f0657983058c6acb37",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.easy.help",
      "title": "If humour would feel wrong",
      "text": "Do not use it. A straightforward, respectful delivery can fit better. The other person’s approval is not the test.",
      "textSha256": "5e5f42c31379ffb30ba17531adea813b752b7788a9c8f94ba33d9c3ac3bf0697",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.rehearse",
      "title": "Rehearse the opening",
      "text": "Try your opening once, privately, aloud or in optional notes. You can try just the part you are working on rather than a polished speech.\n\nThen choose a possible response below if you want to rehearse the next turn. Another person may respond differently.",
      "textSha256": "5f2a3eca8f75a47a3e9d287b7fbf5f4879c1109a96c73c0892fb658e255f8a01",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.respond",
      "title": "Practise a possible next turn",
      "text": "Choose one possible response. Read it, then try what you might say or do next. A pause or ending the exchange can be a response.\n\nIf no branch fits, you can imagine your own ordinary reply or leave this step. Nothing is selected for you.",
      "textSha256": "c949599d21f2c903ce6aebf4579eef7e1497a0f4c802ea0c5e40f7d7e1eaae1d",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.practice.review",
      "title": "Review and, if useful, try again",
      "text": "Did you leave room for the other person’s account, acknowledge only what you could reasonably understand, and keep any needed limit? Could you try a more respectful version without forcing warmth or agreement?\n\nTry one revised response if you want. You can also leave the practice here with uncertainty, discomfort or no change.",
      "textSha256": "e72f5b4573ae68d0375c30b9625c273d306e82f47159fd536325a2090df56724",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.different.reply",
      "title": "One possible reply",
      "text": "“I thought our plans were only tentative.”",
      "textSha256": "600e986406ec8d26618c696ef640dfcd1cd3a2f9c1c124d7241e9277c52c0e88",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.different.practice",
      "title": "Try your next response",
      "text": "Try checking what you heard, acknowledging any understandable uncertainty and saying what you understood without declaring motives.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "02a28dbd44d7137a2a129c408cd61a91e2f17a0fa0cd35e3622e5076466c0ad7",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.different.practice.help",
      "title": "If you want a starting point",
      "text": "For Kit: “You thought we had not confirmed. I thought we had. Could we make that clearer next time?”",
      "textSha256": "a9d3b2e2b8c573b135052f0402138a1735e4cc9be07ff638b266dddffcd18076",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.cannot.reply",
      "title": "One possible reply",
      "text": "“I understand, but sometimes my shift changes without notice.”",
      "textSha256": "8960aeb6bce6a7383df30771b14be58cd957f1b2c256593f5ae7543e56579825",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.cannot.practice",
      "title": "Try your next response",
      "text": "Try acknowledging the constraint and saying what remains workable for you. You do not have to pretend the difficulty is solved.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "0ddffecbd28a7c60d225e21ed125d90cc8396b7c7b01c33ea7eba4e18026fa42",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.cannot.practice.help",
      "title": "If you want a starting point",
      "text": "For Kit: “That sounds hard to plan around. Could you let me know when you find out? I may need to make other plans.”",
      "textSha256": "bb98e6eefc76c52b437704907e05f58ba34f7c436f92c907c380792424d5e4ab",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.dismiss.reply",
      "title": "One possible reply",
      "text": "“You are making too much of this.”",
      "textSha256": "2eecd7f58b6bcc3b652691e8a9f6987a48a729acb97e77731059e9e85aa6cf55",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.dismiss.practice",
      "title": "Try your next response",
      "text": "Try a respectful restatement or a pause. You do not have to persuade the person to validate you.\n\nThink it, say it or use the optional response notes. You can pause or leave this unpractised.",
      "textSha256": "ca45ad46354002f2e3d833db515c44144de42e110c0ce864cedc45ea8e8a5961",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.response.dismiss.practice.help",
      "title": "If you want a starting point",
      "text": "For Kit: “It matters to me to know when plans change. I’m going to pause this conversation for now.” If there is harm or coercion, prioritise support rather than preserving warmth.",
      "textSha256": "ed0d6ca031224b304b318b17cf9d67704043432f2c57dc57d7088aa621a2ece9",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored contextual-help text.",
      "legacyExactMatchIds": []
    },
    {
      "id": "give.close",
      "title": "Leave the practice here",
      "text": "You can finish after reading, rehearsing, revising or stopping. Agreement, confidence and a change in feeling are not required.\n\nYou can return to any part, keep only notes you deliberately select, save a shortcut to the tool, or finish and clear the notes here.",
      "textSha256": "98842bb1caa1cd4c7f24055cbd5db61e5c4e89be997ac002d557721caab6ffd3",
      "status": "Candidate script only; not generated or listening-approved",
      "visibleScope": "Only exact visible authored paragraphs for this section; no heading, control, hidden branch or private value.",
      "capabilityGate": "Do not bind or make this script available until implementationGates capability tests pass in the actual renderer.",
      "legacyExactMatchIds": []
    }
  ]
};
