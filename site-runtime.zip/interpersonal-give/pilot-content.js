window.InterpersonalPilotContent = {
  "schema": "a-place-to-practise.optional-fictional-pilot.v1",
  "id": "pilot/give-comparison",
  "canonicalId": "classic/give",
  "resourceId": "tool/give",
  "title": "Explore Kit’s wording and the reply",
  "version": "2026-11-03-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "integration": {
    "anchorIds": [
      "give.practice.easy",
      "give.practice.respond"
    ],
    "placement": "One optional teaching exercise opened from a quiet text action beside the stated prompt or contextual help. Not a new required step, top-level mode, route, tool or catalogue entry.",
    "preserve": "All existing 7/4/4 prompts, original examples, three adjacent Practice this skill / See an example / Learn more actions, note preview/export/guide behavior, saved IDs and safety/support remain unchanged.",
    "entry": "No automatic opening. Keep the precise originating prompt, active context, response choice, scroll/focus and notes; opening this fiction exercise does not select fictional context in the underlying personal practice.",
    "exit": "Close/Back returns to the precise originating prompt and state. Finish/support/leave obey existing tool-wide clear policy. No required choices or completion event.",
    "state": "Only authored fictional selection state inside this optional exercise; no persistence or analytics. Switching unrelated pilot scenarios resets their local edits, never personal practice notes. Closing resets local pilot selections and stops its audio; the main practice is untouched.",
    "privacy": "Do not read, import, infer, copy into, overwrite, score or narrate any private field. This fictional-only pilot has no personal writing input, microphone, recording, timer or automatic export.",
    "narration": "Exact static visible section only, explicit Listen/Pause/Resume; Replay unavailable until that exact clip actually plays. Stop before any panel/choice/scenario/phrase/action change, close, navigation or focus return. No autoplay, composite-script speech, hidden-branch audio, TTS or new provider.",
    "support": "Existing support/finish remain reachable. No safety questionnaire, safety determination or instruction to test a boundary with another person.",
    "entryLabel": "Compare fictional responses"
  },
  "sources": [
    {
      "id": "linehan-handouts-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Historical interpersonal handouts 4–7 provide the distinctions between objective, relationship and self-respect skills; this is original fictional teaching, not a reproduced worksheet.",
      "limits": "Not exact 2025 wording, digital efficacy evidence or permission to redistribute publisher materials."
    },
    {
      "id": "linehan-worksheets-2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-worksheets.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Interpersonal worksheet 4 supports mental/spoken rehearsal.",
      "limits": "Does not test the proposed interaction or establish its superiority."
    }
  ],
  "acceptance": [
    "No required click, rating, score, streak, mastery badge, good/bad response label or controlled-outcome claim.",
    "Every fictional choice and stopping option is reachable without personal input or audio.",
    "Fictional exercise does not change current practice context, notes, selected response or export selections.",
    "No snippet or action can invent a private interpretation, obligation or promise.",
    "All new audio remains unavailable until exact approved assets and integration/listening checks; existing recordings are not reassigned.",
    "Targeted source/content review required before any freeze; separate model, DOM, browser, accessibility, privacy and audio review for implementation."
  ],
  "learningObjective": "Distinguish respectful manner, asking a question and acknowledging a difficulty, while understanding that another person’s reaction is not a grade or predictable reward.",
  "intro": {
    "id": "pilot.give.intro",
    "title": "Different responses, one concern",
    "paragraphs": [
      "Kit is disappointed after a friend cancels twice. The friend has explained that work shifts are unpredictable. Kit still wants notice when plans change.",
      "These versions keep that concern, but do different things in the conversation. A question asks for information; an acknowledgement recognises a difficulty; a request states what Kit wants. They are not just different tones or a ranking from bad to good."
    ]
  },
  "concern": {
    "id": "pilot.give.concern",
    "title": "Kit’s concern",
    "paragraphs": [
      "I still need some notice if we’re changing plans."
    ]
  },
  "versions": [
    {
      "id": "direct",
      "label": "State the concern respectfully",
      "line": {
        "id": "pilot.give.direct.line",
        "title": "A possible response",
        "paragraphs": [
          "“I’m disappointed we haven’t met. Please let me know when our plans change.”"
        ]
      },
      "notice": {
        "id": "pilot.give.direct.notice",
        "title": "What this version does",
        "paragraphs": [
          "Kit expresses disappointment and makes a direct request without an insult or accusation. It does not ask a listening question or acknowledge the work difficulty.",
          "Gentle and Easy manner can be direct. No smile, humour, eye contact or performance of calm is required."
        ]
      }
    },
    {
      "id": "question",
      "label": "Ask and leave room for an answer",
      "line": {
        "id": "pilot.give.question.line",
        "title": "A possible response",
        "paragraphs": [
          "“I understand the shifts can change. When do you usually find out? I still need some notice if we’re changing plans.”"
        ]
      },
      "notice": {
        "id": "pilot.give.question.notice",
        "title": "What this version does",
        "paragraphs": [
          "Kit asks for information and would need to leave room for the friend’s answer. This practises Interested; it adds a question rather than merely changing the tone.",
          "The question does not entitle Kit to private work details. The friend can decline to explain or prefer another time."
        ]
      }
    },
    {
      "id": "acknowledge",
      "label": "Acknowledge the difficulty",
      "line": {
        "id": "pilot.give.acknowledge.line",
        "title": "A possible response",
        "paragraphs": [
          "“It sounds hard to plan around changing shifts. I still need some notice if we’re changing plans.”"
        ]
      },
      "notice": {
        "id": "pilot.give.acknowledge.notice",
        "title": "What this version does",
        "paragraphs": [
          "Kit acknowledges a difficulty the friend has described and keeps the request for notice. This practises Validate without pretending every cancellation is acceptable.",
          "Kit is not proving the explanation true, guessing motives or agreeing to abandon the concern. A straightforward respectful delivery can fit."
        ]
      }
    }
  ],
  "reactionIntro": {
    "id": "pilot.give.reactions.intro",
    "title": "Explore a possible reply",
    "paragraphs": [
      "Any of these replies is available with any wording above. Choosing a version does not cause, predict or earn a particular reply.",
      "You can explore a reply without choosing a version. The friend’s disappointment or disagreement would not show that Kit used the skill incorrectly."
    ]
  },
  "reactions": [
    {
      "id": "different",
      "label": "The friend understood the plans differently",
      "reply": {
        "id": "pilot.give.reaction.different",
        "title": "One possible reply",
        "paragraphs": [
          "“I thought our plans were only tentative.”"
        ]
      },
      "response": {
        "id": "pilot.give.reaction.different.response",
        "title": "An optional next turn",
        "paragraphs": [
          "Kit could check the difference: “You thought they weren’t confirmed. I thought they were. Could we be clearer next time?”",
          "Try that response privately, try your own, or leave it. Checking understanding does not require declaring who is right."
        ]
      }
    },
    {
      "id": "cannot",
      "label": "The friend understands but has a limit",
      "reply": {
        "id": "pilot.give.reaction.cannot",
        "title": "One possible reply",
        "paragraphs": [
          "“I understand, but sometimes my shift changes without notice.”"
        ]
      },
      "response": {
        "id": "pilot.give.reaction.cannot.response",
        "title": "An optional next turn",
        "paragraphs": [
          "Kit could acknowledge the limit and ask about what is possible: “Could you let me know when you find out? I may need to make other plans.”",
          "The problem may remain. Understanding the constraint does not require Kit to promise unlimited flexibility."
        ]
      }
    },
    {
      "id": "dismiss",
      "label": "The friend dismisses the concern",
      "reply": {
        "id": "pilot.give.reaction.dismiss",
        "title": "One possible reply",
        "paragraphs": [
          "“You are making too much of this.”"
        ]
      },
      "response": {
        "id": "pilot.give.reaction.dismiss.response",
        "title": "An optional next turn",
        "paragraphs": [
          "Kit could restate the concern or pause: “Knowing when plans change matters to me. I’m going to pause this conversation.”",
          "Kit does not have to keep sounding warmer to obtain a better response. Harm or coercion calls for support and safety, not a more pleasing reply."
        ]
      }
    }
  ],
  "behavior": {
    "initial": "No version or reaction selected; each independently optional. Show concern and choice labels.",
    "version": "Display one version and its notice. Changing version does not select, reorder, rank or reset the independently chosen reaction; clearly label the reaction as hypothetical and independent. Stop audio on change.",
    "reaction": "All three available irrespective of version or previous choice. Display one chosen reaction and optional next-turn text; no simulated person, score or conditional approval.",
    "comparison": "Optional comparison view may show the three authored lines and their distinct functions together, but not nine complete transcripts. No binary G/I/V/E toggles.",
    "narration": "No claimed expressive/tone effect from text scripts. Any later tone recording must have a matching written cue and separate review; silence supplies the complete teaching."
  },
  "close": {
    "id": "pilot.give.close",
    "title": "Return to the practice",
    "paragraphs": [
      "You can take a wording idea, keep your own approach or leave the choice open. The aim is care in your part of the conversation, not control over the other person’s response."
    ]
  },
  "narrationSegments": [
    {
      "id": "pilot.give.intro",
      "title": "Different responses, one concern",
      "text": "Kit is disappointed after a friend cancels twice. The friend has explained that work shifts are unpredictable. Kit still wants notice when plans change.\n\nThese versions keep that concern, but do different things in the conversation. A question asks for information; an acknowledgement recognises a difficulty; a request states what Kit wants. They are not just different tones or a ranking from bad to good.",
      "textSha256": "040931f8ede90586aaeed783409beed7cde188c8f8bd96811f3eaa2458c66804",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.concern",
      "title": "Kit’s concern",
      "text": "I still need some notice if we’re changing plans.",
      "textSha256": "a9412e62e8435ba419b863d93210dc2027d437b777661017a0032bd73c0e77eb",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.direct.line",
      "title": "A possible response",
      "text": "“I’m disappointed we haven’t met. Please let me know when our plans change.”",
      "textSha256": "20b06d47b785ad57e9dee06070dd0c8f7dd9a80fc5668efb636cbfc98ad959f2",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.direct.notice",
      "title": "What this version does",
      "text": "Kit expresses disappointment and makes a direct request without an insult or accusation. It does not ask a listening question or acknowledge the work difficulty.\n\nGentle and Easy manner can be direct. No smile, humour, eye contact or performance of calm is required.",
      "textSha256": "a997d492737ef1a70f4d8435d43cec3eb7832fc17040b29b3c05e1d126d9900b",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.question.line",
      "title": "A possible response",
      "text": "“I understand the shifts can change. When do you usually find out? I still need some notice if we’re changing plans.”",
      "textSha256": "aadfc8d6a9196d8ac37d71df5956115215d8042257bf15e49254f755b1fb432c",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.question.notice",
      "title": "What this version does",
      "text": "Kit asks for information and would need to leave room for the friend’s answer. This practises Interested; it adds a question rather than merely changing the tone.\n\nThe question does not entitle Kit to private work details. The friend can decline to explain or prefer another time.",
      "textSha256": "de25e48fc26c456ed9185594098d670aa58027a3b066a7b02486332cfdacb5ab",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.acknowledge.line",
      "title": "A possible response",
      "text": "“It sounds hard to plan around changing shifts. I still need some notice if we’re changing plans.”",
      "textSha256": "b989aa9e07977221d487266c57f27376f236f8844156a998315deb81548a6ac1",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.acknowledge.notice",
      "title": "What this version does",
      "text": "Kit acknowledges a difficulty the friend has described and keeps the request for notice. This practises Validate without pretending every cancellation is acceptable.\n\nKit is not proving the explanation true, guessing motives or agreeing to abandon the concern. A straightforward respectful delivery can fit.",
      "textSha256": "3832eea8d7f96dd1be1b7cdc8e5fbd696551ad9bceea3b9e72c503f1edc0f586",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.reactions.intro",
      "title": "Explore a possible reply",
      "text": "Any of these replies is available with any wording above. Choosing a version does not cause, predict or earn a particular reply.\n\nYou can explore a reply without choosing a version. The friend’s disappointment or disagreement would not show that Kit used the skill incorrectly.",
      "textSha256": "39ded56542816772b660de43476ef505ab7955c56bf8cf605a30d821a2b4458f",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.reaction.different",
      "title": "One possible reply",
      "text": "“I thought our plans were only tentative.”",
      "textSha256": "600e986406ec8d26618c696ef640dfcd1cd3a2f9c1c124d7241e9277c52c0e88",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.reaction.different.response",
      "title": "An optional next turn",
      "text": "Kit could check the difference: “You thought they weren’t confirmed. I thought they were. Could we be clearer next time?”\n\nTry that response privately, try your own, or leave it. Checking understanding does not require declaring who is right.",
      "textSha256": "de445bb11eef35dec12674098fa4adec10af64de035c658353c6ba5eeabcce3f",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.reaction.cannot",
      "title": "One possible reply",
      "text": "“I understand, but sometimes my shift changes without notice.”",
      "textSha256": "8960aeb6bce6a7383df30771b14be58cd957f1b2c256593f5ae7543e56579825",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.reaction.cannot.response",
      "title": "An optional next turn",
      "text": "Kit could acknowledge the limit and ask about what is possible: “Could you let me know when you find out? I may need to make other plans.”\n\nThe problem may remain. Understanding the constraint does not require Kit to promise unlimited flexibility.",
      "textSha256": "9790e8f630f2c49f7da8b1d596413b1b3ba03c2134fffb37107aa9aa0637659a",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.reaction.dismiss",
      "title": "One possible reply",
      "text": "“You are making too much of this.”",
      "textSha256": "2eecd7f58b6bcc3b652691e8a9f6987a48a729acb97e77731059e9e85aa6cf55",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.reaction.dismiss.response",
      "title": "An optional next turn",
      "text": "Kit could restate the concern or pause: “Knowing when plans change matters to me. I’m going to pause this conversation.”\n\nKit does not have to keep sounding warmer to obtain a better response. Harm or coercion calls for support and safety, not a more pleasing reply.",
      "textSha256": "f68720ebf605aee0f52b799a423ce9c338ecef8e85a5318faa654ff3af03a52e",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    },
    {
      "id": "pilot.give.close",
      "title": "Return to the practice",
      "text": "You can take a wording idea, keep your own approach or leave the choice open. The aim is care in your part of the conversation, not control over the other person’s response.",
      "textSha256": "2f3360dddd0d68af90ce9d0ac3e3f9a0e8cc282102845ade4a8320400e22964d",
      "status": "Frozen authored script; no generated asset or listening approval",
      "scope": "Exact visible authored paragraph nodes only. Heading, controls, private values and composite draft excluded."
    }
  ]
};
