window.DBTChoiceContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "accepts.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact assets, listening and integration pass; never narrate personal entries.",
    "timer": "None",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "choiceMethods": {
      "selectorLabel": "Choose one ACCEPTS option",
      "default": "No selected method. Show seven names with one short summary each in one accessible selector; not seven required screens.",
      "methodsSource": "methods array; exact authored teaching/example/help for each id.",
      "placement": "choice selector beside practice.choose; selected teaching and actual-action instructions beside practice.try, not hidden behind extra reading.",
      "learnExample": "Practice / See an example / Learn more remain adjacent. If selected, Example shows that method’s exact example; with none, show the global example labeled as one example only. Learn includes general rationale and selected method teaching, not all seven expansions.",
      "showAll": "Show all exposes shared steps plus the selected method only. Optional overview can list all seven summaries; do not auto-expand seven full practices.",
      "noSelection": "At try, show choice selector or read/finish options; do not choose a default or imply practice occurred.",
      "changingChoice": "Stop old-method playback and replace teaching/example/help with new exact branch. Retain endpoint/review notes without rewriting or relabeling them. If either note is nonempty when method changes, set a context-change notice that remains visible beside both note areas until those notes are cleared or the tool restarts. Never mark a newly selected method tried.",
      "choiceChangeNotice": "Your existing stopping-point or review notes may refer to an earlier option. They have not been changed. Choosing a new option does not mean you have tried it.",
      "exampleIdentity": "A global example reuses the exact selected-method example ID of its originating method, with that method label visible. Viewing this default example never selects that method or labels it practised.",
      "navigation": "Internal Back/Learn/Example retains explicit choice and notes. Clear/restart/reload/leave resets choice and clears notes/echoes. Direct jumps recheck selection; no inferred method from history.",
      "audio": "Only selected static method scripts eligible for matching controls; never auto-play, sequentially play all methods or narrate personal writing. Normal-practice activation requires separate approval.",
      "privacy": "All private entries hidden with writing; no score, mastery, method-completion badge or stored diary."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/accepts",
  "title": "Wise Mind ACCEPTS",
  "subtitle": "Choose one short-term distraction practice",
  "scope": "All seven named ACCEPTS options offered as an ordinary-context choice set. One selected practice is not mastery of all options or a complete DBT programme.",
  "version": "2026-11-03-distress-choice-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish temporary attention-shifting from denying a problem, chronic avoidance or ignoring urgent needs.",
    "practiceObjective": "Choose one suitable ACCEPTS method, set a brief return point, actually try it if appropriate, then review fit and what needs attention without requiring relief or further tasks.",
    "observedPractice": "Reading, rehearsal, planning and actual action are separate; no compulsory writing, numeric rating, symptom reduction or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "sources": [
    {
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-handouts.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Official 2015 Distress Tolerance handout 7 provides method identity and procedure.",
      "limits": "Original app wording/examples only; no copied worksheet. Current 2025 edition scope recognised separately; exact revised procedure not asserted identical. Adult framework does not validate this digital 16–17 adaptation."
    },
    {
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-4teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Qualified-professional crisis-survival teaching: temporary tolerating of distress without making things worse; balance with appropriate practical response.",
      "limits": "Not a substitute for assessment, personal safety plan or complete DBT. Restricted reproduction licence; source suggestions narrowed for this ordinary-context adaptation."
    }
  ],
  "resourceId": "tool/wise-mind-accepts",
  "routeProposal": "tool/wise-mind-accepts",
  "groupedSetStatus": "Seven named options available; one chosen practice per visit. No new count per choice or claim all were practised.",
  "intro": {
    "id": "accepts.intro",
    "title": "A temporary change of focus",
    "paragraphs": [
      "ACCEPTS is a menu of short-term distraction methods. It can give attention somewhere else to go while a difficult moment cannot be resolved immediately. It is not a way to erase the problem.",
      "Choose one option, not seven steps. You can read its example, try briefly if suitable, or finish. A less distressed feeling is not required."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "accepts.fit",
    "title": "Check whether a distraction fits now",
    "paragraphs": [
      "Use this after your therapist introduces it for an ordinary, manageable situation. Do not use it instead of urgent care, protection or an essential responsibility.",
      "If you are following an exposure or other treatment plan, check with your therapist whether distraction fits; it can work against some agreed practices. Repeatedly postponing a problem without returning is different from a brief break.",
      "Choose accessible actions that respect health, energy, allergies, sensory needs and boundaries. No pain, extreme temperatures, loud sound, food, spending or unwanted contact is needed. Stop if a choice increases distress or feels unsafe."
    ]
  },
  "learn": {
    "id": "accepts.learn",
    "title": "Why choose and then return?",
    "paragraphs": [
      "Short-term distraction deliberately shifts attention for a while instead of staying with the same distressing cue. It does not have to stop every thought from returning.",
      "The letters name alternatives: Activities, Contributing, Comparisons, Emotions, Pushing Away, Thoughts and Sensations. Different methods fit different people and situations.",
      "Choose a small stopping point before trying, such as the end of one ordinary activity. Then check the situation again. Returning means noticing what needs attention or support, not necessarily solving the problem immediately."
    ]
  },
  "methods": [
    {
      "id": "activities",
      "label": "Activities",
      "summary": "Give attention to an ordinary task.",
      "teaching": {
        "id": "accepts.method.activities",
        "title": "Activities",
        "paragraphs": [
          "An activity occupies attention through doing something different for a short time. It need not be productive or impressive.",
          "Choose an accessible, non-urgent task such as sorting a few pens or working on a familiar puzzle. Attend to the task until your chosen stopping point, then leave it and check back."
        ]
      },
      "example": {
        "id": "accepts.example.activities",
        "title": "Example — Activities",
        "paragraphs": [
          "Rae sorts a few pens after an upsetting but non-urgent message. The message comes to mind again, and Rae returns attention to the sorting.",
          "At the chosen end, Rae checks back. Upset remains, and Rae decides whether a later response or support is needed; the sorting did not resolve the message."
        ]
      },
      "help": {
        "id": "accepts.help.activities",
        "title": "If this option does not fit",
        "paragraphs": [
          "If a task becomes another demand, choose less or stop. Distraction does not have to be useful work."
        ]
      }
    },
    {
      "id": "contributing",
      "label": "Contributing",
      "summary": "Offer a small freely chosen contribution.",
      "teaching": {
        "id": "accepts.method.contributing",
        "title": "Contributing",
        "paragraphs": [
          "A modest contribution can shift attention toward an act of care or helpfulness. It is not paying for permission to have needs.",
          "Choose a safe, wanted action within your limits, such as putting shared materials back where they belong. Do it briefly, then check back. No contact, money or taking over another person’s responsibility is required."
        ]
      },
      "example": {
        "id": "accepts.example.contributing",
        "title": "Example — Contributing",
        "paragraphs": [
          "Rae puts shared pencils back in their box, an ordinary helpful action that is welcome in that setting.",
          "Rae notices attention moved for a moment; worry remains. Rae stops after the small action rather than adding more chores."
        ]
      },
      "help": {
        "id": "accepts.help.contributing",
        "title": "If this option does not fit",
        "paragraphs": [
          "Skip this if helping is already a pressure or the action is not welcome. Choose another method rather than earn relief by overgiving."
        ]
      }
    },
    {
      "id": "comparisons",
      "label": "Comparisons",
      "summary": "Recall a different moment in your own coping.",
      "teaching": {
        "id": "accepts.method.comparisons",
        "title": "Comparisons",
        "paragraphs": [
          "A comparison can widen the view beyond how this moment feels. This version compares with your own experience, not with people who are supposedly worse off.",
          "If a tolerable example comes readily, recall a time when a difficult moment felt different later or you used support. Notice one difference from now, then return. Do not search for a painful memory."
        ]
      },
      "example": {
        "id": "accepts.example.comparisons",
        "title": "Example — Comparisons",
        "paragraphs": [
          "Rae recalls another ordinary tense afternoon when a conversation with a trusted person helped.",
          "Rae notices that support has been possible before without assuming today must unfold the same way. The present concern still matters."
        ]
      },
      "help": {
        "id": "accepts.help.comparisons",
        "title": "If this option does not fit",
        "paragraphs": [
          "If no example comes easily, skip this. You do not need to prove you have coped well before or minimise your pain."
        ]
      }
    },
    {
      "id": "emotions",
      "label": "Emotions",
      "summary": "Make room for a different emotional tone.",
      "teaching": {
        "id": "accepts.method.emotions",
        "title": "Emotions",
        "paragraphs": [
          "A suitable story, image or piece of music can invite a different emotional experience for a short time. It is an invitation, not a command to feel happy.",
          "Choose familiar content you expect to be tolerable, such as a light story or gentle music. Give it attention briefly, then stop at your chosen point and check back. Avoid content that intensifies distress."
        ]
      },
      "example": {
        "id": "accepts.example.emotions",
        "title": "Example — Emotions",
        "paragraphs": [
          "Rae reads a short familiar amusing passage and notices a little interest, though not laughter.",
          "Rae stops at the end of the passage and returns to the situation; no positive emotion had to appear."
        ]
      },
      "help": {
        "id": "accepts.help.emotions",
        "title": "If this option does not fit",
        "paragraphs": [
          "If the content feels irritating, upsetting or flat, stop or choose another method. Do not keep searching until you feel the right emotion."
        ]
      }
    },
    {
      "id": "pushing-away",
      "label": "Pushing Away",
      "summary": "Set a non-urgent issue aside temporarily.",
      "teaching": {
        "id": "accepts.method.pushing-away",
        "title": "Pushing Away",
        "paragraphs": [
          "This adapted option creates a deliberate short boundary around attention. It does not deny that the issue exists or require suppressing every thought.",
          "Choose when to check back, then put aside a non-urgent cue if safe—for example, close an ordinary message thread for a brief pause. If it returns to mind, acknowledge that and turn to another ordinary focus."
        ]
      },
      "example": {
        "id": "accepts.example.pushing-away",
        "title": "Example — Pushing Away",
        "paragraphs": [
          "Rae closes a non-urgent message thread until after a short drink break. Thoughts about it return, and Rae notices them without trying to force them out.",
          "At the agreed point Rae checks back and considers what needs attention. The issue was postponed briefly, not declared unreal."
        ]
      },
      "help": {
        "id": "accepts.help.pushing-away",
        "title": "If this option does not fit",
        "paragraphs": [
          "Do not set aside urgent information, safety duties or an agreed treatment task. If postponing keeps extending, stop and review the pattern with your therapist."
        ]
      }
    },
    {
      "id": "thoughts",
      "label": "Thoughts",
      "summary": "Use a neutral thinking task.",
      "teaching": {
        "id": "accepts.method.thoughts",
        "title": "Thoughts",
        "paragraphs": [
          "A neutral mental task gives attention a different job for a short time. It is not an argument with the distressing thought.",
          "Try naming a few ordinary objects that begin with a chosen letter, or a familiar simple puzzle. Stop at a small chosen point and check back; mistakes do not matter."
        ]
      },
      "example": {
        "id": "accepts.example.thoughts",
        "title": "Example — Thoughts",
        "paragraphs": [
          "Rae names a few everyday objects beginning with B and loses track once. Rae starts again without treating it as a test.",
          "After the small task, Rae checks the situation again. The concern remains, but attention was briefly elsewhere."
        ]
      },
      "help": {
        "id": "accepts.help.thoughts",
        "title": "If this option does not fit",
        "paragraphs": [
          "Avoid difficult counting or perfectionistic rules. If the task becomes compulsive checking or frustrating, stop or choose a simpler option."
        ]
      }
    },
    {
      "id": "sensations",
      "label": "Sensations",
      "summary": "Notice a safe, distinctive sensation.",
      "teaching": {
        "id": "accepts.method.sensations",
        "title": "Sensations",
        "paragraphs": [
          "A tolerable sensory detail can draw attention away from the distressing cue. Unlike self-soothing, the immediate aim here is a change of focus, not necessarily comfort.",
          "Choose a familiar safe sensation, such as the texture of a sleeve or a nearby ordinary sound at comfortable volume. Notice a few details briefly, then check back. Do not use pain, ice, extreme temperature or intense stimulation."
        ]
      },
      "example": {
        "id": "accepts.example.sensations",
        "title": "Example — Sensations",
        "paragraphs": [
          "Rae notices the texture of a familiar sleeve without squeezing or rubbing hard.",
          "The texture is tolerable; frustration remains. Rae stops after a brief look and touch and returns to the situation."
        ]
      },
      "help": {
        "id": "accepts.help.sensations",
        "title": "If this option does not fit",
        "paragraphs": [
          "Touch and body attention are optional. Respect sensory sensitivity, pain and health advice; use another choice if this does not fit."
        ]
      }
    }
  ],
  "example": {
    "id": "accepts.example.activities",
    "title": "Example — Activities",
    "paragraphs": [
      "Rae sorts a few pens after an upsetting but non-urgent message. The message comes to mind again, and Rae returns attention to the sorting.",
      "At the chosen end, Rae checks back. Upset remains, and Rae decides whether a later response or support is needed; the sorting did not resolve the message."
    ]
  },
  "practiceScenario": {
    "id": "accepts.scenario",
    "title": "If you prefer a fictional rehearsal",
    "paragraphs": [
      "Rae has received an upsetting ordinary message that is not urgent. Rae can safely pause before deciding how to respond.",
      "Choose a method and consider how Rae would try it and check back. Reading or planning for Rae is not the same as trying a distraction yourself."
    ]
  },
  "practice": [
    {
      "id": "accepts.practice.choose",
      "title": "Choose one option and a stopping point",
      "paragraphs": [
        "Choose one method that fits this situation and your therapist’s guidance. You do not need to try them all or select the perfect one.",
        "Before trying, choose a brief ordinary stopping point at which to check back. If urgent help or a necessary action cannot wait, attend to that instead."
      ],
      "fields": [
        {
          "key": "endpoint",
          "label": "A suitable stopping point, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If choosing feels like too much",
        "text": "Read one example, use a familiar method already agreed with your therapist, or finish. No option is automatically selected for you."
      }
    },
    {
      "id": "accepts.practice.try",
      "title": "Try the selected method",
      "paragraphs": [
        "Use the instructions for your selected option below. Try only as much as is suitable; stop or change choice if it does not fit.",
        "A thought or feeling may remain. The aim is not to keep practising until it disappears."
      ],
      "help": {
        "title": "Reading is also allowed",
        "text": "You can read the selected example or rehearse it privately instead. Do not label that as a completed personal practice."
      }
    },
    {
      "id": "accepts.practice.review",
      "title": "Check back and review",
      "paragraphs": [
        "At your stopping point, notice what you actually tried and whether it was useful, neutral, uncomfortable or unclear. A changed feeling is not required.",
        "Check the situation again: does anything need attention or support now? You can keep that question open. This is not a new task list or an instruction to solve everything."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I tried or noticed, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you keep extending the break",
        "text": "Notice the pattern without blame. If a needed response keeps being deferred, pause the distraction or break and review with your therapist or other appropriate support."
      }
    }
  ],
  "close": {
    "id": "accepts.close",
    "title": "Finish without a required result",
    "paragraphs": [
      "You can finish after reading, trying or stopping. Keep only what fits. There is no required rating, new plan or improved feeling."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "productAdaptations": [
    "All seven named source options available, each with original taught action, example and help; one selected practice plus return review, not seven compulsory tasks.",
    "Ordinary therapist-introduced context; no emergency assessment or full DBT claim. Short-term endpoint and no-relief requirement are explicit product teaching adaptations.",
    "Comparisons use own past coping rather than ranking suffering; Pushing Away is bounded attention disengagement rather than thought blocking/denial; Sensations omit pain, ice, extreme temperature and loud stimulation. These narrow older-source suggestions rather than claiming verbatim protocol fidelity."
  ],
  "narrationSegments": [
    {
      "id": "accepts.intro",
      "title": "A temporary change of focus",
      "text": "ACCEPTS is a menu of short-term distraction methods. It can give attention somewhere else to go while a difficult moment cannot be resolved immediately. It is not a way to erase the problem.\n\nChoose one option, not seven steps. You can read its example, try briefly if suitable, or finish. A less distressed feeling is not required.",
      "status": "Script only"
    },
    {
      "id": "accepts.fit",
      "title": "Check whether a distraction fits now",
      "text": "Use this after your therapist introduces it for an ordinary, manageable situation. Do not use it instead of urgent care, protection or an essential responsibility.\n\nIf you are following an exposure or other treatment plan, check with your therapist whether distraction fits; it can work against some agreed practices. Repeatedly postponing a problem without returning is different from a brief break.\n\nChoose accessible actions that respect health, energy, allergies, sensory needs and boundaries. No pain, extreme temperatures, loud sound, food, spending or unwanted contact is needed. Stop if a choice increases distress or feels unsafe.",
      "status": "Script only"
    },
    {
      "id": "accepts.learn",
      "title": "Why choose and then return?",
      "text": "Short-term distraction deliberately shifts attention for a while instead of staying with the same distressing cue. It does not have to stop every thought from returning.\n\nThe letters name alternatives: Activities, Contributing, Comparisons, Emotions, Pushing Away, Thoughts and Sensations. Different methods fit different people and situations.\n\nChoose a small stopping point before trying, such as the end of one ordinary activity. Then check the situation again. Returning means noticing what needs attention or support, not necessarily solving the problem immediately.",
      "status": "Script only"
    },
    {
      "id": "accepts.example.activities",
      "title": "Example — Activities",
      "text": "Rae sorts a few pens after an upsetting but non-urgent message. The message comes to mind again, and Rae returns attention to the sorting.\n\nAt the chosen end, Rae checks back. Upset remains, and Rae decides whether a later response or support is needed; the sorting did not resolve the message.",
      "status": "Script only"
    },
    {
      "id": "accepts.scenario",
      "title": "If you prefer a fictional rehearsal",
      "text": "Rae has received an upsetting ordinary message that is not urgent. Rae can safely pause before deciding how to respond.\n\nChoose a method and consider how Rae would try it and check back. Reading or planning for Rae is not the same as trying a distraction yourself.",
      "status": "Script only"
    },
    {
      "id": "accepts.practice.choose",
      "title": "Choose one option and a stopping point",
      "text": "Choose one method that fits this situation and your therapist’s guidance. You do not need to try them all or select the perfect one.\n\nBefore trying, choose a brief ordinary stopping point at which to check back. If urgent help or a necessary action cannot wait, attend to that instead.",
      "status": "Script only"
    },
    {
      "id": "accepts.practice.choose.help",
      "title": "If choosing feels like too much",
      "text": "Read one example, use a familiar method already agreed with your therapist, or finish. No option is automatically selected for you.",
      "status": "Script only"
    },
    {
      "id": "accepts.practice.try",
      "title": "Try the selected method",
      "text": "Use the instructions for your selected option below. Try only as much as is suitable; stop or change choice if it does not fit.\n\nA thought or feeling may remain. The aim is not to keep practising until it disappears.",
      "status": "Script only"
    },
    {
      "id": "accepts.practice.try.help",
      "title": "Reading is also allowed",
      "text": "You can read the selected example or rehearse it privately instead. Do not label that as a completed personal practice.",
      "status": "Script only"
    },
    {
      "id": "accepts.practice.review",
      "title": "Check back and review",
      "text": "At your stopping point, notice what you actually tried and whether it was useful, neutral, uncomfortable or unclear. A changed feeling is not required.\n\nCheck the situation again: does anything need attention or support now? You can keep that question open. This is not a new task list or an instruction to solve everything.",
      "status": "Script only"
    },
    {
      "id": "accepts.practice.review.help",
      "title": "If you keep extending the break",
      "text": "Notice the pattern without blame. If a needed response keeps being deferred, pause the distraction or break and review with your therapist or other appropriate support.",
      "status": "Script only"
    },
    {
      "id": "accepts.close",
      "title": "Finish without a required result",
      "text": "You can finish after reading, trying or stopping. Keep only what fits. There is no required rating, new plan or improved feeling.",
      "status": "Script only"
    },
    {
      "id": "accepts.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    },
    {
      "id": "accepts.method.activities",
      "title": "Activities",
      "text": "An activity occupies attention through doing something different for a short time. It need not be productive or impressive.\n\nChoose an accessible, non-urgent task such as sorting a few pens or working on a familiar puzzle. Attend to the task until your chosen stopping point, then leave it and check back.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.help.activities",
      "title": "If this option does not fit",
      "text": "If a task becomes another demand, choose less or stop. Distraction does not have to be useful work.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.method.contributing",
      "title": "Contributing",
      "text": "A modest contribution can shift attention toward an act of care or helpfulness. It is not paying for permission to have needs.\n\nChoose a safe, wanted action within your limits, such as putting shared materials back where they belong. Do it briefly, then check back. No contact, money or taking over another person’s responsibility is required.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.example.contributing",
      "title": "Example — Contributing",
      "text": "Rae puts shared pencils back in their box, an ordinary helpful action that is welcome in that setting.\n\nRae notices attention moved for a moment; worry remains. Rae stops after the small action rather than adding more chores.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.help.contributing",
      "title": "If this option does not fit",
      "text": "Skip this if helping is already a pressure or the action is not welcome. Choose another method rather than earn relief by overgiving.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.method.comparisons",
      "title": "Comparisons",
      "text": "A comparison can widen the view beyond how this moment feels. This version compares with your own experience, not with people who are supposedly worse off.\n\nIf a tolerable example comes readily, recall a time when a difficult moment felt different later or you used support. Notice one difference from now, then return. Do not search for a painful memory.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.example.comparisons",
      "title": "Example — Comparisons",
      "text": "Rae recalls another ordinary tense afternoon when a conversation with a trusted person helped.\n\nRae notices that support has been possible before without assuming today must unfold the same way. The present concern still matters.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.help.comparisons",
      "title": "If this option does not fit",
      "text": "If no example comes easily, skip this. You do not need to prove you have coped well before or minimise your pain.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.method.emotions",
      "title": "Emotions",
      "text": "A suitable story, image or piece of music can invite a different emotional experience for a short time. It is an invitation, not a command to feel happy.\n\nChoose familiar content you expect to be tolerable, such as a light story or gentle music. Give it attention briefly, then stop at your chosen point and check back. Avoid content that intensifies distress.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.example.emotions",
      "title": "Example — Emotions",
      "text": "Rae reads a short familiar amusing passage and notices a little interest, though not laughter.\n\nRae stops at the end of the passage and returns to the situation; no positive emotion had to appear.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.help.emotions",
      "title": "If this option does not fit",
      "text": "If the content feels irritating, upsetting or flat, stop or choose another method. Do not keep searching until you feel the right emotion.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.method.pushing-away",
      "title": "Pushing Away",
      "text": "This adapted option creates a deliberate short boundary around attention. It does not deny that the issue exists or require suppressing every thought.\n\nChoose when to check back, then put aside a non-urgent cue if safe—for example, close an ordinary message thread for a brief pause. If it returns to mind, acknowledge that and turn to another ordinary focus.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.example.pushing-away",
      "title": "Example — Pushing Away",
      "text": "Rae closes a non-urgent message thread until after a short drink break. Thoughts about it return, and Rae notices them without trying to force them out.\n\nAt the agreed point Rae checks back and considers what needs attention. The issue was postponed briefly, not declared unreal.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.help.pushing-away",
      "title": "If this option does not fit",
      "text": "Do not set aside urgent information, safety duties or an agreed treatment task. If postponing keeps extending, stop and review the pattern with your therapist.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.method.thoughts",
      "title": "Thoughts",
      "text": "A neutral mental task gives attention a different job for a short time. It is not an argument with the distressing thought.\n\nTry naming a few ordinary objects that begin with a chosen letter, or a familiar simple puzzle. Stop at a small chosen point and check back; mistakes do not matter.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.example.thoughts",
      "title": "Example — Thoughts",
      "text": "Rae names a few everyday objects beginning with B and loses track once. Rae starts again without treating it as a test.\n\nAfter the small task, Rae checks the situation again. The concern remains, but attention was briefly elsewhere.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.help.thoughts",
      "title": "If this option does not fit",
      "text": "Avoid difficult counting or perfectionistic rules. If the task becomes compulsive checking or frustrating, stop or choose a simpler option.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.method.sensations",
      "title": "Sensations",
      "text": "A tolerable sensory detail can draw attention away from the distressing cue. Unlike self-soothing, the immediate aim here is a change of focus, not necessarily comfort.\n\nChoose a familiar safe sensation, such as the texture of a sleeve or a nearby ordinary sound at comfortable volume. Notice a few details briefly, then check back. Do not use pain, ice, extreme temperature or intense stimulation.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.example.sensations",
      "title": "Example — Sensations",
      "text": "Rae notices the texture of a familiar sleeve without squeezing or rubbing hard.\n\nThe texture is tolerable; frustration remains. Rae stops after a brief look and touch and returns to the situation.",
      "status": "Selected-method static script only"
    },
    {
      "id": "accepts.help.sensations",
      "title": "If this option does not fit",
      "text": "Touch and body attention are optional. Respect sensory sensitivity, pain and health advice; use another choice if this does not fit.",
      "status": "Selected-method static script only"
    }
  ]
}
;
