window.MaintenancePlanningContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/maintenance",
  "resourceId": "tool/maintenance-planning",
  "routeProposal": "/maintenance-planning/",
  "title": "Maintenance Planning",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Make a plan with your therapist to keep using what helps and know when to seek more support.",
  "groupedSetStatus": "One existing canonical entry, classic/maintenance. Related support tools and Coping Cards remain separate resources or component references. This candidate does not establish relapse prevention efficacy or replace clinical follow-up. No new catalogue count.",
  "clinicalContract": {
    "sourcePopulationContext": "NICE guidance concerns adult depression; CCI sources concern depression and panic. These sources do not validate this generic digital adaptation across ages or diagnoses. There is no blanket adult-only or 16+ restriction and no universal age-suitability claim. Therapist adaptation must consider development, safeguarding, health, communication and access.",
    "learningObjective": "Understand how useful learning, familiar practice, personal changes, likely challenges, linked responses, support and later review form one revisable plan.",
    "practiceObjective": "Think through or optionally record a coherent plan with specific responses, a kind restart, ordinary support, professional re-entry, rehearsal and review after actual use.",
    "exclusions": [
      "Crisis or suicide safety planning",
      "Substance-use relapse planning",
      "Medication advice or treatment/discharge decisions",
      "New exposure, trauma or other specialist treatment instructions",
      "Diagnostic scoring, risk prediction or guarantees against recurrence"
    ],
    "reviewGates": [
      "Qualified clinician review of exact text, fictional example and individualized fit",
      "Comprehension review, including users with different communication and access needs",
      "Authorized integrated browser, keyboard, screen-reader, mobile and destination tests",
      "Exact script binding and listening review before any narration activation",
      "Canonical integration and release acceptance"
    ],
    "adaptations": [
      "Original text and fictional example, not a reproduced clinical worksheet",
      "One manageable plan, optional writing and no automatic inference of progress",
      "Concrete linked sign and challenge responses, not unconnected lists",
      "No symptom threshold, waiting period, compliance score or imposed schedule",
      "Explicit untried, unchanged, harder and unavailable-support paths",
      "Notes remain in memory in this open tool; selected-only export"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Choose how to use your plan",
      "options": [
        {
          "value": "plan",
          "label": "Make or revise my plan",
          "startSectionId": "maintenance-planning.practice.learning"
        },
        {
          "value": "review",
          "label": "Review how it went",
          "startSectionId": "maintenance-planning.practice.review"
        }
      ]
    },
    "entryGate": "Visible therapist-supported fit text precedes either own-practice choice. This is an instruction, not a safety assessment. Example, Learn, Finish and urgent support are always available.",
    "focus": "One meaningful prompt group, free jump, Show all, Previous and Finish. No forced writing or completion lock.",
    "reviewAccess": "Direct review requires no plan, attempt or improvement. Planning and review share one in-memory record but retain their own prompt positions.",
    "writing": "Hidden and optional by default. Fiction never fills personal fields. Hide conceals all private displays and invalidates export selection.",
    "persistence": "Notes stay during internal reading/navigation only. Leaving, reload, clear, restart, history navigation or BFCache return clears them. Offscreen visibility alone retains them.",
    "export": "Explicit selection and exact preview before copy/download. No default note selection. Editing, hiding, stage or mode changes invalidate preview.",
    "narration": "Exact fixed paragraph/help scripts only. No personal answers in scripts. No recordings, Audio/TTS, autoplay or enabled playback.",
    "completion": "No success, completed, attempted, improvement, compliance, score or streak state.",
    "monitoring": "No alerts, contact, sharing, booked appointments, reminders or clinician access."
  },
  "intro": {
    "id": "maintenance-planning.intro",
    "title": "Keep a plan you can change",
    "paragraphs": [
      "Maintenance means keeping up what helps. This plan brings together what you have learned, changes to notice, steps you can take and people or services you can ask for help.",
      "Use it with skills your therapist has taught and checked with you. You can make a plan, read a made-up example, or review how a plan went. You do not need to show progress to use this page."
    ]
  },
  "fit": {
    "id": "maintenance-planning.fit",
    "title": "Before making your own plan",
    "paragraphs": [
      "Choose familiar skills with your therapist. Check what fits your needs now and when you should seek more help. This page cannot decide that for you. If no skill seems to help, bring that to your therapist rather than making yourself practise it.",
      "This is not a crisis or suicide safety plan. For immediate danger or urgent help, use Support and urgent help now. You do not need to finish this page. No one watches these notes or gets an alert from them.",
      "Use specialist care for a substance-use relapse plan. Keep following health advice. Do not use this page to change medicine, leave treatment, or start a new exposure or trauma exercise.",
      "If things are getting worse or you need more help, contact an appropriate professional. Do not keep repeating skills instead. You can also read the example, skip a prompt or stop."
    ]
  },
  "privacy": {
    "id": "maintenance-planning.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, diagnoses and contact details are not needed. A role, such as my therapist, may be enough.",
      "Notes stay while you use this open tool, including its example and help. Leaving this tool, reloading, clearing or starting again removes them. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "Nothing is sent to a therapist or support person. The optional narration uses fixed guidance, not your notes. If you use a screen reader or another read-aloud tool, it may read notes you choose to show. This page does not contact anyone, watch for changes or set reminders. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "maintenance-planning.close",
    "title": "Leave the plan here for now",
    "paragraphs": [
      "You can finish with a full plan, one useful idea or questions to bring to therapy. A draft does not mean you used the plan or that anyone agreed to help.",
      "You can return to any prompt or choose notes to keep. Finish and clear removes the notes in this tool. It does not remove a copy you kept elsewhere."
    ]
  },
  "example": {
    "id": "maintenance-planning.example",
    "title": "Alex plans for a changing work week",
    "paragraphs": [
      "This example is made up. It is not a plan you need to copy. Alex and their therapist review what has helped and what is still hard.",
      "Learning: Breaking a task into one small step has helped Alex start some household jobs. Tired evenings are still hard. Alex does not call every week better.",
      "Keep practising: On a free morning, Alex will choose one small part of a household task. If energy is low, Alex can name the first step without doing it yet. They have checked both options with their therapist.",
      "Change to notice: Alex starts putting off a usual small task because it feels too big. First response: At the next chance at home, Alex will use the familiar small-step guide to choose one part. If that still does not fit, Alex will ask for help rather than keep pushing.",
      "Likely challenge: A shift change may leave less time and energy. First response: When Alex sees the new work schedule, they will choose a different time for the familiar practice. The work schedule change is a possible challenge, not proof that things will get worse.",
      "Support: Alex plans to ask a trusted friend to help choose one task. The friend has not agreed yet. Alex and their therapist have agreed to contact the clinic through its usual booking route if everyday tasks become harder to manage or the plan stops fitting. If the clinic cannot respond when help is needed, Alex can contact their usual primary care service. Urgent needs use urgent help, not this routine plan.",
      "Rehearsal: Before choosing the free morning, Alex imagines practising after a late shift. They expect to be too tired. They change the plan to a free morning. If practice is missed, Alex will check what got in the way and restart with a smaller step, without trying to catch up.",
      "After real use: The shift changes. Alex names one small task but does not start it. The friend is away. Alex notes what happened, uses the planned clinic contact and asks to review a plan that fits their energy. Sending that request does not mean an appointment is booked.",
      "Review: Alex will bring the unchanged difficulty and the contact outcome to therapy. They leave the next practice step open until it has been reviewed. Alex plans to look at the plan again when the clinic replies, or sooner if their needs change. This page does not set a reminder."
    ]
  },
  "learn": {
    "id": "maintenance-planning.learn",
    "title": "What this plan adds",
    "paragraphs": [
      "A maintenance plan joins the pieces together. It asks what helped, what to keep practising, what changes or challenges to notice, what to do next, and when to get more help. It also makes room to review the plan after using it.",
      "A change is something you notice, such as finding a usual task harder. A challenge is something that may make things harder, such as a change in routine. Sometimes people call that a trigger. Neither one proves that an illness has returned.",
      "A difficult week or a gap in practice does not erase what you learned. It can show that the plan needs more support, a different step or a fresh review. There is no requirement to make up missed practice.",
      "This plan does not promise to prevent a return of symptoms. Needs, health, time, money, access and support can change. Some difficulties need care beyond a skills plan. Ask for that help rather than treating more practice as the only answer.",
      "The separate Notice a change and ask for support tool helps you describe a change and ask for help. Return after a gap helps you restart a familiar practice. Support Plan helps you choose ordinary support and a contact step. This maintenance plan connects those jobs to useful learning, signs, challenges and review.",
      "A Coping Card can hold a short reminder from your plan. It does not replace the full plan or a support agreement. You and your therapist can decide what, if anything, would be useful to keep."
    ]
  },
  "practice": [
    {
      "id": "maintenance-planning.practice.learning",
      "title": "Look at what you have learned",
      "paragraphs": [
        "Think of the work you have done with your therapist. What have you learned about what helps or gets in the way? What skill, support or practical change was useful, if any?",
        "What is still hard, unchanged or harder now? You do not have to report progress. Use what really happened, not what you think you should say."
      ],
      "fields": [
        {
          "key": "helped",
          "label": "What I learned or found useful",
          "optional": true
        },
        {
          "key": "still-hard",
          "label": "What is still hard or needs review",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing seems to help",
        "text": "You do not have to invent a gain. Take that concern to your therapist. You can leave the practice steps open and use the support prompts instead."
      }
    },
    {
      "id": "maintenance-planning.practice.keep",
      "title": "Choose a useful practice to keep",
      "paragraphs": [
        "Choose one familiar skill you and your therapist think still fits. What small action will you practise? Choose a time, place or everyday cue that could work. A cue is something that helps you remember.",
        "Check your time, energy, health, money, access and support. Keep any aids or help you need. What smaller version, rest or other agreed option could fit a harder day? There is no target or streak to pass."
      ],
      "fields": [
        {
          "key": "practice-plan",
          "label": "My familiar skill, small action, time or cue and place",
          "optional": true
        },
        {
          "key": "smaller-practice",
          "label": "A smaller version or other agreed option",
          "optional": true
        }
      ],
      "help": {
        "title": "If the old practice no longer fits",
        "text": "Do not force it or add a new treatment step here. Ask your therapist to review what fits now. Access needs and low energy are real limits, not a lack of effort."
      }
    },
    {
      "id": "maintenance-planning.practice.notice",
      "title": "Choose a change and a likely challenge",
      "paragraphs": [
        "What personal change would be useful to notice? Choose something you can describe, such as a usual task becoming harder. This is a sign to check what you need, not a diagnosis.",
        "What coming event or change could make using your skills harder? This is a possible challenge, not a prediction that it will go badly. You can choose one change, one challenge, or keep either open.",
        "Ask your therapist what is worth noticing and how. You do not need to watch yourself all day, count symptoms or prove that a change means relapse."
      ],
      "fields": [
        {
          "key": "change-sign",
          "label": "One personal change to notice",
          "optional": true
        },
        {
          "key": "challenge",
          "label": "One likely challenge or change in routine",
          "optional": true
        }
      ],
      "help": {
        "title": "If you are unsure what counts",
        "text": "Start with an ordinary difference from your own usual pattern. A tired day can have many causes. If a change concerns you, ask for advice rather than guessing what it means."
      }
    },
    {
      "id": "maintenance-planning.practice.respond",
      "title": "Link each one to a first step",
      "paragraphs": [
        "For the change you chose, what familiar action or support step did you agree with your therapist? Try: If I notice this change, I will do this first, at this time or place. Leave this open if you did not choose a change.",
        "For the coming challenge, what could you prepare or adjust? Try: If this challenge comes up, I will take this first step. Leave this open if you did not choose a challenge.",
        "Check that each response matches the change or challenge beside it. If the first step cannot happen or no longer fits, what is the safer, workable alternative? It may be rest, practical help or contacting care rather than another skill."
      ],
      "fields": [
        {
          "key": "sign-response",
          "label": "My chosen change and its first response, when and where",
          "optional": true
        },
        {
          "key": "challenge-response",
          "label": "My chosen challenge and its first response, when and where",
          "optional": true
        },
        {
          "key": "fallback",
          "label": "If the first step cannot happen or does not fit",
          "optional": true
        }
      ],
      "help": {
        "title": "If things are getting worse",
        "text": "Do not use a response as a reason to put off needed care. Follow the support plan you made with your therapist or contact an appropriate professional. Use urgent help for an urgent need."
      }
    },
    {
      "id": "maintenance-planning.practice.support",
      "title": "Make support and return to care clear",
      "paragraphs": [
        "Who or what service could help with this plan? What help would you ask for, and how could you reach them? You can use a role instead of a name or phone number.",
        "With your therapist, decide what would mean you need more professional help instead of relying on this plan. Who or which service would you contact, how, and what would you ask for? There is no required number of days to wait.",
        "Check what has really been agreed. Is this still an idea, a request not yet made, a request awaiting a reply, or help actually agreed? Include any limits or availability you know. A draft is not an agreement.",
        "If that person or service is unavailable, what other suitable route could you use? If none is known, ask your therapist to help find one. Urgent help is separate and can be used now, without finishing or waiting for a routine reply."
      ],
      "fields": [
        {
          "key": "ordinary-support",
          "label": "Ordinary help, person or service, and how I would ask",
          "optional": true
        },
        {
          "key": "care-cue",
          "label": "What my therapist and I agreed means I need more care",
          "optional": true
        },
        {
          "key": "care-route",
          "label": "Professional contact route and help I would request",
          "optional": true
        },
        {
          "key": "support-status",
          "label": "What is actually agreed and what is still only planned",
          "optional": true
        },
        {
          "key": "backup-support",
          "label": "An alternative contact route if help is unavailable",
          "optional": true
        }
      ],
      "help": {
        "title": "If no contact comes to mind",
        "text": "The next contact does not have to be someone you know. Ask about a suitable clinic, primary care, community service or other professional route. This page does not check availability, send a request or monitor you."
      }
    },
    {
      "id": "maintenance-planning.practice.rehearse",
      "title": "Rehearse a hard moment and a kind restart",
      "paragraphs": [
        "Choose one ordinary difficulty from your plan. Imagine or say privately: I notice this, so my first step is this. Where would you be? Do you have the time, energy, access and help for that step?",
        "What might get in the way? Try the backup in your mind. Change the plan if needed. This is a rehearsal, not proof that you used the plan or that it will work.",
        "If practice is interrupted, check what changed and whether the skill still fits. Choose one small return already checked with your therapist. You do not need to catch up or punish yourself. If you need more care, use the contact plan instead of pushing through."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "The difficulty, first step and backup I rehearsed",
          "optional": true
        },
        {
          "key": "restart",
          "label": "My kind restart or the support I need instead",
          "optional": true
        }
      ],
      "help": {
        "title": "If imagining it feels too hard",
        "text": "Keep it simple, use the fictional example, or stop. You do not need to picture a frightening event in detail. Ask your therapist to help make the plan usable."
      }
    },
    {
      "id": "maintenance-planning.practice.review",
      "title": "Review what happened in real life",
      "paragraphs": [
        "Come here after a chance to use the plan. Did you use it, use part, change it, or not use it? Any of these can be reviewed. If you have not used it yet, leave the outcome open and move to the next prompt.",
        "What actually happened? What helped, did not help, stayed the same or got harder? Was support available, and what was actually agreed? Keep a hoped-for result separate from a real one.",
        "What needs to stay, change or be checked with your therapist? If the plan is no longer enough, seek more care. You do not have to keep trying it before asking for help."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "What I used, changed or did not use",
          "optional": true
        },
        {
          "key": "actual-result",
          "label": "What really happened, including support availability",
          "optional": true
        },
        {
          "key": "review-change",
          "label": "What needs to change or be reviewed with my therapist",
          "optional": true
        }
      ],
      "help": {
        "title": "If you did not use the plan",
        "text": "A gap can give useful information about time, access, energy or fit. It does not prove the plan would have worked or that you failed. You can review the barrier without inventing a result."
      }
    },
    {
      "id": "maintenance-planning.practice.summary",
      "title": "Bring the plan together and choose a review cue",
      "paragraphs": [
        "Read or think through one linked plan: what helps me; what I will keep practising; the change or challenge I will notice; my first step and backup; and when and how I will ask for support or more care.",
        "Check that the pieces fit each other. Are the steps small enough and the contact routes real? Leave gaps as questions to review with your therapist. A short reminder can help, but do not leave out the support you need.",
        "If useful, choose a time or cue to look at the plan again, or bring it to a therapy session. Review it sooner if your needs change. This page does not set a reminder or book a session."
      ],
      "fields": [
        {
          "key": "plan-summary",
          "label": "My linked plan or a short reminder",
          "optional": true
        },
        {
          "key": "review-cue",
          "label": "When or what will remind me to review the plan",
          "optional": true
        },
        {
          "key": "therapy-question",
          "label": "A gap or question to bring to therapy",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want to keep part of the plan",
        "text": "Choose notes to keep lets you select and check only the notes you want. No writing is required and nothing is sent to anyone. You decide if, when and how to share a copy."
      }
    }
  ],
  "sources": [
    {
      "id": "NICE Quality statement 3 Preventing relapse",
      "url": "https://www.nice.org.uk/guidance/qs8/chapter/Quality-statement-3-Preventing-relapse",
      "supports": "Review therapy learning, continue useful practice, link personal warning signs and likely difficulties to responses, and prepare for foreseeable challenges.",
      "limits": "Adult depression guidance. Not evidence of generic app efficacy or suitability across ages. Direct page returned 403; authoritative search-index text was verified."
    },
    {
      "id": "CCI Maintaining Your Gains",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Consumer-Modules/When-Panic-Attacks/When-Panic-Attacks---Module-7---Maintaining-Your-Gains.pdf",
      "supports": "Review learning, signs and triggers, useful skills, support and future plans.",
      "limits": "Panic-specific clinical education. Exposure instructions are deliberately not imported into this generic practice."
    },
    {
      "id": "CCI Self Management",
      "url": "https://cci.health.wa.gov.au/~/media/CCI/Consumer-Modules/Back-from-The-Bluez/Back-from-the-Bluez---09---Self-Management.pdf",
      "supports": "Continue useful practice, revise goals, use social support and respond to setbacks without treating earlier learning as erased.",
      "limits": "Depression-specific clinical education. No guarantee against recurrence or independently validated digital treatment is claimed."
    }
  ],
  "relatedResources": [
    {
      "resourceId": "tool/notice-a-change-and-ask-for-support",
      "label": "Notice a change and ask for support",
      "role": "Practise describing a change and asking for help.",
      "href": null,
      "availability": "Older external reference withheld from this written REVIEW build; not verified as equivalent."
    },
    {
      "resourceId": "tool/return-to-practice",
      "label": "Return after a gap",
      "role": "Check whether a familiar skill still fits and choose a small return to it.",
      "href": null,
      "availability": "Older external reference withheld from this written REVIEW build; not verified as equivalent."
    },
    {
      "resourceId": "tool/support-plan",
      "label": "Support Plan",
      "role": "Choose ordinary support and a possible contact step.",
      "href": "../batch-1/#tool/support-plan"
    }
  ],
  "methodTraceability": [
    {
      "operation": "Review useful learning and remaining difficulties",
      "sections": [
        "practice.learning"
      ],
      "source": "NICE; CCI maintenance; original Maps & Mirrors review material"
    },
    {
      "operation": "Specific attainable continued practice",
      "sections": [
        "practice.keep"
      ],
      "source": "NICE; CCI; access and no-compliance safeguards are explicit adaptation"
    },
    {
      "operation": "Distinguish changes from challenges and pair each with a response",
      "sections": [
        "practice.notice",
        "practice.respond"
      ],
      "source": "NICE signs/difficulties/foreseeable events; CCI signs/triggers"
    },
    {
      "operation": "Ordinary support, professional re-entry and available alternatives",
      "sections": [
        "practice.support"
      ],
      "source": "CCI support; current Support Plan identity and conservative care-boundary adaptation"
    },
    {
      "operation": "Rehearsal, barrier check and kind restart",
      "sections": [
        "practice.rehearse"
      ],
      "source": "NICE concrete contingency plans; CCI setbacks; rehearsal is a transparent adaptation"
    },
    {
      "operation": "Actual-use review and revisable coherent plan",
      "sections": [
        "practice.review",
        "practice.summary"
      ],
      "source": "NICE therapy learning review; CCI revisable goals; original Maps & Mirrors honest review"
    }
  ],
  "narrationSegments": [
    {
      "id": "maintenance-planning.intro",
      "title": "Keep a plan you can change",
      "text": "Maintenance means keeping up what helps. This plan brings together what you have learned, changes to notice, steps you can take and people or services you can ask for help.\n\nUse it with skills your therapist has taught and checked with you. You can make a plan, read a made-up example, or review how a plan went. You do not need to show progress to use this page.",
      "sha256": "da73307a0e6082b97fc6a7adc441764855b305462fd7543de59246ef09f0bc71",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.fit",
      "title": "Before making your own plan",
      "text": "Choose familiar skills with your therapist. Check what fits your needs now and when you should seek more help. This page cannot decide that for you. If no skill seems to help, bring that to your therapist rather than making yourself practise it.\n\nThis is not a crisis or suicide safety plan. For immediate danger or urgent help, use Support and urgent help now. You do not need to finish this page. No one watches these notes or gets an alert from them.\n\nUse specialist care for a substance-use relapse plan. Keep following health advice. Do not use this page to change medicine, leave treatment, or start a new exposure or trauma exercise.\n\nIf things are getting worse or you need more help, contact an appropriate professional. Do not keep repeating skills instead. You can also read the example, skip a prompt or stop.",
      "sha256": "19aa5e612ee16c6ed6bc3552e79f14a559a684e8a5628ef16c164949c768dd01",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. Names, diagnoses and contact details are not needed. A role, such as my therapist, may be enough.\n\nNotes stay while you use this open tool, including its example and help. Leaving this tool, reloading, clearing or starting again removes them. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nNothing is sent to a therapist or support person. The optional narration uses fixed guidance, not your notes. If you use a screen reader or another read-aloud tool, it may read notes you choose to show. This page does not contact anyone, watch for changes or set reminders. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "eed5de104b8a6ecade63df6c104178f801652e024331a923fbe2725b5ac550b4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.close",
      "title": "Leave the plan here for now",
      "text": "You can finish with a full plan, one useful idea or questions to bring to therapy. A draft does not mean you used the plan or that anyone agreed to help.\n\nYou can return to any prompt or choose notes to keep. Finish and clear removes the notes in this tool. It does not remove a copy you kept elsewhere.",
      "sha256": "fa6b5a24ddb8ce4dfebba914875fd33686e8d45e020d5a4e39878376785cca19",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.example",
      "title": "Alex plans for a changing work week",
      "text": "This example is made up. It is not a plan you need to copy. Alex and their therapist review what has helped and what is still hard.\n\nLearning: Breaking a task into one small step has helped Alex start some household jobs. Tired evenings are still hard. Alex does not call every week better.\n\nKeep practising: On a free morning, Alex will choose one small part of a household task. If energy is low, Alex can name the first step without doing it yet. They have checked both options with their therapist.\n\nChange to notice: Alex starts putting off a usual small task because it feels too big. First response: At the next chance at home, Alex will use the familiar small-step guide to choose one part. If that still does not fit, Alex will ask for help rather than keep pushing.\n\nLikely challenge: A shift change may leave less time and energy. First response: When Alex sees the new work schedule, they will choose a different time for the familiar practice. The work schedule change is a possible challenge, not proof that things will get worse.\n\nSupport: Alex plans to ask a trusted friend to help choose one task. The friend has not agreed yet. Alex and their therapist have agreed to contact the clinic through its usual booking route if everyday tasks become harder to manage or the plan stops fitting. If the clinic cannot respond when help is needed, Alex can contact their usual primary care service. Urgent needs use urgent help, not this routine plan.\n\nRehearsal: Before choosing the free morning, Alex imagines practising after a late shift. They expect to be too tired. They change the plan to a free morning. If practice is missed, Alex will check what got in the way and restart with a smaller step, without trying to catch up.\n\nAfter real use: The shift changes. Alex names one small task but does not start it. The friend is away. Alex notes what happened, uses the planned clinic contact and asks to review a plan that fits their energy. Sending that request does not mean an appointment is booked.\n\nReview: Alex will bring the unchanged difficulty and the contact outcome to therapy. They leave the next practice step open until it has been reviewed. Alex plans to look at the plan again when the clinic replies, or sooner if their needs change. This page does not set a reminder.",
      "sha256": "40123db0f8210955bdf8e0f2100b189979db6f9f88b1765fc9f6b328d3b485b5",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.learn",
      "title": "What this plan adds",
      "text": "A maintenance plan joins the pieces together. It asks what helped, what to keep practising, what changes or challenges to notice, what to do next, and when to get more help. It also makes room to review the plan after using it.\n\nA change is something you notice, such as finding a usual task harder. A challenge is something that may make things harder, such as a change in routine. Sometimes people call that a trigger. Neither one proves that an illness has returned.\n\nA difficult week or a gap in practice does not erase what you learned. It can show that the plan needs more support, a different step or a fresh review. There is no requirement to make up missed practice.\n\nThis plan does not promise to prevent a return of symptoms. Needs, health, time, money, access and support can change. Some difficulties need care beyond a skills plan. Ask for that help rather than treating more practice as the only answer.\n\nThe separate Notice a change and ask for support tool helps you describe a change and ask for help. Return after a gap helps you restart a familiar practice. Support Plan helps you choose ordinary support and a contact step. This maintenance plan connects those jobs to useful learning, signs, challenges and review.\n\nA Coping Card can hold a short reminder from your plan. It does not replace the full plan or a support agreement. You and your therapist can decide what, if anything, would be useful to keep.",
      "sha256": "741b84d9d01e32b925e04a125491972c4de1cc96c10de1b192dd141088bc8c38",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.learning",
      "title": "Look at what you have learned",
      "text": "Think of the work you have done with your therapist. What have you learned about what helps or gets in the way? What skill, support or practical change was useful, if any?\n\nWhat is still hard, unchanged or harder now? You do not have to report progress. Use what really happened, not what you think you should say.",
      "sha256": "d5c960f9025fa2d80fbda3af2c2daaeeb85c98deb9d6aa5165a84ab7d9f22baf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.learning.help",
      "title": "If nothing seems to help",
      "text": "You do not have to invent a gain. Take that concern to your therapist. You can leave the practice steps open and use the support prompts instead.",
      "sha256": "eae942853ee9fdc20e70828409fd8d72f76d195fdeb904a6936bb4e5804e5b9d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "maintenance-planning.practice.keep",
      "title": "Choose a useful practice to keep",
      "text": "Choose one familiar skill you and your therapist think still fits. What small action will you practise? Choose a time, place or everyday cue that could work. A cue is something that helps you remember.\n\nCheck your time, energy, health, money, access and support. Keep any aids or help you need. What smaller version, rest or other agreed option could fit a harder day? There is no target or streak to pass.",
      "sha256": "68a0bee21c85ac75e8ffc68d77b7fc2ab9ce32e2be9891f766350321eb522e3c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.keep.help",
      "title": "If the old practice no longer fits",
      "text": "Do not force it or add a new treatment step here. Ask your therapist to review what fits now. Access needs and low energy are real limits, not a lack of effort.",
      "sha256": "6da1441fe18745f157579e175ce43cdc94f2c24d94eece32a6941963793bde98",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "maintenance-planning.practice.notice",
      "title": "Choose a change and a likely challenge",
      "text": "What personal change would be useful to notice? Choose something you can describe, such as a usual task becoming harder. This is a sign to check what you need, not a diagnosis.\n\nWhat coming event or change could make using your skills harder? This is a possible challenge, not a prediction that it will go badly. You can choose one change, one challenge, or keep either open.\n\nAsk your therapist what is worth noticing and how. You do not need to watch yourself all day, count symptoms or prove that a change means relapse.",
      "sha256": "821c6202f239f8bed740cbbb93ccceefde9bc1b749339c932e76f6ef7476fc2c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.notice.help",
      "title": "If you are unsure what counts",
      "text": "Start with an ordinary difference from your own usual pattern. A tired day can have many causes. If a change concerns you, ask for advice rather than guessing what it means.",
      "sha256": "234085a42ec9ee651db2db2da016ab0cceff6c731021e65f84269efef5e43cc8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "maintenance-planning.practice.respond",
      "title": "Link each one to a first step",
      "text": "For the change you chose, what familiar action or support step did you agree with your therapist? Try: If I notice this change, I will do this first, at this time or place. Leave this open if you did not choose a change.\n\nFor the coming challenge, what could you prepare or adjust? Try: If this challenge comes up, I will take this first step. Leave this open if you did not choose a challenge.\n\nCheck that each response matches the change or challenge beside it. If the first step cannot happen or no longer fits, what is the safer, workable alternative? It may be rest, practical help or contacting care rather than another skill.",
      "sha256": "ca25daeeb4604b7c44af88b0b94fbc1b486715b0884222df15b599fe5fec9775",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.respond.help",
      "title": "If things are getting worse",
      "text": "Do not use a response as a reason to put off needed care. Follow the support plan you made with your therapist or contact an appropriate professional. Use urgent help for an urgent need.",
      "sha256": "6a74c2fc3ee9b465c15dc20be76ef09f3b256debc8030b7f2dcb1abe9173a9cb",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "maintenance-planning.practice.support",
      "title": "Make support and return to care clear",
      "text": "Who or what service could help with this plan? What help would you ask for, and how could you reach them? You can use a role instead of a name or phone number.\n\nWith your therapist, decide what would mean you need more professional help instead of relying on this plan. Who or which service would you contact, how, and what would you ask for? There is no required number of days to wait.\n\nCheck what has really been agreed. Is this still an idea, a request not yet made, a request awaiting a reply, or help actually agreed? Include any limits or availability you know. A draft is not an agreement.\n\nIf that person or service is unavailable, what other suitable route could you use? If none is known, ask your therapist to help find one. Urgent help is separate and can be used now, without finishing or waiting for a routine reply.",
      "sha256": "32c4fbf46f699d95721c030cd0ad0d1bc882e8b60e863ae6274f986a385ca47f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.support.help",
      "title": "If no contact comes to mind",
      "text": "The next contact does not have to be someone you know. Ask about a suitable clinic, primary care, community service or other professional route. This page does not check availability, send a request or monitor you.",
      "sha256": "c1d4566381a0456d33e9459ac993f4308756f2f3ad6ae8b802a2733d97cb0623",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "maintenance-planning.practice.rehearse",
      "title": "Rehearse a hard moment and a kind restart",
      "text": "Choose one ordinary difficulty from your plan. Imagine or say privately: I notice this, so my first step is this. Where would you be? Do you have the time, energy, access and help for that step?\n\nWhat might get in the way? Try the backup in your mind. Change the plan if needed. This is a rehearsal, not proof that you used the plan or that it will work.\n\nIf practice is interrupted, check what changed and whether the skill still fits. Choose one small return already checked with your therapist. You do not need to catch up or punish yourself. If you need more care, use the contact plan instead of pushing through.",
      "sha256": "22246fab6687c8757df4101671c1c1013d965dd3c8ddc17b11fd5817b5ba2da6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.rehearse.help",
      "title": "If imagining it feels too hard",
      "text": "Keep it simple, use the fictional example, or stop. You do not need to picture a frightening event in detail. Ask your therapist to help make the plan usable.",
      "sha256": "999ce59902fb7987e0c5f86bb3f0aac470e7d988bb0f9c28b72528aa9c3c64cd",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "maintenance-planning.practice.review",
      "title": "Review what happened in real life",
      "text": "Come here after a chance to use the plan. Did you use it, use part, change it, or not use it? Any of these can be reviewed. If you have not used it yet, leave the outcome open and move to the next prompt.\n\nWhat actually happened? What helped, did not help, stayed the same or got harder? Was support available, and what was actually agreed? Keep a hoped-for result separate from a real one.\n\nWhat needs to stay, change or be checked with your therapist? If the plan is no longer enough, seek more care. You do not have to keep trying it before asking for help.",
      "sha256": "ce91903a42b732c024f8dd853c22ffaf1e8a59c0976aab212ca116d5d6576982",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.review.help",
      "title": "If you did not use the plan",
      "text": "A gap can give useful information about time, access, energy or fit. It does not prove the plan would have worked or that you failed. You can review the barrier without inventing a result.",
      "sha256": "e5b79acea1180deb017f73679103c6169b96299144b4bc9eec2788dba1381b1c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "maintenance-planning.practice.summary",
      "title": "Bring the plan together and choose a review cue",
      "text": "Read or think through one linked plan: what helps me; what I will keep practising; the change or challenge I will notice; my first step and backup; and when and how I will ask for support or more care.\n\nCheck that the pieces fit each other. Are the steps small enough and the contact routes real? Leave gaps as questions to review with your therapist. A short reminder can help, but do not leave out the support you need.\n\nIf useful, choose a time or cue to look at the plan again, or bring it to a therapy session. Review it sooner if your needs change. This page does not set a reminder or book a session.",
      "sha256": "d507ea9371175be561d49255b3ea35118e4540e1e85be2e84f348a40f549275a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "maintenance-planning.practice.summary.help",
      "title": "If you want to keep part of the plan",
      "text": "Choose notes to keep lets you select and check only the notes you want. No writing is required and nothing is sent to anyone. You decide if, when and how to share a copy.",
      "sha256": "63d3950f13958f321ebd0ed60f058ddd70c62785aa3a6890718581f0fcbb9f86",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
