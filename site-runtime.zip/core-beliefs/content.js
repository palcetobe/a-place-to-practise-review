window.CoreBeliefsContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/core",
  "resourceId": "tool/core-beliefs",
  "routeProposal": "/core-beliefs/",
  "title": "Developing Balanced Core Beliefs",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Work with a broad belief you and your therapist have chosen, then review small agreed practice.",
  "groupedSetStatus": "One existing canonical entry, classic/core. Full bounded core-belief practice is distinct from a Thought Record, Rules and Assumptions, positive-evidence log or identity reflection. No new count. Downward Arrow remains an unimplemented clinician-guided formulation component, not a solo route.",
  "clinicalContract": {
    "learningObjective": "Recognize the difference between one event and an overall self-belief; develop a credible balanced alternative using context, evidence and agreed practice, without putting human worth on trial.",
    "practiceObjective": "Use an already therapist-formulated ordinary self-belief; examine specific apparent evidence in context, notice existing and future evidence for a balanced alternative, rehearse a bounded agreed action and review actual experience, non-use and both beliefs over time.",
    "sourcePopulationContext": "Adult-framed CCI and professional CBT teaching sources establish procedures, not validation of this isolated adaptation. No blanket age floor and no universal age-suitability claim. Individual developmental, clinical, safeguarding, health, communication, cultural, power and access needs require therapist review.",
    "exclusions": [
      "No autonomous Downward Arrow, search for a deepest belief, trauma recall or memory reconstruction",
      "No testing personal worth, deservingness of care, identity, oppression or whether abuse was justified",
      "No self-directed exposure/ERP, dropping protective aids or changes to health care, food, medication, sleep or substance use",
      "No dangerous tasks, unsafe relationships, legal/financial commitments, humiliation or compelled disclosure",
      "No compulsory positive declarations, belief ratings, equal evidence lists or promised emotional change"
    ],
    "adaptations": [
      "Therapist-formulated target and explicit prior instruction gate",
      "This adaptation uses manageable ordinary examples; deeper autobiographical exploration is outside its scope",
      "Original language, example and page structure; no source worksheet reproduced",
      "Optional qualitative or numeric ratings of beliefs, never scores of personal worth",
      "Actual non-use, mixed/adverse results and unchanged belief supported",
      "Exact selected-note export from open-page memory only; no automatic therapist report"
    ],
    "reviewGates": [
      "Owner/clinician and rights review of full adapted method, wording, example and component boundaries",
      "Individual clinical, developmental, safeguarding and access fit",
      "Novice comprehension review; grade-five language is a target, not a validated reading level",
      "Real integrated desktop/mobile/keyboard/screen-reader and lifecycle/navigation acceptance",
      "Authorized narration generation, exact-script listening, binding and controls review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use the belief and practice you agreed with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Work on my agreed belief",
          "startSectionId": "core-beliefs.practice.belief"
        },
        {
          "value": "review",
          "label": "Review my agreed practice",
          "startSectionId": "core-beliefs.practice.review"
        }
      ]
    },
    "entryGate": "Visible therapist-formulated scope before explicit entry choice; not screening, proof of fit or action approval. Example, Learn, Finish and support remain available.",
    "focus": "One meaningful prompt group with free jump, Show all, Previous and Finish. No required writing or completion locks.",
    "reviewAccess": "Direct blank review without a stored plan or assumed attempt. All prompt groups remain available in both modes.",
    "writing": "Optional and hidden initially. Fiction never fills notes. Hiding notes removes private displays and invalidates export selection.",
    "persistence": "In-memory open-page notes only. Internal readings/navigation retain them; clear, restart, leaving/reloading, history navigation and BFCache return clear them. Offscreen visibility alone retains them.",
    "export": "No default selection; explicit selection yields exact preview/copy/download. Editing, hiding, mode or stage changes invalidate selection.",
    "narration": "Hashed fixed public paragraphs and help only, never notes. No audio, TTS, autoplay or activation.",
    "timer": "None. Real practice follows the agreed plan, not an app timer.",
    "completion": "No completion, attempted, success, mood, confidence or belief-change verdict."
  },
  "intro": {
    "id": "core-beliefs.intro",
    "title": "Make room for a fuller view of yourself",
    "paragraphs": [
      "A core belief is a broad idea about yourself that can feel deeply true. It may shape how you read many events. A mistake can seem to say something about your whole self, not just one moment.",
      "With your therapist, you can examine one belief and build a fairer view that fits more of your life. This takes more than saying a positive phrase. You do not have to make a belief change today."
    ]
  },
  "fit": {
    "id": "core-beliefs.fit",
    "title": "Before using your own belief",
    "paragraphs": [
      "Use one ordinary belief you and your therapist have already named and worked on together. Agree how to use these steps between sessions. If you have not done this yet, read the example or Learn more and take your questions to your therapist.",
      "This page is not for finding your deepest belief or going over a traumatic event. Do not use it to test your worth, your right to care, your identity, or whether you deserved harm. Real unfairness and unsafe conditions need to be taken seriously.",
      "Before trying a new action, agree the exact small plan, limits and review with your therapist. Keep needed care, aids and safety steps. Do not choose an action involving danger, abuse, harm, money or legal duties. Do not use this page to change food, medicine, sleep or substance use. Do not start an exposure exercise (facing a fear as treatment) here.",
      "You may pause, skip, use the example or stop. If you feel numb or far away, painful memories come up, or shame, upset or a drive to keep checking builds, leave the exercise and ask for support. This page cannot decide what is safe or suitable for you."
    ]
  },
  "privacy": {
    "id": "core-beliefs.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes to your therapist. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "core-beliefs.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "Reading, asking a question, leaving an answer open or stopping can all be enough for today. A planned action is not an action you have done. You do not have to leave with a new belief or a better feeling.",
      "You can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere."
    ]
  },
  "example": {
    "id": "core-beliefs.example",
    "title": "Kris looks at a broad belief about learning",
    "paragraphs": [
      "This is made up, not a plan to copy. Kris and their therapist have already worked on the broad belief \"I am incapable.\" It shows up in many ordinary tasks. It feels very strong after mistakes and less strong when Kris has time and support. When it shows up, Kris feels low and often quits a new task.",
      "They choose a possible fuller view: \"I have skills and limits. I can learn some things with time and support.\" Kris is not very sure of it yet. It does not mean being good at everything, and no task can decide what Kris is worth.",
      "The old belief seems to fit a recent event: Kris forgot two rules in a new card game. Looking closely, Kris had only heard the rules once. A missed rule shows a gap in learning that game, not a fact about every skill. Kris does not need to call the mistake a success.",
      "Other facts: Kris learned a phone setting after using written steps, and learned a different game with practice. These events fit the fuller view. Having help does not erase what Kris learned. They are not proof that every new task will be easy.",
      "Future evidence: Kris and the therapist choose to notice one ordinary time when practice or help supports learning. They also agree a small action: use the usual rule card to practise one part of the new game for up to five minutes. Kris can stop sooner and keep all usual aids.",
      "Beforehand, Kris expects: \"Even with the rule card, I will not learn any part.\" Another possible result is learning one move while still forgetting others. Kris and the therapist rehearse how to use the card and agree to review at the next session. No one needs to play against Kris.",
      "Actual result: Kris uses the card for three minutes, learns when to draw a card, and still mixes up one other move. Kris feels frustrated. The result does not fit learning nothing. It fits learning part with support, without proving future success.",
      "At the next session, Kris and the therapist review the facts. \"Incapable\" still feels strong, though a little less certain. The fuller view feels more possible. They keep the wording and agree that any next practice should stay small. No further practice has happened in this example.",
      "If Kris had not tried, there would be no action result. They could review the barrier or changed need. A hard result would need care and context, not a forced positive meaning or a judgment about Kris as a person."
    ]
  },
  "learn": {
    "id": "core-beliefs.learn",
    "title": "A broader belief, not just one thought",
    "paragraphs": [
      "A thought may be \"I forgot that rule.\" A personal rule may be \"I must learn fast.\" A core belief may be \"I am incapable.\" A core belief can colour many thoughts and rules. None of these labels proves a belief is wrong.",
      "A balanced belief takes in more facts, including strengths, limits, help and the setting. It is not praise you must agree with. You can hold it as a possibility while you and your therapist learn more.",
      "The practice has two parts: look fairly at what seems to support the old view, and give the fuller view a fair chance through real evidence and small agreed actions. Looking for new evidence does not mean hiding facts that are hard or unclear.",
      "A thought record looks closely at one situation. A positive-evidence log helps you notice things you may miss. These can support core-belief work, but do not replace its wider view and ongoing review.",
      "Therapists sometimes use a method called Downward Arrow to explore meanings. This page does not guide you to keep asking what a thought says about you. Finding or changing a painful belief needs paced work together, not an endless chain of questions.",
      "There is no required rate of change. A belief can feel different in different settings. If the exercise becomes an argument with yourself or repeated checking, stop and discuss the approach with your therapist."
    ]
  },
  "practice": [
    {
      "id": "core-beliefs.practice.belief",
      "title": "Name the belief you have already chosen",
      "paragraphs": [
        "Use the broad belief you and your therapist have already discussed. Keep its words as close as you can. You do not need to search for a deeper belief or explain where it came from.",
        "When does it feel strongest? When is it less strong? Notice the current setting, mood, support and real pressures. If useful, note how true it feels now in words or from zero to one hundred. You are rating a belief, not your worth.",
        "If useful, notice what you feel and tend to do when this belief shows up. You can describe this briefly without rating the feeling or going over a painful event."
      ],
      "fields": [
        {
          "key": "old-belief",
          "label": "The broad belief we chose",
          "optional": true
        },
        {
          "key": "belief-context",
          "label": "When it feels stronger or less strong",
          "optional": true
        },
        {
          "key": "old-rating",
          "label": "How true the old belief feels now, if useful",
          "optional": true
        },
        {
          "key": "feelings-response",
          "label": "Feelings and what I tend to do when the belief shows up",
          "optional": true
        }
      ],
      "help": {
        "title": "If you have not chosen a belief together",
        "text": "You do not need to turn an everyday worry into a belief about your whole self. Leave this blank and use the example. Bring the question to your therapist rather than digging for painful memories."
      }
    },
    {
      "id": "core-beliefs.practice.alternative",
      "title": "Try a fuller view as a possibility",
      "paragraphs": [
        "With your therapist, name a fairer view you could explore. Say what may be true about you, not only what you are not. Make room for strengths, limits, needs and support. It need not sound cheerful or certain.",
        "Is the wording believable enough to consider? If useful, note how true it feels now using the same kind of words or scale as before. You can revise it later. Do not force yourself to repeat words you cannot mean."
      ],
      "fields": [
        {
          "key": "balanced-belief",
          "label": "The fuller belief I want to explore",
          "optional": true
        },
        {
          "key": "new-rating",
          "label": "How true the fuller belief feels now, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If every alternative feels false",
        "text": "You can leave this as a question for your therapist. A smaller, less certain view may fit better. You do not have to claim that all people are safe, all things will work out, or that painful events did not happen."
      }
    },
    {
      "id": "core-beliefs.practice.evidence",
      "title": "Look closely at the old view",
      "paragraphs": [
        "Choose one or two ordinary facts you have already agreed to examine. What seems to support the old belief? Separate the event from the meaning you gave it. Use recent, manageable examples, not a search through painful history.",
        "What else matters in each event: chance, practice, illness, access, support, another person's choices or unfair treatment? What does the event show, and what does it not show about your whole self?",
        "Keep the facts, including mistakes or real limits. Look for a fair explanation, not an excuse or a positive spin. If this feels too hard or the event is unsafe or traumatic, leave it for supported work with your therapist."
      ],
      "fields": [
        {
          "key": "old-evidence",
          "label": "The specific ordinary events I want to examine",
          "optional": true
        },
        {
          "key": "fair-context",
          "label": "Other facts, context and fair limits to what they show",
          "optional": true
        }
      ],
      "help": {
        "title": "If you feel pulled to prove you are good enough",
        "text": "This is not a trial of your right to care or respect. A task, rating, mistake or another person's response cannot decide that. Pause rather than collecting a case against yourself."
      }
    },
    {
      "id": "core-beliefs.practice.support",
      "title": "Notice facts the fuller view includes",
      "paragraphs": [
        "What specific events fit the fuller view, even partly? Use ordinary examples you can recall without forcing a memory. They may include effort, learning, care, asking for help or coping with a limit. You do not need a big achievement.",
        "If you dismiss an event as \"only luck\" or \"only because I had help\", check whether that leaves out part of the facts. Name what support did and what you did. Do not take away real support or claim credit that is not yours.",
        "What does each event suggest about the fuller belief? What is still uncertain? You do not need equal lists for each belief, and no list proves your value as a person."
      ],
      "fields": [
        {
          "key": "new-evidence",
          "label": "Specific events that fit the fuller belief",
          "optional": true
        },
        {
          "key": "evidence-meaning",
          "label": "What these events suggest and what is still unknown",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot find an example",
        "text": "Leave it open. Not recalling evidence now is not proof that the old belief is true. You can ask your therapist to help you notice facts without making up an example or seeking repeated reassurance."
      }
    },
    {
      "id": "core-beliefs.practice.notice",
      "title": "Plan what to notice in daily life",
      "paragraphs": [
        "With your therapist, choose what ordinary event might give the fuller view a fair chance. For example, notice a time when support helped you learn one part of a task. Be specific about what you could see or describe.",
        "Agree a small limit for noticing or making a note, and when to review it. This is not a daily quota or a search for proof all day. Keep facts that are mixed or unclear too. If checking starts to take over, stop and review the plan."
      ],
      "fields": [
        {
          "key": "future-evidence",
          "label": "What real event I could notice",
          "optional": true
        },
        {
          "key": "notice-limits",
          "label": "Our limits for noticing and when to review",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing comes up",
        "text": "There may be no useful event before your review. You do not have to create one or make a list look full. Tell your therapist what happened and whether the plan fit your life."
      }
    },
    {
      "id": "core-beliefs.practice.plan",
      "title": "Set out one small action you agreed",
      "paragraphs": [
        "What small action would let you practise the fuller view? Use only the exact plan agreed with your therapist. Note what, where, when and how much if useful. An idea here is not approval to act.",
        "What does the old view predict about this action? What other result is possible? Choose an outcome you could observe, not a guess about someone's private thoughts or a test of your human worth.",
        "Keep needed care, support, aids and safety steps. Include barriers, when to stop, how to get help and when to review. If no plan is agreed, leave the action open and take the idea to your session."
      ],
      "fields": [
        {
          "key": "prediction",
          "label": "The specific prediction and another possible result",
          "optional": true
        },
        {
          "key": "agreed-action",
          "label": "The exact small action and limits we agreed",
          "optional": true
        },
        {
          "key": "observing-plan",
          "label": "What I could observe",
          "optional": true
        },
        {
          "key": "safeguards",
          "label": "Support, barriers, stopping and review arrangements",
          "optional": true
        }
      ],
      "help": {
        "title": "If the plan involves more risk than you expected",
        "text": "Do not make it harder, drop protections or use this page to approve it. Pause and check with your therapist. Health changes, exposure treatment, unsafe relationships and major commitments are outside this practice."
      }
    },
    {
      "id": "core-beliefs.practice.use",
      "title": "Rehearse, then use only the agreed plan",
      "paragraphs": [
        "If your therapist has asked you to rehearse, practise the first small step as agreed. This may be saying the fuller belief in your own words, showing how you will use an aid, or planning how to pause. A mental picture is not required.",
        "A real action happens in your life, not by pressing Next. Try it only if the plan still fits. You may stop, do part, or not try. Do not repeat it to force a good result or a lower rating.",
        "You can leave and return to Review my agreed practice later. Notes here are not saved when you leave or reload. Choose notes to keep first if you want a copy."
      ],
      "fields": [
        {
          "key": "rehearsal",
          "label": "What I rehearsed or need help to rehearse",
          "optional": true
        }
      ],
      "help": {
        "title": "If you did not try",
        "text": "There is no result from an action you did not take. You can still review a barrier, changed need or decision to stop. You do not need to catch up, invent learning or treat non-use as proof of the old belief."
      }
    },
    {
      "id": "core-beliefs.practice.review",
      "title": "Review what actually happened",
      "paragraphs": [
        "Use this after the agreed time, whether you noticed evidence, tried all or part of the action, or did neither. What actually happened? If nothing was tried, keep the action result open.",
        "Note what you saw, did or learned, including hard, mixed or unclear parts. Keep observations apart from guesses. If you can recall your original prediction, compare the facts with it. If not, leave the comparison open.",
        "What fits the old view? What fits the fuller view? What could have another explanation? Do not turn one event into a verdict about every setting or your whole self."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "What I tried, noticed, changed or did not try",
          "optional": true
        },
        {
          "key": "observations",
          "label": "The actual facts and what is unknown",
          "optional": true
        },
        {
          "key": "comparison",
          "label": "How the facts compare with the prediction and both beliefs",
          "optional": true
        }
      ],
      "help": {
        "title": "If something hurtful or unsafe happened",
        "text": "Take it seriously. Stop and seek the support you need. You do not have to explain it away or find a positive lesson. Review with your therapist before another action. Support and urgent help has help options."
      }
    },
    {
      "id": "core-beliefs.practice.beliefs",
      "title": "Check the wording and how it feels now",
      "paragraphs": [
        "After looking at the facts, how true does each belief feel now? If you rated them before, use the same words or scale if useful. You can skip ratings. The old view need not weaken, and the fuller view need not feel stronger.",
        "Does the fuller view need clearer words, a smaller claim or more room for a real limit? Keep changes as ideas to review with your therapist. Feeling different today does not prove what will happen tomorrow."
      ],
      "fields": [
        {
          "key": "beliefs-after",
          "label": "How true each belief feels now, if useful",
          "optional": true
        },
        {
          "key": "wording-review",
          "label": "Wording I might keep, revise or leave open",
          "optional": true
        }
      ],
      "help": {
        "title": "If you understand it but do not feel it",
        "text": "That difference can be worth discussing. You do not need to argue until the feeling changes. Tell your therapist what makes sense, what still feels hard and whether this way of working fits."
      }
    },
    {
      "id": "core-beliefs.practice.continue",
      "title": "Choose what to bring to your therapist",
      "paragraphs": [
        "Bring what you learned, what did not fit, any cost or distress, and questions you still have. Agree together whether to keep, change, pause or stop this work. This page does not set the next task.",
        "Over time, you may return to the fuller view and new evidence as agreed. There is no streak to keep or deadline for believing it. You can finish now without a new plan."
      ],
      "fields": [
        {
          "key": "therapy-review",
          "label": "What I want to review before any next practice",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want a copy for your session",
        "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide whether, when and how to share a copy."
      }
    }
  ],
  "sources": [
    {
      "id": "CCI: Developing Balanced Core Beliefs",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Improving-Self-Esteem/Improving-Self-Esteem---08---Developing-Balanced-Core-Beliefs.pdf",
      "supports": "Balanced alternative; contextual review of old evidence; evidence and actions supporting the new view; later belief review and ongoing practice.",
      "limits": "Adult-framed source, not validation of this digital adaptation or an all-age recommendation. Original text and example; no worksheet reproduced. No safety-behaviour removal, trauma example or promised belief change imported."
    },
    {
      "id": "Beck Institute: Negative Core Beliefs, Why They Become So Strong",
      "url": "https://beckinstitute.org/blog/negative-core-beliefs-why-they-become-so-strong/",
      "supports": "Broad belief activation, attention to confirming information and discounting contrary experience; supports noticing specific real-world evidence.",
      "limits": "Judith Beck professional teaching, not a trial of this page. Developmental history, diagnostic assumptions and source examples are not imported."
    },
    {
      "id": "Beck Institute: Another CT Myth, Put on Those Rose-Colored Glasses",
      "url": "https://beckinstitute.org/blog/another-ct-myth-put-on-those-rose-colored-glasses/",
      "supports": "Realistic appraisal and appropriate action rather than forced optimism; a negative account of a real situation can be accurate.",
      "limits": "Professional explanation, not validation or endorsement of this adaptation."
    },
    {
      "id": "Beck Institute: What Is the Status of Homework in CBT, 50 Years On?",
      "url": "https://beckinstitute.org/blog/what-is-the-status-of-homework-in-cognitive-behavior-therapy-50-years-on/",
      "supports": "Collaborative individual action plans, barriers and subjective difficulty; review engagement rather than demand perfect compliance.",
      "limits": "Professional account by Nikolaos Kazantzis. No medication examples, treatment-effect sizes or claim that this page is validated are imported."
    },
    {
      "id": "CCI: Copyright and Disclaimer",
      "url": "https://www.cci.health.wa.gov.au/Home/Utilities/Copyright-and-Disclaimer",
      "supports": "Source-use restrictions and the difference between educational materials and individualized clinical care.",
      "limits": "Public access does not grant permission to reproduce or publish original source materials. This candidate links to sources and uses independently authored text; rights review remains open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Use an already formulated broad belief and context-dependent conviction",
      "sections": [
        "practice.belief"
      ],
      "source": "CCI module 8 identification/ratings; therapist-first boundary is a conservative adaptation, not independent Downward Arrow"
    },
    {
      "operation": "Provisional credible fuller view before evidence work",
      "sections": [
        "practice.alternative"
      ],
      "source": "CCI module 8 section 2"
    },
    {
      "operation": "Examine apparent old evidence and alternative contextual meaning",
      "sections": [
        "practice.evidence"
      ],
      "source": "CCI module 8 section 3; this adaptation uses manageable ordinary examples, while deeper autobiographical exploration is outside its scope"
    },
    {
      "operation": "Specific existing and future evidence for the balanced view",
      "sections": [
        "practice.support",
        "practice.notice"
      ],
      "source": "CCI module 8 section 4; bounded noticing and no quota are safety adaptations"
    },
    {
      "operation": "Agreed action, rehearsal, actual observations and comparison",
      "sections": [
        "practice.plan",
        "practice.use",
        "practice.review"
      ],
      "source": "CCI module 8 section 4; Beck Institute Kazantzis on collaborative practice and barriers; bounded therapist agreement, explicit rehearsal and neutral actual/non-use review are product safety/fidelity adaptations"
    },
    {
      "operation": "Review both beliefs and continue as agreed",
      "sections": [
        "practice.beliefs",
        "practice.continue"
      ],
      "source": "CCI module 8 section 5 and ongoing process; no required rating direction or guaranteed improvement"
    }
  ],
  "narrationSegments": [
    {
      "id": "core-beliefs.intro",
      "title": "Make room for a fuller view of yourself",
      "text": "A core belief is a broad idea about yourself that can feel deeply true. It may shape how you read many events. A mistake can seem to say something about your whole self, not just one moment.\n\nWith your therapist, you can examine one belief and build a fairer view that fits more of your life. This takes more than saying a positive phrase. You do not have to make a belief change today.",
      "sha256": "2b49fb3a6838722c5b84973fdd2683b4b281c3f1bc95e40cdb81dc80b8f1408f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.fit",
      "title": "Before using your own belief",
      "text": "Use one ordinary belief you and your therapist have already named and worked on together. Agree how to use these steps between sessions. If you have not done this yet, read the example or Learn more and take your questions to your therapist.\n\nThis page is not for finding your deepest belief or going over a traumatic event. Do not use it to test your worth, your right to care, your identity, or whether you deserved harm. Real unfairness and unsafe conditions need to be taken seriously.\n\nBefore trying a new action, agree the exact small plan, limits and review with your therapist. Keep needed care, aids and safety steps. Do not choose an action involving danger, abuse, harm, money or legal duties. Do not use this page to change food, medicine, sleep or substance use. Do not start an exposure exercise (facing a fear as treatment) here.\n\nYou may pause, skip, use the example or stop. If you feel numb or far away, painful memories come up, or shame, upset or a drive to keep checking builds, leave the exercise and ask for support. This page cannot decide what is safe or suitable for you.",
      "sha256": "288094b667fa7ac87eef57bda44c25d65f3590c2cf3342e9627f988198da3235",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes to your therapist. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "07d2c4ba17eda8f147248a607190bd4efeca29909a9e9eebe4354280ef30d4ab",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.close",
      "title": "Leave the practice here",
      "text": "Reading, asking a question, leaving an answer open or stopping can all be enough for today. A planned action is not an action you have done. You do not have to leave with a new belief or a better feeling.\n\nYou can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere.",
      "sha256": "2c304215fd489bfea19a39b1343ee2ccfd547fb44b99eb9ec41cf5aae5a8bd59",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.example",
      "title": "Kris looks at a broad belief about learning",
      "text": "This is made up, not a plan to copy. Kris and their therapist have already worked on the broad belief \"I am incapable.\" It shows up in many ordinary tasks. It feels very strong after mistakes and less strong when Kris has time and support. When it shows up, Kris feels low and often quits a new task.\n\nThey choose a possible fuller view: \"I have skills and limits. I can learn some things with time and support.\" Kris is not very sure of it yet. It does not mean being good at everything, and no task can decide what Kris is worth.\n\nThe old belief seems to fit a recent event: Kris forgot two rules in a new card game. Looking closely, Kris had only heard the rules once. A missed rule shows a gap in learning that game, not a fact about every skill. Kris does not need to call the mistake a success.\n\nOther facts: Kris learned a phone setting after using written steps, and learned a different game with practice. These events fit the fuller view. Having help does not erase what Kris learned. They are not proof that every new task will be easy.\n\nFuture evidence: Kris and the therapist choose to notice one ordinary time when practice or help supports learning. They also agree a small action: use the usual rule card to practise one part of the new game for up to five minutes. Kris can stop sooner and keep all usual aids.\n\nBeforehand, Kris expects: \"Even with the rule card, I will not learn any part.\" Another possible result is learning one move while still forgetting others. Kris and the therapist rehearse how to use the card and agree to review at the next session. No one needs to play against Kris.\n\nActual result: Kris uses the card for three minutes, learns when to draw a card, and still mixes up one other move. Kris feels frustrated. The result does not fit learning nothing. It fits learning part with support, without proving future success.\n\nAt the next session, Kris and the therapist review the facts. \"Incapable\" still feels strong, though a little less certain. The fuller view feels more possible. They keep the wording and agree that any next practice should stay small. No further practice has happened in this example.\n\nIf Kris had not tried, there would be no action result. They could review the barrier or changed need. A hard result would need care and context, not a forced positive meaning or a judgment about Kris as a person.",
      "sha256": "7bf8db86a509a80edc6419e18fecdf7f567bef1b02f35809e1dc0442ccd19183",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.learn",
      "title": "A broader belief, not just one thought",
      "text": "A thought may be \"I forgot that rule.\" A personal rule may be \"I must learn fast.\" A core belief may be \"I am incapable.\" A core belief can colour many thoughts and rules. None of these labels proves a belief is wrong.\n\nA balanced belief takes in more facts, including strengths, limits, help and the setting. It is not praise you must agree with. You can hold it as a possibility while you and your therapist learn more.\n\nThe practice has two parts: look fairly at what seems to support the old view, and give the fuller view a fair chance through real evidence and small agreed actions. Looking for new evidence does not mean hiding facts that are hard or unclear.\n\nA thought record looks closely at one situation. A positive-evidence log helps you notice things you may miss. These can support core-belief work, but do not replace its wider view and ongoing review.\n\nTherapists sometimes use a method called Downward Arrow to explore meanings. This page does not guide you to keep asking what a thought says about you. Finding or changing a painful belief needs paced work together, not an endless chain of questions.\n\nThere is no required rate of change. A belief can feel different in different settings. If the exercise becomes an argument with yourself or repeated checking, stop and discuss the approach with your therapist.",
      "sha256": "3bc397b7e76792f8469488a5dcdad32986562734f529b092e4346ba628a30f89",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.belief",
      "title": "Name the belief you have already chosen",
      "text": "Use the broad belief you and your therapist have already discussed. Keep its words as close as you can. You do not need to search for a deeper belief or explain where it came from.\n\nWhen does it feel strongest? When is it less strong? Notice the current setting, mood, support and real pressures. If useful, note how true it feels now in words or from zero to one hundred. You are rating a belief, not your worth.\n\nIf useful, notice what you feel and tend to do when this belief shows up. You can describe this briefly without rating the feeling or going over a painful event.",
      "sha256": "459364cdcd425f709fdc58f4d7b3d1e0f8e292a6c1fec853bdc882693466fecc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.belief.help",
      "title": "If you have not chosen a belief together",
      "text": "You do not need to turn an everyday worry into a belief about your whole self. Leave this blank and use the example. Bring the question to your therapist rather than digging for painful memories.",
      "sha256": "df0738b5f44577471225661c2c2ecd063afb58e9bf8da100f73761ae6799cd9e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.alternative",
      "title": "Try a fuller view as a possibility",
      "text": "With your therapist, name a fairer view you could explore. Say what may be true about you, not only what you are not. Make room for strengths, limits, needs and support. It need not sound cheerful or certain.\n\nIs the wording believable enough to consider? If useful, note how true it feels now using the same kind of words or scale as before. You can revise it later. Do not force yourself to repeat words you cannot mean.",
      "sha256": "2017cc3246e5e9675a6cb7855714dd63948dbcd2e57ef54667dbc419b85c2976",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.alternative.help",
      "title": "If every alternative feels false",
      "text": "You can leave this as a question for your therapist. A smaller, less certain view may fit better. You do not have to claim that all people are safe, all things will work out, or that painful events did not happen.",
      "sha256": "368096483969dbb41a9fca4a675f3e419ec0dd3142d617b203616b30d0208120",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.evidence",
      "title": "Look closely at the old view",
      "text": "Choose one or two ordinary facts you have already agreed to examine. What seems to support the old belief? Separate the event from the meaning you gave it. Use recent, manageable examples, not a search through painful history.\n\nWhat else matters in each event: chance, practice, illness, access, support, another person's choices or unfair treatment? What does the event show, and what does it not show about your whole self?\n\nKeep the facts, including mistakes or real limits. Look for a fair explanation, not an excuse or a positive spin. If this feels too hard or the event is unsafe or traumatic, leave it for supported work with your therapist.",
      "sha256": "401e9344623bee6d193179b6f64bd3465594d7627f5c40fc586164d093ccaa22",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.evidence.help",
      "title": "If you feel pulled to prove you are good enough",
      "text": "This is not a trial of your right to care or respect. A task, rating, mistake or another person's response cannot decide that. Pause rather than collecting a case against yourself.",
      "sha256": "4fc12ab62c72d948dc3b65525c9d377ff7d785c5cfb4cacb4a74c4bd456cd7d8",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.support",
      "title": "Notice facts the fuller view includes",
      "text": "What specific events fit the fuller view, even partly? Use ordinary examples you can recall without forcing a memory. They may include effort, learning, care, asking for help or coping with a limit. You do not need a big achievement.\n\nIf you dismiss an event as \"only luck\" or \"only because I had help\", check whether that leaves out part of the facts. Name what support did and what you did. Do not take away real support or claim credit that is not yours.\n\nWhat does each event suggest about the fuller belief? What is still uncertain? You do not need equal lists for each belief, and no list proves your value as a person.",
      "sha256": "de5f8c9039e19442c38605f6fec7043f498b7ef16a4237d12fb58c82c8ea9687",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.support.help",
      "title": "If you cannot find an example",
      "text": "Leave it open. Not recalling evidence now is not proof that the old belief is true. You can ask your therapist to help you notice facts without making up an example or seeking repeated reassurance.",
      "sha256": "50d63e1cb49a2023d49515822954a36a73d3f29f437f0a1e47608c774f269fc9",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.notice",
      "title": "Plan what to notice in daily life",
      "text": "With your therapist, choose what ordinary event might give the fuller view a fair chance. For example, notice a time when support helped you learn one part of a task. Be specific about what you could see or describe.\n\nAgree a small limit for noticing or making a note, and when to review it. This is not a daily quota or a search for proof all day. Keep facts that are mixed or unclear too. If checking starts to take over, stop and review the plan.",
      "sha256": "8973685a8111685cc9f37ccb1ff319b6f64d63777163eeb431e48cdcf0e87560",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.notice.help",
      "title": "If nothing comes up",
      "text": "There may be no useful event before your review. You do not have to create one or make a list look full. Tell your therapist what happened and whether the plan fit your life.",
      "sha256": "180e09291d44008181fd5bf875733844ede590baae7c56601c8973e024b09e5a",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.plan",
      "title": "Set out one small action you agreed",
      "text": "What small action would let you practise the fuller view? Use only the exact plan agreed with your therapist. Note what, where, when and how much if useful. An idea here is not approval to act.\n\nWhat does the old view predict about this action? What other result is possible? Choose an outcome you could observe, not a guess about someone's private thoughts or a test of your human worth.\n\nKeep needed care, support, aids and safety steps. Include barriers, when to stop, how to get help and when to review. If no plan is agreed, leave the action open and take the idea to your session.",
      "sha256": "11ca94409de8384efc8c362cb14deaff960676e99da0d9ead5403cc7424d712e",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.plan.help",
      "title": "If the plan involves more risk than you expected",
      "text": "Do not make it harder, drop protections or use this page to approve it. Pause and check with your therapist. Health changes, exposure treatment, unsafe relationships and major commitments are outside this practice.",
      "sha256": "ad680ebdddb877427325f70ec6d3f8beea24f44c203f05590ebaf2f14791563e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.use",
      "title": "Rehearse, then use only the agreed plan",
      "text": "If your therapist has asked you to rehearse, practise the first small step as agreed. This may be saying the fuller belief in your own words, showing how you will use an aid, or planning how to pause. A mental picture is not required.\n\nA real action happens in your life, not by pressing Next. Try it only if the plan still fits. You may stop, do part, or not try. Do not repeat it to force a good result or a lower rating.\n\nYou can leave and return to Review my agreed practice later. Notes here are not saved when you leave or reload. Choose notes to keep first if you want a copy.",
      "sha256": "3de8294cc716e247055932c6453f19eb31576c22f496de76fa9f83c2b1e1c563",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.use.help",
      "title": "If you did not try",
      "text": "There is no result from an action you did not take. You can still review a barrier, changed need or decision to stop. You do not need to catch up, invent learning or treat non-use as proof of the old belief.",
      "sha256": "2be9b4ce8d3b96014c6b1d2943a8ec6a0d80fbf02746403e9255ea92418f6d21",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.review",
      "title": "Review what actually happened",
      "text": "Use this after the agreed time, whether you noticed evidence, tried all or part of the action, or did neither. What actually happened? If nothing was tried, keep the action result open.\n\nNote what you saw, did or learned, including hard, mixed or unclear parts. Keep observations apart from guesses. If you can recall your original prediction, compare the facts with it. If not, leave the comparison open.\n\nWhat fits the old view? What fits the fuller view? What could have another explanation? Do not turn one event into a verdict about every setting or your whole self.",
      "sha256": "dd2f25a42b97119a830eb3fc7487139764e9aa3f60bd8b57ef4a3bff9abcc06a",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.review.help",
      "title": "If something hurtful or unsafe happened",
      "text": "Take it seriously. Stop and seek the support you need. You do not have to explain it away or find a positive lesson. Review with your therapist before another action. Support and urgent help has help options.",
      "sha256": "198244b5e3fc10604b0a507e321ea98c5fcd09c79f531dcec5f5efe2d7fdce30",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.beliefs",
      "title": "Check the wording and how it feels now",
      "text": "After looking at the facts, how true does each belief feel now? If you rated them before, use the same words or scale if useful. You can skip ratings. The old view need not weaken, and the fuller view need not feel stronger.\n\nDoes the fuller view need clearer words, a smaller claim or more room for a real limit? Keep changes as ideas to review with your therapist. Feeling different today does not prove what will happen tomorrow.",
      "sha256": "90fd0fa65290411566e7687d3b826d60f9f4b4dc2c8de0d27f2947842c129699",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.beliefs.help",
      "title": "If you understand it but do not feel it",
      "text": "That difference can be worth discussing. You do not need to argue until the feeling changes. Tell your therapist what makes sense, what still feels hard and whether this way of working fits.",
      "sha256": "b6c31c2a74ef977e4067689359f5d3849222e225b0c775d1b7d965960b546f19",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "core-beliefs.practice.continue",
      "title": "Choose what to bring to your therapist",
      "text": "Bring what you learned, what did not fit, any cost or distress, and questions you still have. Agree together whether to keep, change, pause or stop this work. This page does not set the next task.\n\nOver time, you may return to the fuller view and new evidence as agreed. There is no streak to keep or deadline for believing it. You can finish now without a new plan.",
      "sha256": "ae30a967cf6d417b95fffcff32305ec1f56ba31a7b57a76faff222f79c125e63",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "core-beliefs.practice.continue.help",
      "title": "If you want a copy for your session",
      "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide whether, when and how to share a copy.",
      "sha256": "e557986e1bfe17ac12a3c648aa82826e08a121168d329ea5b44d9a466dd912b5",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
