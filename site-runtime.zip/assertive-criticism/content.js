window.AssertiveCriticismContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/assertive",
  "componentId": "component/assertive/criticism",
  "resourceId": "tool/assertive-criticism",
  "routeProposal": "/assertive-criticism/",
  "title": "Dealing with Criticism Assertively",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Practise receiving or giving ordinary feedback clearly and with respect, while keeping facts, choice and safety in view.",
  "groupedSetStatus": "Existing uncounted criticism component under Assertiveness Training, corresponding to DA18. Two distinct receiving/giving procedures in one component; not another DEAR MAN, GIVE, FAST or refusal resource. No new canonical count or full-workbook claim.",
  "clinicalContract": {
    "learningObjective": "Separate feedback about specific behaviour from a judgement of worth; choose a truthful response or give a specific, proportionate message without demanding agreement.",
    "practiceObjective": "Select a therapist-agreed ordinary situation; check beliefs and context; clarify and assess received feedback or prepare behaviour/impact/request; rehearse, choose whether real contact fits, review actual use/non-use and revise.",
    "sourcePopulationContext": "CCI clinician-produced self-help establishes the named procedure, not efficacy of this app or universal suitability. No age floor. Therapist checks developmental, communication, cultural, access, safeguarding and individual clinical fit; adult material is not automatically suitable for children.",
    "exclusions": [
      "No unsafe confrontation, abuse response, forced disclosure or contact",
      "No duty to accept false claims, humiliation or global labels",
      "No prediction that good words control another person or prevent retaliation",
      "No legal, employment, disciplinary, safeguarding or relationship-ending message drafting",
      "No compelled eye contact, calm, apology, thanks, positivity or repeated practice until comfortable",
      "No automatic communication, advice on others motives, clinical judgement or inferred success"
    ],
    "adaptations": [
      "Original text and two fictional examples; no CCI worksheet or source dialogue copied",
      "Receiving and giving paths keep their own notes and review; both are freely navigable",
      "Negative assertion/inquiry and optional fogging are taught in plain words, with source terminology in Learn",
      "Acknowledgement of a part, possibility or principle must be genuinely accurate or believed, never a concession to false accusation",
      "Consequences mean relevant actual effects or a proportionate action under own control, never threats or a claim to control the listener",
      "Contextual safety, optional communication forms and no-contact rehearsal take priority over performance"
    ],
    "reviewGates": [
      "Owner/clinician review of full bounded receiving/giving component, adaptation limits and rights",
      "Individual developmental, clinical, communication, cultural, safeguarding and access fit",
      "Human comprehension review; grade-five language is a target, not a validated reading level",
      "Integrated desktop/mobile/keyboard/screen-reader, focus, lifecycle and clipboard/download acceptance",
      "Authorized audio generation and exact-script listening/binding review before narration activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "receive",
      "give"
    ],
    "modeChoice": {
      "title": "Choose the kind of feedback practice",
      "options": [
        {
          "value": "receive",
          "label": "Receive feedback",
          "startSectionId": "assertive-criticism.receive.choose"
        },
        {
          "value": "give",
          "label": "Give feedback",
          "startSectionId": "assertive-criticism.give.choose"
        }
      ]
    },
    "entryGate": "Scope and safety visible before either path; examples, learning, Finish and support available without writing.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish; no required sequence or writing.",
    "reviewAccess": "Choose a path and jump straight to its blank Review group. No stored plan, contact or attempted flag required.",
    "writing": "Optional and hidden initially. Each path has separate fields; fiction never fills answers. Hiding removes private echoes and invalidates export.",
    "persistence": "Open-page memory only. Internal reading and path changes retain their separate notes; clear/restart/leaving/reload/history/BFCache clear; offscreen visibility alone retains.",
    "export": "No default selection. Only literal selected notes from the current path. Edits, hiding, stage/path changes invalidate export. No script assembled or sent.",
    "narration": "Exact static public text/help only. No audio, TTS, recording upload, autoplay or personal-note narration.",
    "timer": "None. No contact reminders or rehearsal dose.",
    "completion": "No inferred rehearsal, message, conversation, agreement, improvement or emotional change."
  },
  "intro": {
    "id": "assertive-criticism.intro",
    "title": "Keep the message separate from your worth",
    "paragraphs": [
      "Feedback can point to a useful change. It can also be unclear, mistaken or hurtful. You can consider what is true without accepting every claim or letting someone judge your whole worth.",
      "This practice has two paths. Receiving feedback means checking a message and choosing a response. Giving feedback means describing one behaviour, its effect and a fair request, then making room for a reply. Neither path can make another person agree."
    ]
  },
  "fit": {
    "id": "assertive-criticism.fit",
    "title": "Choose an ordinary, suitable situation",
    "paragraphs": [
      "Use this after your therapist has taught the skill and checked a suitable situation with you. Start with ordinary feedback, not a major accusation, formal complaint, disciplinary issue or decision about ending a relationship.",
      "If there is abuse, bullying, threats, coercion or a risk of retaliation, do not use this page as a test of standing up for yourself. Power, culture, money, care and dependence can change what is safe. Plan with appropriate support instead. Direct contact may not be the right choice.",
      "You may use a made-up example or practise privately without contacting anyone. You can pause, leave or seek help. No one has to disclose personal history, agree with an insult, keep listening, forgive, or force a calm feeling.",
      "Choose a form of communication that fits you. Speaking, writing, signing, a communication aid or a safe agreed supporter may help. Eye contact, a certain tone, smiling and quick replies are not tests of respect. A supporter must not take over your choice."
    ]
  },
  "privacy": {
    "id": "assertive-criticism.privacy",
    "title": "Keep only the notes you choose",
    "paragraphs": [
      "You can think, speak privately, use paper or add optional notes. This tool does not record your voice, send a message or contact the other person or your therapist.",
      "Receiving and giving notes stay separate in this open page. Switching paths, reading an example or opening help keeps them here. Leaving, reloading, clearing or starting again removes them. To keep anything, choose notes from the current path, check the preview, then copy or download.",
      "Leave out names, private accusations or details you do not need. A device, screen reader or person with access to a copy may read it. Skill narration never reads your notes. Copies outside this tool remain until you remove them. The session shortcut works only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "assertive-criticism.close",
    "title": "Finish without proving anything",
    "paragraphs": [
      "A draft, private rehearsal and real conversation are different. You can finish at any point, including without making contact or filling a field. The page does not decide whether you were right or whether the conversation worked.",
      "Keep chosen notes if useful, or let them clear. Finish and clear removes notes here, not copies elsewhere. You choose what to discuss with your therapist."
    ]
  },
  "learn": {
    "id": "assertive-criticism.learn",
    "title": "Assertiveness keeps both truth and choice",
    "paragraphs": [
      "Assertiveness means being clear about your view while respecting other people. It does not mean winning, pleasing everyone or tolerating harm. Listening is not agreement; disagreeing is not automatically aggression.",
      "When receiving feedback, acknowledging a real mistake without attacking yourself is sometimes called negative assertion. Asking for a concrete example is sometimes called negative inquiry. The word negative does not mean you must put yourself down or invite more insults.",
      "Fogging is a name for acknowledging a true part, a real possibility or a general point you actually agree with, while not accepting a broader accusation. For example, a person may prefer clearer labels without you agreeing that your whole project is careless. Do not say something is possible or true just to appease someone. You can disagree, defer or stop instead.",
      "When giving feedback, describe a specific action, say its effect and ask for a realistic change. Listen for information you may have missed. A consequence is an actual effect or your own proportionate next step, not a threat or a way to force agreement.",
      "DEAR MAN supports requests and refusals; GIVE and FAST attend to relationships and self-respect. This component adds checking received feedback and giving behaviour-focused feedback. It is an original CCI-informed adaptation, not the entire Assert Yourself workbook, a conflict-safety assessment or a tested standalone treatment."
    ]
  },
  "examples": [
    {
      "id": "assertive-criticism.example.receive",
      "title": "Mika checks feedback about a game guide",
      "paragraphs": [
        "This is made up, not a script to copy. Mika and a friend are trying a home-made board game. The friend says the guide is confusing. Mika feels stung and thinks, \"That means I did a bad job.\" In therapy, Mika has practised separating one unclear part from the whole effort.",
        "In private rehearsal Mika tries asking which part was hard to use. At the later game, Mika asks, \"Which part was hard to follow?\" The friend points to two steps that do not say who moves first. Mika checks and says, \"I left out who starts. I can add that line.\"",
        "Mika asks, \"Would that make the order clear?\" Mika does not agree that the whole guide is bad. The friend then says the colours are dull. Mika replies, \"I like these colours. We see that differently.\" Different tastes do not need a verdict.",
        "Mika adds the agreed order line later but still feels awkward about the conversation. In review, Mika separates the rehearsal, the real exchange and the edit. Next time Mika may ask to discuss one issue at a time; that idea has not yet been tried."
      ],
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.example.give",
      "title": "Rae asks for a change to a shared art table",
      "paragraphs": [
        "This is made up. Rae and a friend share an art table by agreement. Rae has found wet brushes on the paper area twice. Rae wants usable space, not to prove the friend is careless. The therapist has checked this ordinary example and helped Rae practise a brief message.",
        "Rae privately rehearses describing the wet brushes, the effect on paper and a request to leave them in the rinse cup. Rae also tries listening to a possible reply. This is not yet a conversation with the friend.",
        "At a suitable time Rae asks whether they can talk about the table. Rae says, \"Twice this week wet brushes were on the paper area. The paper got damp. Could you leave the brushes in the rinse cup?\" The friend says the cup was hard to reach and suggests moving it. Rae listens, checks the space and agrees to try that change. Rae does not claim to know why the brushes were left there.",
        "Only this exchange and moving the cup have happened. Rae has not yet seen whether the brushes stay off the paper. In review Rae notes feeling tense and wanting to explain too much. The next observation will be whether the new place works, not whether Rae can make the friend approve."
      ],
      "branch": "give"
    }
  ],
  "practice": [
    {
      "id": "assertive-criticism.receive.choose",
      "title": "Choose one message to work with",
      "paragraphs": [
        "Pick an ordinary message your therapist has helped you choose, or use the made-up example. What was said about a specific action? A short summary is enough; do not copy abuse or painful details.",
        "Notice a thought that makes it hard to respond, such as \"One mistake means I am useless\" or \"I must prove every point.\" Check whether that thought fits the facts. What fairer view leaves room for learning and self-respect? You can bring an unresolved thought to therapy."
      ],
      "fields": [
        {
          "key": "r-situation",
          "label": "The ordinary message and setting",
          "optional": true
        },
        {
          "key": "r-thinking",
          "label": "A thought to check and a fairer view or question",
          "optional": true
        }
      ],
      "help": {
        "title": "If the setting is not safe",
        "text": "You do not have to practise replying. Seek suitable support and plan around safety, power and privacy. Skillful words cannot guarantee safety or make you responsible for another person’s conduct."
      },
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.receive.sort",
      "title": "Separate accuracy from how it was said",
      "paragraphs": [
        "What specific behaviour is the person talking about? What do you know, and what is still unclear? Feedback may be accurate, partly accurate, mistaken, a matter of taste, or not yet checkable.",
        "Notice the delivery separately. A useful point can be expressed harshly; a polite claim can be wrong. A true detail does not justify an insult or mean you are a bad person. You may address the point later without staying in a harmful exchange."
      ],
      "fields": [
        {
          "key": "r-facts",
          "label": "The specific point, facts and unknowns",
          "optional": true
        },
        {
          "key": "r-delivery",
          "label": "Delivery, limits and support to consider",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot tell whether it is fair",
        "text": "You can take time to check or discuss it with your therapist. The page cannot decide who is right. Do not seek endless proof or agree just to stop uncertainty."
      },
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.receive.clarify",
      "title": "Ask for detail only if it helps",
      "paragraphs": [
        "If the message is vague and it is suitable to ask, try one question about the action or example. You might ask which part needs a change or what the person observed. Aim to understand, not to cross-examine.",
        "Listen to the reply and check you understood. You can ask for time to think. If the reply is another insult or pressure, you do not have to keep asking, defend yourself at length or stay in the conversation."
      ],
      "fields": [
        {
          "key": "r-question",
          "label": "A useful question, or why not to ask",
          "optional": true
        },
        {
          "key": "r-check",
          "label": "How I could check understanding or take time",
          "optional": true
        }
      ],
      "help": {
        "title": "If the detail is already clear",
        "text": "You can move to choosing a response. Asking a question is an option, not a required step or an invitation for someone to list everything they dislike."
      },
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.receive.respond",
      "title": "Choose a truthful response",
      "paragraphs": [
        "If a specific point is true, acknowledge it without a global label. You may own a mistake, offer a fitting apology or discuss a change. Accountability does not require blaming yourself for things you did not do.",
        "If only part is true, name that part without accepting the rest. You may acknowledge a genuine possibility or a general point you believe. Be clear about the limit: agreement on one detail is not agreement with an accusation. These are options, not tricks to manage an aggressive person.",
        "Here are made-up examples, not required answers. A true part: \"The title is small; I do not agree the whole guide is careless.\" A real possibility: \"I may have missed a step; I want to check.\" A principle you believe: \"Clear labels matter. I want to look at this label before deciding.\" None requires you to accept the wider claim.",
        "If you disagree, state your view briefly and respectfully. If it is a preference, you may name the difference. If you need to check, say you need time. A boundary, no response or supported follow-up may fit better than a debate."
      ],
      "fields": [
        {
          "key": "r-response",
          "label": "The response that fits the facts and my limits",
          "optional": true
        },
        {
          "key": "r-change",
          "label": "Any change, repair, boundary or question I choose",
          "optional": true
        }
      ],
      "help": {
        "title": "If a possible response feels false",
        "text": "Do not rehearse it as your answer. Change it, ask for help or leave it undecided. You do not owe agreement, an apology or a promise in order to sound assertive."
      },
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.receive.rehearse",
      "title": "Try the words privately",
      "paragraphs": [
        "Try your response in a form that works for you. You can say it quietly, use an aid, write it or rehearse with your therapist. Keep it brief enough to use while preserving what you mean.",
        "Try one likely reply, such as useful detail, disagreement or no answer. How could you check, pause or end the exchange? Rehearsal need not include insults, vivid imagery or creating distress. Notice what you actually tried and revise if useful."
      ],
      "fields": [
        {
          "key": "r-rehearsal",
          "label": "What I actually rehearsed, or did not try",
          "optional": true
        },
        {
          "key": "r-adjustment",
          "label": "A change to words, format or support",
          "optional": true
        }
      ],
      "help": {
        "title": "If rehearsal becomes painful or pressured",
        "text": "Stop or use a more neutral example with support. You do not need to feel calm, sound confident or keep repeating until it feels right."
      },
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.receive.use",
      "title": "Choose whether a real reply fits",
      "paragraphs": [
        "With your therapist, decide whether to use this response, wait, seek help or make no contact. If you choose to reply, consider a suitable time, place and communication form, and how to pause or leave.",
        "Check the real setting again. A plan is not a duty to continue if something changes. You cannot control the reply. Keep needed safety steps and support; urgent help should not wait for this exercise."
      ],
      "fields": [
        {
          "key": "r-plan",
          "label": "The agreed choice, timing and support",
          "optional": true
        },
        {
          "key": "r-limit",
          "label": "What would mean pausing or not replying",
          "optional": true
        }
      ],
      "help": {
        "title": "If you finish with no contact planned",
        "text": "That is a valid choice. Keep a question for your therapist if wanted. Finishing this page sends nothing and does not count as replying."
      },
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.receive.review",
      "title": "Review a reply, rehearsal or no use",
      "paragraphs": [
        "What actually happened: thinking, private rehearsal, a reply, or no use? Keep these separate. If there was no real reply, there is no conversation result to fill in.",
        "If you replied, what was said or done, and what remains unknown? Did your response fit the facts and your needs? Include helpful, awkward, neutral or unwanted effects. Agreement or relief is not required.",
        "With your therapist, choose what to keep, change or stop. New facts, pressure or access problems may call for a different plan. Do not record a proposed next step as something already done."
      ],
      "fields": [
        {
          "key": "r-actual",
          "label": "What actually happened or did not happen",
          "optional": true
        },
        {
          "key": "r-observed",
          "label": "What I noticed, including limits and unknowns",
          "optional": true
        },
        {
          "key": "r-next",
          "label": "What to keep, change, stop or discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If the other person reacted badly",
        "text": "Their reaction alone does not prove you did the skill wrong. Prioritize safety and support. Review context without blaming yourself or assuming that better wording can prevent harm."
      },
      "branch": "receive"
    },
    {
      "id": "assertive-criticism.give.choose",
      "title": "Choose one useful purpose",
      "paragraphs": [
        "Choose an ordinary situation your therapist has checked with you, or use the made-up example. What practical change or shared understanding would help? This is not a way to rate someone’s character or get even.",
        "Notice a thought such as \"They must agree\" or \"Any request will ruin things.\" What do the facts support? A fairer view can allow a clear request and a different answer. If the issue is high-stakes or unsafe, plan with support rather than drafting it here."
      ],
      "fields": [
        {
          "key": "g-situation",
          "label": "The ordinary situation and useful purpose",
          "optional": true
        },
        {
          "key": "g-thinking",
          "label": "A thought to check and a fairer view or question",
          "optional": true
        }
      ],
      "help": {
        "title": "If the purpose is to make someone feel bad",
        "text": "Pause. You may need space or help before deciding what to communicate. Clear feedback describes a concern; it does not punish a person or demand that they feel guilty."
      },
      "branch": "give"
    },
    {
      "id": "assertive-criticism.give.describe",
      "title": "Describe the action and its effect",
      "paragraphs": [
        "Choose one specific action you observed. Keep the time or setting clear enough to understand. Leave out labels, guessed motives and claims about what someone always does.",
        "Say what effect the action had and, if useful, how you felt. Own your view. A feeling is real, but it is not proof of the other person’s motive. Do not add praise you do not mean just to make the message acceptable."
      ],
      "fields": [
        {
          "key": "g-observation",
          "label": "The specific action I observed",
          "optional": true
        },
        {
          "key": "g-effect",
          "label": "Its effect and any feeling I choose to name",
          "optional": true
        }
      ],
      "help": {
        "title": "If you only have second-hand information",
        "text": "Keep that uncertainty clear and seek suitable support before making a claim. This tool does not investigate allegations or prepare a formal complaint."
      },
      "branch": "give"
    },
    {
      "id": "assertive-criticism.give.request",
      "title": "Ask for a realistic change",
      "paragraphs": [
        "What specific, possible change are you asking for? Ask about behaviour, not a different personality. Keep it proportionate and open to information about the other person’s needs or limits.",
        "If useful, explain a real effect of the change or a boundary about your own actions. Do not threaten, invent a consequence, offer a false promise or say you can control what they do. You do not have to include a consequence if none is needed."
      ],
      "fields": [
        {
          "key": "g-request",
          "label": "The specific change I would like to ask for",
          "optional": true
        },
        {
          "key": "g-boundary",
          "label": "Any relevant effect or my own proportionate boundary",
          "optional": true
        }
      ],
      "help": {
        "title": "If you cannot think of a fair request",
        "text": "Pause and clarify the purpose with your therapist. You may only need to describe an effect, ask a question or decide on your own next step. Do not create a demand just to finish the form."
      },
      "branch": "give"
    },
    {
      "id": "assertive-criticism.give.exchange",
      "title": "Leave room for a reply",
      "paragraphs": [
        "Consider a suitable, private-enough time and place. If it fits, ask whether now works. Avoid springing feedback on someone in front of others or when they cannot attend. Privacy and timing do not remove a power imbalance.",
        "After the brief message, invite their view and listen. Check what you heard. You may learn a fact, access need or different view. Look for a workable change if both want one; neither person has to agree to a demand.",
        "A warm ending is optional and should be honest. You can close with what was agreed, what needs thought, or a pause. There is no need to add false praise or keep talking until the answer changes."
      ],
      "fields": [
        {
          "key": "g-opening",
          "label": "A suitable time, setting and opening",
          "optional": true
        },
        {
          "key": "g-listening",
          "label": "How I could invite and check a reply",
          "optional": true
        }
      ],
      "help": {
        "title": "If the reply is defensive or there is no agreement",
        "text": "You can restate the specific point once if useful, listen, take time or end the exchange. Do not use repeated requests to wear someone down. Seek support if power or safety is a concern."
      },
      "branch": "give"
    },
    {
      "id": "assertive-criticism.give.rehearse",
      "title": "Practise the message and listening",
      "paragraphs": [
        "Try your description, effect and request in a form that fits you. Include a pause for a reply, rather than rehearsing a speech that must be finished. Practise with your therapist or privately; do not contact someone just to complete this step.",
        "Try a possible reply with new information or disagreement. Check whether you can listen, revise a mistaken detail or keep a needed limit. Note what you really rehearsed, then shorten or change the message if useful."
      ],
      "fields": [
        {
          "key": "g-rehearsal",
          "label": "What I actually rehearsed, or did not try",
          "optional": true
        },
        {
          "key": "g-adjustment",
          "label": "A change to words, listening, format or support",
          "optional": true
        }
      ],
      "help": {
        "title": "If speaking is not the right form",
        "text": "A written message, signing, communication aid or supported practice may fit. A rehearsed message is not permission to send it. You decide about real use with your therapist."
      },
      "branch": "give"
    },
    {
      "id": "assertive-criticism.give.use",
      "title": "Choose real use, waiting or no contact",
      "paragraphs": [
        "Check with your therapist whether real use fits. If so, agree how, when and where, with the support and limits you need. Recheck that the facts and setting still fit before you begin.",
        "You may postpone, seek help or choose no contact. If an exchange becomes harmful, do not keep applying a script to prove you can be assertive. Actual use happens outside these buttons, and this page sends nothing."
      ],
      "fields": [
        {
          "key": "g-plan",
          "label": "The agreed choice, timing and support",
          "optional": true
        },
        {
          "key": "g-limit",
          "label": "What would mean pausing or not giving feedback",
          "optional": true
        }
      ],
      "help": {
        "title": "If you need a formal or high-impact message",
        "text": "Take it to the appropriate qualified person or support service. This practice is for ordinary feedback, not legal advice, a disciplinary process or a serious accusation."
      },
      "branch": "give"
    },
    {
      "id": "assertive-criticism.give.review",
      "title": "Review what happened, not what you hoped",
      "paragraphs": [
        "Was this a draft, rehearsal, real exchange or no use? What actually happened? Separate the words you used, the other person’s reply and any later change. Do not assume a request led to change.",
        "What was useful, unclear, difficult or unwanted? What did you learn about facts, timing, access or listening? Include a neutral result or disagreement. Feeling tense does not by itself mean the practice failed.",
        "With your therapist, choose whether to keep, revise or stop the plan. If you owe a real correction or repair, consider it without taking responsibility for everything. A future plan is not an action already taken."
      ],
      "fields": [
        {
          "key": "g-actual",
          "label": "What actually happened or did not happen",
          "optional": true
        },
        {
          "key": "g-observed",
          "label": "What I noticed, including limits and unknowns",
          "optional": true
        },
        {
          "key": "g-next",
          "label": "What to keep, change, stop or discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If feedback made the situation worse",
        "text": "Prioritize support and safety. Review the context, not just the wording. You may need a different approach or no further contact; repeating the message is not automatically the next step."
      },
      "branch": "give"
    }
  ],
  "sources": [
    {
      "id": "CCI: Assert Yourself, Module 7",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Consumer%20Modules/Assert%20Yourself/Assert%20Yourself%20-%2007%20%20-%20Dealing%20With%20Criticism%20Assertively.pdf",
      "supports": "Printed pp2–10 distinguish criticism, thinking and receiving-response options; pp11–12 teach giving behaviour-focused feedback. Both named variants inform this original component.",
      "limits": "Not the complete workbook or a fidelity/effectiveness certification. No source worksheet, examples or script copied. This adaptation rejects compulsory agreement, claims to remove distress or defuse aggressive people, false concessions, mandatory positivity and coercive consequences."
    },
    {
      "id": "CCI: Assert Yourself, Module 10",
      "url": "https://cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Assert-Yourself/Assert-Yourself---10---Putting-it-All-Together.pdf",
      "supports": "Printed pp2–5 link thought/behaviour preparation, rehearsal, actual practice and review within learning assertiveness.",
      "limits": "No self-directed hierarchy, escalating challenges, mandatory repetition or comfort criterion is imported. Therapist introduction and fit remain necessary; no isolated-app efficacy claim."
    },
    {
      "id": "ASHA and National Joint Committee: Communication Bill of Rights",
      "url": "https://www.asha.org/njc/communication-bill-of-rights/",
      "supports": "Meaningful communication access, choice, refusal and forms of support inform the access safeguards.",
      "limits": "Rights guidance, not evidence for this criticism intervention or universal clinical suitability."
    },
    {
      "id": "CCI: Copyright and Disclaimer",
      "url": "https://www.cci.health.wa.gov.au/Home/Utilities/Copyright-and-Disclaimer",
      "supports": "Source-use terms and limits on publication/reproduction.",
      "limits": "Public access and attribution do not grant release rights. No permission requested or granted; rights review remains open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Context, thoughts and a fairer view",
      "sections": [
        "receive.choose",
        "receive.sort",
        "give.choose"
      ],
      "source": "CCI07 pp2–5; concrete context/power safeguards are explicit adaptations"
    },
    {
      "operation": "Receiving: clarification, assertion, inquiry and optional accurate fogging",
      "sections": [
        "receive.clarify",
        "receive.respond",
        "learn"
      ],
      "source": "CCI07 pp6–10; only genuinely believed part/possibility/principle acknowledged; no appeasement or aggression-management guarantee"
    },
    {
      "operation": "Giving: specific behaviour, effect, request, consequences and reply",
      "sections": [
        "give.describe",
        "give.request",
        "give.exchange"
      ],
      "source": "CCI07 pp11–12; consequences bounded to real effects/own proportionate actions; no required praise"
    },
    {
      "operation": "Rehearsal, actual-use choice and review",
      "sections": [
        "receive.rehearse",
        "receive.use",
        "receive.review",
        "give.rehearse",
        "give.use",
        "give.review"
      ],
      "source": "CCI10 pp2–5; no mandated contact, escalating hierarchy or comfort endpoint"
    },
    {
      "operation": "Access, privacy and literal state",
      "sections": [
        "fit",
        "privacy"
      ],
      "source": "ASHA/NJC rights and conservative product safeguards; not a validated safety/access assessment"
    }
  ],
  "narrationSegments": [
    {
      "id": "assertive-criticism.intro",
      "title": "Keep the message separate from your worth",
      "text": "Feedback can point to a useful change. It can also be unclear, mistaken or hurtful. You can consider what is true without accepting every claim or letting someone judge your whole worth.\n\nThis practice has two paths. Receiving feedback means checking a message and choosing a response. Giving feedback means describing one behaviour, its effect and a fair request, then making room for a reply. Neither path can make another person agree.",
      "sha256": "11941a1eceb1469982be9d5865611d7e262b257d7c951fe850870b964e5b0e7b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.fit",
      "title": "Choose an ordinary, suitable situation",
      "text": "Use this after your therapist has taught the skill and checked a suitable situation with you. Start with ordinary feedback, not a major accusation, formal complaint, disciplinary issue or decision about ending a relationship.\n\nIf there is abuse, bullying, threats, coercion or a risk of retaliation, do not use this page as a test of standing up for yourself. Power, culture, money, care and dependence can change what is safe. Plan with appropriate support instead. Direct contact may not be the right choice.\n\nYou may use a made-up example or practise privately without contacting anyone. You can pause, leave or seek help. No one has to disclose personal history, agree with an insult, keep listening, forgive, or force a calm feeling.\n\nChoose a form of communication that fits you. Speaking, writing, signing, a communication aid or a safe agreed supporter may help. Eye contact, a certain tone, smiling and quick replies are not tests of respect. A supporter must not take over your choice.",
      "sha256": "06d52908296efb2b537eb8d4d2a4bf8125aa51e7f4e23bf57ec09da38693beca",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.privacy",
      "title": "Keep only the notes you choose",
      "text": "You can think, speak privately, use paper or add optional notes. This tool does not record your voice, send a message or contact the other person or your therapist.\n\nReceiving and giving notes stay separate in this open page. Switching paths, reading an example or opening help keeps them here. Leaving, reloading, clearing or starting again removes them. To keep anything, choose notes from the current path, check the preview, then copy or download.\n\nLeave out names, private accusations or details you do not need. A device, screen reader or person with access to a copy may read it. Skill narration never reads your notes. Copies outside this tool remain until you remove them. The session shortcut works only in this open page and saves no answers.",
      "sha256": "452c037596e8f059a4ea0a41c601c8f614329162eb4b47f25db8b7d9a600bbcf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.close",
      "title": "Finish without proving anything",
      "text": "A draft, private rehearsal and real conversation are different. You can finish at any point, including without making contact or filling a field. The page does not decide whether you were right or whether the conversation worked.\n\nKeep chosen notes if useful, or let them clear. Finish and clear removes notes here, not copies elsewhere. You choose what to discuss with your therapist.",
      "sha256": "35452ec91c1f370082bac4b2a6ee20b2bcf404252173d031fed4816c77eb157b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.learn",
      "title": "Assertiveness keeps both truth and choice",
      "text": "Assertiveness means being clear about your view while respecting other people. It does not mean winning, pleasing everyone or tolerating harm. Listening is not agreement; disagreeing is not automatically aggression.\n\nWhen receiving feedback, acknowledging a real mistake without attacking yourself is sometimes called negative assertion. Asking for a concrete example is sometimes called negative inquiry. The word negative does not mean you must put yourself down or invite more insults.\n\nFogging is a name for acknowledging a true part, a real possibility or a general point you actually agree with, while not accepting a broader accusation. For example, a person may prefer clearer labels without you agreeing that your whole project is careless. Do not say something is possible or true just to appease someone. You can disagree, defer or stop instead.\n\nWhen giving feedback, describe a specific action, say its effect and ask for a realistic change. Listen for information you may have missed. A consequence is an actual effect or your own proportionate next step, not a threat or a way to force agreement.\n\nDEAR MAN supports requests and refusals; GIVE and FAST attend to relationships and self-respect. This component adds checking received feedback and giving behaviour-focused feedback. It is an original CCI-informed adaptation, not the entire Assert Yourself workbook, a conflict-safety assessment or a tested standalone treatment.",
      "sha256": "73c8c9cf73379e94a6632fdc8989b2ba1a544744ce991ba63cba9b718539f8da",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.example.receive",
      "title": "Mika checks feedback about a game guide",
      "text": "This is made up, not a script to copy. Mika and a friend are trying a home-made board game. The friend says the guide is confusing. Mika feels stung and thinks, \"That means I did a bad job.\" In therapy, Mika has practised separating one unclear part from the whole effort.\n\nIn private rehearsal Mika tries asking which part was hard to use. At the later game, Mika asks, \"Which part was hard to follow?\" The friend points to two steps that do not say who moves first. Mika checks and says, \"I left out who starts. I can add that line.\"\n\nMika asks, \"Would that make the order clear?\" Mika does not agree that the whole guide is bad. The friend then says the colours are dull. Mika replies, \"I like these colours. We see that differently.\" Different tastes do not need a verdict.\n\nMika adds the agreed order line later but still feels awkward about the conversation. In review, Mika separates the rehearsal, the real exchange and the edit. Next time Mika may ask to discuss one issue at a time; that idea has not yet been tried.",
      "sha256": "096edf21f10fdd845786fc9eb99b0b4544f287e54cd7bf42d5ae8916fe138ca8",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.example.give",
      "title": "Rae asks for a change to a shared art table",
      "text": "This is made up. Rae and a friend share an art table by agreement. Rae has found wet brushes on the paper area twice. Rae wants usable space, not to prove the friend is careless. The therapist has checked this ordinary example and helped Rae practise a brief message.\n\nRae privately rehearses describing the wet brushes, the effect on paper and a request to leave them in the rinse cup. Rae also tries listening to a possible reply. This is not yet a conversation with the friend.\n\nAt a suitable time Rae asks whether they can talk about the table. Rae says, \"Twice this week wet brushes were on the paper area. The paper got damp. Could you leave the brushes in the rinse cup?\" The friend says the cup was hard to reach and suggests moving it. Rae listens, checks the space and agrees to try that change. Rae does not claim to know why the brushes were left there.\n\nOnly this exchange and moving the cup have happened. Rae has not yet seen whether the brushes stay off the paper. In review Rae notes feeling tense and wanting to explain too much. The next observation will be whether the new place works, not whether Rae can make the friend approve.",
      "sha256": "5ff67b321067bb1319a50585188c7c8893c0746e32187b3dbe3955bc91a28aa1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.choose",
      "title": "Choose one message to work with",
      "text": "Pick an ordinary message your therapist has helped you choose, or use the made-up example. What was said about a specific action? A short summary is enough; do not copy abuse or painful details.\n\nNotice a thought that makes it hard to respond, such as \"One mistake means I am useless\" or \"I must prove every point.\" Check whether that thought fits the facts. What fairer view leaves room for learning and self-respect? You can bring an unresolved thought to therapy.",
      "sha256": "33862bea98024a92dc7902c5021dff367222d146c46de5b48e80af82dcb9059b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.choose.help",
      "title": "If the setting is not safe",
      "text": "You do not have to practise replying. Seek suitable support and plan around safety, power and privacy. Skillful words cannot guarantee safety or make you responsible for another person’s conduct.",
      "sha256": "100ce04b00a6c0a3bd807a8f2dd5c1a119140f0bbb5c27f36d8afff8076d43b0",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.receive.sort",
      "title": "Separate accuracy from how it was said",
      "text": "What specific behaviour is the person talking about? What do you know, and what is still unclear? Feedback may be accurate, partly accurate, mistaken, a matter of taste, or not yet checkable.\n\nNotice the delivery separately. A useful point can be expressed harshly; a polite claim can be wrong. A true detail does not justify an insult or mean you are a bad person. You may address the point later without staying in a harmful exchange.",
      "sha256": "a7ab85e1f84b270defc733717142239b46b76c7f4661ceb1d2ff95c6470d6e14",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.sort.help",
      "title": "If you cannot tell whether it is fair",
      "text": "You can take time to check or discuss it with your therapist. The page cannot decide who is right. Do not seek endless proof or agree just to stop uncertainty.",
      "sha256": "a8c8f0f2cfebafa99f21cc524fb432ebebe2f1842477a18c33b73ac1f4924a43",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.receive.clarify",
      "title": "Ask for detail only if it helps",
      "text": "If the message is vague and it is suitable to ask, try one question about the action or example. You might ask which part needs a change or what the person observed. Aim to understand, not to cross-examine.\n\nListen to the reply and check you understood. You can ask for time to think. If the reply is another insult or pressure, you do not have to keep asking, defend yourself at length or stay in the conversation.",
      "sha256": "c88f0f12549a2ac49df41edf02892feef0476fe49c9d39c8072c7dbef9caf1bd",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.clarify.help",
      "title": "If the detail is already clear",
      "text": "You can move to choosing a response. Asking a question is an option, not a required step or an invitation for someone to list everything they dislike.",
      "sha256": "ec31d04d0a33b32f4e89f521ad96a9c1ea9e0a3338f4b5a8e1ee06dae9d58325",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.receive.respond",
      "title": "Choose a truthful response",
      "text": "If a specific point is true, acknowledge it without a global label. You may own a mistake, offer a fitting apology or discuss a change. Accountability does not require blaming yourself for things you did not do.\n\nIf only part is true, name that part without accepting the rest. You may acknowledge a genuine possibility or a general point you believe. Be clear about the limit: agreement on one detail is not agreement with an accusation. These are options, not tricks to manage an aggressive person.\n\nHere are made-up examples, not required answers. A true part: \"The title is small; I do not agree the whole guide is careless.\" A real possibility: \"I may have missed a step; I want to check.\" A principle you believe: \"Clear labels matter. I want to look at this label before deciding.\" None requires you to accept the wider claim.\n\nIf you disagree, state your view briefly and respectfully. If it is a preference, you may name the difference. If you need to check, say you need time. A boundary, no response or supported follow-up may fit better than a debate.",
      "sha256": "b9d0591cb389e434fa57282cb199cccf0928a8fc8023f1bbc935839957ccbe58",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.respond.help",
      "title": "If a possible response feels false",
      "text": "Do not rehearse it as your answer. Change it, ask for help or leave it undecided. You do not owe agreement, an apology or a promise in order to sound assertive.",
      "sha256": "4e54be2ba04601cdea70814ad5bec28088ab9d639989f69f494e23a760389d3b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.receive.rehearse",
      "title": "Try the words privately",
      "text": "Try your response in a form that works for you. You can say it quietly, use an aid, write it or rehearse with your therapist. Keep it brief enough to use while preserving what you mean.\n\nTry one likely reply, such as useful detail, disagreement or no answer. How could you check, pause or end the exchange? Rehearsal need not include insults, vivid imagery or creating distress. Notice what you actually tried and revise if useful.",
      "sha256": "7221f17c685c7d2fb5b425aca4ab3e57d13aab7e80b34f178c558ee008a266c1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.rehearse.help",
      "title": "If rehearsal becomes painful or pressured",
      "text": "Stop or use a more neutral example with support. You do not need to feel calm, sound confident or keep repeating until it feels right.",
      "sha256": "9050c7872780af006fd893073e2ce97725c6705e619fd33d8e8215a85906fb68",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.receive.use",
      "title": "Choose whether a real reply fits",
      "text": "With your therapist, decide whether to use this response, wait, seek help or make no contact. If you choose to reply, consider a suitable time, place and communication form, and how to pause or leave.\n\nCheck the real setting again. A plan is not a duty to continue if something changes. You cannot control the reply. Keep needed safety steps and support; urgent help should not wait for this exercise.",
      "sha256": "212e30219d5c920c933a2516b519ddbd68c28ebd0cd56ef7db4e3425060a5741",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.use.help",
      "title": "If you finish with no contact planned",
      "text": "That is a valid choice. Keep a question for your therapist if wanted. Finishing this page sends nothing and does not count as replying.",
      "sha256": "08957d9517758b1b57e6e7e388850490a51cdeb5101b442bae22d5644dcff295",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.receive.review",
      "title": "Review a reply, rehearsal or no use",
      "text": "What actually happened: thinking, private rehearsal, a reply, or no use? Keep these separate. If there was no real reply, there is no conversation result to fill in.\n\nIf you replied, what was said or done, and what remains unknown? Did your response fit the facts and your needs? Include helpful, awkward, neutral or unwanted effects. Agreement or relief is not required.\n\nWith your therapist, choose what to keep, change or stop. New facts, pressure or access problems may call for a different plan. Do not record a proposed next step as something already done.",
      "sha256": "53fa736174c42db6fa86c1e9c3a359d501c44a7e40ab719bf675430a4df9da73",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.receive.review.help",
      "title": "If the other person reacted badly",
      "text": "Their reaction alone does not prove you did the skill wrong. Prioritize safety and support. Review context without blaming yourself or assuming that better wording can prevent harm.",
      "sha256": "9e2e3ee3e1a5ba2b56992153af3043dd898a5ddf2ebac8ee52f0120446676340",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.give.choose",
      "title": "Choose one useful purpose",
      "text": "Choose an ordinary situation your therapist has checked with you, or use the made-up example. What practical change or shared understanding would help? This is not a way to rate someone’s character or get even.\n\nNotice a thought such as \"They must agree\" or \"Any request will ruin things.\" What do the facts support? A fairer view can allow a clear request and a different answer. If the issue is high-stakes or unsafe, plan with support rather than drafting it here.",
      "sha256": "99dfe1cb56776a96538a34abc67a0fe2b844325b76fcd1c8e6d2da7541b386c1",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.give.choose.help",
      "title": "If the purpose is to make someone feel bad",
      "text": "Pause. You may need space or help before deciding what to communicate. Clear feedback describes a concern; it does not punish a person or demand that they feel guilty.",
      "sha256": "32c771e708c78f2282f8d8437f805e108e5559c7c0e3e894236c51f72d88ac2b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.give.describe",
      "title": "Describe the action and its effect",
      "text": "Choose one specific action you observed. Keep the time or setting clear enough to understand. Leave out labels, guessed motives and claims about what someone always does.\n\nSay what effect the action had and, if useful, how you felt. Own your view. A feeling is real, but it is not proof of the other person’s motive. Do not add praise you do not mean just to make the message acceptable.",
      "sha256": "707ad6ce3f28b370423aea3842bc50da96638fe2db6f236faa30bdf0ed8bd1e7",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.give.describe.help",
      "title": "If you only have second-hand information",
      "text": "Keep that uncertainty clear and seek suitable support before making a claim. This tool does not investigate allegations or prepare a formal complaint.",
      "sha256": "40326a40c709b53489c986dc46f1d9af9ee0da3393e55e758fc9c0104c2f664b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.give.request",
      "title": "Ask for a realistic change",
      "text": "What specific, possible change are you asking for? Ask about behaviour, not a different personality. Keep it proportionate and open to information about the other person’s needs or limits.\n\nIf useful, explain a real effect of the change or a boundary about your own actions. Do not threaten, invent a consequence, offer a false promise or say you can control what they do. You do not have to include a consequence if none is needed.",
      "sha256": "8f325c9a60282228ab29c7457245a750d4bf6b1a9cd7fa3e56c899d26166634c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.give.request.help",
      "title": "If you cannot think of a fair request",
      "text": "Pause and clarify the purpose with your therapist. You may only need to describe an effect, ask a question or decide on your own next step. Do not create a demand just to finish the form.",
      "sha256": "f25c6816e2194775a7ceb3836a1da9e9a997d8b82fef9bb7a589d1c9c988448e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.give.exchange",
      "title": "Leave room for a reply",
      "text": "Consider a suitable, private-enough time and place. If it fits, ask whether now works. Avoid springing feedback on someone in front of others or when they cannot attend. Privacy and timing do not remove a power imbalance.\n\nAfter the brief message, invite their view and listen. Check what you heard. You may learn a fact, access need or different view. Look for a workable change if both want one; neither person has to agree to a demand.\n\nA warm ending is optional and should be honest. You can close with what was agreed, what needs thought, or a pause. There is no need to add false praise or keep talking until the answer changes.",
      "sha256": "275062eab56afba3d308cd4f56ab6fc072aa9cf9b915626db0889b0295261b99",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.give.exchange.help",
      "title": "If the reply is defensive or there is no agreement",
      "text": "You can restate the specific point once if useful, listen, take time or end the exchange. Do not use repeated requests to wear someone down. Seek support if power or safety is a concern.",
      "sha256": "981b1f0248825c8aeea4910b63797c20501ae3f9ed1889f8d3af985537eae5ad",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.give.rehearse",
      "title": "Practise the message and listening",
      "text": "Try your description, effect and request in a form that fits you. Include a pause for a reply, rather than rehearsing a speech that must be finished. Practise with your therapist or privately; do not contact someone just to complete this step.\n\nTry a possible reply with new information or disagreement. Check whether you can listen, revise a mistaken detail or keep a needed limit. Note what you really rehearsed, then shorten or change the message if useful.",
      "sha256": "544ade3e591cf3d15064a6772968c85514d6d4691296186696654f368b6defdf",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.give.rehearse.help",
      "title": "If speaking is not the right form",
      "text": "A written message, signing, communication aid or supported practice may fit. A rehearsed message is not permission to send it. You decide about real use with your therapist.",
      "sha256": "230b1eb0fd308284baf968e4c055d577a9d459fd272953ed1c9b793e317d81e4",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.give.use",
      "title": "Choose real use, waiting or no contact",
      "text": "Check with your therapist whether real use fits. If so, agree how, when and where, with the support and limits you need. Recheck that the facts and setting still fit before you begin.\n\nYou may postpone, seek help or choose no contact. If an exchange becomes harmful, do not keep applying a script to prove you can be assertive. Actual use happens outside these buttons, and this page sends nothing.",
      "sha256": "514b8bd1eabf4bd27703b66f5d8f0fc7630e050cd2b542d1a5a118a046d840a6",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.give.use.help",
      "title": "If you need a formal or high-impact message",
      "text": "Take it to the appropriate qualified person or support service. This practice is for ordinary feedback, not legal advice, a disciplinary process or a serious accusation.",
      "sha256": "03e25c4d9b1c1aa268949bfa18092082ad7f36d6eb4fe016f24ce0e568f7a092",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "assertive-criticism.give.review",
      "title": "Review what happened, not what you hoped",
      "text": "Was this a draft, rehearsal, real exchange or no use? What actually happened? Separate the words you used, the other person’s reply and any later change. Do not assume a request led to change.\n\nWhat was useful, unclear, difficult or unwanted? What did you learn about facts, timing, access or listening? Include a neutral result or disagreement. Feeling tense does not by itself mean the practice failed.\n\nWith your therapist, choose whether to keep, revise or stop the plan. If you owe a real correction or repair, consider it without taking responsibility for everything. A future plan is not an action already taken.",
      "sha256": "7622f756fa243cd558d6aada6e7d518766fc2966f682d43e45381dd6730968a4",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "assertive-criticism.give.review.help",
      "title": "If feedback made the situation worse",
      "text": "Prioritize support and safety. Review the context, not just the wording. You may need a different approach or no further contact; repeating the message is not automatically the next step.",
      "sha256": "2ece3f48107cb8ada06243261a7ec2660f562882c7b6ece998ab0698784f32ed",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
