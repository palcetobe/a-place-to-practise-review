window.CompassionDiaryContent = {
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/compassion",
  "componentId": "component/compassion/thought-diary",
  "resourceId": "tool/compassionate-thought-diary",
  "routeProposal": "/compassionate-thought-diary/",
  "title": "Compassionate Thought Diary",
  "version": "2026-11-04-isolated-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Use one manageable moment to practise a truthful, caring response with your therapist's guidance.",
  "groupedSetStatus": "Thought Diary component of existing classic/compassion only. Preserve Compassionate Letter as a distinct format. This is not Compassionate Imagery, the complete self-compassionate-behaviour component, a full CFT/MSC programme or a complete grouped-set acceptance claim. No new canonical count.",
  "clinicalContract": {
    "learningObjective": "Notice self-critical content and tone, feelings and responses; deliberately take a caring, realistic stance, form a credible compassionate conclusion and review actual use without requiring relief.",
    "practiceObjective": "Make one structured entry for a therapist-agreed ordinary difficulty: event, criticism, effects, tolerable compassionate stance, perspective/context, support, conclusion, actual reading/rehearsal and neutral review.",
    "sourcePopulationContext": "CCI adult-framed teaching and Neff author-origin exercises establish related methods, not validation of this isolated adaptation. No blanket age floor and no universal age-suitability claim. Individual clinical, developmental, safeguarding, cultural, communication, access and health needs require review.",
    "exclusions": [
      "No compelled warmth, praise, self-love, reassurance, forgiveness or acceptance of harm",
      "No required imagery, caregiver/safe-place memory, touch, closed eyes or breathing change",
      "No trauma reliving, historical search, escalating self-critical interrogation or rehearsing insults",
      "No changing health care, food, medication, sleep or substance use through this page",
      "No claim that thoughts alone cause distress, that injustice is a thinking error or that worth depends on action"
    ],
    "adaptations": [
      "Original diary text and fictional example; no source worksheet or letter template reproduced",
      "CCI diary structure adapted with non-imagery compassionate intention; this is not the exact CCI preparation sequence",
      "Neff mindful acknowledgement, human context and kindness provide related non-imagery principles, not validation of equivalence",
      "One ordinary manageable moment, therapist introduction, optional notes/ratings and limited self-critical detail",
      "Neutral respect can be more tolerable than warmth; actual reading/rehearsal remains distinct from planning",
      "All no-use, unchanged, mixed or adverse responses valid; no automatic verdict",
      "In-memory notes only, explicit selected export, no saved diary/account/reminders/therapist report"
    ],
    "reviewGates": [
      "Owner/clinician and rights review of the adapted diary, example and grouped-set boundaries",
      "Individual clinical, developmental, safeguarding and access fit",
      "Novice comprehension review; grade-five language is a target, not a validated reading level",
      "Real integrated desktop/mobile/keyboard/screen-reader and lifecycle/navigation acceptance",
      "Authorized narration generation, exact-script listening, binding and controls review before activation"
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "modes": [
      "plan",
      "review"
    ],
    "modeChoice": {
      "title": "Use the diary in the way you agreed with your therapist",
      "options": [
        {
          "value": "plan",
          "label": "Make one diary entry",
          "startSectionId": "compassionate-thought-diary.practice.moment"
        },
        {
          "value": "review",
          "label": "Review an entry I tried",
          "startSectionId": "compassionate-thought-diary.practice.review"
        }
      ]
    },
    "entryGate": "Visible therapist-introduced scope before an explicit mode choice. Not screening or proof of individual suitability. Example, Learn, Finish and support remain available without a mode.",
    "focus": "One meaningful group, free jump, Show all, Previous and Finish. No required writing or completion lock.",
    "reviewAccess": "Direct blank review does not require a previous entry or claim that practice occurred. Both modes expose all prompts.",
    "writing": "Optional and hidden initially. Fiction never fills notes. Hiding removes private displays and invalidates exports.",
    "persistence": "In-memory open-page notes only. Internal readings/navigation retain them; clear, restart, leaving/reloading, history navigation and BFCache return clear them. Offscreen visibility alone retains them.",
    "export": "No default note selection. Explicit selection yields exact preview/copy/download; edit, hide, mode/stage change and fresh selection invalidate it.",
    "narration": "Hashed fixed public paragraphs and help only, never notes. No media files, TTS, autoplay or activation.",
    "timer": "None. No daily quota, scheduled reminders or required repetition.",
    "completion": "No inferred attempt, completed diary, self-compassion score, mood improvement or belief-change verdict."
  },
  "intro": {
    "id": "compassionate-thought-diary.intro",
    "title": "Respond to a hard moment with care",
    "paragraphs": [
      "Self-criticism can add harsh words to a hard moment. A compassionate thought diary helps you notice that response and try a different one: truthful, caring and useful to you.",
      "You make one short entry, rather than a letter or a whole life story. You can write, think, speak privately or use paper. Private rehearsal is welcome, but this page does not create a saved diary. Feeling warm or calm is not required."
    ]
  },
  "fit": {
    "id": "compassionate-thought-diary.fit",
    "title": "Choose a moment that fits",
    "paragraphs": [
      "Use this after your therapist has introduced the skill and helped you check its fit. Choose one recent, ordinary difficulty you have agreed is manageable. You can read the example without using your own life.",
      "Do not choose your most painful memory or use this page to go over trauma. You do not need to imagine a caregiver, feel safe in a special place, change your breathing, close your eyes or touch your body.",
      "Care does not mean forgiving someone, excusing harm, ignoring unfairness or giving up a boundary. Do not use this page to change food, medicine, sleep, substance use or other health care. Keep needed aids and support.",
      "If kindness feels threatening, plain respect may fit better. If shame, grief or distress grows, painful memories come up, you feel numb or far away, or you keep checking for the right feeling, pause or stop and seek support. You do not have to finish first."
    ]
  },
  "privacy": {
    "id": "compassionate-thought-diary.privacy",
    "title": "Your choice to write or keep notes",
    "paragraphs": [
      "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.",
      "Leaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.",
      "This page does not send notes to your therapist or save a diary over time. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers."
    ]
  },
  "close": {
    "id": "compassionate-thought-diary.close",
    "title": "You can leave the entry here",
    "paragraphs": [
      "You may finish with an entry, a few words, a question, or no writing. Reading the example is not the same as trying the diary. You do not need a better mood or a finished task to receive care.",
      "You can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere."
    ]
  },
  "example": {
    "id": "compassionate-thought-diary.example",
    "title": "Tess spots a mistake on a handmade card",
    "paragraphs": [
      "This is made up, not a response you need to copy. Tess and their therapist have chosen small everyday mistakes for this practice. Tess sees a spelling mistake on a birthday card they made and thinks, \"I ruin everything.\" The words feel harsh and very convincing.",
      "Tess feels embarrassed and frustrated. Their hands feel tense, and they want to throw the card away. The mistake is real. The diary does not need to deny it or say what the friend will think.",
      "Before seeking new words, Tess chooses the aim: \"I want to help with this mistake without adding insults.\" There is no need to picture a kind person or make a warm feeling happen.",
      "Perspective: One word is wrong. Tess spent time on the drawing and message. Mistakes can be part of making things, but that does not mean Tess must like this one. The whole card, and Tess as a person, are more than that word.",
      "Care: Tess could take a short pause before choosing what to do. Covering the word with a small label may be an option. Repair is a choice, not a price for being treated with respect. Tess has not fixed the card yet.",
      "Tess reads these caring notes once. \"It is only a tiny mistake\" sounds dismissive, so Tess leaves that out. The conclusion becomes: \"This matters to me, and one wrong word is not everything. I can pause and decide how to handle the card without insulting myself.\" Tess tries reading it in a plain, steady tone.",
      "Review: Tess did try the words. Frustration is still strong. \"I ruin everything\" feels less convincing, but Tess does not feel warm. The steady tone is easier to use than forced praise. Tess decides to bring that difference to the therapist. No further action has happened in this example.",
      "If Tess had only planned the words, there would be no reading attempt to review yet. If the words had increased distress, Tess could stop and ask for help rather than repeat them until they worked."
    ]
  },
  "learn": {
    "id": "compassionate-thought-diary.learn",
    "title": "What makes this a compassionate diary?",
    "paragraphs": [
      "The diary notices what happened, what the critic said and how you responded. Then you deliberately turn toward care, look at the situation more fully and try a short caring conclusion. You review the words and tone, not just whether you feel better.",
      "Care is more than proving a thought wrong. It takes pain seriously and asks what would help. It can include an honest limit, support, responsibility, repair or saying no. It is not permission for harm or a promise that things will work out.",
      "Thoughts, feelings, the body, past learning and real conditions can affect one another. Distress is not proof that you are thinking badly. You do not need to debate away poverty, prejudice, illness or unsafe treatment.",
      "A letter joins ideas into a message to yourself. This diary keeps a structured record of one moment and your response. Neither format must work for everyone. A brief Friend Test or a thought record may help, but does not provide the whole diary process.",
      "Some compassion methods use imagery or breathing. This adapted diary uses a caring intention and allows plain, respectful words without those methods. It is not a full course of compassion-focused therapy or a daily routine you must keep.",
      "You can repeat the practice only in the way agreed with your therapist. There is no streak, quota or deadline for self-kindness. If repeating becomes another demand or a search for certainty, pause and review the fit."
    ]
  },
  "practice": [
    {
      "id": "compassionate-thought-diary.practice.moment",
      "title": "Name one manageable moment",
      "paragraphs": [
        "Choose the ordinary situation you agreed to work on. What happened, in a few plain words? Keep the event separate from a verdict about yourself. You do not need names or a full history.",
        "Is it manageable enough to stay with today? If not, use the fictional example, choose a different agreed moment or stop. This page cannot choose a safe subject for you."
      ],
      "fields": [
        {
          "key": "moment",
          "label": "The ordinary moment I chose",
          "optional": true
        }
      ],
      "help": {
        "title": "If there is no clear event",
        "text": "You can note a current everyday worry you have already agreed to explore, without predicting the outcome. You do not need to search for a painful memory or find a hidden reason."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.critic",
      "title": "Notice the message and its tone",
      "paragraphs": [
        "What critical message showed up? Name one short phrase or describe its theme. You do not need to copy insults in full, list every thought or read them aloud.",
        "How does the tone come across: harsh, rushed, cold or something else? If useful, note how convincing the message feels in words or from zero to one hundred. This rates the thought's pull, not your worth."
      ],
      "fields": [
        {
          "key": "critical-message",
          "label": "The message or theme, only as much as useful",
          "optional": true
        },
        {
          "key": "critical-tone",
          "label": "How the critical tone comes across",
          "optional": true
        },
        {
          "key": "belief-before",
          "label": "How convincing the message feels, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If describing the critic makes it louder",
        "text": "You can use a plain label such as \"harsh blame\" instead of its words. Do not rehearse the attack or argue with it. Leave this part or stop if it increases distress."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.effects",
      "title": "Notice how you are affected",
      "paragraphs": [
        "What feelings are here? If useful, choose the main one and describe how strong it is, in words or with a number. You do not need a score to continue.",
        "You may briefly notice what your body is already showing, what you did, or what you feel pulled to do. No body scan is needed. The event and your needs matter too; thoughts are not the only cause of distress."
      ],
      "fields": [
        {
          "key": "feelings-before",
          "label": "Feelings and the main feeling's strength, if useful",
          "optional": true
        },
        {
          "key": "body-response",
          "label": "Body signs or actions I already notice, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If body attention does not fit",
        "text": "Skip body signs and stay with feelings, actions or the event. You do not need to change your breathing, test a sensation or make yourself calm before continuing."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.stance",
      "title": "Choose an intention to help, not attack",
      "paragraphs": [
        "Before looking for new words, choose how you want to approach this moment. Could the aim be to understand the difficulty and offer useful care, rather than punish yourself?",
        "You might use plain respect: \"I want to deal with this without adding harm.\" Use your own wording or just hold the intention. No special voice, image, posture or feeling is required."
      ],
      "fields": [
        {
          "key": "caring-stance",
          "label": "A way of approaching this that feels tolerable",
          "optional": true
        }
      ],
      "help": {
        "title": "If care or kindness feels uncomfortable",
        "text": "You can start with fairness or less harshness, read the example, or pause. You do not have to invent a loving person or push through shame, grief, threat or numbness. Discuss the fit with your therapist."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.perspective",
      "title": "Make room for a caring, realistic view",
      "paragraphs": [
        "What would a respectful response notice about the difficulty? Include the facts, what matters to you, effort, limits, needs and real conditions. Acknowledge a specific mistake if there is one, without making it your whole identity.",
        "If it helps, consider what you would offer someone facing similar facts, or what a fair response from outside the situation could say. You do not need to picture a person. You can also speak directly in your own voice.",
        "Can you place the struggle in a wider human context without brushing it off? People can have limits and need care. Your circumstances are still your own. You do not need to say \"everyone does this\" or that others have it worse."
      ],
      "fields": [
        {
          "key": "caring-perspective",
          "label": "Facts and context a caring response would include",
          "optional": true
        },
        {
          "key": "human-context",
          "label": "A wider view that does not dismiss my situation, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you are tempted to force a positive view",
        "text": "Stay with words you could mean. You do not need to say the problem is small, the future is safe or someone meant well. Real harm may call for a boundary, practical help or protection."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.care",
      "title": "Consider what would help now",
      "paragraphs": [
        "What need can you take seriously here? A caring response might offer understanding, a pause, support, a boundary, practical help or a fair repair. You can leave the action undecided.",
        "If you choose a next step, keep it small, safe and within your existing care plan. You do not earn kindness by completing it. This page does not ask you to contact someone, forgive them or make a promise."
      ],
      "fields": [
        {
          "key": "care-need",
          "label": "A need or form of support that matters",
          "optional": true
        },
        {
          "key": "possible-step",
          "label": "A possible caring step, or why I want to leave it open",
          "optional": true
        }
      ],
      "help": {
        "title": "If responsibility matters here",
        "text": "Care can include owning a specific action and considering repair. It does not require blame for another person's choices, punishment, unsafe contact or a promise never to make a mistake."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.conclusion",
      "title": "Read the caring ideas and try a conclusion",
      "paragraphs": [
        "If you made caring notes, read those ideas once, not the harsh messages. Use Show all prompts or go back to your caring perspective and support notes. Paper or private words are fine too. Check that the tone offers help rather than a hidden demand.",
        "Bring the useful parts into one or two sentences in your own words. Let them acknowledge the difficulty, offer a fair view and leave room for care. They do not need to promise relief or solve everything.",
        "If you want, try reading or privately saying the conclusion once in a tolerable, respectful tone. Neutral is fine. You may change it, leave it unfinished or stop. Planning words and actually trying them are different."
      ],
      "fields": [
        {
          "key": "conclusion",
          "label": "My caring conclusion, if I want one",
          "optional": true
        },
        {
          "key": "tone-plan",
          "label": "A tone or wording I want to try or change",
          "optional": true
        }
      ],
      "help": {
        "title": "If the words are kind but the tone is harsh",
        "text": "You can make the words plainer or drop a hidden \"should\". Do not keep repeating until a feeling changes. It is also okay to stop and bring the unfinished entry to your therapist."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.review",
      "title": "Review the attempt without a target feeling",
      "paragraphs": [
        "Did you actually read or privately try the caring words, do part, only plan them, or not try? There is no required attempt. If you only read the example, say so or leave your own result blank.",
        "How did the words and tone fit? Notice what was useful, awkward, unchanged or upsetting. You do not need to feel warm, calm or grateful.",
        "If useful, return to the same critical message and main feeling you noted earlier. How convincing is that message now? How strong is that feeling? Use the same words or scale if you remember it, or skip this. Neither rating needs to go down."
      ],
      "fields": [
        {
          "key": "actual-use",
          "label": "What I actually read, tried, planned or did not try",
          "optional": true
        },
        {
          "key": "fit-review",
          "label": "How the words and tone fitted, including any difficulty",
          "optional": true
        },
        {
          "key": "belief-after",
          "label": "How convincing the original critical message feels now, if useful",
          "optional": true
        },
        {
          "key": "feeling-after",
          "label": "The original main feeling's strength now, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "If you feel worse or cannot find caring words",
        "text": "Stop rather than treating that as another failure. Ask for support and discuss the response with your therapist. This format may need changes or may not fit now. Support and urgent help has help options."
      }
    },
    {
      "id": "compassionate-thought-diary.practice.next",
      "title": "Choose what to keep or bring to your session",
      "paragraphs": [
        "You can keep a phrase, change it, leave it open or decide not to use this format again until you have discussed it. If you chose a caring action, it remains a plan until you actually do it.",
        "Bring your questions, any discomfort and what made the response easier or harder to your therapist. Agree any next practice together. You can finish without another entry or action."
      ],
      "fields": [
        {
          "key": "therapy-review",
          "label": "What I want to keep, change or discuss",
          "optional": true
        }
      ],
      "help": {
        "title": "If you want a record",
        "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy. The tool keeps no diary after you leave."
      }
    }
  ],
  "sources": [
    {
      "id": "CCI: Self-Compassionate Thinking, Module 5",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Building-Self-Compassion/Building-Self-Compassion---05---Self-Compassionate-Thinking.pdf",
      "supports": "Printed pages 3–7 distinguish diary event/criticism/tone/effects, compassionate perspective, care, rereading/conclusion and later belief/emotion review; pages 8–9 distinguish the letter format.",
      "limits": "CCI explicitly uses slow breathing and compassionate imagery preparation. This original non-imagery adaptation omits those requirements and compulsory feelings/ratings; it is not the exact source sequence or validated equivalent. No source worksheet or example reproduced."
    },
    {
      "id": "Kristin Neff: Self-Compassion Journal",
      "url": "https://self-compassion.org/exercises/exercise-6-self-compassion-journal/",
      "supports": "Related author-origin writing practice using mindful acknowledgement, wider human context and self-kindness without an imagery/breathing prerequisite.",
      "limits": "A related journal method, not the same as the CCI diary. Its daily schedule, example and promises of benefit are not imported. Original wording here; no efficacy or endorsement claim."
    },
    {
      "id": "Neff and Germer: The Role of Self-Compassion in Psychotherapy (2022)",
      "url": "https://doi.org/10.1002/wps.20925",
      "supports": "Clinical commentary on individual customization, distress that compassion can evoke and careful pacing to avoid overwhelming clients.",
      "limits": "Broad psychotherapy context, not a trial of this diary, a validated stop-rule list or evidence of an age threshold. Distress is not presented as proof of healing."
    },
    {
      "id": "Self-Compassion LLC: Terms and Conditions",
      "url": "https://self-compassion.org/terms-and-conditions/",
      "supports": "Rights restrictions on the author-origin site materials; free viewing is not an open reproduction license.",
      "limits": "No original exercise, template or source text is reproduced. Website-access terms are not clinical evidence of an age limit for this independently authored diary. Rights review remains open."
    },
    {
      "id": "CCI: Copyright and Disclaimer",
      "url": "https://www.cci.health.wa.gov.au/Home/Utilities/Copyright-and-Disclaimer",
      "supports": "Source-use restrictions and distinction between educational material and individual clinical care.",
      "limits": "Public access is not permission to reproduce or publish source materials. Links and original text do not establish legal clearance; rights review remains open."
    }
  ],
  "methodTraceability": [
    {
      "operation": "Permission to stop and seek support if compassion evokes distress",
      "sections": [
        "fit",
        "practice.stance",
        "practice.review"
      ],
      "source": "Neff and Germer 2022 clinical commentary; specific plain-language stop cues are conservative adaptation choices, not a validated screening rule"
    },
    {
      "operation": "Manageable moment, criticism content/tone and conviction",
      "sections": [
        "practice.moment",
        "practice.critic"
      ],
      "source": "CCI module 5 pp3–4; bounded ordinary subject and limited critical detail are safety adaptations"
    },
    {
      "operation": "Emotions, optional intensity and body/action effects",
      "sections": [
        "practice.effects"
      ],
      "source": "CCI module 5 p4; optional body attention and no single-cause claim are adaptations"
    },
    {
      "operation": "Deliberately adopt a caring stance before reappraisal",
      "sections": [
        "practice.stance"
      ],
      "source": "CCI module 5 p4 compassionate preparation; non-imagery intention informed by Neff principles is an adaptation, not exact CCI preparation"
    },
    {
      "operation": "Caring perspectives, realistic context and support",
      "sections": [
        "practice.perspective",
        "practice.care"
      ],
      "source": "CCI module 5 p4; Neff mindfulness, human context and kindness; no forced minimization or universal statement"
    },
    {
      "operation": "Reread caring thoughts, check tone, synthesize and actually try a conclusion",
      "sections": [
        "practice.conclusion"
      ],
      "source": "CCI module 5 p5; neutral tone, optional rehearsal and clear non-use distinction are adaptations"
    },
    {
      "operation": "Review original belief/emotion and continue or stop with support",
      "sections": [
        "practice.review",
        "practice.next"
      ],
      "source": "CCI module 5 p5; optional ratings, no required reduction and therapist follow-through are conservative product adaptations"
    }
  ],
  "narrationSegments": [
    {
      "id": "compassionate-thought-diary.intro",
      "title": "Respond to a hard moment with care",
      "text": "Self-criticism can add harsh words to a hard moment. A compassionate thought diary helps you notice that response and try a different one: truthful, caring and useful to you.\n\nYou make one short entry, rather than a letter or a whole life story. You can write, think, speak privately or use paper. Private rehearsal is welcome, but this page does not create a saved diary. Feeling warm or calm is not required.",
      "sha256": "f038f982a9488adea842da2741ac0ff85e37586711d9698e4ab874a744d7818b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.fit",
      "title": "Choose a moment that fits",
      "text": "Use this after your therapist has introduced the skill and helped you check its fit. Choose one recent, ordinary difficulty you have agreed is manageable. You can read the example without using your own life.\n\nDo not choose your most painful memory or use this page to go over trauma. You do not need to imagine a caregiver, feel safe in a special place, change your breathing, close your eyes or touch your body.\n\nCare does not mean forgiving someone, excusing harm, ignoring unfairness or giving up a boundary. Do not use this page to change food, medicine, sleep, substance use or other health care. Keep needed aids and support.\n\nIf kindness feels threatening, plain respect may fit better. If shame, grief or distress grows, painful memories come up, you feel numb or far away, or you keep checking for the right feeling, pause or stop and seek support. You do not have to finish first.",
      "sha256": "bd7c392a8b69225ec33acff1709c368f946fb3093d8731497dce3d9ff2d32e64",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.privacy",
      "title": "Your choice to write or keep notes",
      "text": "You can think, speak privately, use your own paper, or add notes here. Writing is optional. You do not need names, private history or contact details. Notes stay while you use this open tool, including its example and help.\n\nLeaving this tool, reloading, clearing or starting again removes these notes. To keep notes, choose them, check the preview, then copy or download. A copy you keep stays outside this tool until you remove it.\n\nThis page does not send notes to your therapist or save a diary over time. The optional skill narration never reads your notes. A screen reader or other device tool may read what you enter. This tool does not alert anyone if you need help. A session shortcut lasts only in this open page and saves no answers.",
      "sha256": "184134d0a14c3b4a1c95430e3e8c2974c55bc8e74eec23facaa02c8c33764895",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.close",
      "title": "You can leave the entry here",
      "text": "You may finish with an entry, a few words, a question, or no writing. Reading the example is not the same as trying the diary. You do not need a better mood or a finished task to receive care.\n\nYou can return to the prompts or choose notes to keep for your next session. Finish and clear removes notes in this tool. It does not remove a copy you kept elsewhere.",
      "sha256": "9ca56724879fb979344f13f9fc58331e03be0fdba20646dea600772cb915540f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.example",
      "title": "Tess spots a mistake on a handmade card",
      "text": "This is made up, not a response you need to copy. Tess and their therapist have chosen small everyday mistakes for this practice. Tess sees a spelling mistake on a birthday card they made and thinks, \"I ruin everything.\" The words feel harsh and very convincing.\n\nTess feels embarrassed and frustrated. Their hands feel tense, and they want to throw the card away. The mistake is real. The diary does not need to deny it or say what the friend will think.\n\nBefore seeking new words, Tess chooses the aim: \"I want to help with this mistake without adding insults.\" There is no need to picture a kind person or make a warm feeling happen.\n\nPerspective: One word is wrong. Tess spent time on the drawing and message. Mistakes can be part of making things, but that does not mean Tess must like this one. The whole card, and Tess as a person, are more than that word.\n\nCare: Tess could take a short pause before choosing what to do. Covering the word with a small label may be an option. Repair is a choice, not a price for being treated with respect. Tess has not fixed the card yet.\n\nTess reads these caring notes once. \"It is only a tiny mistake\" sounds dismissive, so Tess leaves that out. The conclusion becomes: \"This matters to me, and one wrong word is not everything. I can pause and decide how to handle the card without insulting myself.\" Tess tries reading it in a plain, steady tone.\n\nReview: Tess did try the words. Frustration is still strong. \"I ruin everything\" feels less convincing, but Tess does not feel warm. The steady tone is easier to use than forced praise. Tess decides to bring that difference to the therapist. No further action has happened in this example.\n\nIf Tess had only planned the words, there would be no reading attempt to review yet. If the words had increased distress, Tess could stop and ask for help rather than repeat them until they worked.",
      "sha256": "8d81df1b5515293ec691742d228084e769671e14a5acc81203011249067b5d84",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.learn",
      "title": "What makes this a compassionate diary?",
      "text": "The diary notices what happened, what the critic said and how you responded. Then you deliberately turn toward care, look at the situation more fully and try a short caring conclusion. You review the words and tone, not just whether you feel better.\n\nCare is more than proving a thought wrong. It takes pain seriously and asks what would help. It can include an honest limit, support, responsibility, repair or saying no. It is not permission for harm or a promise that things will work out.\n\nThoughts, feelings, the body, past learning and real conditions can affect one another. Distress is not proof that you are thinking badly. You do not need to debate away poverty, prejudice, illness or unsafe treatment.\n\nA letter joins ideas into a message to yourself. This diary keeps a structured record of one moment and your response. Neither format must work for everyone. A brief Friend Test or a thought record may help, but does not provide the whole diary process.\n\nSome compassion methods use imagery or breathing. This adapted diary uses a caring intention and allows plain, respectful words without those methods. It is not a full course of compassion-focused therapy or a daily routine you must keep.\n\nYou can repeat the practice only in the way agreed with your therapist. There is no streak, quota or deadline for self-kindness. If repeating becomes another demand or a search for certainty, pause and review the fit.",
      "sha256": "91e3ab4544d7c9304d56d637a456e2e175325b50f0716997b94ac0d92ae41423",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.moment",
      "title": "Name one manageable moment",
      "text": "Choose the ordinary situation you agreed to work on. What happened, in a few plain words? Keep the event separate from a verdict about yourself. You do not need names or a full history.\n\nIs it manageable enough to stay with today? If not, use the fictional example, choose a different agreed moment or stop. This page cannot choose a safe subject for you.",
      "sha256": "4eceeec3637243a1fa07aafd399f445bf68286f54d820111d192ca4480a9635c",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.moment.help",
      "title": "If there is no clear event",
      "text": "You can note a current everyday worry you have already agreed to explore, without predicting the outcome. You do not need to search for a painful memory or find a hidden reason.",
      "sha256": "aff4da9a72db41699624fcb40b02f88905d30057335dc628edd76611ff809d88",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.critic",
      "title": "Notice the message and its tone",
      "text": "What critical message showed up? Name one short phrase or describe its theme. You do not need to copy insults in full, list every thought or read them aloud.\n\nHow does the tone come across: harsh, rushed, cold or something else? If useful, note how convincing the message feels in words or from zero to one hundred. This rates the thought's pull, not your worth.",
      "sha256": "300f3aba19bf88ec7672711296518407f9c5a3c92c790006c29807527de872ce",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.critic.help",
      "title": "If describing the critic makes it louder",
      "text": "You can use a plain label such as \"harsh blame\" instead of its words. Do not rehearse the attack or argue with it. Leave this part or stop if it increases distress.",
      "sha256": "29ba3a231e35f68821540587eb601be7fcdfd87abcfae541ced23d60fa47008c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.effects",
      "title": "Notice how you are affected",
      "text": "What feelings are here? If useful, choose the main one and describe how strong it is, in words or with a number. You do not need a score to continue.\n\nYou may briefly notice what your body is already showing, what you did, or what you feel pulled to do. No body scan is needed. The event and your needs matter too; thoughts are not the only cause of distress.",
      "sha256": "0f1835991914d4ff0752cb59aabc43f6721fa73d8d9ff3fcdebc7f2207b764dc",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.effects.help",
      "title": "If body attention does not fit",
      "text": "Skip body signs and stay with feelings, actions or the event. You do not need to change your breathing, test a sensation or make yourself calm before continuing.",
      "sha256": "1d15e02e6362a9a7dea4996e92981010c95ab2a8fa50a5d91f8322b28fe7cc8c",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.stance",
      "title": "Choose an intention to help, not attack",
      "text": "Before looking for new words, choose how you want to approach this moment. Could the aim be to understand the difficulty and offer useful care, rather than punish yourself?\n\nYou might use plain respect: \"I want to deal with this without adding harm.\" Use your own wording or just hold the intention. No special voice, image, posture or feeling is required.",
      "sha256": "b2bfd8a2b2cc8d8454bd2045292a1b6cfad87244df27d67c987ea7cf8d672a36",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.stance.help",
      "title": "If care or kindness feels uncomfortable",
      "text": "You can start with fairness or less harshness, read the example, or pause. You do not have to invent a loving person or push through shame, grief, threat or numbness. Discuss the fit with your therapist.",
      "sha256": "e37bb63b29f878120ad3521f6bb457947ee99062e944c3601277d95276d83bb7",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.perspective",
      "title": "Make room for a caring, realistic view",
      "text": "What would a respectful response notice about the difficulty? Include the facts, what matters to you, effort, limits, needs and real conditions. Acknowledge a specific mistake if there is one, without making it your whole identity.\n\nIf it helps, consider what you would offer someone facing similar facts, or what a fair response from outside the situation could say. You do not need to picture a person. You can also speak directly in your own voice.\n\nCan you place the struggle in a wider human context without brushing it off? People can have limits and need care. Your circumstances are still your own. You do not need to say \"everyone does this\" or that others have it worse.",
      "sha256": "db9cc0a02e387aad5c223befcb34092cf5c9175382063c782d9a01a2f6c6359b",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.perspective.help",
      "title": "If you are tempted to force a positive view",
      "text": "Stay with words you could mean. You do not need to say the problem is small, the future is safe or someone meant well. Real harm may call for a boundary, practical help or protection.",
      "sha256": "c5e535477e61bf0dd02111bd10745c0c7de1c7d91508530e03d79865e9b1fc93",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.care",
      "title": "Consider what would help now",
      "text": "What need can you take seriously here? A caring response might offer understanding, a pause, support, a boundary, practical help or a fair repair. You can leave the action undecided.\n\nIf you choose a next step, keep it small, safe and within your existing care plan. You do not earn kindness by completing it. This page does not ask you to contact someone, forgive them or make a promise.",
      "sha256": "46826f078d334dbc8b56508dc1626618505e0d5a431e91173242f3f20b096c7f",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.care.help",
      "title": "If responsibility matters here",
      "text": "Care can include owning a specific action and considering repair. It does not require blame for another person's choices, punishment, unsafe contact or a promise never to make a mistake.",
      "sha256": "1a06d64c573fc3f722cb3239dec472fb8ba8aca25affe67c3ed7e1b06b013984",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.conclusion",
      "title": "Read the caring ideas and try a conclusion",
      "text": "If you made caring notes, read those ideas once, not the harsh messages. Use Show all prompts or go back to your caring perspective and support notes. Paper or private words are fine too. Check that the tone offers help rather than a hidden demand.\n\nBring the useful parts into one or two sentences in your own words. Let them acknowledge the difficulty, offer a fair view and leave room for care. They do not need to promise relief or solve everything.\n\nIf you want, try reading or privately saying the conclusion once in a tolerable, respectful tone. Neutral is fine. You may change it, leave it unfinished or stop. Planning words and actually trying them are different.",
      "sha256": "05c73db47b649259e995c42a1abff5db63ae5ce43016b4d3de016ea1c8182116",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.conclusion.help",
      "title": "If the words are kind but the tone is harsh",
      "text": "You can make the words plainer or drop a hidden \"should\". Do not keep repeating until a feeling changes. It is also okay to stop and bring the unfinished entry to your therapist.",
      "sha256": "cd9c92423158273cbb01695c0842acbbd656beac3be475a72b919efdf58e3a9e",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.review",
      "title": "Review the attempt without a target feeling",
      "text": "Did you actually read or privately try the caring words, do part, only plan them, or not try? There is no required attempt. If you only read the example, say so or leave your own result blank.\n\nHow did the words and tone fit? Notice what was useful, awkward, unchanged or upsetting. You do not need to feel warm, calm or grateful.\n\nIf useful, return to the same critical message and main feeling you noted earlier. How convincing is that message now? How strong is that feeling? Use the same words or scale if you remember it, or skip this. Neither rating needs to go down.",
      "sha256": "d1d956f6211761f627b9f78c4ac85d085ebde90f7a8bd6f71f2d2e66418b0d31",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.review.help",
      "title": "If you feel worse or cannot find caring words",
      "text": "Stop rather than treating that as another failure. Ask for support and discuss the response with your therapist. This format may need changes or may not fit now. Support and urgent help has help options.",
      "sha256": "5b2e7b2d30701ea6355629d71d811cb6d0173006acbadd23c393bcc02c7f124d",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    },
    {
      "id": "compassionate-thought-diary.practice.next",
      "title": "Choose what to keep or bring to your session",
      "text": "You can keep a phrase, change it, leave it open or decide not to use this format again until you have discussed it. If you chose a caring action, it remains a plan until you actually do it.\n\nBring your questions, any discomfort and what made the response easier or harder to your therapist. Agree any next practice together. You can finish without another entry or action.",
      "sha256": "23b164fbbe434d9cf866516c801ee603bb2b3d192e48c6a00b8f797c6072fd66",
      "audioAsset": null,
      "listeningApproved": false
    },
    {
      "id": "compassionate-thought-diary.practice.next.help",
      "title": "If you want a record",
      "text": "Choose notes to keep lets you select and check only the notes you want. Nothing is sent to your therapist. You decide if, when and how to share a copy. The tool keeps no diary after you leave.",
      "sha256": "93b531a4505856e286dd6aa8c32b92490def52e2c60b399a2ac9ca81f64a961b",
      "audioAsset": null,
      "listeningApproved": false,
      "visibleOnlyWhenHelpOpen": true
    }
  ]
};
