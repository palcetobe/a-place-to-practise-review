window.BoundedSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "id": "classic/positive",
  "version": "2026-11-02-content-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "title": "Positive Qualities Record / Positive Data Log",
  "subtitle": "Notice credible evidence you might overlook",
  "scope": "Rehearse one specific entry or review entries you keep elsewhere; this session-only tool is not a saved ongoing record.",
  "clinicalContract": {
    "learningObjective": "Distinguish specific evidence of a quality from forced praise, perfection or proving personal worth.",
    "practiceObjective": "Recall one credible observation, consider a modest quality it may show, and practise retaining that evidence without exaggerating it; optionally review an existing record over time with a therapist.",
    "observedPractice": "Private consideration or optional writing demonstrates rehearsal only. An attempt and a later review are distinct from planning. No symptom change, rating, typed response or additional task is required to finish.",
    "sourcePopulationContext": "CCI sources describe broader clinical methods, not validation of this digital adaptation or suitability across ages. Therapist selection and adaptation should account for development, communication, context, consent, privacy and safeguarding. Method-specific source populations and suitability limits still apply."
  },
  "privacy": {
    "id": "positive.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "entry",
      "review"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Matched authored scripts only. Established voice; do not imply generated, listened or live audio. Private inputs never sent to narration.",
    "timer": "No timer required or proposed.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon."
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "sources": [
    {
      "id": "cci-positive-module",
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Improving-Self-Esteem/Improving-Self-Esteem---06---Accepting-Yourself.pdf",
      "reviewed": "2026-11-02",
      "supports": "Balanced self-evaluation, credible qualities, concrete past and everyday evidence, written record over time."
    },
    {
      "id": "cci-positive-record",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Self-Esteem/Self-Esteem---Worksheets/Self-Esteem-Worksheet---03---Positive-Qualities-Record.pdf",
      "reviewed": "2026-11-02",
      "supports": "Identifying positive qualities, including modest or small examples rather than only large achievements."
    },
    {
      "id": "cci-positive-journal",
      "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Self-Esteem/Self-Esteem---Worksheets/Self-Esteem-Worksheet---04---Positive-You-Journal.pdf",
      "reviewed": "2026-11-02",
      "supports": "Specific past examples and dated everyday actions linked to qualities."
    },
    {
      "id": "cci-selfesteem-index",
      "url": "https://www.cci.health.wa.gov.au/Resources/For-Clinicians/Self-Esteem",
      "reviewed": "2026-11-02",
      "supports": "Structured broader self-esteem learning; source programme is not a standalone one-screen intervention."
    }
  ],
  "productAdaptations": [
    "One-entry rehearsal and optional review of an off-tool record; explicit limit because repeated collection is central to the fuller method.",
    "Original Rae example with two dated/contextual observations and remaining doubt.",
    "No forced praise, achievement-based worth, daily quota or requirement to disclose personal material.",
    "Optional writing is an accessibility adaptation, not a claim that private thought equals a longitudinal record."
  ],
  "routeProposal": "tool/positive-qualities-record",
  "intro": {
    "id": "positive.intro",
    "title": "A place to begin",
    "paragraphs": [
      "Sometimes an unkind view of ourselves leaves out evidence that does not fit it. Here you can notice one specific moment and a quality it may show.",
      "You do not have to praise yourself, feel convinced or find an achievement. Your worth is not something this record measures."
    ],
    "actions": [
      {
        "id": "entry",
        "label": "Practise one entry"
      },
      {
        "id": "review",
        "label": "Review entries I keep elsewhere"
      }
    ]
  },
  "fit": {
    "id": "positive.fit",
    "title": "A supported practice",
    "paragraphs": [
      "Use this with your therapist, who can help keep the evidence believable and balanced.",
      "If searching for positives increases shame or feels like another test, pause. You can describe a fact without choosing a quality, or bring the difficulty to your therapist. You do not need to force an answer."
    ]
  },
  "learn": {
    "id": "positive.learn",
    "title": "Why this skill may help",
    "paragraphs": [
      "A record can make overlooked evidence easier to remember. Specific moments are more useful than a sweeping statement you do not believe.",
      "A quality can appear sometimes without describing you perfectly. Noticing care on one occasion does not require you to be caring in every situation.",
      "The fuller practice gathers and revisits examples over time. This page rehearses an entry; it does not keep a journal. If useful, agree an accessible, private record with your therapist, such as paper or another method you choose."
    ]
  },
  "example": {
    "id": "positive.example",
    "title": "Example — noticing consideration",
    "paragraphs": [
      "Rae tends to think, “I never consider anyone.” Yesterday a housemate was resting, so Rae used headphones instead of playing music aloud.",
      "Rae records the occasion and the action, then adds, “This was a considerate choice.” That feels more accurate than “I am always thoughtful.” Rae still feels doubtful, but keeps the specific fact.",
      "Later, using a paper record agreed with their therapist, Rae notices another example: asking before borrowing an item. In review, Rae can see two occasions of consideration without claiming perfection or dismissing times they acted differently."
    ]
  },
  "entry": [
    {
      "id": "positive.entry.moment",
      "title": "Choose one specific moment",
      "paragraphs": [
        "Recall a recent or past moment you might usually dismiss. What actually happened? It can be ordinary, quiet or incomplete; it does not need to be an achievement."
      ],
      "fields": [
        {
          "key": "moment",
          "label": "The occasion and what happened",
          "optional": true
        }
      ],
      "help": {
        "title": "If nothing comes to mind",
        "text": "Consider a small act of care, honesty, curiosity or respect. These are possibilities, not a checklist. You can pause and explore an example with your therapist."
      }
    },
    {
      "id": "positive.entry.quality",
      "title": "Consider what the evidence shows",
      "paragraphs": [
        "What quality, if any, could this particular action suggest? Use words you find credible. “I showed patience then” may fit better than a broad claim.",
        "You can keep the factual observation without naming a quality yet."
      ],
      "fields": [
        {
          "key": "quality",
          "label": "A quality this moment may show",
          "optional": true
        }
      ],
      "help": {
        "title": "If it seems too small to count",
        "text": "Small does not mean invented. Keep the scale of the statement as modest as the event. There is no minimum achievement to qualify."
      }
    },
    {
      "id": "positive.entry.balance",
      "title": "Keep the statement believable",
      "paragraphs": [
        "Read or recall the fact and the possible quality together. Are you exaggerating it, or explaining it away? Aim for a fair account, not a positive verdict about your whole self."
      ],
      "fields": [
        {
          "key": "balanced",
          "label": "A fair wording I can keep",
          "optional": true
        }
      ],
      "help": {
        "title": "If a critical thought appears",
        "text": "You do not have to win an argument with it. Return to what happened; a different difficulty does not erase this specific occasion."
      }
    },
    {
      "id": "positive.entry.record",
      "title": "Choose whether to keep an entry",
      "paragraphs": [
        "If you and your therapist are using an ongoing record, you can add this example there in a private, accessible way. An occasion or date may help you recognise it later.",
        "Nothing is added automatically. Notes on this page disappear when you leave this tool or reload. You can finish without keeping an entry."
      ],
      "help": {
        "title": "No ongoing record yet?",
        "text": "This page offers practice with one entry. Discuss a suitable way to collect and review examples over time if you want to continue; a daily quota is not required here."
      }
    }
  ],
  "review": [
    {
      "id": "positive.review.notice",
      "title": "Review an existing record",
      "paragraphs": [
        "If you have entries elsewhere, look at one or two that you choose. You do not need to copy them here. What specific evidence do they contain?"
      ],
      "fields": [
        {
          "key": "reviewEvidence",
          "label": "Something I noticed, if I want to write",
          "optional": true
        }
      ],
      "help": {
        "title": "If you do not have a record",
        "text": "Use “Practise one entry” or finish here. This tool cannot retrieve previous visits."
      }
    },
    {
      "id": "positive.review.meaning",
      "title": "Look for a balanced pattern",
      "paragraphs": [
        "Do the examples suggest a quality you tend to overlook? You can also notice that there is not enough information yet. No conclusion about your worth is needed."
      ],
      "fields": [
        {
          "key": "reviewMeaning",
          "label": "A balanced observation",
          "optional": true
        }
      ],
      "help": {
        "title": "If entries feel unconvincing",
        "text": "Look for the concrete event rather than stronger praise. Your therapist can help explore what makes the evidence difficult to take in."
      }
    }
  ],
  "close": {
    "id": "positive.close",
    "title": "Leave it here for now",
    "paragraphs": [
      "One credible observation is enough to practise with. You do not need to feel positive or add another entry before you finish."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "narrationSegments": [
    {
      "id": "positive.intro",
      "title": "A place to begin",
      "text": "Sometimes an unkind view of ourselves leaves out evidence that does not fit it. Here you can notice one specific moment and a quality it may show.\n\nYou do not have to praise yourself, feel convinced or find an achievement. Your worth is not something this record measures.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.fit",
      "title": "A supported practice",
      "text": "Use this with your therapist, who can help keep the evidence believable and balanced.\n\nIf searching for positives increases shame or feels like another test, pause. You can describe a fact without choosing a quality, or bring the difficulty to your therapist. You do not need to force an answer.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.learn",
      "title": "Why this skill may help",
      "text": "A record can make overlooked evidence easier to remember. Specific moments are more useful than a sweeping statement you do not believe.\n\nA quality can appear sometimes without describing you perfectly. Noticing care on one occasion does not require you to be caring in every situation.\n\nThe fuller practice gathers and revisits examples over time. This page rehearses an entry; it does not keep a journal. If useful, agree an accessible, private record with your therapist, such as paper or another method you choose.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.example",
      "title": "Example — noticing consideration",
      "text": "Rae tends to think, “I never consider anyone.” Yesterday a housemate was resting, so Rae used headphones instead of playing music aloud.\n\nRae records the occasion and the action, then adds, “This was a considerate choice.” That feels more accurate than “I am always thoughtful.” Rae still feels doubtful, but keeps the specific fact.\n\nLater, using a paper record agreed with their therapist, Rae notices another example: asking before borrowing an item. In review, Rae can see two occasions of consideration without claiming perfection or dismissing times they acted differently.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.entry.moment",
      "title": "Choose one specific moment",
      "text": "Recall a recent or past moment you might usually dismiss. What actually happened? It can be ordinary, quiet or incomplete; it does not need to be an achievement.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.entry.moment.help",
      "title": "If nothing comes to mind",
      "text": "Consider a small act of care, honesty, curiosity or respect. These are possibilities, not a checklist. You can pause and explore an example with your therapist.",
      "status": "Script only"
    },
    {
      "id": "positive.entry.quality",
      "title": "Consider what the evidence shows",
      "text": "What quality, if any, could this particular action suggest? Use words you find credible. “I showed patience then” may fit better than a broad claim.\n\nYou can keep the factual observation without naming a quality yet.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.entry.quality.help",
      "title": "If it seems too small to count",
      "text": "Small does not mean invented. Keep the scale of the statement as modest as the event. There is no minimum achievement to qualify.",
      "status": "Script only"
    },
    {
      "id": "positive.entry.balance",
      "title": "Keep the statement believable",
      "text": "Read or recall the fact and the possible quality together. Are you exaggerating it, or explaining it away? Aim for a fair account, not a positive verdict about your whole self.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.entry.balance.help",
      "title": "If a critical thought appears",
      "text": "You do not have to win an argument with it. Return to what happened; a different difficulty does not erase this specific occasion.",
      "status": "Script only"
    },
    {
      "id": "positive.entry.record",
      "title": "Choose whether to keep an entry",
      "text": "If you and your therapist are using an ongoing record, you can add this example there in a private, accessible way. An occasion or date may help you recognise it later.\n\nNothing is added automatically. Notes on this page disappear when you leave this tool or reload. You can finish without keeping an entry.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.entry.record.help",
      "title": "No ongoing record yet?",
      "text": "This page offers practice with one entry. Discuss a suitable way to collect and review examples over time if you want to continue; a daily quota is not required here.",
      "status": "Script only"
    },
    {
      "id": "positive.review.notice",
      "title": "Review an existing record",
      "text": "If you have entries elsewhere, look at one or two that you choose. You do not need to copy them here. What specific evidence do they contain?",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.review.notice.help",
      "title": "If you do not have a record",
      "text": "Use “Practise one entry” or finish here. This tool cannot retrieve previous visits.",
      "status": "Script only"
    },
    {
      "id": "positive.review.meaning",
      "title": "Look for a balanced pattern",
      "text": "Do the examples suggest a quality you tend to overlook? You can also notice that there is not enough information yet. No conclusion about your worth is needed.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.review.meaning.help",
      "title": "If entries feel unconvincing",
      "text": "Look for the concrete event rather than stronger praise. Your therapist can help explore what makes the evidence difficult to take in.",
      "status": "Script only"
    },
    {
      "id": "positive.close",
      "title": "Leave it here for now",
      "text": "One credible observation is enough to practise with. You do not need to feel positive or add another entry before you finish.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    },
    {
      "id": "positive.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only; no generated, listening-approved or live audio asserted"
    }
  ]
}
;
