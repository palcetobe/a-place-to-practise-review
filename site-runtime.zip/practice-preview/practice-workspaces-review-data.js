window.PracticeWorkspacesReviewData={
  "version": "focused-practice-workspaces-v1.2",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "tools": {
    "worry": {
      "title": "CBT worry time",
      "route": "tool/worry-postponement",
      "savedIdentity": {
        "p": "thought-spiral",
        "c": "card-thought-spiral-worry-postponement"
      },
      "intro": {
        "title": "CBT worry time",
        "paragraphs": [
          "Worry can keep pulling your attention back to what might go wrong. Worry time means choosing a short time to give worries your attention, instead of following each worry through the day.",
          "You practise noticing the worry, choosing to come back to it at your planned time, and returning your attention to what you’re doing now.",
          "Use an everyday worry to begin. Do not put off urgent safety, health or practical action. You can stop, change approach or seek support at any point."
        ]
      },
      "prepareNow": {
        "title": "Prepare a brief postponement practice",
        "paragraphs": [
          "Choose a time during the day or early evening and a place for your worry time. Keep it away from bedtime. You can choose 10 to 20 minutes; the optional review timer is set to 15 minutes and does not start automatically. Adjust your plan if it does not fit your life, and finish earlier when useful.",
          "Think through your plan privately, say it off-device, or make an optional note. This website will not schedule a future reminder or bring you back automatically."
        ]
      },
      "practiceNow": {
        "title": "Practise postponing and returning attention",
        "paragraphs": [],
        "sections": [
          {
            "title": "1. Notice one worry",
            "paragraphs": [
              "Choose one everyday worry, or use Noor’s job-reply example. Notice the topic now. You can think it, say a few words privately, or use the optional writing space. You do not need to write it all out."
            ]
          },
          {
            "title": "2. Bring your planned time to mind",
            "paragraphs": [
              "Bring your planned time to mind. Try saying privately, “I can come back to this at my planned time,” or use words that fit you. You are leaving the continued worrying for that time, not trying to force the thought away."
            ]
          },
          {
            "title": "3. Return to an actual activity",
            "paragraphs": [
              "Choose one part of the activity you want to return to: a word you are reading, the food you are eating, or an ordinary detail around you. Notice one detail now, in a way that fits your senses and circumstances.",
              "The worry may return. That is not failure. You can notice it and return again without arguing with it. If something needs prompt action or support, attend to that now.",
              "Try this in your own time. You can move on without doing it or stop if it is not useful."
            ]
          }
        ]
      },
      "practiceReview": {
        "title": "Practise at your planned worry time",
        "paragraphs": [
          "Look at the topics you noticed, or bring one to mind. Which still need attention? You do not have to make yourself worry about a topic that no longer matters.",
          "Choose one that still matters. Is there a practical part you could act on, or mainly a “what if” about an uncertain outcome? A useful action may be for later, not right now. It may include both. You can leave the distinction unclear.",
          "Use the planned period as a limit, not time you must fill. You can finish earlier.",
          "If useful, choose a possible response for this worry now: something you can act on, a “what if” you cannot resolve right now, or both / not sure. These are not permanent labels. You can change your choice or skip sorting.",
          "Some worry may still be there. If the review turns into the same loop, or feels too much, you can shorten or stop it. Your therapist can help you adjust the practice."
        ]
      },
      "responses": {
        "act": {
          "title": "A practical step you could take",
          "text": [
            "If there is a practical part you could act on, name one part you can work on. Consider realistic options and what they need. Choose one small step. When will you take it? The step can be for later; you do not have to do it during worry time. You can open the full practical problem-solving practice for more guidance."
          ],
          "optionalFields": [
            "One small step (optional)",
            "When I could take it (optional)"
          ],
          "narration": "If there is a practical part you could act on, name one part you can work on. Consider realistic options and what they need. Choose one small step. When will you take it? The step can be for later; you do not have to do it during worry time. You can open the full practical problem-solving practice for more guidance."
        },
        "uncertain": {
          "title": "Leave uncertainty open for now",
          "text": [
            "If it is mainly an uncertain “what if”, more thinking may not give you the answer. You can acknowledge what you cannot know now and choose what deserves your attention next. You do not have to reassure yourself or feel certain first.",
            "Choose an ordinary next activity, rest or support that fits now. You can take that next step with uncertainty still present."
          ],
          "optionalFields": [
            "What I choose to give attention to next (optional)"
          ],
          "narration": "If it is mainly an uncertain “what if”, more thinking may not give you the answer. You can acknowledge what you cannot know now and choose what deserves your attention next. You do not have to reassure yourself or feel certain first.\n\nChoose an ordinary next activity, rest or support that fits now. You can take that next step with uncertainty still present."
        },
        "mixed": {
          "title": "Look for a part you can use",
          "text": [
            "It can include both a practical concern and uncertainty, or you may not be sure yet. You do not have to settle a category.",
            "Ask whether there is one small practical step you could take. If there is, consider what it is and when it could fit, including later. Leave the outcome you cannot decide open. If no step is clear, you can choose an ordinary next activity, pause, or ask your therapist to help you choose a next step. Urgent action or support still comes first."
          ],
          "optionalFields": [
            "A step, next activity, support or open question (optional)",
            "When a step or review might fit (optional)"
          ],
          "narration": "It can include both a practical concern and uncertainty, or you may not be sure yet. You do not have to settle a category.\n\nAsk whether there is one small practical step you could take. If there is, consider what it is and when it could fit, including later. Leave the outcome you cannot decide open. If no step is clear, you can choose an ordinary next activity, pause, or ask your therapist to help you choose a next step. Urgent action or support still comes first."
        },
        "none": {
          "title": "Leave sorting open",
          "text": [
            "It can include both a practical concern and uncertainty, or you may not be sure yet. You do not have to settle a category.",
            "Ask whether there is one small practical step you could take. If there is, consider what it is and when it could fit, including later. Leave the outcome you cannot decide open. If no step is clear, you can choose an ordinary next activity, pause, or ask your therapist to help you choose a next step. Urgent action or support still comes first."
          ],
          "optionalFields": [
            "A step, next activity, support or open question (optional)",
            "When a step or review might fit (optional)"
          ],
          "narration": "It can include both a practical concern and uncertainty, or you may not be sure yet. You do not have to settle a category.\n\nAsk whether there is one small practical step you could take. If there is, consider what it is and when it could fit, including later. Leave the outcome you cannot decide open. If no step is clear, you can choose an ordinary next activity, pause, or ask your therapist to help you choose a next step. Urgent action or support still comes first."
        }
      },
      "sortChoices": [
        {
          "value": "act",
          "label": "Something I can act on"
        },
        {
          "value": "uncertain",
          "label": "A what if I can’t resolve right now"
        },
        {
          "value": "mixed",
          "label": "Both / I’m not sure"
        }
      ],
      "finishNow": {
        "title": "Finish this brief practice",
        "paragraphs": [
          "You can leave this practice here, whether or not the worry is still present.",
          "What did you notice? You can skip reflecting. Choose the activity, rest or support that fits next. You do not have to sort or solve the worry during this rehearsal."
        ]
      },
      "finishReview": {
        "title": "Close the period and choose what comes next",
        "paragraphs": [
          "When you reach the end of the period, finish looking through your worries. Choose an ordinary next activity, rest or support. A worry may come along with you; you do not have to wait for it to disappear.",
          "What did you notice? It may have been useful, difficult, unchanged or unclear. You can skip this reflection. Consider what you would keep or adjust next time, including the time, length or way of capturing topics.",
          "If worry keeps disrupting your day, gets worse, or this approach is not helping, speak with your therapist or a healthcare professional. You can seek support sooner; finishing this practice is not a requirement."
        ]
      },
      "optional": {
        "learn": {
          "title": "A thought can appear without taking all your attention",
          "paragraphs": [
            "A thought might be, “What if I do badly?” Worry can add more “what ifs”, guesses about what may happen and trying again and again to feel sure.",
            "You are not trying to force the first thought away. When it appears, notice it. You can decide to return to the topic at your planned time, even if the thought or feeling stays nearby.",
            "This is one skill for working with worry. It is not a whole treatment for anxiety, and it does not tell you whether a concern is true."
          ]
        },
        "example": {
          "title": "Example: waiting for a reply",
          "paragraphs": [
            "Noor is waiting to hear about a job application. While eating lunch, Noor starts imagining several ways it could go wrong.",
            "Noor has chosen 15 minutes at 5 p.m. in a quiet chair for worry time. Noor makes a short note: “job reply”, then returns attention to lunch. The thought returns. Noor notices it and uses the same plan again.",
            "At 5 p.m., Noor checks which worries still need attention. One practical question is when the employer said they would reply. Noor checks that detail once and decides when a follow-up would fit. Whether the job offer comes is still uncertain.",
            "Noor ends the period and chooses the next activity. Worry may still be there. The practice is choosing how to respond, not proving that nothing bad will happen."
          ]
        },
        "barriers": {
          "title": "If the practice is hard to use",
          "paragraphs": [
            "The thought keeps returning: that is not failure. Notice it without forcing it away, and gently return to what you choose now.",
            "I miss the planned time: choose another realistic period. You do not need to catch up on every worry or make the next period longer.",
            "Some worry may still be there. If the review turns into the same loop, or feels too much, you can shorten or stop it. Your therapist can help you adjust the practice.",
            "I cannot write or do not want to: think privately, say a few words off-device, or use paper if useful. You do not have to type into the website.",
            "I am worried about something urgent: use appropriate practical or safety support now. Do not wait for worry time."
          ]
        }
      },
      "timerCopy": [
        "The timer is optional and starts only when you choose Start timer. Choose 10 to 20 minutes; 15 minutes is selected to begin. This is a maximum period, not time you must spend worrying. You can finish earlier.",
        "The timer has no alarm, voice or notification. It pauses if this page is hidden. Return and choose Resume timer if you want to continue. Leaving, reloading or clearing this practice stops and resets it. It does not schedule a future reminder."
      ],
      "privacy": "Writing is optional. Notes and choices stay only in this open practice. The on-page Back button keeps them. Leaving this tool, reloading, clearing or starting again removes them, including hidden fields. Nothing is sent for narration. There is no note export or future reminder. My Toolbox saves a shortcut, not your worries or timer.",
      "sources": [
        {
          "title": "CCI Postpone Your Worry information sheet",
          "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Generalised-Anxiety/Generalised-Anxiety---Information-Sheets/Generalised-Anxiety-Information-Sheet---05---Postpone-your-Worry.pdf"
        },
        {
          "title": "CCI Postpone Your Worry worksheet",
          "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Mental-Health-Professionals/Generalised-Anxiety/Generalised-Anxiety---Worksheets/Generalised-Anxiety-Worksheet---01---Postpone-your-Worry.pdf"
        },
        {
          "title": "CCI What? Me Worry? Module 3",
          "url": "https://www.cci.health.wa.gov.au/~/media/CCI/Consumer-Modules/What-Me-Worry/What-Me-Worry--03--Negative-Beliefs-About-Worry-Uncontrollability.pdf"
        },
        {
          "title": "NHS Tackling your worries",
          "url": "https://www.nhs.uk/every-mind-matters/mental-wellbeing-tips/self-help-cbt-techniques/tackling-your-worries/"
        }
      ]
    },
    "urge": {
      "title": "Urge surfing",
      "route": "tool/urge-surfing",
      "savedIdentity": {
        "p": "urge-surfing",
        "c": null
      },
      "intro": {
        "title": "Urge surfing",
        "paragraphs": [
          "An urge is a pull to do something. This practice helps you notice the pull without automatically following it. You will notice what it feels like, any changes, and what you need next.",
          "The aim is not to force the urge away or wait until it is gone. It may ease, stay strong, change or return. That does not decide whether you have done the practice correctly.",
          "Start with an everyday, non-urgent urge you do not want to follow, such as sending an angry reply. Safety or practical help comes first when needed. You can stop or seek support at any point."
        ]
      },
      "prepare": {
        "title": "Before you start",
        "paragraphs": [
          "Is the urge connected to hurting yourself or someone else, unsafe driving, taking more medication than is safe, risky drinking or drug use, or being responsible for someone else's care?",
          "This is a self-check, not an assessment of your safety. Entries are not monitored.",
          "Choose an everyday, non-urgent urge. You can name it silently or keep a few words off-device. Writing and ratings are optional.",
          "Notice a sensation, a thought or the pull itself, if comfortable. You do not need a precise word or to change it. If looking inward is too much, use something around you to stay oriented, change your focus, stop or choose support. Breathing practice is not required."
        ]
      },
      "practice": {
        "title": "Practise noticing the urge",
        "paragraphs": [
          "Notice the pull without needing to follow it. If comfortable, choose one part of the experience to observe: a sensation, a thought, or the urge itself.",
          "Describe to yourself what you notice. It might feel tight, restless, hot, vague, or different from those words. Notice any change, or no clear change. You do not have to make it rise or fall.",
          "If your attention wanders, notice that and return when you choose. This is not a willpower test. An urge staying strong is not failure, and you do not need a lower rating to finish.",
          "Practise without a timer, or choose a two-minute practice. Two minutes is just a short time to try the skill. It does not tell you how long an urge will last. You can pause or finish at any point.",
          "If risk changes or you need help, use support now. You do not have to wait for the timer or complete the exercise."
        ]
      },
      "finish": {
        "title": "This practice has ended",
        "paragraphs": [
          "You can leave the practice here. Ending the practice is separate from the urge ending. The urge may still be here, feel different, or be hard to judge.",
          "If useful, notice what you learned about the pull or how you responded. You can keep this private, optionally write a few words, or skip reflecting.",
          "Consider what you need next. If risk has changed, check safety or get support. You do not have to practise again or wait for a different feeling."
        ]
      },
      "acted": {
        "title": "If you acted on the urge",
        "paragraphs": [
          "If you acted on the urge, first check what help is needed now. Call 911 if someone is in immediate danger, is badly hurt, may be having an overdose, or is having trouble breathing. For other possible poisoning, call your local poison centre right away. For a non-emergency injury or health concern, get medical advice. You can stop this practice and get support. You can take responsibility for what happened without judging your whole self."
        ],
        "links": [
          {
            "label": "Ontario Poison Centre: first aid",
            "url": "https://www.ontariopoisoncentre.ca/for-families/first-aid/"
          }
        ]
      },
      "optional": {
        "learn": {
          "title": "How urge surfing works",
          "paragraphs": [
            "An urge can include thoughts, feelings and sensations that pull you toward an action. Urge surfing means noticing this experience and its changes without automatically acting on it.",
            "A wave is one way to picture this. It is a metaphor, not a forecast. An urge may change in different ways, stay strong or return. You do not need to imagine a wave if that is not useful.",
            "Observing an urge is different from forcing it away, arguing with it, or waiting for a certain result. A timer or rating can be a practice aid, but neither is required and neither assesses safety."
          ]
        },
        "example": {
          "title": "Example: an angry reply",
          "paragraphs": [
            "Casey feels pulled to send an angry reply to an ordinary, non-urgent message. Casey leaves the message unsent and notices the pull.",
            "Casey notices tense hands and the thought, “I need to answer now.” Casey names those experiences privately and watches for any change, without forcing the feeling away.",
            "One time the pull feels less pressing. Another time it stays strong. In either case, Casey can finish this short practice and choose to draft a clearer reply later.",
            "The example is not a promise that every urge will fade. It does not establish that a particular action is safe or that waiting is appropriate for an urgent concern."
          ]
        },
        "barriers": {
          "title": "If the practice is difficult",
          "paragraphs": [
            "The urge is not easing: a lower rating is not the task. You can finish, change approach or seek support while the urge is still present.",
            "My attention keeps wandering: notice that and return to one part of the experience when you choose. You do not have to concentrate perfectly.",
            "I cannot find a body sensation: you can notice the thought or pull itself. You do not need to invent a sensation or stay focused inward if it is uncomfortable.",
            "I do not want to use numbers or write: you can notice privately and continue without a rating or typed answer.",
            "I need support or risk has changed: use the support options now. There is no timer or checklist to finish first."
          ]
        }
      },
      "ratingCopy": "A rating is optional. If you choose to record one, choose the number yourself. It describes your experience; it does not assess safety. If useful, choose a rating from 0 to 10, or skip the rating. Nothing is selected or carried forward for you. A rating does not decide whether you are safe or whether the practice helped.",
      "timerEndText": "The two minutes are over. The urge may still be here. You can finish now and choose what you need next.",
      "timerReview": {
        "default": "untimed",
        "optionalMinutes": 2,
        "endText": "The two minutes are over. The urge may still be here. You can finish now and choose what you need next.",
        "status": "Proposed product choice pending review; no universal or optimal clinical dose established."
      },
      "privacy": "Writing and ratings are optional. Notes, ratings, reflection and helpfulness choices stay only in this open practice. The on-page Back button keeps them. Leaving this tool, reloading, clearing or starting again removes them, including hidden fields. A Toolbox shortcut does not save your answers. No personal notes are sent for narration. There is no personal-note export.",
      "sources": [
        "https://www.ontario.ca/page/emergency-rooms",
        "https://www.ontario.ca/page/get-naloxone-kits-free",
        "https://www.ontariopoisoncentre.ca/for-families/first-aid/",
        "https://www.mirecc.va.gov/MIRECC/visn5/EBT/CBT-SUD/Urge-Surfing.asp",
        "https://mirecc.va.gov/MIRECC/VISN16/docs/act-for-ptsd-therapist-manual.pdf"
      ],
      "timerHelp": "The timer starts only when you choose Start two-minute timer. There is no future reminder, sound or automatic move to another screen. You can finish at any time.",
      "anchorChoices": [
        {
          "value": "none",
          "label": "No extra anchor",
          "prompt": null
        },
        {
          "value": "surroundings",
          "label": "Something around me while I notice the urge",
          "prompt": "Let a colour, shape or sound help you stay oriented while you notice the pull. You do not need to push it away."
        },
        {
          "value": "body",
          "label": "A sensation, if comfortable",
          "prompt": "If comfortable, notice one sensation with the urge. You can change your focus or stop."
        }
      ],
      "ratingsGraphCopy": "Each dot is one rating you chose. Dot size is constant. Spacing shows report order, not time. Lines connect reports, not a predicted wave. A change does not measure helpfulness.",
      "ratingsTableHeaders": [
        "Report",
        "Intensity (0 to 10)",
        "Active practice time"
      ]
    }
  },
  "feedbackQuestion": "Optional: was this approach useful just now?",
  "feedbackChoices": [
    "Helpful",
    "Not helpful",
    "Unsure",
    "Uncomfortable",
    "Skip"
  ],
  "narrationScope": "Text-only review draft. No matching recording is available.",
  "clinicalLimits": [
    "No clinical efficacy or optimal-duration claim.",
    "Worry review10–20minutes/default15 preserved; no timer in postponement rehearsal.",
    "Urge untimed default/optional two-minute rehearsal remains a proposed product choice.",
    "Essential fit/safety, uncertainty, recurrence, stop/support and non-writing participation remain on the main path."
  ],
  "narrationDetail": "Written practice draft. No matching recording is available for this version. The transcript contains authored instructions only, never your writing."
};
