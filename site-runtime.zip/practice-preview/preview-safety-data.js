window.PracticePreviewSafety={
  "urge-safer-first": [
    {
      "tag": "p",
      "text": "Urges → Make it safer first"
    },
    {
      "tag": "p",
      "text": "Check what support is needed now."
    },
    {
      "tag": "p",
      "text": "Before we work with the urge, let's make the situation a little safer."
    },
    {
      "tag": "p",
      "text": "Choose what fits the situation. These steps don't establish that you or anyone else is safe."
    },
    {
      "tag": "p",
      "text": "A few things that can help, in the next few minutes:"
    },
    {
      "tag": "ul",
      "items": [
        "— Put the thing you're pulled toward out of reach. Move away from a trigger if it's safe, put a distracting phone aside, or ask a trusted person to stay with you. Medication and driving risks need the specific steps below, not a general disposal instruction.",
        "— If someone depends on you right now, make the situation safer if you can. If it's safe to do so, create a little space — even just taking one step back, sitting down, or moving to the other side of the room. If another adult is nearby, let them know you're working through a hard moment and ask them to step in for a few minutes.",
        "— If driving was part of it: put the keys somewhere you'd have to think to reach, or give them to someone.",
        "— If a medication was part of it: if you're worried about taking more than prescribed or using medication to harm yourself, ask a trusted person or health professional to help make a safer-access plan. A pharmacist can advise on storage and access to needed doses. This isn't an instruction to stop prescribed treatment. If an overdose may have happened or there is immediate danger, call 911 now.",
        "— Tell someone, even briefly. A text is enough:\"I'm having a hard moment. I'm doing some safety steps. Can you check in with me?\""
      ]
    },
    {
      "tag": "p",
      "text": "You can get support at any point. There's no required waiting period or checklist to finish before getting help. If you choose to return to an urge practice, keep checking whether support is needed."
    }
  ],
  "crisis-now": [
    {
      "tag": "h1",
      "text": "If you're not safe right now"
    },
    {
      "tag": "h2",
      "text": "What to do now"
    },
    {
      "tag": "p",
      "text": "If you are in immediate danger, call 911. If you are in suicide crisis or worried you might not stay safe, call 988 or text 988 from your phone."
    },
    {
      "tag": "p",
      "text": "Call 911 now — immediate danger"
    },
    {
      "tag": "p",
      "text": "If you or someone else is in immediate danger, or you need an ambulance, police, or fire, call 911 now."
    },
    {
      "tag": "h3",
      "text": "988 — Suicide crisis support"
    },
    {
      "tag": "p",
      "text": "For suicide crisis support, or if you are worried you might not stay safe. 24/7 across Canada."
    },
    {
      "tag": "a",
      "text": "📞 Call 988",
      "href": "tel:988"
    },
    {
      "tag": "p",
      "text": "Text 988 from your phone"
    },
    {
      "tag": "h2",
      "text": "Additional support"
    },
    {
      "tag": "h3",
      "text": "Hope for Wellness — Indigenous support"
    },
    {
      "tag": "p",
      "text": "Mental health counselling and crisis support for Indigenous people across Canada. Phone and online chat available 24/7."
    },
    {
      "tag": "p",
      "text": "Phone and online chat are available in English and French. Cree, Ojibway, and Inuktitut telephone support may be available on request."
    },
    {
      "tag": "a",
      "text": "📞 Call 1-855-242-3310",
      "href": "tel:18552423310"
    },
    {
      "tag": "a",
      "text": "Open chat / website ↗",
      "href": "https://www.hopeforwellness.ca/"
    },
    {
      "tag": "h3",
      "text": "Trans Lifeline — peer support"
    },
    {
      "tag": "p",
      "text": "Peer support for trans and questioning people in Canada."
    },
    {
      "tag": "a",
      "text": "📞 Call 1-877-330-6366",
      "href": "tel:18773306366"
    },
    {
      "tag": "h3",
      "text": "ConnexOntario — Ontario mental health, addiction, and gambling"
    },
    {
      "tag": "p",
      "text": "Free and confidential support, 24/7."
    },
    {
      "tag": "a",
      "text": "📞 Call 1-866-531-2600",
      "href": "tel:18665312600"
    },
    {
      "tag": "p",
      "text": "Text CONNEX to 247247"
    },
    {
      "tag": "a",
      "text": "Open website ↗",
      "href": "https://www.connexontario.ca/"
    },
    {
      "tag": "p",
      "text": "If you feel frozen: put both feet on the floor, take one slow breath, then choose the safest next step above."
    }
  ]
};
