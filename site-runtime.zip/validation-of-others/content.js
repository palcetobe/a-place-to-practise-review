window.ValidationOthersContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "support": {
    "label": "Support and urgent help",
    "placement": "Always reachable outside focus folds, including before practice.",
    "destination": "Reuse verified project support route; do not invent contacts."
  },
  "acceptance": [
    "Complete named component operations remain teachable and actually practicable, not just definitions.",
    "Original worked example includes actual rehearsal/attempt and neutral review.",
    "All help, fit and full teaching accessible without enforced reading.",
    "No writing, rating, emotion change or real-world activity required to leave.",
    "Content review is separate from clinical validation, UI testing, guide/export review and audio listening."
  ],
  "privacy": {
    "id": "validation-others.privacy",
    "title": "Writing is optional",
    "paragraphs": [
      "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.",
      "Leaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.",
      "Review session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored."
    ]
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "Practice enters/resumes directly; no duplicate Start. One focused prompt group by default; free jump, Show all, Back and Finish always available. No completion locks.",
    "writing": "Hidden by default and optional; hiding removes every private echo/preview from view. No required fields, analysis, ratings or generated feedback.",
    "persistence": "Active-tool memory only. Internal navigation retains choices/notes; leaving/reload/restart/clear erases them. No localStorage, backend, diary or automatic carry-forward. Returning later allows a fresh account or privately kept notes, never claims restoration.",
    "narration": "Exact static section text only, user-initiated Listen/Pause/Resume; Replay only after this exact current clip was actually played. Leaving section/branch/tool stops playback. No autoplay, concatenated hidden branches, private-answer speech or TTS fallback. No recording acceptance implied.",
    "timer": "None. Rehearsal and actual activity are user-paced; no countdown or prescribed dose.",
    "visual": "Textually labelled method map only. No scores, ticks implying completion, streaks, positive-outcome badges or forced reflection.",
    "context": "Fictional scene always accessible, never copied into private fields. A learner may instead privately use a suitable ordinary situation without an extra mode gate. Supplied possible replies are labelled fiction, not predictions about a personal situation.",
    "modes": [
      "practice"
    ],
    "stateBoundary": "One practice flow with six optional approach choices. Preserve separate response notes per approach and focus positions during internal navigation. Rehearsal response choices have separate revision notes. Changing approach/fictional reply stops audio, hides old branch and keeps old notes private; never reassign them to a new approach. Leave/reload/restart/clear erases notes, selections and echoes.",
    "shortcut": "Existing public REVIEW session-only shortcut keyed by exact component/resource identity. No usual Toolbox write, durable persistence, localStorage or personal notes. Display the exact review-session lifetime notice; shortcut lifetime distinct from active-tool note clearing.",
    "reviewAccess": "Review is always accessible, including no attempt, partial attempt or changed situation. No required response, selected approach, emotion change, live contact or completion checkbox.",
    "approachChoice": {
      "title": "Choose a way to respond",
      "selection": "No approach chosen automatically. Six equally presented options; not levels to complete or increasingly advanced scores. Choice opens only that approach’s teaching and illustration beside Choose. Its actual attempt/help belongs in Try once, not duplicated at Choose. Other approaches remain easy to reach.",
      "options": [
        {
          "value": "attention",
          "label": "Give attention"
        },
        {
          "value": "reflect",
          "label": "Reflect accurately"
        },
        {
          "value": "tentative",
          "label": "Tentatively notice the unspoken"
        },
        {
          "value": "context",
          "label": "Understand known context"
        },
        {
          "value": "valid",
          "label": "Acknowledge and act on what is valid"
        },
        {
          "value": "equality",
          "label": "Respond as an equal"
        }
      ],
      "showAll": "Show all expands common stages plus only the selected approach and selected fictional reply. Learn more presents all six, separately labelled. Never narrate unselected options or hidden branch bodies."
    },
    "responseChoice": {
      "title": "Try a possible fictional reply, if useful",
      "selection": "Two explicitly chosen replies, neither preselected. Show only the chosen reply plus its revision prompt. No AI interlocutor or evaluation. Can skip all replies.",
      "contextChange": "Warn that retained notes may refer to the prior approach, reply or context. Keep separate response/revision namespaces; do not merge or rewrite user notes."
    },
    "selectedPracticePlacement": "At Hear show scene/common prompts. At Choose show selector plus selected approach teaching/illustration. At Try show common try instructions plus selected approach attempt/fields/help once. If unselected, keep six choices reachable without inventing a default or blocking Finish/review. At Reply show selected fictional reply only. Learn presents all six teaching/illustrations; optional links jump to that approach for practice without automatic completed status."
  },
  "close": {
    "id": "validation-others.close",
    "title": "Leave the practice here",
    "paragraphs": [
      "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.",
      "Return to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here."
    ],
    "actions": [
      "Back to practice",
      "Choose notes to keep",
      "Save session shortcut",
      "Finish and clear"
    ]
  },
  "implementationGates": {
    "capabilityClaims": "Privacy/close text must not be offered or narrated until exact persistence, explicit selected-note preview/copy/download and shortcut behaviors pass actual runtime tests. Implement the contract, do not silently remove capabilities or promise them before tests.",
    "gatedSectionIds": [
      "validation-others.privacy",
      "validation-others.close"
    ],
    "testsRequired": [
      "Internal Practice/Example/Learn/help/back retains notes and mode",
      "Leave/reload/restart/clear removes all notes and echoes",
      "Hidden writing hides all private previews",
      "No note selected by default; exact selection/preview before explicit copy/download",
      "Shortcut retains only distinct component identity in the open preview session; reload/session closure removes it; usual Toolbox is unchanged",
      "Audio contains only visible static current section, stops on navigation, and never uses private fields",
      "Free jump/Show all/Finish works without input, completion or improved emotion",
      "Later return is fresh; no planned or attempted status inferred",
      "All six approaches visible as options but only chosen approach body/notes/audio shown in Practice",
      "No approach or fictional reply default selected; changing selection stops old audio and hides all old echoes",
      "Learn exposes complete six-approach teaching; reading all is not inferred to be practice",
      "Correction and pause reply branches retain separate private revisions; no real-world reply prediction",
      "Fictional scene accessible without prefilled personal notes; no response/approach required to reach review"
    ]
  },
  "staticTextCopyContract": {
    "scope": "An explicitly requested copy/download of authored teaching or narration transcript is separate from selected personal notes. No clipboard/export on navigation, Finish, Listen, mode selection or source visit.",
    "permissions": "No source PDF copying or redistribution. Cite sources; offer only original authored static content. Personal notes never appended by default."
  },
  "id": "classic/validation",
  "componentId": "component/validation/validating-others",
  "resourceId": "tool/validation-of-others",
  "routeProposal": "/validation-of-others/",
  "title": "Validation of Others",
  "subtitle": "Take another person’s experience seriously without losing your own position",
  "version": "2026-11-03-validation-others-candidate-1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "scope": "Six recognized validation approaches taught as optional ways of responding, with an original ordinary-context rehearsal and optional correction/revision. Not a compulsory sequence, full interpersonal module or complete DBT programme.",
  "groupedSetStatus": "Validation of Others component under existing classic/validation. Current self-validation remains unchanged. No new canonical count or automatic claim the grouped set is clinically complete.",
  "clinicalContract": {
    "learningObjective": "Distinguish six ways to communicate understanding, including correction, tentative inference, known context, present facts and equal respect, without treating validation as agreement or praise.",
    "practiceObjective": "Attend to an ordinary account, choose a fitting approach, actually try a response or conduct privately, and optionally revise after a clearly fictional reply.",
    "sourcePopulationContext": "Therapist-introduced; individual developmental, communication, consent, safeguarding and support fit. No universal age gate or all-age/app validation claim. Existing self-validation source/population metadata is preserved elsewhere, not inherited as a gate.",
    "observedPractice": "Reading, selecting an approach, rehearsing a response and a live conversation are distinct. No automatic completed/practised inference from navigation or notes."
  },
  "intro": {
    "id": "validation-others.intro",
    "title": "Validation of Others",
    "paragraphs": [
      "Validation means taking seriously something you can honestly understand about another person’s experience. It does not require agreeing with every claim, praising them, excusing harm or giving up a limit.",
      "Here you can try one of six ways to respond, then practise taking in a correction. Use the fictional scene or a manageable ordinary situation with your therapist’s guidance. You can think, speak privately, sign or use optional notes; no contact with anyone is required."
    ]
  },
  "fit": {
    "id": "validation-others.fit",
    "title": "Check whether this fits",
    "paragraphs": [
      "Choose a situation where you have a choice about taking part. If there are threats, coercion, abuse or fear of retaliation, put safety and appropriate support first. You do not have to validate your way through mistreatment or keep engaging.",
      "Do not use this practice to diagnose someone, work out their hidden motives, investigate their past or take responsibility for their safety. You can acknowledge distress while leaving an accusation uncertain and refusing harmful behaviour.",
      "If the practice feels overwhelming, stop or use fiction. Eye contact, smiling, a particular posture, warmth, apology, personal disclosure and speaking aloud are not required. Adapt communication to the people and context."
    ]
  },
  "learn": {
    "id": "validation-others.learn",
    "title": "Six approaches, not six steps to complete",
    "paragraphs": [
      "Validation can be shown by attention, an accurate reflection, a tentative understanding of what is not said, known context, acknowledging present facts with an appropriate response, or treating the person as an equal. Choose what fits; you do not need to use all six in one conversation.",
      "Listening helps you check what someone means. Validation goes further into what you can honestly recognise as understandable or valid. GIVE places validation alongside a caring communication style; this page gives that part more room. Self-validation is the separate practice of acknowledging your own experience.",
      "A guess about someone’s feelings is still a guess. An explanation based on past experience is different from recognising a legitimate concern in the present. For example, do not dismiss an actual missed agreement by suggesting the other person is only upset because of their history.",
      "The purpose is an honest response, not a technique for making someone calm down, agree or like you. You can admit that you do not understand, invite clarification, keep a limit or stop. The other person may still disagree."
    ]
  },
  "scenario": {
    "id": "validation-others.scenario",
    "title": "Fictional scene: a borrowed book",
    "paragraphs": [
      "Alex agreed to return Noor’s book on Tuesday and forgot. Noor had set aside Tuesday evening to read it before a book-club meeting. The book is still with Alex. Alex can offer collection this afternoon, but does not know whether that would suit Noor.",
      "Noor says: “You said Tuesday. I kept the evening free to read it. I suppose my plans don’t matter.”",
      "The missed agreement and changed reading plans are known. The idea that Noor’s plans do not matter is Noor’s interpretation, not an established fact about Alex’s intentions. Noor has not named a feeling or described any earlier history. There is no need to invent either."
    ]
  },
  "example": {
    "id": "validation-others.example",
    "title": "Example: an acknowledgment that leaves room for correction",
    "paragraphs": [
      "Alex puts down another task and reads Noor’s message. Alex first thinks of replying, “You’re overreacting.” Instead, Alex tries: “I said Tuesday and I didn’t return it. That disrupted the reading time you planned.”",
      "Alex wonders whether Noor is disappointed, but does not state it as fact: “Are you feeling disappointed, or have I missed what matters most?” Noor replies, “I’m mostly worried I won’t finish before the group. I just need to know when I can get it.”",
      "Alex takes in the correction: “Thanks for telling me. You need a workable way to get the book. It’s here, and I can offer collection this afternoon. Would that suit you?” Noor says they need to check their schedule. Alex leaves room for that instead of pushing for a reassuring reply.",
      "In review, Alex notices the difference between acknowledging the actual missed agreement, tentatively naming a feeling, and changing the response after clarification. There is no confirmed collection yet, and Noor may still be unhappy. Alex did not need to use every approach or secure approval."
    ]
  },
  "practice": [
    {
      "id": "validation-others.practice.hear",
      "title": "Hear the situation",
      "paragraphs": [
        "Read Noor’s message, or bring to mind a suitable ordinary message you actually heard or read. Give the account a little space before planning a rebuttal.",
        "What is stated or known, and what remains uncertain? If you missed something, asking for clarification is possible. You do not need a feeling label, a motive or a personal history."
      ],
      "fields": [
        {
          "key": "situation",
          "label": "The account or situation, if I want to note it",
          "optional": true
        },
        {
          "key": "known",
          "label": "What is known and what remains uncertain",
          "optional": true
        }
      ],
      "help": {
        "title": "If I cannot tell what the person feels",
        "text": "Leave it unknown. You can attend to what they actually said or ask a tentative question. Behaviour and tone do not prove a private feeling or intention."
      }
    },
    {
      "id": "validation-others.practice.choose",
      "title": "Choose a fitting approach",
      "paragraphs": [
        "Choose one of the six approaches to explore. Each offers teaching, an illustration and something to try. You can change approaches, read them in Learn more, or leave this part unchosen.",
        "A simple approach can fit just as well as another. These are not six escalating steps, and the page will not score how many you use."
      ],
      "help": {
        "title": "If none seems to fit",
        "text": "You can acknowledge that you do not understand, ask a respectful question or pause. Do not invent a sympathetic explanation simply to produce a validating sentence."
      }
    },
    {
      "id": "validation-others.practice.try",
      "title": "Try the response privately",
      "paragraphs": [
        "Use the attempt prompt for your chosen approach. Actually try the words, imagine the conduct, sign or rehearse quietly, or use optional notes. Selecting an approach or reading its example is not the same as trying it.",
        "You can use Alex and Noor’s scene without personal disclosure. A live exchange is a separate choice; you do not need to send a message, apologize or contact anyone."
      ],
      "help": {
        "title": "If a sentence sounds scripted",
        "text": "Use plainer words that you can mean. You do not need a polished speech, forced warmth or a formula ending in “because.”"
      }
    },
    {
      "id": "validation-others.practice.reply",
      "title": "Take in a possible fictional reply",
      "paragraphs": [
        "If useful, choose one supplied possible reply from Noor. Read it and try what you could say or do next. You can revise your understanding, acknowledge a limit or leave the exchange.",
        "These replies belong to the fictional scene. They do not predict how someone in your own situation will respond. For a personal situation, use an actual reply you already know or leave the outcome open."
      ],
      "help": {
        "title": "If I want to work through my own reply instead",
        "text": "You can privately rehearse with information you actually have. Do not treat an invented answer as evidence about the other person. There is no need to record it here."
      }
    },
    {
      "id": "validation-others.practice.review",
      "title": "Review or leave",
      "paragraphs": [
        "What did you actually try, if anything? Did you stay with known facts, allow correction and respond without treating your interpretation as certain? Was there a real concern to acknowledge or a limit to keep?",
        "If useful, revise one part and try again. You can also leave with uncertainty or no change. The other person’s agreement, mood or approval is not a measure of whether you completed this page."
      ],
      "fields": [
        {
          "key": "review",
          "label": "What I noticed or might revise",
          "optional": true
        }
      ],
      "help": {
        "title": "If I did not try a response",
        "text": "You can leave it there, return to an approach or keep a question for your therapist. Nothing will be marked as a completed conversation or mastered skill."
      }
    }
  ],
  "approaches": [
    {
      "key": "attention",
      "label": "Give attention",
      "teaching": {
        "id": "validation-others.approach.attention.teaching",
        "title": "Give attention",
        "paragraphs": [
          "Attention communicates that the person’s account matters enough to hear. It does not signal agreement with every claim. You can listen, read or use another communication form that fits.",
          "A pause and room for the account may be enough; eye contact or a particular facial expression is not required. You still have a choice about continuing."
        ],
        "approach": "attention"
      },
      "illustration": {
        "id": "validation-others.approach.attention.example",
        "title": "In the book example",
        "paragraphs": [
          "Alex pauses the other task and reads the whole message before answering. Alex can recognise that Noor is describing disrupted plans without agreeing that their plans do not matter."
        ],
        "approach": "attention"
      },
      "attempt": {
        "id": "validation-others.approach.attention.attempt",
        "title": "Try give attention",
        "paragraphs": [
          "Read Noor’s message once without composing a defence. Imagine putting another task aside long enough to hear the main concern. What attentive response or pause could you actually try?",
          "For your own situation, choose a realistic way of attending. If you cannot give attention now, a respectful limit can be more honest than pretending to listen."
        ],
        "fields": [
          {
            "key": "response-attention",
            "label": "My response or conduct for this approach, if useful",
            "optional": true
          }
        ],
        "help": {
          "title": "If attention feels like surrender",
          "text": "Listening does not commit you to a request, explanation or continued contact. Keep any necessary boundary."
        },
        "approach": "attention"
      }
    },
    {
      "key": "reflect",
      "label": "Reflect accurately",
      "teaching": {
        "id": "validation-others.approach.reflect.teaching",
        "title": "Reflect accurately",
        "paragraphs": [
          "Reflection checks whether you have heard the account accurately. Use what was said or observed and leave room for correction.",
          "Do not add a diagnosis, motive or feeling that was not supplied. Reflecting that someone believes something does not establish the belief as fact."
        ],
        "approach": "reflect"
      },
      "illustration": {
        "id": "validation-others.approach.reflect.example",
        "title": "In the book example",
        "paragraphs": [
          "Alex might reflect that Noor expected the book Tuesday and planned to read that evening, then ask whether that captures the problem. This checks the account without confirming an intention to disregard Noor."
        ],
        "approach": "reflect"
      },
      "attempt": {
        "id": "validation-others.approach.reflect.attempt",
        "title": "Try reflect accurately",
        "paragraphs": [
          "Try a short reflection of Noor’s stated concern and invite correction. Include the missed return and reading plan rather than adding a feeling Noor has not named.",
          "With a personal message, use the actual words or events you know. Let the other person correct the account rather than treating your summary as the final version."
        ],
        "fields": [
          {
            "key": "response-reflect",
            "label": "My response or conduct for this approach, if useful",
            "optional": true
          }
        ],
        "help": {
          "title": "If I disagree with the interpretation",
          "text": "Acknowledge the experience or account as the person’s perspective. You do not need to repeat an accusation as though it were proven."
        },
        "approach": "reflect"
      }
    },
    {
      "key": "tentative",
      "label": "Tentatively notice the unspoken",
      "teaching": {
        "id": "validation-others.approach.tentative.teaching",
        "title": "Tentatively notice the unspoken",
        "paragraphs": [
          "Sometimes a tentative question about what has not been said can help someone feel understood. It is a guess to check, not a way to read minds.",
          "Do not treat tone, posture, the effect on you or a past pattern as proof of someone’s feelings or intentions. If there is not enough information, leave it unknown."
        ],
        "approach": "tentative"
      },
      "illustration": {
        "id": "validation-others.approach.tentative.example",
        "title": "In the book example",
        "paragraphs": [
          "Alex asks whether disappointment fits, rather than announcing that Noor feels rejected. Noor’s later clarification is new information Alex must take seriously."
        ],
        "approach": "tentative"
      },
      "attempt": {
        "id": "validation-others.approach.tentative.attempt",
        "title": "Try tentatively notice the unspoken",
        "paragraphs": [
          "In the scene, Noor has not named a feeling. Try one tentative question, or choose to ask what matters most without naming an emotion. Leave room for “No, that is not it.”",
          "If you later choose the fictional correction, revise your understanding using what Noor actually says. Do not explain why your first guess must still be right."
        ],
        "fields": [
          {
            "key": "response-tentative",
            "label": "My response or conduct for this approach, if useful",
            "optional": true
          }
        ],
        "help": {
          "title": "If guessing feels intrusive",
          "text": "Do not guess. You can ask an open question, reflect what was said or choose another approach. No emotion label is required."
        },
        "approach": "tentative"
      }
    },
    {
      "key": "context",
      "label": "Understand known context",
      "teaching": {
        "id": "validation-others.approach.context.teaching",
        "title": "Understand known context",
        "paragraphs": [
          "A response may be understandable in light of circumstances or experiences that are already known. Context can explain a reaction without making every interpretation or action accurate or acceptable.",
          "Use context that is actually available and appropriate to mention. Do not search for private history, diagnose the person or invent a cause."
        ],
        "approach": "context"
      },
      "illustration": {
        "id": "validation-others.approach.context.example",
        "title": "In the book example",
        "paragraphs": [
          "Alex can recognise why waiting for a promised book might leave Noor thinking their plans were disregarded. That makes the stated interpretation understandable in context; it does not establish Alex’s intention. By contrast, acknowledging present validity means directly owning the actual missed return and considering a fitting practical response. Neither approach requires inventing a history of being ignored."
        ],
        "approach": "context"
      },
      "attempt": {
        "id": "validation-others.approach.context.attempt",
        "title": "Try understand known context",
        "paragraphs": [
          "In the scene, Noor says “my plans don’t matter” after waiting on the promised return. Try acknowledging how the missed agreement could make that interpretation understandable, without confirming that Alex intended to disregard Noor. Do not add earlier rejection or other history.",
          "For your own situation, use only appropriate context you already know. If none is known, ask respectfully or choose another approach instead of making up a reason."
        ],
        "fields": [
          {
            "key": "response-context",
            "label": "My response or conduct for this approach, if useful",
            "optional": true
          }
        ],
        "help": {
          "title": "If the present facts already justify the concern",
          "text": "Acknowledge those facts directly. Explaining a real missed agreement as someone else’s emotional history can dismiss the issue instead of validating it."
        },
        "approach": "context"
      }
    },
    {
      "key": "valid",
      "label": "Acknowledge and act on what is valid",
      "teaching": {
        "id": "validation-others.approach.valid.teaching",
        "title": "Acknowledge and act on what is valid",
        "paragraphs": [
          "Sometimes the concern fits the present facts. Acknowledge what is true and consider an appropriate response, not only an explanation of the person’s feelings.",
          "A response might be an honest correction, practical help that is wanted, recognition of effort or keeping a necessary limit. It is not a promise to fix every problem or meet every demand."
        ],
        "approach": "valid"
      },
      "illustration": {
        "id": "validation-others.approach.valid.example",
        "title": "In the book example",
        "paragraphs": [
          "Alex acknowledges the missed return rather than blaming Noor’s reaction. Alex offers a possible collection time and asks whether it fits. The offer does not undo the missed reading time or guarantee agreement."
        ],
        "approach": "valid"
      },
      "attempt": {
        "id": "validation-others.approach.valid.attempt",
        "title": "Try acknowledge and act on what is valid",
        "paragraphs": [
          "In the scene, Alex did miss the agreed return. Try an acknowledgment of that fact, then consider the offered collection this afternoon as an option to check with Noor, not a plan decided for them.",
          "With your own situation, distinguish a valid concern from an unsupported claim or harmful demand. Offer only what is appropriate, wanted and within your role and capacity."
        ],
        "fields": [
          {
            "key": "response-valid",
            "label": "My response or conduct for this approach, if useful",
            "optional": true
          }
        ],
        "help": {
          "title": "If I can understand the feeling but not agree with the claim",
          "text": "Acknowledge the experience you can honestly understand, keep the disputed claim uncertain and retain any needed limit. Do not validate harm as acceptable or make a promise you cannot keep."
        },
        "approach": "valid"
      }
    },
    {
      "key": "equality",
      "label": "Respond as an equal",
      "teaching": {
        "id": "validation-others.approach.equality.teaching",
        "title": "Respond as an equal",
        "paragraphs": [
          "Respect the person as someone with their own knowledge, choices and abilities. Be genuine rather than patronising, treating them as helpless or putting yourself above or below them.",
          "Equal respect does not erase differences in responsibility or power. You can be honest about your limits and what you do not understand."
        ],
        "approach": "equality"
      },
      "illustration": {
        "id": "validation-others.approach.equality.example",
        "title": "In the book example",
        "paragraphs": [
          "Alex lets Noor decide whether collection fits their schedule. Alex does not tell Noor to calm down, assume they cannot manage the book-club situation, or demand that Noor say everything is fine."
        ],
        "approach": "equality"
      },
      "attempt": {
        "id": "validation-others.approach.equality.attempt",
        "title": "Try respond as an equal",
        "paragraphs": [
          "Try a response to Noor that takes their concern seriously without talking down to them or requiring reassurance. You can acknowledge what you do not know and invite their view.",
          "For your own situation, notice whether you are taking over, lecturing, demanding disclosure or pretending to understand. Try a more straightforward response, or pause."
        ],
        "fields": [
          {
            "key": "response-equality",
            "label": "My response or conduct for this approach, if useful",
            "optional": true
          }
        ],
        "help": {
          "title": "If I do not understand yet",
          "text": "It is possible to admit that and ask whether the person wants to clarify. They do not owe you more explanation, and you do not have to continue the exchange."
        },
        "approach": "equality"
      }
    }
  ],
  "responses": [
    {
      "key": "clarification",
      "label": "Noor clarifies the concern",
      "content": {
        "id": "validation-others.reply.clarification",
        "title": "A fictional clarification",
        "paragraphs": [
          "Noor says: “I’m mostly worried I won’t finish before the group. I just need to know when I can get it.”",
          "Take that as new information. If your earlier response guessed a different feeling or focused elsewhere, try revising it. What would acknowledge the stated concern and leave room to check a practical option?"
        ],
        "fields": [
          {
            "key": "revision-clarification",
            "label": "What I could try after this clarification",
            "optional": true
          }
        ],
        "help": {
          "title": "If my first response was already close",
          "text": "You can acknowledge the extra detail without inventing a mistake. The aim is to stay responsive, not to find something wrong with every attempt."
        },
        "reply": "clarification"
      }
    },
    {
      "key": "pause",
      "label": "Noor wants to pause",
      "content": {
        "id": "validation-others.reply.pause",
        "title": "A fictional pause",
        "paragraphs": [
          "Noor says: “I don’t want to discuss it now.”",
          "Try a response that respects the pause. You do not need to keep explaining or obtain forgiveness. You can leave the conversation without deciding how Noor must feel."
        ],
        "fields": [
          {
            "key": "revision-pause",
            "label": "What I could say or do when a pause is requested",
            "optional": true
          }
        ],
        "help": {
          "title": "If a practical detail still matters",
          "text": "Keep any genuinely necessary communication brief and proportionate. In this rehearsal you can leave the next arrangement unresolved; no message needs to be sent."
        },
        "reply": "pause"
      }
    }
  ],
  "methodElements": [
    "Attention",
    "Accurate reflection open to correction",
    "Tentative sensitivity to unspoken experience",
    "Understanding appropriate known context",
    "Acknowledging present validity with appropriate action",
    "Authentic equal respect"
  ],
  "methodTraceability": {
    "primaryProcedure": "Linehan historical2015 Interpersonal Effectiveness Handouts17–18a, PDF pp39–41; Worksheet12, p70; teaching notes PDF pp65,69–73.",
    "mapping": {
      "attention": {
        "sourceApproach": 1,
        "teachingId": "validation-others.approach.attention.teaching",
        "attemptId": "validation-others.approach.attention.attempt"
      },
      "reflect": {
        "sourceApproach": 2,
        "teachingId": "validation-others.approach.reflect.teaching",
        "attemptId": "validation-others.approach.reflect.attempt"
      },
      "tentative": {
        "sourceApproach": 3,
        "teachingId": "validation-others.approach.tentative.teaching",
        "attemptId": "validation-others.approach.tentative.attempt"
      },
      "context": {
        "sourceApproach": 4,
        "teachingId": "validation-others.approach.context.teaching",
        "attemptId": "validation-others.approach.context.attempt"
      },
      "valid": {
        "sourceApproach": 5,
        "teachingId": "validation-others.approach.valid.teaching",
        "attemptId": "validation-others.approach.valid.attempt"
      },
      "equality": {
        "sourceApproach": 6,
        "teachingId": "validation-others.approach.equality.teaching",
        "attemptId": "validation-others.approach.equality.attempt"
      }
    },
    "scopeLimit": "All six approaches available to learn/try. A single selected practice is not all-six practice, mastery or full DBT. A private fictional correction is an original learning scaffold, not the source group exercise or a prediction.",
    "identity": "Existing classic/validation and component/validation/validating-others. tool/validation-of-others and local /validation-of-others/ newly proposed, not accepted legacy replacements. DA15/DA19/DA25/giving-support remain grouped source leads, not silently remapped."
  },
  "sources": [
    {
      "id": "linehan-interpersonal2015",
      "url": "https://www.guilford.com/add/linehan6_old/lin-c-2.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "Handouts17–18a and Worksheet12: six approaches, validation versus agreement, practice review even when little/no attempt.",
      "limits": "Historical2015, not exact revised2025 wording, app efficacy or population validation. No copied worksheets/examples."
    },
    {
      "id": "linehan-teaching2015",
      "url": "https://www.guilford.com/add/linehan7_old/lin-p-2teaching.pdf?t=1",
      "reviewed": "2026-11-03",
      "supports": "PDF pp65,69–73: actual practice, tentative inference/correction, known causes versus current validity and action, genuine equal respect.",
      "limits": "Teacher-facing source; this private rehearsal is an original bounded adaptation."
    },
    {
      "id": "behavioraltech-give2",
      "url": "https://behavioraltech.org/teaching-give-skills-part-2/",
      "reviewed": "2026-11-03",
      "supports": "Author teaching commentary distinguishes validation from praise or superficial acknowledgment and supports not abandoning limits.",
      "limits": "2021 commentary, not clinical evidence for this app or a guarantee of another person’s response."
    }
  ],
  "productAdaptations": [
    "Original book scene, approach illustrations and optional fictional replies; no publisher worksheet/example reproduction.",
    "Six selectable approaches instead of a mandatory six-stage ladder; all remain teachable and practicable.",
    "No required gaze, facial expression, voice, emotion label, disclosure, apology or contact.",
    "No diagnosis, speculation about history, inferred private intent, scoring, automatic text interpretation or guaranteed outcome."
  ],
  "relatedResources": {
    "status": "Only link after verifying exact private routes; no remapping/replacement.",
    "resources": [
      "classic/give",
      "tool/listen-and-check-understanding",
      "component/validation/self-validation"
    ]
  },
  "narrationSegments": [
    {
      "id": "validation-others.privacy",
      "title": "Writing is optional",
      "text": "You can think privately, speak, use your own paper, or add optional notes here. Notes stay in this open tool while you move between practice, the example and help.\n\nLeaving this tool, reloading, clearing or starting again removes the notes here. To keep something, select the notes you want, check the preview, then choose copy or download. A copy you keep remains outside this tool until you remove it.\n\nReview session only: this shortcut lasts in this open session. It is not saved to your usual Toolbox. No answers are saved. Your notes are not sent to your therapist or read aloud. This tool is not monitored.",
      "textSha256": "08e5d33489f269867a52f82337eafbed695f22fd860232e4a1260c736a31d56d",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "capabilityGate": "Unavailable until actual renderer capability claims verified."
    },
    {
      "id": "validation-others.intro",
      "title": "Validation of Others",
      "text": "Validation means taking seriously something you can honestly understand about another person’s experience. It does not require agreeing with every claim, praising them, excusing harm or giving up a limit.\n\nHere you can try one of six ways to respond, then practise taking in a correction. Use the fictional scene or a manageable ordinary situation with your therapist’s guidance. You can think, speak privately, sign or use optional notes; no contact with anyone is required.",
      "textSha256": "3a689cc824e34a738d609c0d83e863c5b77a93a49d4b9c98b2030b099d32bea1",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.fit",
      "title": "Check whether this fits",
      "text": "Choose a situation where you have a choice about taking part. If there are threats, coercion, abuse or fear of retaliation, put safety and appropriate support first. You do not have to validate your way through mistreatment or keep engaging.\n\nDo not use this practice to diagnose someone, work out their hidden motives, investigate their past or take responsibility for their safety. You can acknowledge distress while leaving an accusation uncertain and refusing harmful behaviour.\n\nIf the practice feels overwhelming, stop or use fiction. Eye contact, smiling, a particular posture, warmth, apology, personal disclosure and speaking aloud are not required. Adapt communication to the people and context.",
      "textSha256": "5366907a938e8167b9bfc86150cd46ccbddc4d1d56d70ff4303013bc7047885f",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.learn",
      "title": "Six approaches, not six steps to complete",
      "text": "Validation can be shown by attention, an accurate reflection, a tentative understanding of what is not said, known context, acknowledging present facts with an appropriate response, or treating the person as an equal. Choose what fits; you do not need to use all six in one conversation.\n\nListening helps you check what someone means. Validation goes further into what you can honestly recognise as understandable or valid. GIVE places validation alongside a caring communication style; this page gives that part more room. Self-validation is the separate practice of acknowledging your own experience.\n\nA guess about someone’s feelings is still a guess. An explanation based on past experience is different from recognising a legitimate concern in the present. For example, do not dismiss an actual missed agreement by suggesting the other person is only upset because of their history.\n\nThe purpose is an honest response, not a technique for making someone calm down, agree or like you. You can admit that you do not understand, invite clarification, keep a limit or stop. The other person may still disagree.",
      "textSha256": "4930a3aa796046dd462bad6e7124aa93632a86f5926ca49cdd90881f0fc6ec98",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.scenario",
      "title": "Fictional scene: a borrowed book",
      "text": "Alex agreed to return Noor’s book on Tuesday and forgot. Noor had set aside Tuesday evening to read it before a book-club meeting. The book is still with Alex. Alex can offer collection this afternoon, but does not know whether that would suit Noor.\n\nNoor says: “You said Tuesday. I kept the evening free to read it. I suppose my plans don’t matter.”\n\nThe missed agreement and changed reading plans are known. The idea that Noor’s plans do not matter is Noor’s interpretation, not an established fact about Alex’s intentions. Noor has not named a feeling or described any earlier history. There is no need to invent either.",
      "textSha256": "9925b4cc568add4d544eb900692cc00a9bb0ad6bba59b60dc38ca1e6843168ac",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.example",
      "title": "Example: an acknowledgment that leaves room for correction",
      "text": "Alex puts down another task and reads Noor’s message. Alex first thinks of replying, “You’re overreacting.” Instead, Alex tries: “I said Tuesday and I didn’t return it. That disrupted the reading time you planned.”\n\nAlex wonders whether Noor is disappointed, but does not state it as fact: “Are you feeling disappointed, or have I missed what matters most?” Noor replies, “I’m mostly worried I won’t finish before the group. I just need to know when I can get it.”\n\nAlex takes in the correction: “Thanks for telling me. You need a workable way to get the book. It’s here, and I can offer collection this afternoon. Would that suit you?” Noor says they need to check their schedule. Alex leaves room for that instead of pushing for a reassuring reply.\n\nIn review, Alex notices the difference between acknowledging the actual missed agreement, tentatively naming a feeling, and changing the response after clarification. There is no confirmed collection yet, and Noor may still be unhappy. Alex did not need to use every approach or secure approval.",
      "textSha256": "fee20ed7d3f9c3e7fd8c3e4ba2a64dfb834058e178911538c90df50e7e306da8",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.practice.hear",
      "title": "Hear the situation",
      "text": "Read Noor’s message, or bring to mind a suitable ordinary message you actually heard or read. Give the account a little space before planning a rebuttal.\n\nWhat is stated or known, and what remains uncertain? If you missed something, asking for clarification is possible. You do not need a feeling label, a motive or a personal history.",
      "textSha256": "a2399bc08397d903ba6921e4923776f6986ed9b5ff42dcb632c49c11291fb342",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.practice.hear.help",
      "title": "If I cannot tell what the person feels",
      "text": "Leave it unknown. You can attend to what they actually said or ask a tentative question. Behaviour and tone do not prove a private feeling or intention.",
      "textSha256": "99284f7489559b5ba71e3eaf8d52466d8bfd6e0ca8d2fc3232eb7a69ff451ee8",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded."
    },
    {
      "id": "validation-others.practice.choose",
      "title": "Choose a fitting approach",
      "text": "Choose one of the six approaches to explore. Each offers teaching, an illustration and something to try. You can change approaches, read them in Learn more, or leave this part unchosen.\n\nA simple approach can fit just as well as another. These are not six escalating steps, and the page will not score how many you use.",
      "textSha256": "c812d5cc88240dd09e9066f20cd645f5d0f66d01a29c10d1f22ea7ff3b05d528",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.practice.choose.help",
      "title": "If none seems to fit",
      "text": "You can acknowledge that you do not understand, ask a respectful question or pause. Do not invent a sympathetic explanation simply to produce a validating sentence.",
      "textSha256": "6756ad2baf9968af95b42b5a10cbd397c14d64ccd6e00af2081e312dac4e4bae",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded."
    },
    {
      "id": "validation-others.practice.try",
      "title": "Try the response privately",
      "text": "Use the attempt prompt for your chosen approach. Actually try the words, imagine the conduct, sign or rehearse quietly, or use optional notes. Selecting an approach or reading its example is not the same as trying it.\n\nYou can use Alex and Noor’s scene without personal disclosure. A live exchange is a separate choice; you do not need to send a message, apologize or contact anyone.",
      "textSha256": "0e33278bb37bd5b0f26d46cb85ff6c5955baf5ac4a3b071508aae5d0803d9f1e",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.practice.try.help",
      "title": "If a sentence sounds scripted",
      "text": "Use plainer words that you can mean. You do not need a polished speech, forced warmth or a formula ending in “because.”",
      "textSha256": "63d1f8c50705ed312a774e406ae4c7755efd0c4469bc5f52eb0c3fe482a280af",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded."
    },
    {
      "id": "validation-others.practice.reply",
      "title": "Take in a possible fictional reply",
      "text": "If useful, choose one supplied possible reply from Noor. Read it and try what you could say or do next. You can revise your understanding, acknowledge a limit or leave the exchange.\n\nThese replies belong to the fictional scene. They do not predict how someone in your own situation will respond. For a personal situation, use an actual reply you already know or leave the outcome open.",
      "textSha256": "ad34219cd06e9dea1cba3940295d8a09854d6f153c41f082c932d6c284b34c94",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.practice.reply.help",
      "title": "If I want to work through my own reply instead",
      "text": "You can privately rehearse with information you actually have. Do not treat an invented answer as evidence about the other person. There is no need to record it here.",
      "textSha256": "ba68867f354b7a0c11b386117332f690a00a90e70290314956496d5fb3d384cd",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded."
    },
    {
      "id": "validation-others.practice.review",
      "title": "Review or leave",
      "text": "What did you actually try, if anything? Did you stay with known facts, allow correction and respond without treating your interpretation as certain? Was there a real concern to acknowledge or a limit to keep?\n\nIf useful, revise one part and try again. You can also leave with uncertainty or no change. The other person’s agreement, mood or approval is not a measure of whether you completed this page.",
      "textSha256": "7eb0169c834f62dbc1b881756729fd438dd11ea413c4bdd719b13a950e5cd516",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch."
    },
    {
      "id": "validation-others.practice.review.help",
      "title": "If I did not try a response",
      "text": "You can leave it there, return to an approach or keep a question for your therapist. Nothing will be marked as a completed conversation or mastered skill.",
      "textSha256": "37d62a10141c61efe715ed9e32e716cdea4de4d4c0083047260b1a6fce1fd2d8",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded."
    },
    {
      "id": "validation-others.close",
      "title": "Leave the practice here",
      "text": "You can finish after reading, planning, trying something, reviewing or deciding this does not fit. You do not have to feel better or reach a result.\n\nReturn to any part, select notes you want to keep, save a shortcut for this open session, or finish and clear the notes here.",
      "textSha256": "c9171e9f0e25d189db3f09fbfa5ba8707d92ece31276d5ba3baa1b8bcbdbf102",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "capabilityGate": "Unavailable until actual renderer capability claims verified."
    },
    {
      "id": "validation-others.approach.attention.teaching",
      "title": "Give attention",
      "text": "Attention communicates that the person’s account matters enough to hear. It does not signal agreement with every claim. You can listen, read or use another communication form that fits.\n\nA pause and room for the account may be enough; eye contact or a particular facial expression is not required. You still have a choice about continuing.",
      "textSha256": "ee7b40d772fbb2c02df9ae97b97b3b9749d662557264d9f787a80a13bfebef8f",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "attention"
    },
    {
      "id": "validation-others.approach.attention.example",
      "title": "In the book example",
      "text": "Alex pauses the other task and reads the whole message before answering. Alex can recognise that Noor is describing disrupted plans without agreeing that their plans do not matter.",
      "textSha256": "ce80c8ce12c4b654d05366ea1f22429df983eff0a2efa505300f1c033831b488",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "attention"
    },
    {
      "id": "validation-others.approach.attention.attempt",
      "title": "Try give attention",
      "text": "Read Noor’s message once without composing a defence. Imagine putting another task aside long enough to hear the main concern. What attentive response or pause could you actually try?\n\nFor your own situation, choose a realistic way of attending. If you cannot give attention now, a respectful limit can be more honest than pretending to listen.",
      "textSha256": "ed95ca8b1764f008bba545fbd647da08c652fcc253181be091d16b944bd6ff8e",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "attention"
    },
    {
      "id": "validation-others.approach.attention.attempt.help",
      "title": "If attention feels like surrender",
      "text": "Listening does not commit you to a request, explanation or continued contact. Keep any necessary boundary.",
      "textSha256": "fa247f5edc162e3eb4488a89496f57da11d926121abc8f53a6360adba648635e",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "approach": "attention"
    },
    {
      "id": "validation-others.approach.reflect.teaching",
      "title": "Reflect accurately",
      "text": "Reflection checks whether you have heard the account accurately. Use what was said or observed and leave room for correction.\n\nDo not add a diagnosis, motive or feeling that was not supplied. Reflecting that someone believes something does not establish the belief as fact.",
      "textSha256": "b5eed8c232b9dba2c1ab274df568169e879e778558118c8afbe3c234f850a90c",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "reflect"
    },
    {
      "id": "validation-others.approach.reflect.example",
      "title": "In the book example",
      "text": "Alex might reflect that Noor expected the book Tuesday and planned to read that evening, then ask whether that captures the problem. This checks the account without confirming an intention to disregard Noor.",
      "textSha256": "a2f2686388b6a9a197ee583c4f6f89e48f5cd85fc6f33419a4ee1e89fdb0d0d6",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "reflect"
    },
    {
      "id": "validation-others.approach.reflect.attempt",
      "title": "Try reflect accurately",
      "text": "Try a short reflection of Noor’s stated concern and invite correction. Include the missed return and reading plan rather than adding a feeling Noor has not named.\n\nWith a personal message, use the actual words or events you know. Let the other person correct the account rather than treating your summary as the final version.",
      "textSha256": "1550f080adbfadd81bac6c933cde1e755d8274fc1d6ff312ff1b1db5a2012086",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "reflect"
    },
    {
      "id": "validation-others.approach.reflect.attempt.help",
      "title": "If I disagree with the interpretation",
      "text": "Acknowledge the experience or account as the person’s perspective. You do not need to repeat an accusation as though it were proven.",
      "textSha256": "69222510615e03fcbe1c92ce68066d31ea9bc1261a451e47cfbbb79eb6757a0a",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "approach": "reflect"
    },
    {
      "id": "validation-others.approach.tentative.teaching",
      "title": "Tentatively notice the unspoken",
      "text": "Sometimes a tentative question about what has not been said can help someone feel understood. It is a guess to check, not a way to read minds.\n\nDo not treat tone, posture, the effect on you or a past pattern as proof of someone’s feelings or intentions. If there is not enough information, leave it unknown.",
      "textSha256": "e332a0dd75f4e809ce36a2ef3c61d274bdeeea985a0d7dddf67e1f97781260ee",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "tentative"
    },
    {
      "id": "validation-others.approach.tentative.example",
      "title": "In the book example",
      "text": "Alex asks whether disappointment fits, rather than announcing that Noor feels rejected. Noor’s later clarification is new information Alex must take seriously.",
      "textSha256": "5aef55de300343d475cd7704a5d9f2debee9df397d05ecce277764fab39b11a1",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "tentative"
    },
    {
      "id": "validation-others.approach.tentative.attempt",
      "title": "Try tentatively notice the unspoken",
      "text": "In the scene, Noor has not named a feeling. Try one tentative question, or choose to ask what matters most without naming an emotion. Leave room for “No, that is not it.”\n\nIf you later choose the fictional correction, revise your understanding using what Noor actually says. Do not explain why your first guess must still be right.",
      "textSha256": "43270d20ace0d1e3375a7baf3439586dc6bdf9cf5064788e2457b0a9d52f41f6",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "tentative"
    },
    {
      "id": "validation-others.approach.tentative.attempt.help",
      "title": "If guessing feels intrusive",
      "text": "Do not guess. You can ask an open question, reflect what was said or choose another approach. No emotion label is required.",
      "textSha256": "a1328e1685ddae3033362cb45ad73d040b49533dc6e6edfc91ec77075958c404",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "approach": "tentative"
    },
    {
      "id": "validation-others.approach.context.teaching",
      "title": "Understand known context",
      "text": "A response may be understandable in light of circumstances or experiences that are already known. Context can explain a reaction without making every interpretation or action accurate or acceptable.\n\nUse context that is actually available and appropriate to mention. Do not search for private history, diagnose the person or invent a cause.",
      "textSha256": "211d4de99fb89cc254ce5df05772ce31fed10c723e5a103f43ec84888c997794",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "context"
    },
    {
      "id": "validation-others.approach.context.example",
      "title": "In the book example",
      "text": "Alex can recognise why waiting for a promised book might leave Noor thinking their plans were disregarded. That makes the stated interpretation understandable in context; it does not establish Alex’s intention. By contrast, acknowledging present validity means directly owning the actual missed return and considering a fitting practical response. Neither approach requires inventing a history of being ignored.",
      "textSha256": "5a5194d211e332d4ad32874e6255ecdd91e836007248e883bd99a37652e8a195",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "context"
    },
    {
      "id": "validation-others.approach.context.attempt",
      "title": "Try understand known context",
      "text": "In the scene, Noor says “my plans don’t matter” after waiting on the promised return. Try acknowledging how the missed agreement could make that interpretation understandable, without confirming that Alex intended to disregard Noor. Do not add earlier rejection or other history.\n\nFor your own situation, use only appropriate context you already know. If none is known, ask respectfully or choose another approach instead of making up a reason.",
      "textSha256": "6aa41f5a4789ddcebbc16e717cf906624053d88d4a388999496379b284746e08",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "context"
    },
    {
      "id": "validation-others.approach.context.attempt.help",
      "title": "If the present facts already justify the concern",
      "text": "Acknowledge those facts directly. Explaining a real missed agreement as someone else’s emotional history can dismiss the issue instead of validating it.",
      "textSha256": "22b2e2144a82578988128ae0bb61c2064a5ead38d488aa009ead145c3dd61b1c",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "approach": "context"
    },
    {
      "id": "validation-others.approach.valid.teaching",
      "title": "Acknowledge and act on what is valid",
      "text": "Sometimes the concern fits the present facts. Acknowledge what is true and consider an appropriate response, not only an explanation of the person’s feelings.\n\nA response might be an honest correction, practical help that is wanted, recognition of effort or keeping a necessary limit. It is not a promise to fix every problem or meet every demand.",
      "textSha256": "26a2229c182c037122c25d9684cda9e10e7900d69d5591ecb7648abc93ffde96",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "valid"
    },
    {
      "id": "validation-others.approach.valid.example",
      "title": "In the book example",
      "text": "Alex acknowledges the missed return rather than blaming Noor’s reaction. Alex offers a possible collection time and asks whether it fits. The offer does not undo the missed reading time or guarantee agreement.",
      "textSha256": "ce5d3cfd814a241cd8f067622f9c9307c2eab0475e97a5c24aced641c84f60fc",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "valid"
    },
    {
      "id": "validation-others.approach.valid.attempt",
      "title": "Try acknowledge and act on what is valid",
      "text": "In the scene, Alex did miss the agreed return. Try an acknowledgment of that fact, then consider the offered collection this afternoon as an option to check with Noor, not a plan decided for them.\n\nWith your own situation, distinguish a valid concern from an unsupported claim or harmful demand. Offer only what is appropriate, wanted and within your role and capacity.",
      "textSha256": "ac82c0774914fcf852dcb54de3f43de6511c0e33496418a285474a62de4a62ca",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "valid"
    },
    {
      "id": "validation-others.approach.valid.attempt.help",
      "title": "If I can understand the feeling but not agree with the claim",
      "text": "Acknowledge the experience you can honestly understand, keep the disputed claim uncertain and retain any needed limit. Do not validate harm as acceptable or make a promise you cannot keep.",
      "textSha256": "ea5ddc2a4bf96b14ac2e411c92e65f020cfb9ddf77401c172e059f2fbe89c52d",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "approach": "valid"
    },
    {
      "id": "validation-others.approach.equality.teaching",
      "title": "Respond as an equal",
      "text": "Respect the person as someone with their own knowledge, choices and abilities. Be genuine rather than patronising, treating them as helpless or putting yourself above or below them.\n\nEqual respect does not erase differences in responsibility or power. You can be honest about your limits and what you do not understand.",
      "textSha256": "3a1d9ba6e2468a7a99d93ce1f25d6cba71ed85b34a91968c98a056c38fc55426",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "equality"
    },
    {
      "id": "validation-others.approach.equality.example",
      "title": "In the book example",
      "text": "Alex lets Noor decide whether collection fits their schedule. Alex does not tell Noor to calm down, assume they cannot manage the book-club situation, or demand that Noor say everything is fine.",
      "textSha256": "1027875cc544c14cfc15603087bcaff76c03e3a151537c6e31a183519d0f0d74",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "equality"
    },
    {
      "id": "validation-others.approach.equality.attempt",
      "title": "Try respond as an equal",
      "text": "Try a response to Noor that takes their concern seriously without talking down to them or requiring reassurance. You can acknowledge what you do not know and invite their view.\n\nFor your own situation, notice whether you are taking over, lecturing, demanding disclosure or pretending to understand. Try a more straightforward response, or pause.",
      "textSha256": "17e83d94c3abb87f818c037e2334317da476cf8fadf3829d423f7ddeff0719ad",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "approach": "equality"
    },
    {
      "id": "validation-others.approach.equality.attempt.help",
      "title": "If I do not understand yet",
      "text": "It is possible to admit that and ask whether the person wants to clarify. They do not owe you more explanation, and you do not have to continue the exchange.",
      "textSha256": "60845369ee1f3ce428dc15fb7fe8f511020570ef14d31271f6ee94e2bceda2f3",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "approach": "equality"
    },
    {
      "id": "validation-others.reply.clarification",
      "title": "A fictional clarification",
      "text": "Noor says: “I’m mostly worried I won’t finish before the group. I just need to know when I can get it.”\n\nTake that as new information. If your earlier response guessed a different feeling or focused elsewhere, try revising it. What would acknowledge the stated concern and leave room to check a practical option?",
      "textSha256": "2f0b0e84f696d788b01c5d8969835c0545df3c424bf80d97e346ec03811afda1",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "reply": "clarification"
    },
    {
      "id": "validation-others.reply.clarification.help",
      "title": "If my first response was already close",
      "text": "You can acknowledge the extra detail without inventing a mistake. The aim is to stay responsive, not to find something wrong with every attempt.",
      "textSha256": "95066ed0e3e3a555400b2f48e5210c915f2ac477ef2233381f4d06fc81fa7b05",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "reply": "clarification"
    },
    {
      "id": "validation-others.reply.pause",
      "title": "A fictional pause",
      "text": "Noor says: “I don’t want to discuss it now.”\n\nTry a response that respects the pause. You do not need to keep explaining or obtain forgiveness. You can leave the conversation without deciding how Noor must feel.",
      "textSha256": "79ea1022588083989dc87b57e846f37425b03906fc7a41427964aff84a169135",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact current visible authored paragraphs only. No heading, field label, control, private response or unselected branch.",
      "reply": "pause"
    },
    {
      "id": "validation-others.reply.pause.help",
      "title": "If a practical detail still matters",
      "text": "Keep any genuinely necessary communication brief and proportionate. In this rehearsal you can leave the next arrangement unresolved; no message needs to be sent.",
      "textSha256": "a3df9cf4fb21a55ade9e3f1a1a3ce542afbfcaeec3e29f5b1eac107c2a9d9b5b",
      "status": "Candidate static script only; no generation or listening approval",
      "visibleScope": "Exact authored help only while its associated section is visible and help expanded; private text excluded.",
      "reply": "pause"
    }
  ]
}
;
