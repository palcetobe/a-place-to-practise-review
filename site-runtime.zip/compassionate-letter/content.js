window.NightSkillContent={
  "schema": "a-place-to-practise.skill-content.v1",
  "privacy": {
    "id": "compassion.privacy",
    "title": "Your writing is optional",
    "paragraphs": [
      "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.",
      "Leaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders."
    ]
  },
  "support": {
    "label": "Support and urgent help",
    "placement": "Always available, including before practice and outside focus folds.",
    "destination": "Reuse the existing project support route; do not invent or silently change contacts."
  },
  "interactionContract": {
    "navigation": [
      "Practice this skill",
      "See an example",
      "Learn more"
    ],
    "focus": "One focused prompt group by default; Show all, free jump, Back and Finish available. Contextual help next to the relevant prompt.",
    "writing": "Hidden by default and optional throughout; hide all private echoes when writing is hidden.",
    "modes": [
      "practice"
    ],
    "persistence": "Session-only, no localStorage, account, diary, reminders, personal export or backend writes.",
    "narration": "Script only until exact-match assets, listening and integration gates pass. No private text voiced.",
    "timer": "None; practice can be brief or stopped at any point.",
    "visual": "Text-equivalent low-load orientation only; no score, streak, success animation or new per-skill icon.",
    "fictionalPractice": "Show the optional fictional practice card before the first prompt, and keep it accessible from every relevant prompt. Personal/fictitious practice is a preference, not a completion gate. Do not prefill private input or infer a choice from a blank field.",
    "assembledLetter": {
      "placement": "At compassion-letter.practice.review, adjacent to the whole-letter review prompt, also available in Show all.",
      "label": "Your letter so far",
      "fields": [
        "acknowledge",
        "perspective",
        "response"
      ],
      "behavior": "Show the user-authored nonempty sections together in original order as one read-only preview only when optional writing is shown. No invented joins, autofill, scoring or interpretation. Provide an adjacent edit/back affordance that retains all sections.",
      "emptyState": "No letter has been entered here. You can review words privately or on your own paper, go back to compose, or finish.",
      "privacy": "Hide the entire preview and every private echo when writing is hidden. Clear on leave, reload, clear or restart. Never narrate it or copy it into any static script.",
      "alternative": "Private rehearsal or paper remains valid; do not infer a letter was composed from an empty field."
    }
  },
  "acceptance": [
    "Exact canonical ID, distinct technique and honest bounded scope.",
    "Intro, fit, why, complete example and actual practice all accessible.",
    "All writing and review optional; Finish always available.",
    "No forced relief, positivity, ratings or new action plan.",
    "Client-visible fit and always-reachable support.",
    "Examples show an actual attempt and neutral review, not only a hypothetical plan.",
    "Leaving tool clears; internal teaching/example navigation retains. Verify in UI.",
    "Narration status remains honest until matching assets, listening and integration pass."
  ],
  "id": "classic/compassion",
  "title": "Compassionate Letter",
  "subtitle": "A credible, caring response to a difficult moment",
  "scope": "Compassionate Letter component of Compassionate Thought Diary / Letter. Not the thought-diary format, compassionate imagery or a complete compassion-focused therapy.",
  "resourceId": "tool/compassionate-letter",
  "routeProposal": "tool/compassionate-letter",
  "version": "2026-11-02-night-v1",
  "status": "Public REVIEW written candidate. Clinical, source-rights, developmental/access fit and browser acceptance remain pending. Audio is unavailable.",
  "clinicalContract": {
    "learningObjective": "Distinguish a caring, realistic response from forced praise, excusing harm or pretending the difficulty is solved.",
    "practiceObjective": "Form a short compassionate letter for one manageable difficulty, then read or privately hear the words and review whether their tone and meaning fit.",
    "observedPractice": "Reading, preparing and actually trying are distinct; no compulsory writing, rating, relief or mastery claim.",
    "sourcePopulationContext": "Therapist-supported practice with individual review of development, communication, consent, privacy, safeguarding and circumstances. Adult source recognition does not validate this digital adaptation or establish suitability across ages. Method-specific source populations and suitability limits still apply."
  },
  "componentId": "component/compassion/letter",
  "groupedSetStatus": "Letter component only; diary and imagery not marked built. No new canonical count.",
  "intro": {
    "id": "compassion-letter.intro",
    "title": "Write to yourself without taking the critic’s side",
    "paragraphs": [
      "A compassionate letter acknowledges a difficulty and responds with care and perspective. It can be short and plain. It does not need to sound positive or make you feel warm.",
      "You can write here, use your own paper, or compose the words privately. Privately trying the wording is an accessible rehearsal, not a saved written letter. Reading the example is also welcome."
    ],
    "actions": [
      {
        "id": "practice",
        "label": "Practice this skill"
      }
    ]
  },
  "fit": {
    "id": "compassion-letter.fit",
    "title": "Choose a manageable subject",
    "paragraphs": [
      "Use this with your therapist between sessions. Choose a recent ordinary difficulty or the fictional example, not your most painful memory.",
      "You do not need to imagine a caregiver, recall a safe place, change your breathing, forgive anyone or excuse harm. If compassionate language brings shame, grief or threat, use neutral respectful words, pause, or discuss the fit with your therapist. Support does not have to wait until you finish."
    ]
  },
  "learn": {
    "id": "compassion-letter.learn",
    "title": "Why use a letter?",
    "paragraphs": [
      "Self-criticism can turn a specific difficulty into a verdict about the whole person. A letter makes room to describe what hurts without adding that verdict.",
      "The method has three parts: acknowledge the difficulty, offer a realistic caring perspective, and consider what support or response might fit. Join these into a message to yourself, then read or privately hear it. That final reading lets you check whether the words actually feel credible, rather than simply collecting kind phrases.",
      "Care and responsibility can coexist. You can recognise a mistake and consider repair without using insults. A letter does not decide disputed facts or require an action plan."
    ]
  },
  "example": {
    "id": "compassion-letter.example",
    "title": "Example — a missed message",
    "paragraphs": [
      "Lee forgot to reply to a friend and thinks, “I’m a terrible friend.” Lee writes a short letter:",
      "“Lee, you feel upset that your friend was left waiting. You care about being dependable. Missing this message is something specific to acknowledge; it is not the whole story of how you treat people. You can offer a brief apology if that fits, without promising never to miss anything again. You also deserve a respectful response from yourself while you work out what to do.”",
      "Lee reads it and finds “deserve” awkward. Lee changes the last sentence to “Insulting yourself is not required to take responsibility.” Guilt remains, but the revised letter sounds more believable. Lee stops there; sending an apology is a separate decision, not completion of this exercise."
    ]
  },
  "practiceScenario": {
    "id": "compassion-letter.scenario",
    "title": "Optional fictional practice — Robin",
    "paragraphs": [
      "Robin did not finish an ordinary personal project and says, “I never do anything properly.” Robin had less time than expected and still cares about the project.",
      "Try a short letter that takes the disappointment seriously without making a global judgment or insisting Robin finish today. You can also use your own manageable example or just read."
    ]
  },
  "practice": [
    {
      "id": "compassion-letter.practice.acknowledge",
      "title": "Acknowledge what is difficult",
      "paragraphs": [
        "Address yourself by name, say “Dear me,” or leave out a greeting. Describe the specific difficulty and what is hard about it, without making a verdict about your worth.",
        "One or two sentences are enough. Keep details private if you prefer."
      ],
      "fields": [
        {
          "key": "acknowledge",
          "label": "What I want to acknowledge",
          "optional": true
        }
      ],
      "help": {
        "title": "If this sounds like self-pity",
        "text": "Acknowledging pain does not exaggerate it or deny anyone else’s experience. Plain description is enough."
      }
    },
    {
      "id": "compassion-letter.practice.perspective",
      "title": "Offer a credible caring perspective",
      "paragraphs": [
        "What context would a respectful, well-informed response include? Recognise limits, effort, needs or a specific mistake without pretending it does not matter.",
        "Use words you can stand behind. You do not need praise, “everyone does this,” or a promise it will work out."
      ],
      "fields": [
        {
          "key": "perspective",
          "label": "A caring perspective that seems believable",
          "optional": true
        }
      ],
      "help": {
        "title": "If kind words feel false",
        "text": "Try neutral fairness: “This is a specific difficulty, not a complete description of me.” Change or reject that sentence if it does not fit."
      }
    },
    {
      "id": "compassion-letter.practice.response",
      "title": "Consider care or support",
      "paragraphs": [
        "What might a caring response offer here: understanding, a boundary, rest, support, or a possible repair? You can leave the next step undecided.",
        "Add a closing sentence in your own voice. This is a letter, not a demand to earn kindness by doing something."
      ],
      "fields": [
        {
          "key": "response",
          "label": "A response or closing sentence, if useful",
          "optional": true
        }
      ],
      "help": {
        "title": "For Robin’s example",
        "text": "A possible response recognises the time limit and disappointment, without calling Robin lazy. It could offer a pause before deciding whether to resize the project. That is one possible response, not the correct answer."
      }
    },
    {
      "id": "compassion-letter.practice.review",
      "title": "Read it as a whole",
      "paragraphs": [
        "If you made a letter, read it once or privately hear the sentences together. Does it acknowledge the difficulty and speak respectfully without making claims you do not believe?",
        "Change a sentence, keep it, or leave it unfinished. Notice the fit, not whether you feel better. If you only read the example, you can finish without claiming to have written or rehearsed a letter."
      ],
      "fields": [
        {
          "key": "review",
          "label": "Something I would keep or change",
          "optional": true
        }
      ],
      "help": {
        "title": "If it still sounds critical",
        "text": "Notice any hidden “should” or demand. You can soften that, use a neutral sentence, stop, or bring the unfinished letter to a therapist."
      }
    }
  ],
  "close": {
    "id": "compassion-letter.close",
    "title": "The letter can stay unfinished",
    "paragraphs": [
      "You can finish whether the words feel helpful, awkward or unchanged. No action or feeling is required. This page does not save your letter; use your own private record if you want to keep one."
    ],
    "actions": [
      "Back to practice",
      "Finish and clear"
    ]
  },
  "sources": [
    {
      "url": "https://www.cci.health.wa.gov.au/-/media/CCI/Consumer-Modules/Building-Self-Compassion/Building-Self-Compassion---05---Self-Compassionate-Thinking.pdf",
      "reviewed": "2026-11-02",
      "supports": "Printed pp8–9: specific difficulty, compassionate letter perspective and response; distinct format from thought diary. Reopened direct primary PDF.",
      "limits": "Source sequences slow breathing/imagery and arising compassionate feelings. This therapist-introduced accessible adaptation omits required imagery/breathing/feeling shift and compulsory writing; not exact CCI sequence or validated isolated app."
    },
    {
      "url": "https://self-compassion.org/exercises/exercise-3-exploring-self-compassion-through-writing/",
      "reviewed": "2026-11-02",
      "supports": "Author-origin corroboration: letter perspective and rereading, not only listing kind statements.",
      "limits": "Source uses imaginary-friend imagery and expected soothing; neither is required in this bounded adaptation. No copied exercise or equivalence claim."
    }
  ],
  "productAdaptations": [
    "Original Lee/Robin examples and concise composition/review prompts; no copied worksheet.",
    "Optional private verbal rehearsal and neutral respectful language preserve the caring-response aim but are adaptations, not proof of equivalent learning outcomes.",
    "Existing tool/friend-test remains related brief material; no relabeling as this letter."
  ],
  "narrationSegments": [
    {
      "id": "compassion-letter.intro",
      "title": "Write to yourself without taking the critic’s side",
      "text": "A compassionate letter acknowledges a difficulty and responds with care and perspective. It can be short and plain. It does not need to sound positive or make you feel warm.\n\nYou can write here, use your own paper, or compose the words privately. Privately trying the wording is an accessible rehearsal, not a saved written letter. Reading the example is also welcome.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.fit",
      "title": "Choose a manageable subject",
      "text": "Use this with your therapist between sessions. Choose a recent ordinary difficulty or the fictional example, not your most painful memory.\n\nYou do not need to imagine a caregiver, recall a safe place, change your breathing, forgive anyone or excuse harm. If compassionate language brings shame, grief or threat, use neutral respectful words, pause, or discuss the fit with your therapist. Support does not have to wait until you finish.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.learn",
      "title": "Why use a letter?",
      "text": "Self-criticism can turn a specific difficulty into a verdict about the whole person. A letter makes room to describe what hurts without adding that verdict.\n\nThe method has three parts: acknowledge the difficulty, offer a realistic caring perspective, and consider what support or response might fit. Join these into a message to yourself, then read or privately hear it. That final reading lets you check whether the words actually feel credible, rather than simply collecting kind phrases.\n\nCare and responsibility can coexist. You can recognise a mistake and consider repair without using insults. A letter does not decide disputed facts or require an action plan.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.example",
      "title": "Example — a missed message",
      "text": "Lee forgot to reply to a friend and thinks, “I’m a terrible friend.” Lee writes a short letter:\n\n“Lee, you feel upset that your friend was left waiting. You care about being dependable. Missing this message is something specific to acknowledge; it is not the whole story of how you treat people. You can offer a brief apology if that fits, without promising never to miss anything again. You also deserve a respectful response from yourself while you work out what to do.”\n\nLee reads it and finds “deserve” awkward. Lee changes the last sentence to “Insulting yourself is not required to take responsibility.” Guilt remains, but the revised letter sounds more believable. Lee stops there; sending an apology is a separate decision, not completion of this exercise.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.scenario",
      "title": "Optional fictional practice — Robin",
      "text": "Robin did not finish an ordinary personal project and says, “I never do anything properly.” Robin had less time than expected and still cares about the project.\n\nTry a short letter that takes the disappointment seriously without making a global judgment or insisting Robin finish today. You can also use your own manageable example or just read.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.acknowledge",
      "title": "Acknowledge what is difficult",
      "text": "Address yourself by name, say “Dear me,” or leave out a greeting. Describe the specific difficulty and what is hard about it, without making a verdict about your worth.\n\nOne or two sentences are enough. Keep details private if you prefer.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.acknowledge.help",
      "title": "If this sounds like self-pity",
      "text": "Acknowledging pain does not exaggerate it or deny anyone else’s experience. Plain description is enough.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.perspective",
      "title": "Offer a credible caring perspective",
      "text": "What context would a respectful, well-informed response include? Recognise limits, effort, needs or a specific mistake without pretending it does not matter.\n\nUse words you can stand behind. You do not need praise, “everyone does this,” or a promise it will work out.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.perspective.help",
      "title": "If kind words feel false",
      "text": "Try neutral fairness: “This is a specific difficulty, not a complete description of me.” Change or reject that sentence if it does not fit.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.response",
      "title": "Consider care or support",
      "text": "What might a caring response offer here: understanding, a boundary, rest, support, or a possible repair? You can leave the next step undecided.\n\nAdd a closing sentence in your own voice. This is a letter, not a demand to earn kindness by doing something.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.response.help",
      "title": "For Robin’s example",
      "text": "A possible response recognises the time limit and disappointment, without calling Robin lazy. It could offer a pause before deciding whether to resize the project. That is one possible response, not the correct answer.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.review",
      "title": "Read it as a whole",
      "text": "If you made a letter, read it once or privately hear the sentences together. Does it acknowledge the difficulty and speak respectfully without making claims you do not believe?\n\nChange a sentence, keep it, or leave it unfinished. Notice the fit, not whether you feel better. If you only read the example, you can finish without claiming to have written or rehearsed a letter.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.practice.review.help",
      "title": "If it still sounds critical",
      "text": "Notice any hidden “should” or demand. You can soften that, use a neutral sentence, stop, or bring the unfinished letter to a therapist.",
      "status": "Script only"
    },
    {
      "id": "compassion-letter.close",
      "title": "The letter can stay unfinished",
      "text": "You can finish whether the words feel helpful, awkward or unchanged. No action or feeling is required. This page does not save your letter; use your own private record if you want to keep one.",
      "status": "Script only"
    },
    {
      "id": "compassion.privacy",
      "title": "Your writing is optional",
      "text": "You can think privately, use your own paper, or write here. Notes stay only in this open tool. Reading an example or Learn more, going Back, or changing practice mode keeps them.\n\nLeaving this tool, reloading, clearing or starting again removes your notes. Nothing is sent to your therapist or used for narration. This tool is not monitored and does not save a diary or send reminders.",
      "status": "Script only"
    }
  ]
}
;
